From Dr. Okafor on Monday. She opens a telehealth chat, closes it, opens again, and from then on every status change comes twice, read receipts too, few rounds later three, four. Dashboard showed dozens of channels from her browser, chats closed hours ago. telehealthChatService in features/telehealth/api only remembers the messages channel of a session, status and read status ones are never written down, so unsubscribe drops one of three, unsubscribeAll too. Close a chat, all its channels go and get forgotten, other sessions keep theirs, closing everything the same. Open the same chat again and old channels get swapped out, not piled up, whichever subscribes first.

Also reopens while the chat is open, didn't expect that. useTelehealthChat hook in features/telehealth/hooks resubscribes on every render, each keystroke takes all three down and up, message arriving right then is gone. Open once, keep them while the chat is open, callbacks as now.

Then I counted. Messages page with one chat open, seven channels in dashboard, the chat's three, one for its message list, two for the session list, one the page holds for sessions. Other four do the same dance, new one with a number on the end on every redraw, click a chat in the list, its channel goes and comes back. Seven while I'm there, three once the chat closes, zero after I leave.

Popout is worse. Pop out the chat you're looking at, the page one stops getting messages, close popout and neither does. Both should keep getting everything, only when both are shut do the channels go. No doubling, three channels for that chat, not six.

Also chat text in browser console, service prints piece of every message when it arrives, plus subscription status. Patient data, stop printing it. Tests please, there are none.
