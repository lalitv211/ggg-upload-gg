import { describe, it, expect, vi, afterEach } from 'vitest';

// A tiny hooks runtime: runs one hook function outside a renderer, re-rendering on state changes,
// running effects (and their cleanups) the way React orders them for a single component.
const rt = vi.hoisted(() => {
  const state: any = { cells: [], idx: 0, pending: [], hook: undefined, dirty: false, result: undefined };
  const same = (a: any, b: any) =>
    Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((v: any, i: number) => Object.is(v, b[i]));
  const schedule = () => {
    state.dirty = true;
  };
  const cell = (init: () => any) => {
    const i = state.idx++;
    if (!(i in state.cells)) state.cells[i] = init();
    return state.cells[i];
  };
  const effect = (fn: any, deps: any) => {
    const i = state.idx++;
    const prev = state.cells[i];
    const changed = !prev || !deps || !prev.deps || !same(deps, prev.deps);
    if (!prev) state.cells[i] = { deps, cleanup: undefined, effect: true };
    else prev.deps = deps;
    if (changed) state.pending.push({ i, fn });
  };
  const hooks: any = {
    useState(init: any) {
      const c = cell(() => ({ v: typeof init === 'function' ? init() : init }));
      const set = (nv: any) => {
        const next = typeof nv === 'function' ? nv(c.v) : nv;
        if (!Object.is(next, c.v)) {
          c.v = next;
          schedule();
        }
      };
      return [c.v, set];
    },
    useReducer(red: any, init: any, initf?: any) {
      const c = cell(() => ({ v: initf ? initf(init) : init }));
      const dispatch = (a: any) => {
        const next = red(c.v, a);
        if (!Object.is(next, c.v)) {
          c.v = next;
          schedule();
        }
      };
      return [c.v, dispatch];
    },
    useRef(init: any) {
      return cell(() => ({ current: init }));
    },
    useEffect: effect,
    useLayoutEffect: effect,
    useInsertionEffect: effect,
    useMemo(f: any, deps: any) {
      const i = state.idx++;
      const prev = state.cells[i];
      if (prev && same(deps, prev.deps)) return prev.v;
      const v = f();
      state.cells[i] = { v, deps };
      return v;
    },
    useCallback(fn: any, deps: any) {
      return hooks.useMemo(() => fn, deps);
    },
    useId() {
      return cell(() => 'id-' + Math.random().toString(36).slice(2));
    },
    useContext(ctx: any) {
      return ctx?._currentValue;
    },
    useDebugValue() {},
    useTransition() {
      return [false, (fn: any) => fn()];
    },
    useDeferredValue(v: any) {
      return v;
    },
    useSyncExternalStore(subscribe: any, getSnapshot: any) {
      cell(() => ({ unsub: subscribe(() => schedule()) }));
      return getSnapshot();
    },
  };
  const flush = () => {
    const pending = state.pending;
    state.pending = [];
    for (const e of pending) {
      const c = state.cells[e.i];
      if (typeof c.cleanup === 'function') c.cleanup();
      const r = e.fn();
      c.cleanup = typeof r === 'function' ? r : undefined;
    }
  };
  const render = (props: any) => {
    let guard = 0;
    do {
      state.dirty = false;
      state.idx = 0;
      state.pending = [];
      state.result = state.hook(props);
      flush();
    } while (state.dirty && ++guard < 20);
    return state.result;
  };
  return {
    hooks,
    mount(hook: any, props: any) {
      state.cells = [];
      state.hook = hook;
      return render(props);
    },
    rerender(props: any) {
      return render(props);
    },
    unmount() {
      for (const c of state.cells) {
        if (c && typeof c.cleanup === 'function') {
          c.cleanup();
          c.cleanup = undefined;
        }
      }
      state.cells = [];
    },
  };
});

vi.mock('react', async (importOriginal) => {
  const actual: any = await importOriginal();
  return { ...actual, ...rt.hooks, default: { ...actual.default, ...rt.hooks } };
});

vi.mock('@/lib/supabaseClient', () => {
  const live = new Set<any>();
  const all: any[] = [];
  const make = (name: string) => {
    const ch: any = {
      name,
      alive: true,
      handlers: [] as any[],
      on(type: string, opts: any, cb: any) {
        ch.handlers.push({ type, ...(opts || {}), cb });
        return ch;
      },
      subscribe(cb?: any) {
        if (typeof cb === 'function') cb('SUBSCRIBED');
        return ch;
      },
      unsubscribe() {
        ch.alive = false;
        live.delete(ch);
        return Promise.resolve('ok');
      },
    };
    return ch;
  };
  const supabase = {
    channel(name: string) {
      const ch = make(name);
      live.add(ch);
      all.push(ch);
      return ch;
    },
    removeChannel(ch: any) {
      if (ch) {
        ch.alive = false;
        live.delete(ch);
      }
      return Promise.resolve('ok');
    },
    removeAllChannels() {
      for (const ch of live) ch.alive = false;
      live.clear();
      return Promise.resolve([]);
    },
    getChannels() {
      return [...live];
    },
  };
  const __reset = () => {
    live.clear();
    all.length = 0;
  };
  return { supabase, __live: live, __all: all, __reset };
});


const kindOf = (ch: any): string => {
  const h = ch.handlers[0];
  if (!h) return 'foreign';
  if (h.table === 'telehealth_sessions') return 'status';
  if (h.table === 'telehealth_messages' && h.event === 'INSERT') return 'messages';
  if (h.table === 'telehealth_messages') return 'read';
  return 'other';
};
const sessionOf = (ch: any): string => {
  const m = /eq\.(.+)$/.exec(String(ch.handlers[0]?.filter || ''));
  return m ? m[1] : '';
};

async function load() {
  vi.resetModules();
  const sb: any = await import('@/lib/supabaseClient');
  sb.__reset();
  const mod: any = await import('@/features/telehealth/hooks/useTelehealthChat');
  const live = (): any[] => [...sb.__live];
  const liveOf = (session: string, kind?: string) =>
    live().filter((c) => sessionOf(c) === session && (!kind || kindOf(c) === kind));
  const fire = (kind: string, session: string, payload: any) =>
    liveOf(session, kind).forEach((ch) => ch.handlers.forEach((h: any) => h.cb(payload)));
  // The page's chat and a popout window of the same chat, drawn in one pass: two hook instances.
  const heard = { page: [] as string[], popout: [] as string[] };
  const two = (p: { page: string | null; popout: string | null }) => {
    mod.useTelehealthChat({
      sessionId: p.page,
      onNewMessage: (m: any) => heard.page.push('msg:' + m.id),
      onStatusChange: (s: any) => heard.page.push('status:' + s),
      onReadUpdate: (m: any) => heard.page.push('read:' + m.id),
    });
    mod.useTelehealthChat({
      sessionId: p.popout,
      onNewMessage: (m: any) => heard.popout.push('msg:' + m.id),
      onStatusChange: (s: any) => heard.popout.push('status:' + s),
      onReadUpdate: (m: any) => heard.popout.push('read:' + m.id),
    });
    return null;
  };
  return { sb, live, liveOf, fire, heard, two, close: rt.unmount };
}

afterEach(() => {
  rt.unmount();
  vi.restoreAllMocks();
});

describe('a popout of the chat on the page shares its channels', () => {
  it('both views hear a new message', async () => {
    const t = await load();
    rt.mount(t.two, { page: 's1', popout: 's1' });
    t.fire('messages', 's1', { eventType: 'INSERT', new: { id: 'm1', session_id: 's1', content: 'x' } });
    expect(t.heard.page).toEqual(['msg:m1']);
    expect(t.heard.popout).toEqual(['msg:m1']);
  });

  it('both views hear a status change and a read update', async () => {
    const t = await load();
    rt.mount(t.two, { page: 's1', popout: 's1' });
    t.fire('status', 's1', { eventType: 'UPDATE', new: { id: 's1', status: 'completed' } });
    t.fire('read', 's1', { eventType: 'UPDATE', new: { id: 'm1', session_id: 's1', is_read: true } });
    expect(t.heard.page).toEqual(['status:completed', 'read:m1']);
    expect(t.heard.popout).toEqual(['status:completed', 'read:m1']);
  });

  it('the popout does not double the three channels of the session', async () => {
    const t = await load();
    rt.mount(t.two, { page: 's1', popout: 's1' });
    expect(t.liveOf('s1').length).toBe(3);
    expect(t.liveOf('s1').map(kindOf).sort()).toEqual(['messages', 'read', 'status']);
  });

  it('closing the popout leaves the page chat hearing status changes', async () => {
    const t = await load();
    rt.mount(t.two, { page: 's1', popout: 's1' });
    rt.rerender({ page: 's1', popout: null });
    t.fire('status', 's1', { eventType: 'UPDATE', new: { id: 's1', status: 'completed' } });
    expect(t.heard.page).toEqual(['status:completed']);
    expect(t.liveOf('s1').length).toBe(3);
  });

  it('closing the page chat leaves the popout hearing', async () => {
    const t = await load();
    rt.mount(t.two, { page: 's1', popout: 's1' });
    rt.rerender({ page: null, popout: 's1' });
    t.fire('messages', 's1', { eventType: 'INSERT', new: { id: 'm3', session_id: 's1', content: 'x' } });
    expect(t.heard.popout).toEqual(['msg:m3']);
    expect(t.liveOf('s1').length).toBe(3);
  });

  it('closing both leaves nothing of the session', async () => {
    const t = await load();
    rt.mount(t.two, { page: 's1', popout: 's1' });
    rt.rerender({ page: 's1', popout: null });
    rt.rerender({ page: null, popout: null });
    expect(t.liveOf('s1')).toEqual([]);
  });

  it('a popout of another chat keeps its own three', async () => {
    const t = await load();
    rt.mount(t.two, { page: 's1', popout: 's2' });
    expect(t.liveOf('s1').length).toBe(3);
    expect(t.liveOf('s2').length).toBe(3);
    rt.rerender({ page: 's1', popout: null });
    expect(t.liveOf('s2')).toEqual([]);
    expect(t.liveOf('s1').length).toBe(3);
  });
});
