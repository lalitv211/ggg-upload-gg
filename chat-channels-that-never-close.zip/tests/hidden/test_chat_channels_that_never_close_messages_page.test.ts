import { describe, it, expect, vi, afterEach } from 'vitest';

// A small tree renderer: runs the real Messages page and every function component under it,
// each with its own hook state, unmounting components that leave the tree and running effects
// (cleanups first, then the new effects) after each pass, the way React commits.
const rt = vi.hoisted(() => {
  const ELEMENT = Symbol.for('react.element');
  const FORWARD_REF = Symbol.for('react.forward_ref');
  const MEMO = Symbol.for('react.memo');
  const PROVIDER = Symbol.for('react.provider');
  const CONTEXT = Symbol.for('react.context');
  const PORTAL = Symbol.for('react.portal');
  const LAZY = Symbol.for('react.lazy');
  const state: any = {
    insts: new Map<string, any>(),
    cur: null,
    idx: 0,
    order: [] as any[],
    ctx: new Map<any, any>(),
    dirty: false,
    root: null,
    rootProps: {},
  };
  const ids = new WeakMap<any, number>();
  let nextId = 1;
  const idOf = (fn: any) => {
    if (!ids.has(fn)) ids.set(fn, nextId++);
    return ids.get(fn);
  };
  const same = (a: any, b: any) =>
    Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((v: any, i: number) => Object.is(v, b[i]));
  const cell = (init: () => any) => {
    const inst = state.cur;
    if (!inst) throw new Error('hook called outside a component');
    const i = state.idx++;
    if (!(i in inst.cells)) inst.cells[i] = init();
    return inst.cells[i];
  };
  const effect = (fn: any, deps: any) => {
    const inst = state.cur;
    const i = state.idx++;
    const prev = inst.cells[i];
    const changed = !prev || !deps || !prev.deps || !same(deps, prev.deps);
    if (!prev) inst.cells[i] = { deps, cleanup: undefined, effect: true };
    else prev.deps = deps;
    if (changed) inst.pending.push({ i, fn });
  };
  const hooks: any = {
    useState(init: any) {
      const c = cell(() => {
        const s: any = { v: typeof init === 'function' ? init() : init };
        s.set = (nv: any) => {
          const next = typeof nv === 'function' ? nv(s.v) : nv;
          if (!Object.is(next, s.v)) {
            s.v = next;
            state.dirty = true;
          }
        };
        return s;
      });
      return [c.v, c.set];
    },
    useReducer(red: any, init: any, initf?: any) {
      const c = cell(() => {
        const s: any = { v: initf ? initf(init) : init };
        s.dispatch = (a: any) => {
          const next = red(s.v, a);
          if (!Object.is(next, s.v)) {
            s.v = next;
            state.dirty = true;
          }
        };
        return s;
      });
      return [c.v, c.dispatch];
    },
    useRef(init: any) {
      return cell(() => ({ current: init }));
    },
    useEffect: effect,
    useLayoutEffect: effect,
    useInsertionEffect: effect,
    useMemo(f: any, deps: any) {
      const inst = state.cur;
      const i = state.idx++;
      const prev = inst.cells[i];
      if (prev && same(deps, prev.deps)) return prev.v;
      const v = f();
      inst.cells[i] = { v, deps };
      return v;
    },
    useCallback(fn: any, deps: any) {
      return hooks.useMemo(() => fn, deps);
    },
    useId() {
      return cell(() => ({ v: 'id-' + Math.random().toString(36).slice(2) })).v;
    },
    useContext(ctx: any) {
      return state.ctx.has(ctx) ? state.ctx.get(ctx) : ctx?._currentValue;
    },
    useImperativeHandle() {},
    useDebugValue() {},
    useTransition() {
      return [false, (fn: any) => fn()];
    },
    useDeferredValue(v: any) {
      return v;
    },
    useSyncExternalStore(subscribe: any, getSnapshot: any) {
      cell(() => ({ unsub: subscribe(() => (state.dirty = true)) }));
      return getSnapshot();
    },
  };
  const component = (fn: any, props: any, path: string) => {
    const key = path + '#' + idOf(fn);
    let inst = state.insts.get(key);
    if (!inst) {
      inst = { cells: [], pending: [], seen: false };
      state.insts.set(key, inst);
    }
    inst.seen = true;
    const saved = [state.cur, state.idx];
    state.cur = inst;
    state.idx = 0;
    let out: any;
    try {
      out = fn(props);
    } finally {
      [state.cur, state.idx] = saved;
    }
    walk(out, key);
    state.order.push(inst);
  };
  const walk = (node: any, path: string): void => {
    if (node === null || node === undefined || typeof node === 'boolean') return;
    if (typeof node === 'string' || typeof node === 'number') return;
    if (Array.isArray(node)) {
      node.forEach((c, i) => walk(c, path + '.' + (c && c.key != null ? 'k' + c.key : i)));
      return;
    }
    if (node.$$typeof === PORTAL) return walk(node.children, path + '/portal');
    if (node.$$typeof !== ELEMENT) return;
    const t = node.type;
    const props = node.props || {};
    if (typeof t === 'function') {
      if (t.prototype && t.prototype.isReactComponent) throw new Error('class components are not supported');
      return component(t, props, path);
    }
    if (t && typeof t === 'object') {
      if (t.$$typeof === FORWARD_REF) return component((p: any) => t.render(p, node.ref ?? null), props, path + '/fr' + idOf(t));
      if (t.$$typeof === MEMO) return walk({ ...node, type: t.type }, path + '/memo');
      if (t.$$typeof === PROVIDER) {
        const ctx = t._context;
        const had = state.ctx.has(ctx);
        const prev = state.ctx.get(ctx);
        state.ctx.set(ctx, props.value);
        try {
          walk(props.children, path + '/provider');
        } finally {
          if (had) state.ctx.set(ctx, prev);
          else state.ctx.delete(ctx);
        }
        return;
      }
      if (t.$$typeof === CONTEXT) {
        const v = state.ctx.has(t) ? state.ctx.get(t) : t._currentValue;
        return walk(typeof props.children === 'function' ? props.children(v) : null, path + '/consumer');
      }
      if (t.$$typeof === LAZY) throw new Error('lazy components are not supported');
    }
    // host elements, fragments and other built-ins: only their children render
    walk(props.children, path + '/' + (typeof t === 'string' ? t : 'f'));
  };
  const cleanupAll = (inst: any) => {
    for (const c of inst.cells) {
      if (c && c.effect && typeof c.cleanup === 'function') {
        const f = c.cleanup;
        c.cleanup = undefined;
        f();
      }
    }
  };
  const pass = () => {
    for (const inst of state.insts.values()) {
      inst.seen = false;
      inst.pending = [];
    }
    state.order = [];
    walk({ $$typeof: ELEMENT, type: state.root, props: state.rootProps, key: null, ref: null }, 'root');
    for (const [k, inst] of [...state.insts.entries()]) {
      if (!inst.seen) {
        cleanupAll(inst);
        state.insts.delete(k);
      }
    }
    for (const inst of state.order) {
      for (const e of inst.pending) {
        const c = inst.cells[e.i];
        if (typeof c.cleanup === 'function') {
          const f = c.cleanup;
          c.cleanup = undefined;
          f();
        }
      }
    }
    for (const inst of state.order) {
      for (const e of inst.pending) {
        const r = e.fn();
        inst.cells[e.i].cleanup = typeof r === 'function' ? r : undefined;
      }
      inst.pending = [];
    }
  };
  const render = () => {
    let guard = 0;
    do {
      state.dirty = false;
      pass();
    } while (state.dirty && ++guard < 30);
  };
  return {
    hooks,
    mount(root: any, props: any = {}) {
      state.insts = new Map();
      state.root = root;
      state.rootProps = props;
      render();
    },
    rerender(props?: any) {
      if (props) state.rootProps = props;
      render();
    },
    unmount() {
      for (const inst of state.insts.values()) cleanupAll(inst);
      state.insts = new Map();
      state.root = null;
    },
  };
});

vi.mock('react', async (importOriginal) => {
  const actual: any = await importOriginal();
  return { ...actual, ...rt.hooks, default: { ...actual.default, ...rt.hooks } };
});

vi.mock('@/lib/supabaseClient', () => {
  const live = new Set<any>();
  const all: any[] = [];
  const make = (name: string) => {
    const ch: any = {
      name,
      alive: true,
      handlers: [] as any[],
      on(type: string, opts: any, cb: any) {
        ch.handlers.push({ type, ...(opts || {}), cb });
        return ch;
      },
      subscribe(cb?: any) {
        if (typeof cb === 'function') cb('SUBSCRIBED');
        return ch;
      },
      unsubscribe() {
        ch.alive = false;
        live.delete(ch);
        return Promise.resolve('ok');
      },
    };
    return ch;
  };
  const supabase = {
    channel(name: string) {
      const ch = make(name);
      live.add(ch);
      all.push(ch);
      return ch;
    },
    removeChannel(ch: any) {
      if (ch) {
        ch.alive = false;
        live.delete(ch);
      }
      return Promise.resolve('ok');
    },
    removeAllChannels() {
      for (const ch of live) ch.alive = false;
      live.clear();
      return Promise.resolve([]);
    },
    getChannels() {
      return [...live];
    },
  };
  const __reset = () => {
    live.clear();
    all.length = 0;
  };
  return { supabase, __live: live, __all: all, __reset };
});

// The route the page reads, and a navigate that moves it.
const route = vi.hoisted(() => ({ params: {} as Record<string, string>, moved: false }));
vi.mock('react-router-dom', () => {
  const navigate = (to: any) => {
    const m = /\/message\/([^/?#]+)/.exec(String(to));
    route.params = m ? { sessionId: m[1] } : {};
    route.moved = true;
  };
  const pass = (p: any) => (p && p.children) ?? null;
  return {
    useParams: () => ({ ...route.params }),
    useNavigate: () => navigate,
    useLocation: () => ({ pathname: route.params.sessionId ? `/message/${route.params.sessionId}` : '/message', search: '', hash: '', state: null }),
    useSearchParams: () => [new URLSearchParams(), () => undefined],
    Link: pass,
    NavLink: pass,
    Navigate: () => null,
    Outlet: () => null,
  };
});

// The UI kit and the icons draw nothing here; only the realtime channels are observed.
const stubModule = (make: (name: string) => any) =>
  new Proxy(
    {},
    {
      get: (_t, name) => {
        if (typeof name !== 'string' || name === 'then') return undefined;
        if (name === '__esModule') return true;
        return make(name);
      },
      has: (_t, name) => typeof name === 'string' && name !== 'then',
    }
  );
vi.mock('@/components/common/shadcn', () => stubModule(() => (p: any) => (p && p.children) ?? null));
vi.mock('lucide-react', () => stubModule(() => () => null));
vi.mock('@/lib/utils', async (importOriginal) => {
  const actual: any = await importOriginal();
  return { ...actual, roleCheck: () => true };
});

const session = (id: string): any => ({
  id,
  status: 'in_progress',
  client_id: 'cl1',
  vet_id: 'v1',
  pet_id: 'p1',
  consultation_type: 'chat',
  pet: { id: 'p1', name: 'Fluffy' },
  client: { id: 'cl1', user: { full_name: 'Casey Client' } },
  scheduled_time: '2021-03-15T10:00:00.000Z',
  created_at: '2021-03-15T09:00:00.000Z',
  updated_at: '2021-03-15T09:00:00.000Z',
  unread_count: 0,
});
const data = vi.hoisted(() => ({ sessions: [] as any[], empty: [] as any[] }));
vi.mock('@tanstack/react-query', () => {
  const client = {
    invalidateQueries: () => Promise.resolve(),
    setQueryData: () => undefined,
    getQueryData: () => undefined,
    cancelQueries: () => Promise.resolve(),
  };
  const result = (d: any) => ({ data: d, isLoading: false, isError: false, error: null, refetch: () => Promise.resolve() });
  return {
    useQueryClient: () => client,
    useQuery: (opts: any) => {
      const key: any[] = Array.isArray(opts?.queryKey) ? opts.queryKey : [];
      if (key.includes('sessions') && key.length === 2) return result(data.sessions);
      if (key.includes('sessions') && key.length === 3) return result(data.sessions.find((s) => s.id === key[2]) ?? null);
      return result(data.empty);
    },
    useMutation: () => ({ mutate: () => undefined, mutateAsync: () => Promise.resolve({ success: true }), isPending: false }),
    QueryClient: class {},
  };
});
vi.mock('@/hooks/useNotification', () => ({ useNotification: () => ({ showNotification: () => undefined }) }));
vi.mock('@/hooks/useAuth', () => ({
  useAuth: () => ({ user: { _uuid: 'v1', id: 'v1', role: 'veterinarian', clinic_id: 'c1', role_isDefault: true } }),
}));

const filterOf = (ch: any): string => String(ch.handlers[0]?.filter || '');
const sessionOf = (ch: any): string => {
  const m = /eq\.(.+)$/.exec(filterOf(ch));
  return m ? m[1] : '';
};
// channels on the session list as a whole (no row filter): the page's, the list's and its hook's
const sessionWide = (ch: any) => ch.handlers[0]?.table === 'telehealth_sessions' && !ch.handlers[0]?.filter;

async function load(at: string | null) {
  vi.resetModules();
  data.sessions = [session('s1'), session('s2')];
  route.params = at ? { sessionId: at } : {};
  route.moved = false;
  const sb: any = await import('@/lib/supabaseClient');
  sb.__reset();
  const page: any = await import('@/pages/telehealth/MessagesPage');
  const live = (): any[] => [...sb.__live];
  const all = (): any[] => [...sb.__all];
  const go = (to: string | null) => {
    route.params = to ? { sessionId: to } : {};
    rt.rerender();
  };
  rt.mount(page.default, {});
  return { live, all, go, redraw: () => rt.rerender(), leave: () => rt.unmount() };
}

afterEach(() => {
  rt.unmount();
  vi.restoreAllMocks();
});

describe('the real Messages page', () => {
  it('with one chat open the page holds seven channels', async () => {
    const t = await load('s1');
    expect(t.live().length).toBe(7);
    expect(t.live().filter((c) => sessionOf(c) === 's1').length).toBe(4);
    expect(t.live().filter(sessionWide).length).toBe(3);
  });

  it('redrawing the page opens no channel anywhere', async () => {
    const t = await load('s1');
    t.redraw();
    t.redraw();
    t.redraw();
    expect(t.all().length).toBe(7);
    expect(t.live().length).toBe(7);
  });

  it('closing the chat leaves the page with three channels', async () => {
    const t = await load('s1');
    t.go(null);
    expect(t.live().length).toBe(3);
    expect(t.live().filter(sessionWide).length).toBe(3);
    expect(t.live().filter((c) => sessionOf(c) === 's1')).toEqual([]);
  });

  it("clicking another chat moves only the chat's channels", async () => {
    const t = await load('s1');
    t.go('s2');
    t.redraw();
    expect(t.live().length).toBe(7);
    expect(t.live().filter((c) => sessionOf(c) === 's1')).toEqual([]);
    expect(t.live().filter((c) => sessionOf(c) === 's2').length).toBe(4);
    expect(t.all().filter(sessionWide).length).toBe(3);
  });

  it('leaving the page closes every channel', async () => {
    const t = await load('s1');
    t.redraw();
    t.leave();
    expect(t.live()).toEqual([]);
  });
});
