import { describe, it, expect, vi, afterEach } from 'vitest';

// A tiny hooks runtime: runs one hook function outside a renderer, re-rendering on state changes,
// running effects (and their cleanups) the way React orders them for a single component.
const rt = vi.hoisted(() => {
  const state: any = { cells: [], idx: 0, pending: [], hook: undefined, dirty: false, result: undefined };
  const same = (a: any, b: any) =>
    Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((v: any, i: number) => Object.is(v, b[i]));
  const schedule = () => {
    state.dirty = true;
  };
  const cell = (init: () => any) => {
    const i = state.idx++;
    if (!(i in state.cells)) state.cells[i] = init();
    return state.cells[i];
  };
  const effect = (fn: any, deps: any) => {
    const i = state.idx++;
    const prev = state.cells[i];
    const changed = !prev || !deps || !prev.deps || !same(deps, prev.deps);
    if (!prev) state.cells[i] = { deps, cleanup: undefined, effect: true };
    else prev.deps = deps;
    if (changed) state.pending.push({ i, fn });
  };
  const hooks: any = {
    useState(init: any) {
      const c = cell(() => ({ v: typeof init === 'function' ? init() : init }));
      const set = (nv: any) => {
        const next = typeof nv === 'function' ? nv(c.v) : nv;
        if (!Object.is(next, c.v)) {
          c.v = next;
          schedule();
        }
      };
      return [c.v, set];
    },
    useReducer(red: any, init: any, initf?: any) {
      const c = cell(() => ({ v: initf ? initf(init) : init }));
      const dispatch = (a: any) => {
        const next = red(c.v, a);
        if (!Object.is(next, c.v)) {
          c.v = next;
          schedule();
        }
      };
      return [c.v, dispatch];
    },
    useRef(init: any) {
      return cell(() => ({ current: init }));
    },
    useEffect: effect,
    useLayoutEffect: effect,
    useInsertionEffect: effect,
    useMemo(f: any, deps: any) {
      const i = state.idx++;
      const prev = state.cells[i];
      if (prev && same(deps, prev.deps)) return prev.v;
      const v = f();
      state.cells[i] = { v, deps };
      return v;
    },
    useCallback(fn: any, deps: any) {
      return hooks.useMemo(() => fn, deps);
    },
    useId() {
      return cell(() => 'id-' + Math.random().toString(36).slice(2));
    },
    useContext(ctx: any) {
      return ctx?._currentValue;
    },
    useDebugValue() {},
    useTransition() {
      return [false, (fn: any) => fn()];
    },
    useDeferredValue(v: any) {
      return v;
    },
    useSyncExternalStore(subscribe: any, getSnapshot: any) {
      cell(() => ({ unsub: subscribe(() => schedule()) }));
      return getSnapshot();
    },
  };
  const flush = () => {
    const pending = state.pending;
    state.pending = [];
    for (const e of pending) {
      const c = state.cells[e.i];
      if (typeof c.cleanup === 'function') c.cleanup();
      const r = e.fn();
      c.cleanup = typeof r === 'function' ? r : undefined;
    }
  };
  const render = (props: any) => {
    let guard = 0;
    do {
      state.dirty = false;
      state.idx = 0;
      state.pending = [];
      state.result = state.hook(props);
      flush();
    } while (state.dirty && ++guard < 20);
    return state.result;
  };
  return {
    hooks,
    mount(hook: any, props: any) {
      state.cells = [];
      state.hook = hook;
      return render(props);
    },
    rerender(props: any) {
      return render(props);
    },
    unmount() {
      for (const c of state.cells) {
        if (c && typeof c.cleanup === 'function') {
          c.cleanup();
          c.cleanup = undefined;
        }
      }
      state.cells = [];
    },
  };
});

vi.mock('react', async (importOriginal) => {
  const actual: any = await importOriginal();
  return { ...actual, ...rt.hooks, default: { ...actual.default, ...rt.hooks } };
});

vi.mock('@/lib/supabaseClient', () => {
  const live = new Set<any>();
  const all: any[] = [];
  const make = (name: string) => {
    const ch: any = {
      name,
      alive: true,
      handlers: [] as any[],
      on(type: string, opts: any, cb: any) {
        ch.handlers.push({ type, ...(opts || {}), cb });
        return ch;
      },
      subscribe(cb?: any) {
        if (typeof cb === 'function') cb('SUBSCRIBED');
        return ch;
      },
      unsubscribe() {
        ch.alive = false;
        live.delete(ch);
        return Promise.resolve('ok');
      },
    };
    return ch;
  };
  const supabase = {
    channel(name: string) {
      const ch = make(name);
      live.add(ch);
      all.push(ch);
      return ch;
    },
    removeChannel(ch: any) {
      if (ch) {
        ch.alive = false;
        live.delete(ch);
      }
      return Promise.resolve('ok');
    },
    removeAllChannels() {
      for (const ch of live) ch.alive = false;
      live.clear();
      return Promise.resolve([]);
    },
    getChannels() {
      return [...live];
    },
  };
  const __reset = () => {
    live.clear();
    all.length = 0;
  };
  return { supabase, __live: live, __all: all, __reset };
});

const kindOf = (ch: any): string => {
  const h = ch.handlers[0];
  if (!h) return 'foreign';
  if (h.table === 'telehealth_sessions') return 'status';
  if (h.table === 'telehealth_messages' && h.event === 'INSERT') return 'messages';
  if (h.table === 'telehealth_messages') return 'read';
  return 'other';
};
const sessionOf = (ch: any): string => {
  const m = /eq\.(.+)$/.exec(String(ch.handlers[0]?.filter || ''));
  return m ? m[1] : '';
};

async function load() {
  vi.resetModules();
  const sb: any = await import('@/lib/supabaseClient');
  sb.__reset();
  const mod: any = await import('@/features/telehealth/hooks/useTelehealthChat');
  const live = (): any[] => [...sb.__live];
  const liveOf = (session: string, kind?: string) =>
    live().filter((c) => sessionOf(c) === session && (!kind || kindOf(c) === kind));
  const created = (session: string) => (sb.__all as any[]).filter((c) => sessionOf(c) === session).length;
  const fire = (ch: any, payload: any) => ch.handlers.forEach((h: any) => h.cb(payload));
  const hook = mod.useTelehealthChat;
  const open = (sessionId: string | null, cbs: any = {}) =>
    rt.mount(hook, {
      sessionId,
      onNewMessage: cbs.onNewMessage || ((m: any) => m),
      onStatusChange: cbs.onStatusChange || ((s: any) => s),
      onReadUpdate: cbs.onReadUpdate || ((m: any) => m),
    });
  const again = (sessionId: string | null, cbs: any = {}) =>
    rt.rerender({
      sessionId,
      onNewMessage: cbs.onNewMessage || ((m: any) => m),
      onStatusChange: cbs.onStatusChange || ((s: any) => s),
      onReadUpdate: cbs.onReadUpdate || ((m: any) => m),
    });
  return { sb, live, liveOf, created, fire, open, again, close: rt.unmount };
}

afterEach(() => {
  rt.unmount();
  vi.restoreAllMocks();
});

describe('the chat screen hook keeps working', () => {
  it('opening a chat subscribes its three channels once', async () => {
    const t = await load();
    const r = t.open('s1');
    expect(t.liveOf('s1').length).toBe(3);
    expect(t.created('s1')).toBe(3);
    expect(r.isConnected).toBe(true);
  });

  it('no session means no channel', async () => {
    const t = await load();
    const r = t.open(null);
    expect(t.live()).toEqual([]);
    expect(r.isConnected).toBe(false);
  });

  it('a message that arrives after a re-render reaches the newest callback', async () => {
    const t = await load();
    const first = vi.fn();
    const second = vi.fn();
    t.open('s1', { onNewMessage: first });
    t.again('s1', { onNewMessage: second });
    const msg = { id: 'm1', session_id: 's1', content: 'hello' };
    for (const ch of t.liveOf('s1', 'messages')) t.fire(ch, { new: msg });
    expect(second).toHaveBeenCalledWith(msg);
    expect(first).not.toHaveBeenCalled();
  });


  it('a message reaches the callback given at mount', async () => {
    const t = await load();
    const onNewMessage = vi.fn();
    t.open('s1', { onNewMessage });
    const msg = { id: 'm1', session_id: 's1', content: 'hello' };
    for (const ch of t.liveOf('s1', 'messages')) t.fire(ch, { new: msg });
    expect(onNewMessage).toHaveBeenCalledWith(msg);
  });
});
