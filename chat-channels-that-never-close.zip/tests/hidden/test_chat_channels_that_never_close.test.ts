import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

vi.mock('@/lib/supabaseClient', () => {
  const live = new Set<any>();
  const all: any[] = [];
  const make = (name: string) => {
    const ch: any = {
      name,
      alive: true,
      handlers: [] as any[],
      on(type: string, opts: any, cb: any) {
        ch.handlers.push({ type, ...(opts || {}), cb });
        return ch;
      },
      subscribe(cb?: any) {
        ch.statusCb = cb;
        if (typeof cb === 'function') cb('SUBSCRIBED');
        return ch;
      },
      unsubscribe() {
        ch.alive = false;
        live.delete(ch);
        return Promise.resolve('ok');
      },
    };
    return ch;
  };
  const supabase = {
    channel(name: string) {
      const ch = make(name);
      live.add(ch);
      all.push(ch);
      return ch;
    },
    removeChannel(ch: any) {
      if (ch) {
        ch.alive = false;
        live.delete(ch);
      }
      return Promise.resolve('ok');
    },
    removeAllChannels() {
      for (const ch of live) ch.alive = false;
      live.clear();
      return Promise.resolve([]);
    },
    getChannels() {
      return [...live];
    },
  };
  const __reset = () => {
    live.clear();
    all.length = 0;
  };
  return { supabase, __live: live, __all: all, __reset };
});

type Fake = any;
const kindOf = (ch: Fake): string => {
  const h = ch.handlers[0];
  if (!h) return 'foreign';
  if (h.table === 'telehealth_sessions') return 'status';
  if (h.table === 'telehealth_messages' && h.event === 'INSERT') return 'messages';
  if (h.table === 'telehealth_messages') return 'read';
  return 'other';
};
const sessionOf = (ch: Fake): string => {
  const f = ch.handlers[0]?.filter || '';
  const m = /eq\.(.+)$/.exec(String(f));
  return m ? m[1] : '';
};

async function load() {
  vi.resetModules();
  const sb: any = await import('@/lib/supabaseClient');
  sb.__reset();
  const mod: any = await import('@/features/telehealth/api/telehealthChatService');
  const service = mod.telehealthChatService;
  const live = (): Fake[] => [...sb.__live];
  const liveOf = (session: string, kind?: string) =>
    live().filter((c) => sessionOf(c) === session && (!kind || kindOf(c) === kind));
  const fire = (ch: Fake, payload: any) => ch.handlers.forEach((h: any) => h.cb(payload));
  const openAll = (session: string, cbs: any = {}) => {
    service.subscribeToMessages(session, cbs.onMessage || (() => {}));
    service.subscribeToStatus(session, cbs.onStatus || (() => {}));
    service.subscribeToReadStatus(session, cbs.onRead || (() => {}));
  };
  return { sb, service, live, liveOf, fire, openAll, all: sb.__all as Fake[] };
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe('closing a chat takes every channel of that session down', () => {
  it('no channel of the session is left after unsubscribe', async () => {
    const t = await load();
    t.openAll('s1');
    expect(t.liveOf('s1').length).toBe(3);
    t.service.unsubscribe('s1');
    expect(t.liveOf('s1')).toEqual([]);
  });

  it('the status channel is gone after unsubscribe', async () => {
    const t = await load();
    t.openAll('s1');
    t.service.unsubscribe('s1');
    expect(t.liveOf('s1', 'status')).toEqual([]);
  });

  it('the read receipt channel is gone after unsubscribe', async () => {
    const t = await load();
    t.openAll('s1');
    t.service.unsubscribe('s1');
    expect(t.liveOf('s1', 'read')).toEqual([]);
  });

  it('the channels of another session stay', async () => {
    const t = await load();
    t.openAll('s1');
    t.openAll('s2');
    t.service.unsubscribe('s1');
    expect(t.liveOf('s1')).toEqual([]);
    expect(t.liveOf('s2').length).toBe(3);
  });

  it('a closed chat opened again has exactly one channel per kind', async () => {
    const t = await load();
    t.openAll('s1');
    t.service.unsubscribe('s1');
    t.openAll('s1');
    expect(t.liveOf('s1', 'messages').length).toBe(1);
    expect(t.liveOf('s1', 'status').length).toBe(1);
    expect(t.liveOf('s1', 'read').length).toBe(1);
  });

  it('closing twice in a row leaves nothing and does not throw', async () => {
    const t = await load();
    t.openAll('s1');
    t.service.unsubscribe('s1');
    expect(() => t.service.unsubscribe('s1')).not.toThrow();
    expect(t.liveOf('s1')).toEqual([]);
  });
  it('a closed chat opened again hears each status change once', async () => {
    const t = await load();
    const onStatus = vi.fn();
    t.openAll('s1', { onStatus });
    t.service.unsubscribe('s1');
    t.openAll('s1', { onStatus });
    for (const ch of t.liveOf('s1', 'status')) t.fire(ch, { new: { id: 's1', status: 'closed' } });
    expect(onStatus).toHaveBeenCalledTimes(1);
  });

  it('closing one session after closing everything leaves nothing and does not throw', async () => {
    const t = await load();
    t.openAll('s1');
    t.service.unsubscribeAll();
    expect(() => t.service.unsubscribe('s1')).not.toThrow();
    expect(t.liveOf('s1')).toEqual([]);
  });
});

describe('closing everything takes down every channel the service opened', () => {
  it('two sessions with three channels each are all gone', async () => {
    const t = await load();
    t.openAll('s1');
    t.openAll('s2');
    t.service.unsubscribeAll();
    expect(t.liveOf('s1')).toEqual([]);
    expect(t.liveOf('s2')).toEqual([]);
  });

  it('the status channels are gone after unsubscribeAll', async () => {
    const t = await load();
    t.openAll('s1');
    t.service.unsubscribeAll();
    expect(t.liveOf('s1', 'status')).toEqual([]);
    expect(t.liveOf('s1', 'read')).toEqual([]);
  });

  it('subscribing after unsubscribeAll gives one live channel per kind', async () => {
    const t = await load();
    t.openAll('s1');
    t.service.unsubscribeAll();
    t.openAll('s1');
    expect(t.liveOf('s1', 'status').length).toBe(1);
    expect(t.liveOf('s1', 'read').length).toBe(1);
    expect(t.liveOf('s1', 'messages').length).toBe(1);
  });
});

describe('opening the same chat again replaces the earlier channel of the same kind', () => {
  it('a second status subscription leaves one live status channel', async () => {
    const t = await load();
    t.service.subscribeToStatus('s1', () => {});
    t.service.subscribeToStatus('s1', () => {});
    expect(t.liveOf('s1', 'status').length).toBe(1);
  });

  it('a second read receipt subscription leaves one live read channel', async () => {
    const t = await load();
    t.service.subscribeToReadStatus('s1', () => {});
    t.service.subscribeToReadStatus('s1', () => {});
    expect(t.liveOf('s1', 'read').length).toBe(1);
  });

  it('the replaced status channel is dead', async () => {
    const t = await load();
    const first = t.service.subscribeToStatus('s1', () => {});
    t.service.subscribeToStatus('s1', () => {});
    expect((first as any).alive).toBe(false);
  });

  it('the replaced read receipt channel is dead', async () => {
    const t = await load();
    const first = t.service.subscribeToReadStatus('s1', () => {});
    t.service.subscribeToReadStatus('s1', () => {});
    expect((first as any).alive).toBe(false);
  });

  it('whatever the order, a close after a replace leaves nothing', async () => {
    const t = await load();
    t.service.subscribeToStatus('s1', () => {});
    t.service.subscribeToMessages('s1', () => {});
    t.service.subscribeToReadStatus('s1', () => {});
    t.service.subscribeToStatus('s1', () => {});
    t.service.subscribeToReadStatus('s1', () => {});
    t.service.unsubscribe('s1');
    expect(t.liveOf('s1')).toEqual([]);
  });

  it('only the newest status callback hears a status change', async () => {
    const t = await load();
    const first = vi.fn();
    const second = vi.fn();
    t.service.subscribeToStatus('s1', first);
    t.service.subscribeToStatus('s1', second);
    for (const ch of t.liveOf('s1', 'status')) t.fire(ch, { new: { id: 's1', status: 'closed' } });
    expect(second).toHaveBeenCalledWith('closed');
    expect(first).not.toHaveBeenCalled();
  });

  it('only the newest read callback hears a read update', async () => {
    const t = await load();
    const first = vi.fn();
    const second = vi.fn();
    t.service.subscribeToReadStatus('s1', first);
    t.service.subscribeToReadStatus('s1', second);
    const msg = { id: 'm1', session_id: 's1', is_read: true };
    for (const ch of t.liveOf('s1', 'read')) t.fire(ch, { new: msg });
    expect(second).toHaveBeenCalledWith(msg);
    expect(first).not.toHaveBeenCalled();
  });

  it('a replace in one session leaves the other session untouched', async () => {
    const t = await load();
    t.openAll('s1');
    t.openAll('s2');
    t.service.subscribeToStatus('s1', () => {});
    t.service.subscribeToReadStatus('s1', () => {});
    expect(t.liveOf('s1').length).toBe(3);
    expect(t.liveOf('s2').length).toBe(3);
  });
});

describe('chat text stays out of the console', () => {
  it('an arriving message is not printed by the service', async () => {
    const t = await load();
    const spies = ['log', 'info', 'debug', 'warn', 'error'].map((m) =>
      vi.spyOn(console, m as any).mockImplementation(() => {})
    );
    const onMessage = vi.fn();
    t.service.subscribeToMessages('s1', onMessage);
    const msg = { id: 'm1', session_id: 's1', sender_type: 'client', content: 'Fluffy has a fever since Monday' };
    for (const ch of t.liveOf('s1', 'messages')) t.fire(ch, { new: msg });
    expect(onMessage).toHaveBeenCalledWith(msg);
    const printed = spies.flatMap((s) => s.mock.calls).filter((args) =>
      args.some((a) => JSON.stringify(a ?? '').includes('Fluffy has a fever'))
    );
    expect(printed).toEqual([]);
  });

  it('a message with a long text is not printed in part either', async () => {
    const t = await load();
    const spies = ['log', 'info', 'debug', 'warn', 'error'].map((m) =>
      vi.spyOn(console, m as any).mockImplementation(() => {})
    );
    t.service.subscribeToMessages('s1', () => {});
    const content = 'Owner reports vomiting twice tonight and refuses water, please advise on next steps';
    for (const ch of t.liveOf('s1', 'messages')) t.fire(ch, { new: { id: 'm2', session_id: 's1', content } });
    const printed = spies.flatMap((s) => s.mock.calls).filter((args) =>
      args.some((a) => JSON.stringify(a ?? '').includes('Owner reports vomiting'))
    );
    expect(printed).toEqual([]);
  });
});
