// Prettier and ESLint on the files a change adds or edits under apps/web/src/, against their
// base versions: a file that was formatted stays formatted, a new file is formatted, and no file
// gains ESLint problems (errors or warnings) over its base version. Old problems in lines the change
// did not create are not the change's to fix. Run from the repository root with the change applied
// as uncommitted edits on the base commit.
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';

const repo = execFileSync('git', ['rev-parse', '--show-toplevel'], { encoding: 'utf8' }).trim();
const req = createRequire(path.join(repo, 'package.json'));
const git = (...args) => execFileSync('git', args, { cwd: repo, encoding: 'utf8', maxBuffer: 64 << 20 });
const lines = (s) => s.split('\n').map((l) => l.trim()).filter(Boolean);

const touched = new Set([...lines(git('diff', '--name-only', 'HEAD')), ...lines(git('ls-files', '--others', '--exclude-standard'))]);
const configs = ['eslint.config.mjs', '.prettierrc.json', '.prettierignore', 'apps/web/eslint.config.mjs', 'apps/web/.prettierrc.json'];
const problems = [];
for (const c of configs) if (touched.has(c)) problems.push(`${c}: the change edits a lint or format config`);

const files = [...touched]
  .filter((f) => /^apps\/web\/src\/.+\.(ts|tsx)$/.test(f))
  .filter((f) => !/(^|\/)test_hidden_[^/]*$/.test(f) && !f.includes('/hidden-pristine/'))
  .filter((f) => fs.existsSync(path.join(repo, f)))
  .sort();
const baseText = (f) => {
  try {
    return execFileSync('git', ['show', `HEAD:${f}`], { cwd: repo, encoding: 'utf8', maxBuffer: 64 << 20, stdio: ['ignore', 'pipe', 'ignore'] });
  } catch {
    return null;
  }
};

const prettier = req('prettier');
const { ESLint } = req('eslint');
const eslint = new ESLint({ cwd: repo });
const count = (results) => results.reduce((n, r) => n + r.errorCount + r.warningCount, 0);

for (const f of files) {
  const abs = path.join(repo, f);
  const now = fs.readFileSync(abs, 'utf8');
  const before = baseText(f);

  const info = await prettier.getFileInfo(abs, { ignorePath: path.join(repo, '.prettierignore') });
  if (!info.ignored) {
    const options = { ...((await prettier.resolveConfig(abs)) || {}), filepath: abs };
    const okNow = await prettier.check(now, options);
    const okBefore = before === null ? true : await prettier.check(before, options);
    if (!okNow && okBefore) problems.push(`${f}: not formatted with Prettier (run prettier --write)`);
  }

  if (!(await eslint.isPathIgnored(abs))) {
    const after = await eslint.lintText(now, { filePath: abs });
    const base = before === null ? [] : await eslint.lintText(before, { filePath: abs });
    const a = count(after);
    const b = count(base);
    if (a > b) {
      const seen = new Map();
      for (const m of base.flatMap((r) => r.messages)) seen.set(m.ruleId, (seen.get(m.ruleId) || 0) + 1);
      const fresh = [];
      for (const m of after.flatMap((r) => r.messages)) {
        const left = seen.get(m.ruleId) || 0;
        if (left > 0) seen.set(m.ruleId, left - 1);
        else fresh.push(`${m.line}:${m.column} ${m.ruleId || 'parse'} ${m.message}`);
      }
      problems.push(`${f}: ESLint problems went from ${b} to ${a}\n    ${fresh.slice(0, 12).join('\n    ')}`);
    }
  }
}

console.log(`checked ${files.length} changed file(s) under apps/web/src/`);
if (problems.length) {
  console.log(problems.join('\n'));
  process.exit(1);
}
console.log('no new Prettier or ESLint problems');
