import { describe, it, expect, vi, afterEach } from 'vitest';

// A tiny hooks runtime: runs one hook function outside a renderer, re-rendering on state changes,
// running effects (and their cleanups) the way React orders them for a single component.
const rt = vi.hoisted(() => {
  const state: any = { cells: [], idx: 0, pending: [], hook: undefined, dirty: false, result: undefined };
  const same = (a: any, b: any) =>
    Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((v: any, i: number) => Object.is(v, b[i]));
  const schedule = () => {
    state.dirty = true;
  };
  const cell = (init: () => any) => {
    const i = state.idx++;
    if (!(i in state.cells)) state.cells[i] = init();
    return state.cells[i];
  };
  const effect = (fn: any, deps: any) => {
    const i = state.idx++;
    const prev = state.cells[i];
    const changed = !prev || !deps || !prev.deps || !same(deps, prev.deps);
    if (!prev) state.cells[i] = { deps, cleanup: undefined, effect: true };
    else prev.deps = deps;
    if (changed) state.pending.push({ i, fn });
  };
  const hooks: any = {
    useState(init: any) {
      const c = cell(() => ({ v: typeof init === 'function' ? init() : init }));
      const set = (nv: any) => {
        const next = typeof nv === 'function' ? nv(c.v) : nv;
        if (!Object.is(next, c.v)) {
          c.v = next;
          schedule();
        }
      };
      return [c.v, set];
    },
    useReducer(red: any, init: any, initf?: any) {
      const c = cell(() => ({ v: initf ? initf(init) : init }));
      const dispatch = (a: any) => {
        const next = red(c.v, a);
        if (!Object.is(next, c.v)) {
          c.v = next;
          schedule();
        }
      };
      return [c.v, dispatch];
    },
    useRef(init: any) {
      return cell(() => ({ current: init }));
    },
    useEffect: effect,
    useLayoutEffect: effect,
    useInsertionEffect: effect,
    useMemo(f: any, deps: any) {
      const i = state.idx++;
      const prev = state.cells[i];
      if (prev && same(deps, prev.deps)) return prev.v;
      const v = f();
      state.cells[i] = { v, deps };
      return v;
    },
    useCallback(fn: any, deps: any) {
      return hooks.useMemo(() => fn, deps);
    },
    useId() {
      return cell(() => 'id-' + Math.random().toString(36).slice(2));
    },
    useContext(ctx: any) {
      return ctx?._currentValue;
    },
    useDebugValue() {},
    useTransition() {
      return [false, (fn: any) => fn()];
    },
    useDeferredValue(v: any) {
      return v;
    },
    useSyncExternalStore(subscribe: any, getSnapshot: any) {
      cell(() => ({ unsub: subscribe(() => schedule()) }));
      return getSnapshot();
    },
  };
  const flush = () => {
    const pending = state.pending;
    state.pending = [];
    for (const e of pending) {
      const c = state.cells[e.i];
      if (typeof c.cleanup === 'function') c.cleanup();
      const r = e.fn();
      c.cleanup = typeof r === 'function' ? r : undefined;
    }
  };
  const render = (props: any) => {
    let guard = 0;
    do {
      state.dirty = false;
      state.idx = 0;
      state.pending = [];
      state.result = state.hook(props);
      flush();
    } while (state.dirty && ++guard < 20);
    return state.result;
  };
  return {
    hooks,
    mount(hook: any, props: any) {
      state.cells = [];
      state.hook = hook;
      return render(props);
    },
    rerender(props: any) {
      return render(props);
    },
    unmount() {
      for (const c of state.cells) {
        if (c && typeof c.cleanup === 'function') {
          c.cleanup();
          c.cleanup = undefined;
        }
      }
      state.cells = [];
    },
  };
});

vi.mock('react', async (importOriginal) => {
  const actual: any = await importOriginal();
  return { ...actual, ...rt.hooks, default: { ...actual.default, ...rt.hooks } };
});

vi.mock('@/lib/supabaseClient', () => {
  const live = new Set<any>();
  const all: any[] = [];
  const make = (name: string) => {
    const ch: any = {
      name,
      alive: true,
      handlers: [] as any[],
      on(type: string, opts: any, cb: any) {
        ch.handlers.push({ type, ...(opts || {}), cb });
        return ch;
      },
      subscribe(cb?: any) {
        if (typeof cb === 'function') cb('SUBSCRIBED');
        return ch;
      },
      unsubscribe() {
        ch.alive = false;
        live.delete(ch);
        return Promise.resolve('ok');
      },
    };
    return ch;
  };
  const supabase = {
    channel(name: string) {
      const ch = make(name);
      live.add(ch);
      all.push(ch);
      return ch;
    },
    removeChannel(ch: any) {
      if (ch) {
        ch.alive = false;
        live.delete(ch);
      }
      return Promise.resolve('ok');
    },
    removeAllChannels() {
      for (const ch of live) ch.alive = false;
      live.clear();
      return Promise.resolve([]);
    },
    getChannels() {
      return [...live];
    },
  };
  const __reset = () => {
    live.clear();
    all.length = 0;
  };
  return { supabase, __live: live, __all: all, __reset };
});


// Everything else the page touches is mocked so that only the realtime channels are observed.
const EMPTY: any[] = [];
const qc = vi.hoisted(() => ({ calls: [] as any[] }));
vi.mock('@tanstack/react-query', () => {
  const client = {
    invalidateQueries: (arg: any) => {
      qc.calls.push(arg);
      return Promise.resolve();
    },
    setQueryData: () => undefined,
    getQueryData: () => undefined,
    cancelQueries: () => Promise.resolve(),
  };
  return {
    useQueryClient: () => client,
    useQuery: () => ({ data: EMPTY, isLoading: false, isError: false, error: null, refetch: () => Promise.resolve() }),
    useMutation: () => ({ mutate: () => undefined, mutateAsync: () => Promise.resolve({ success: true }), isPending: false }),
    QueryClient: class {},
  };
});
vi.mock('@/hooks/useNotification', () => ({ useNotification: () => ({ showNotification: () => undefined }) }));
vi.mock('@/hooks/useAuth', () => ({
  useAuth: () => ({ user: { _uuid: 'v1', id: 'v1', role: 'veterinarian', clinic_id: 'c1' } }),
}));

const tableOf = (ch: any): string => String(ch.handlers[0]?.table || '');
const filterOf = (ch: any): string => String(ch.handlers[0]?.filter || '');
const sessionOf = (ch: any): string => {
  const m = /eq\.(.+)$/.exec(filterOf(ch));
  return m ? m[1] : '';
};
const feed = (ch: any) => tableOf(ch) === 'telehealth_messages' && ch.handlers.length === 1 && ch.handlers[0].event === '*';
const chatKind = (ch: any): string => {
  const h = ch.handlers[0];
  if (!h) return 'foreign';
  if (h.table === 'telehealth_sessions') return h.filter ? 'status' : 'list';
  if (h.table === 'telehealth_messages' && h.event === 'INSERT') return 'messages';
  if (h.table === 'telehealth_messages' && h.event === 'UPDATE') return 'read';
  if (h.table === 'telehealth_messages') return 'feed';
  return 'other';
};

const session = (id: string): any => ({
  id,
  status: 'in_progress',
  client_id: 'cl1',
  vet_id: 'v1',
  pet_id: 'p1',
  consultation_type: 'chat',
  pet: { id: 'p1', name: 'Fluffy' },
  client: { id: 'cl1', user: { full_name: 'Casey Client' } },
  scheduled_time: '2021-03-15T10:00:00.000Z',
  created_at: '2021-03-15T09:00:00.000Z',
  updated_at: '2021-03-15T09:00:00.000Z',
});

async function load() {
  vi.resetModules();
  qc.calls.length = 0;
  const sb: any = await import('@/lib/supabaseClient');
  sb.__reset();
  const backend: any = await import('@/features/telehealth/hooks/useBackendTelehealth');
  const list: any = await import('@/features/telehealth/components/SessionList');
  const chat: any = await import('@/features/telehealth/components/ChatInterface');
  const live = (): any[] => [...sb.__live];
  const all = (): any[] => [...sb.__all];
  const fire = (ch: any, payload: any) => ch.handlers.forEach((h: any) => h.cb(payload));
  // The Messages page: the session list beside one chat, both drawn in one pass.
  const page = (p: { open: any }) => {
    list.SessionList({ selectedSessionId: p.open ? p.open.id : null, onSelectSession: () => undefined });
    chat.ChatInterface({ session: p.open, isPopout: false });
    return null;
  };
  return { sb, backend, list, chat, live, all, fire, page, close: rt.unmount };
}

afterEach(() => {
  rt.unmount();
  vi.restoreAllMocks();
});

describe('the realtime feeds keep working', () => {
  it('a message change after switching chats refreshes the chat now open', async () => {
    const t = await load();
    rt.mount(t.backend.useBackendTelehealthMessages, 's1');
    rt.rerender('s2');
    qc.calls.length = 0;
    const ch = t.live().filter(feed).find((c) => sessionOf(c) === 's2');
    expect(ch).toBeTruthy();
    t.fire(ch, { eventType: 'INSERT', new: { id: 'm1', session_id: 's2', content: 'hello' } });
    const keys = qc.calls.map((c) => JSON.stringify(c.queryKey));
    expect(keys).toContain(JSON.stringify(['telehealth', 'messages', 's2']));
    expect(keys).not.toContain(JSON.stringify(['telehealth', 'messages', 's1']));
  });

  it('a message change refreshes the open chat', async () => {
    const t = await load();
    rt.mount(t.backend.useBackendTelehealthMessages, 's1');
    const ch = t.live().filter(feed)[0];
    t.fire(ch, { eventType: 'UPDATE', new: { id: 'm1', session_id: 's1', is_read: true } });
    expect(qc.calls.map((c) => JSON.stringify(c.queryKey))).toContain(JSON.stringify(['telehealth', 'messages', 's1']));
  });

  it('no session means no feed', async () => {
    const t = await load();
    rt.mount(t.backend.useBackendTelehealthMessages, null);
    expect(t.live().filter(feed)).toEqual([]);
  });

  it('the feed listens to the open session only', async () => {
    const t = await load();
    rt.mount(t.backend.useBackendTelehealthMessages, 's1');
    expect(t.live().filter(feed).map(filterOf)).toEqual(['session_id=eq.s1']);
  });

  it('leaving the messages hook closes its feed', async () => {
    const t = await load();
    rt.mount(t.backend.useBackendTelehealthMessages, 's1');
    t.close();
    expect(t.live()).toEqual([]);
  });

  it('a session update refreshes the session list', async () => {
    const t = await load();
    rt.mount(t.backend.useBackendTelehealthSessions, undefined);
    const ch = t.live()[0];
    t.fire(ch, { eventType: 'UPDATE', new: { id: 's1', status: 'completed' } });
    expect(qc.calls.map((c) => JSON.stringify(c.queryKey))).toContain(JSON.stringify(['telehealth', 'sessions']));
  });

  it("the list's own channel listens to session updates and refreshes the list", async () => {
    const t = await load();
    rt.mount(t.list.SessionList, { selectedSessionId: null, onSelectSession: () => undefined });
    const ch = t.live().find((c) => chatKind(c) === 'list' && c.handlers[0].event === 'UPDATE');
    expect(ch).toBeTruthy();
    qc.calls.length = 0;
    t.fire(ch, { eventType: 'UPDATE', new: { id: 's1', status: 'completed' } });
    expect(qc.calls.map((c) => JSON.stringify(c.queryKey))).toContain(JSON.stringify(['telehealth', 'sessions']));
  });

  it('leaving the list closes its channels', async () => {
    const t = await load();
    rt.mount(t.list.SessionList, { selectedSessionId: null, onSelectSession: () => undefined });
    expect(t.live().length).toBe(2);
    t.close();
    expect(t.live()).toEqual([]);
  });

  it('the shared realtime hook opens nothing while disabled', async () => {
    const t = await load();
    const mod: any = await import('@/hooks/useRealtimeSubscription');
    rt.mount(mod.useRealtimeSubscription, { table: 'telehealth_sessions', enabled: false, onAll: () => undefined });
    expect(t.live()).toEqual([]);
  });

  it('the shared realtime hook routes inserts, updates and deletes to their handlers', async () => {
    const t = await load();
    const mod: any = await import('@/hooks/useRealtimeSubscription');
    const got: string[] = [];
    rt.mount(mod.useRealtimeSubscription, {
      table: 'telehealth_messages',
      filter: 'session_id=eq.s1',
      onInsert: () => got.push('insert'),
      onUpdate: () => got.push('update'),
      onDelete: () => got.push('delete'),
    });
    const ch = t.live()[0];
    expect(filterOf(ch)).toBe('session_id=eq.s1');
    t.fire(ch, { eventType: 'INSERT', new: {} });
    t.fire(ch, { eventType: 'UPDATE', new: {} });
    t.fire(ch, { eventType: 'DELETE', old: {} });
    expect(got).toEqual(['insert', 'update', 'delete']);
  });
});

describe('the shared realtime hook hears with the newest handlers', () => {
  const opts = (handlers: Record<string, (payload: any) => void>) => ({
    table: 'telehealth_messages',
    filter: 'session_id=eq.s1',
    enabled: true,
    ...handlers,
  });

  const cases: Array<[string, string, any]> = [
    ['an insert', 'onInsert', { eventType: 'INSERT', new: { id: 'm1' } }],
    ['an update', 'onUpdate', { eventType: 'UPDATE', new: { id: 'm1' } }],
    ['a delete', 'onDelete', { eventType: 'DELETE', old: { id: 'm1' } }],
  ];

  for (const [what, key, payload] of cases) {
    it(`${what} after a re-render with a new handler reaches only the new handler, on one live channel`, async () => {
      const t = await load();
      const mod: any = await import('@/hooks/useRealtimeSubscription');
      const got: string[] = [];
      rt.mount(mod.useRealtimeSubscription, opts({ [key]: () => got.push('first') }));
      rt.rerender(opts({ [key]: () => got.push('second') }));
      for (const ch of t.live()) t.fire(ch, payload);
      expect({ got, live: t.live().length }).toEqual({ got: ['second'], live: 1 });
    });
  }

  it('any event after a re-render with a new catch-all handler reaches only the new one, on one live channel', async () => {
    const t = await load();
    const mod: any = await import('@/hooks/useRealtimeSubscription');
    const got: string[] = [];
    rt.mount(mod.useRealtimeSubscription, opts({ onAll: () => got.push('first') }));
    rt.rerender(opts({ onAll: () => got.push('second') }));
    for (const ch of t.live()) t.fire(ch, { eventType: 'INSERT', new: { id: 'm1' } });
    expect({ got, live: t.live().length }).toEqual({ got: ['second'], live: 1 });
  });
});
