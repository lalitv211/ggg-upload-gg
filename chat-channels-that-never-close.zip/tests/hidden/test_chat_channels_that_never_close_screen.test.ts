import { describe, it, expect, vi, afterEach } from 'vitest';
import React from 'react';
import { renderToString } from 'react-dom/server';

let captured: any = null;
vi.mock('@/features/telehealth/hooks/useTelehealthChat', () => ({
  useTelehealthChat: (options: any) => {
    captured = options;
    return { isConnected: true };
  },
  useUnreadCount: (session: any) => session?.unread_count || 0,
}));
vi.mock('@/features/telehealth/hooks/useBackendTelehealth', () => ({
  useBackendTelehealthSessions: () => ({ data: [], isLoading: false }),
  useBackendTelehealthSession: () => ({ data: null, isLoading: false }),
  useBackendTelehealthMessages: () => ({ data: [], isLoading: false, error: null, refetch: vi.fn() }),
  useBackendMarkMessagesAsRead: () => ({ mutate: vi.fn(), mutateAsync: vi.fn(), isPending: false }),
  useBackendCloseTelehealthSession: () => ({ mutate: vi.fn(), mutateAsync: vi.fn(), isPending: false }),
  useBackendSendTelehealthMessage: () => ({ mutate: vi.fn(), mutateAsync: vi.fn(), isPending: false }),
}));
vi.mock('@/hooks/useAuth', () => ({ useAuth: () => ({ user: { _uuid: 'v1', id: 'v1', role: 'veterinarian', clinic_id: 'c1' } }) }));
vi.mock('@/contexts/MessagePopoutContext', () => ({ useMessagePopout: () => ({ popout: vi.fn(), isPoppedOut: () => false }) }));
vi.mock('@/lib/supabaseClient', () => ({
  supabase: {
    channel: () => ({ on() { return this; }, subscribe() { return this; }, unsubscribe() { return Promise.resolve('ok'); } }),
    removeChannel: () => Promise.resolve('ok'),
    removeAllChannels: () => Promise.resolve([]),
    getChannels: () => [],
    auth: { getSession: async () => ({ data: { session: null } }) },
  },
}));

const session: any = {
  id: 's1',
  status: 'active',
  client_id: 'cl1',
  vet_id: 'v1',
  pet_id: 'p1',
  consultation_type: 'chat',
  pet: { id: 'p1', name: 'Fluffy' },
  client: { id: 'cl1', user: { full_name: 'Dana Reyes' } },
  unread_count: 0,
};

async function openScreen() {
  captured = null;
  const mod: any = await import('@/features/telehealth/components/ChatInterface');
  const html = renderToString(React.createElement(mod.ChatInterface, { session }));
  if (!captured || typeof captured.onNewMessage !== 'function') throw new Error('the chat screen did not hand its handlers to the chat hook');
  return { html, handlers: captured };
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe('the chat screen keeps message text out of the console', () => {
  it('a client message handled by the screen is not printed', async () => {
    const { handlers } = await openScreen();
    const spies = ['log', 'info', 'debug', 'warn', 'error'].map((m) => vi.spyOn(console, m as any).mockImplementation(() => {}));
    handlers.onNewMessage({ id: 'm1', session_id: 's1', sender_type: 'client', content: 'Fluffy has a fever since Monday', created_at: '2021-03-15T10:00:00Z', is_read: false });
    const printed = spies.flatMap((s) => s.mock.calls).filter((args) => args.some((a) => JSON.stringify(a ?? '').includes('Fluffy has a fever')));
    expect(printed).toEqual([]);
  });

  it('a vet message handled by the screen is not printed either', async () => {
    const { handlers } = await openScreen();
    const spies = ['log', 'info', 'debug', 'warn', 'error'].map((m) => vi.spyOn(console, m as any).mockImplementation(() => {}));
    handlers.onNewMessage({ id: 'm2', session_id: 's1', sender_type: 'vet', content: 'Bring Fluffy in tomorrow morning please', created_at: '2021-03-15T10:05:00Z', is_read: true });
    const printed = spies.flatMap((s) => s.mock.calls).filter((args) => args.some((a) => JSON.stringify(a ?? '').includes('Bring Fluffy in')));
    expect(printed).toEqual([]);
  });
});
