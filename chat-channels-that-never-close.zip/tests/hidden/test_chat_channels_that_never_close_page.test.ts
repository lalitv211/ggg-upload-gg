import { describe, it, expect, vi, afterEach } from 'vitest';

// A tiny hooks runtime: runs one hook function outside a renderer, re-rendering on state changes,
// running effects (and their cleanups) the way React orders them for a single component.
const rt = vi.hoisted(() => {
  const state: any = { cells: [], idx: 0, pending: [], hook: undefined, dirty: false, result: undefined };
  const same = (a: any, b: any) =>
    Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((v: any, i: number) => Object.is(v, b[i]));
  const schedule = () => {
    state.dirty = true;
  };
  const cell = (init: () => any) => {
    const i = state.idx++;
    if (!(i in state.cells)) state.cells[i] = init();
    return state.cells[i];
  };
  const effect = (fn: any, deps: any) => {
    const i = state.idx++;
    const prev = state.cells[i];
    const changed = !prev || !deps || !prev.deps || !same(deps, prev.deps);
    if (!prev) state.cells[i] = { deps, cleanup: undefined, effect: true };
    else prev.deps = deps;
    if (changed) state.pending.push({ i, fn });
  };
  const hooks: any = {
    useState(init: any) {
      const c = cell(() => ({ v: typeof init === 'function' ? init() : init }));
      const set = (nv: any) => {
        const next = typeof nv === 'function' ? nv(c.v) : nv;
        if (!Object.is(next, c.v)) {
          c.v = next;
          schedule();
        }
      };
      return [c.v, set];
    },
    useReducer(red: any, init: any, initf?: any) {
      const c = cell(() => ({ v: initf ? initf(init) : init }));
      const dispatch = (a: any) => {
        const next = red(c.v, a);
        if (!Object.is(next, c.v)) {
          c.v = next;
          schedule();
        }
      };
      return [c.v, dispatch];
    },
    useRef(init: any) {
      return cell(() => ({ current: init }));
    },
    useEffect: effect,
    useLayoutEffect: effect,
    useInsertionEffect: effect,
    useMemo(f: any, deps: any) {
      const i = state.idx++;
      const prev = state.cells[i];
      if (prev && same(deps, prev.deps)) return prev.v;
      const v = f();
      state.cells[i] = { v, deps };
      return v;
    },
    useCallback(fn: any, deps: any) {
      return hooks.useMemo(() => fn, deps);
    },
    useId() {
      return cell(() => 'id-' + Math.random().toString(36).slice(2));
    },
    useContext(ctx: any) {
      return ctx?._currentValue;
    },
    useDebugValue() {},
    useTransition() {
      return [false, (fn: any) => fn()];
    },
    useDeferredValue(v: any) {
      return v;
    },
    useSyncExternalStore(subscribe: any, getSnapshot: any) {
      cell(() => ({ unsub: subscribe(() => schedule()) }));
      return getSnapshot();
    },
  };
  const flush = () => {
    const pending = state.pending;
    state.pending = [];
    for (const e of pending) {
      const c = state.cells[e.i];
      if (typeof c.cleanup === 'function') c.cleanup();
      const r = e.fn();
      c.cleanup = typeof r === 'function' ? r : undefined;
    }
  };
  const render = (props: any) => {
    let guard = 0;
    do {
      state.dirty = false;
      state.idx = 0;
      state.pending = [];
      state.result = state.hook(props);
      flush();
    } while (state.dirty && ++guard < 20);
    return state.result;
  };
  return {
    hooks,
    mount(hook: any, props: any) {
      state.cells = [];
      state.hook = hook;
      return render(props);
    },
    rerender(props: any) {
      return render(props);
    },
    unmount() {
      for (const c of state.cells) {
        if (c && typeof c.cleanup === 'function') {
          c.cleanup();
          c.cleanup = undefined;
        }
      }
      state.cells = [];
    },
  };
});

vi.mock('react', async (importOriginal) => {
  const actual: any = await importOriginal();
  return { ...actual, ...rt.hooks, default: { ...actual.default, ...rt.hooks } };
});

vi.mock('@/lib/supabaseClient', () => {
  const live = new Set<any>();
  const all: any[] = [];
  const make = (name: string) => {
    const ch: any = {
      name,
      alive: true,
      handlers: [] as any[],
      on(type: string, opts: any, cb: any) {
        ch.handlers.push({ type, ...(opts || {}), cb });
        return ch;
      },
      subscribe(cb?: any) {
        if (typeof cb === 'function') cb('SUBSCRIBED');
        return ch;
      },
      unsubscribe() {
        ch.alive = false;
        live.delete(ch);
        return Promise.resolve('ok');
      },
    };
    return ch;
  };
  const supabase = {
    channel(name: string) {
      const ch = make(name);
      live.add(ch);
      all.push(ch);
      return ch;
    },
    removeChannel(ch: any) {
      if (ch) {
        ch.alive = false;
        live.delete(ch);
      }
      return Promise.resolve('ok');
    },
    removeAllChannels() {
      for (const ch of live) ch.alive = false;
      live.clear();
      return Promise.resolve([]);
    },
    getChannels() {
      return [...live];
    },
  };
  const __reset = () => {
    live.clear();
    all.length = 0;
  };
  return { supabase, __live: live, __all: all, __reset };
});


// Everything else the page touches is mocked so that only the realtime channels are observed.
const EMPTY: any[] = [];
const qc = vi.hoisted(() => ({ calls: [] as any[] }));
vi.mock('@tanstack/react-query', () => {
  const client = {
    invalidateQueries: (arg: any) => {
      qc.calls.push(arg);
      return Promise.resolve();
    },
    setQueryData: () => undefined,
    getQueryData: () => undefined,
    cancelQueries: () => Promise.resolve(),
  };
  return {
    useQueryClient: () => client,
    useQuery: () => ({ data: EMPTY, isLoading: false, isError: false, error: null, refetch: () => Promise.resolve() }),
    useMutation: () => ({ mutate: () => undefined, mutateAsync: () => Promise.resolve({ success: true }), isPending: false }),
    QueryClient: class {},
  };
});
vi.mock('@/hooks/useNotification', () => ({ useNotification: () => ({ showNotification: () => undefined }) }));
vi.mock('@/hooks/useAuth', () => ({
  useAuth: () => ({ user: { _uuid: 'v1', id: 'v1', role: 'veterinarian', clinic_id: 'c1' } }),
}));

const tableOf = (ch: any): string => String(ch.handlers[0]?.table || '');
const filterOf = (ch: any): string => String(ch.handlers[0]?.filter || '');
const sessionOf = (ch: any): string => {
  const m = /eq\.(.+)$/.exec(filterOf(ch));
  return m ? m[1] : '';
};
const feed = (ch: any) => tableOf(ch) === 'telehealth_messages' && ch.handlers.length === 1 && ch.handlers[0].event === '*';
const chatKind = (ch: any): string => {
  const h = ch.handlers[0];
  if (!h) return 'foreign';
  if (h.table === 'telehealth_sessions') return h.filter ? 'status' : 'list';
  if (h.table === 'telehealth_messages' && h.event === 'INSERT') return 'messages';
  if (h.table === 'telehealth_messages' && h.event === 'UPDATE') return 'read';
  if (h.table === 'telehealth_messages') return 'feed';
  return 'other';
};

const session = (id: string): any => ({
  id,
  status: 'in_progress',
  client_id: 'cl1',
  vet_id: 'v1',
  pet_id: 'p1',
  consultation_type: 'chat',
  pet: { id: 'p1', name: 'Fluffy' },
  client: { id: 'cl1', user: { full_name: 'Casey Client' } },
  scheduled_time: '2021-03-15T10:00:00.000Z',
  created_at: '2021-03-15T09:00:00.000Z',
  updated_at: '2021-03-15T09:00:00.000Z',
});

async function load() {
  vi.resetModules();
  qc.calls.length = 0;
  const sb: any = await import('@/lib/supabaseClient');
  sb.__reset();
  const backend: any = await import('@/features/telehealth/hooks/useBackendTelehealth');
  const list: any = await import('@/features/telehealth/components/SessionList');
  const chat: any = await import('@/features/telehealth/components/ChatInterface');
  const live = (): any[] => [...sb.__live];
  const all = (): any[] => [...sb.__all];
  const fire = (ch: any, payload: any) => ch.handlers.forEach((h: any) => h.cb(payload));
  // The Messages page: the session list beside one chat, both drawn in one pass.
  const page = (p: { open: any }) => {
    list.SessionList({ selectedSessionId: p.open ? p.open.id : null, onSelectSession: () => undefined });
    chat.ChatInterface({ session: p.open, isPopout: false });
    return null;
  };
  return { sb, backend, list, chat, live, all, fire, page, close: rt.unmount };
}

afterEach(() => {
  rt.unmount();
  vi.restoreAllMocks();
});

describe('the chat screen opens its message feed once', () => {
  it('re-rendering the messages hook for the same session opens no second feed', async () => {
    const t = await load();
    rt.mount(t.backend.useBackendTelehealthMessages, 's1');
    rt.rerender('s1');
    rt.rerender('s1');
    expect(t.all().filter(feed).length).toBe(1);
    expect(t.live().filter(feed).length).toBe(1);
  });

  it('switching the messages hook to another session closes the first feed and opens the second once', async () => {
    const t = await load();
    rt.mount(t.backend.useBackendTelehealthMessages, 's1');
    rt.rerender('s2');
    rt.rerender('s2');
    const feeds = t.live().filter(feed);
    expect(feeds.map(sessionOf)).toEqual(['s2']);
    expect(t.all().filter(feed).length).toBe(2);
  });

  it('re-rendering the sessions hook opens its channel once', async () => {
    const t = await load();
    rt.mount(t.backend.useBackendTelehealthSessions, undefined);
    rt.rerender(undefined);
    rt.rerender(undefined);
    rt.rerender(undefined);
    expect(t.all().length).toBe(1);
    expect(t.live().length).toBe(1);
  });

  it('re-rendering the single session hook opens its channel once', async () => {
    const t = await load();
    rt.mount(t.backend.useBackendTelehealthSession, 's1');
    rt.rerender('s1');
    rt.rerender('s1');
    expect(t.all().length).toBe(1);
    expect(t.live().map(sessionOf)).toEqual(['s1']);
  });
});

describe('the session list keeps its own channel', () => {
  it('redrawing the list opens its update channel once', async () => {
    const t = await load();
    const props = { selectedSessionId: null, onSelectSession: () => undefined };
    rt.mount(t.list.SessionList, props);
    rt.rerender({ ...props, selectedSessionId: 's1' });
    rt.rerender({ ...props, selectedSessionId: 's2' });
    rt.rerender({ ...props, selectedSessionId: null });
    // the list's own update channel plus the one its sessions hook holds, each opened once
    const own = (c: any) => chatKind(c) === 'list' && c.handlers[0].event === 'UPDATE';
    expect(t.all().filter(own).length).toBe(1);
    expect(t.all().filter((c) => chatKind(c) === 'list').length).toBe(2);
    expect(t.live().filter((c) => chatKind(c) === 'list').length).toBe(2);
  });
});

describe('the messages page as a whole', () => {
  it('the page with one chat open holds exactly six channels, each opened once', async () => {
    const t = await load();
    rt.mount(t.page, { open: session('s1') });
    expect(t.live().length).toBe(6);
    expect(t.all().length).toBe(6);
    expect(t.live().map(chatKind).sort()).toEqual(['feed', 'list', 'list', 'messages', 'read', 'status']);
  });

  it('typing in the chat opens no channel anywhere on the page', async () => {
    const t = await load();
    rt.mount(t.page, { open: session('s1') });
    rt.rerender({ open: session('s1') });
    rt.rerender({ open: session('s1') });
    rt.rerender({ open: session('s1') });
    expect(t.all().length).toBe(6);
    expect(t.live().length).toBe(6);
  });

  it("closing the chat leaves only the list's two channels", async () => {
    const t = await load();
    rt.mount(t.page, { open: session('s1') });
    rt.rerender({ open: null });
    expect(t.live().map(chatKind).sort()).toEqual(['list', 'list']);
    expect(t.live().filter((c) => sessionOf(c) === 's1')).toEqual([]);
  });

  it("clicking another chat moves the chat's four channels to that session", async () => {
    const t = await load();
    rt.mount(t.page, { open: session('s1') });
    rt.rerender({ open: session('s2') });
    rt.rerender({ open: session('s2') });
    expect(t.live().filter((c) => sessionOf(c) === 's1')).toEqual([]);
    expect(t.live().filter((c) => sessionOf(c) === 's2').map(chatKind).sort()).toEqual(['feed', 'messages', 'read', 'status']);
    expect(t.live().length).toBe(6);
    expect(t.all().length).toBe(10);
  });

  it('leaving the page closes everything', async () => {
    const t = await load();
    rt.mount(t.page, { open: session('s1') });
    rt.rerender({ open: session('s1') });
    t.close();
    expect(t.live()).toEqual([]);
  });
});
