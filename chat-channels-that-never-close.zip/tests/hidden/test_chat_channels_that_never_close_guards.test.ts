import { describe, it, expect, vi, afterEach } from 'vitest';

vi.mock('@/lib/supabaseClient', () => {
  const live = new Set<any>();
  const make = (name: string) => {
    const ch: any = {
      name,
      alive: true,
      handlers: [] as any[],
      on(type: string, opts: any, cb: any) {
        ch.handlers.push({ type, ...(opts || {}), cb });
        return ch;
      },
      subscribe(cb?: any) {
        if (typeof cb === 'function') cb('SUBSCRIBED');
        return ch;
      },
      unsubscribe() {
        ch.alive = false;
        live.delete(ch);
        return Promise.resolve('ok');
      },
    };
    return ch;
  };
  const supabase = {
    channel(name: string) {
      const ch = make(name);
      live.add(ch);
      return ch;
    },
    removeChannel(ch: any) {
      if (ch) {
        ch.alive = false;
        live.delete(ch);
      }
      return Promise.resolve('ok');
    },
    removeAllChannels() {
      for (const ch of live) ch.alive = false;
      live.clear();
      return Promise.resolve([]);
    },
    getChannels() {
      return [...live];
    },
  };
  const __reset = () => {
    live.clear();
  };
  return { supabase, __live: live, __reset };
});

const kindOf = (ch: any): string => {
  const h = ch.handlers[0];
  if (!h) return 'foreign';
  if (h.table === 'telehealth_sessions') return 'status';
  if (h.table === 'telehealth_messages' && h.event === 'INSERT') return 'messages';
  if (h.table === 'telehealth_messages') return 'read';
  return 'other';
};
const sessionOf = (ch: any): string => {
  const m = /eq\.(.+)$/.exec(String(ch.handlers[0]?.filter || ''));
  return m ? m[1] : '';
};

async function load() {
  vi.resetModules();
  const sb: any = await import('@/lib/supabaseClient');
  sb.__reset();
  const mod: any = await import('@/features/telehealth/api/telehealthChatService');
  const live = (): any[] => [...sb.__live];
  const liveOf = (session: string, kind?: string) =>
    live().filter((c) => sessionOf(c) === session && (!kind || kindOf(c) === kind));
  const fire = (ch: any, payload: any) => ch.handlers.forEach((h: any) => h.cb(payload));
  return { sb, service: mod.telehealthChatService, live, liveOf, fire };
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe('what already worked keeps working', () => {
  it('the service exposes the five channel methods', async () => {
    const t = await load();
    for (const m of ['subscribeToMessages', 'subscribeToStatus', 'subscribeToReadStatus', 'unsubscribe', 'unsubscribeAll']) {
      expect(typeof t.service[m]).toBe('function');
    }
  });

  it('a second messages subscription leaves one live messages channel', async () => {
    const t = await load();
    t.service.subscribeToMessages('s1', () => {});
    t.service.subscribeToMessages('s1', () => {});
    expect(t.liveOf('s1', 'messages').length).toBe(1);
  });

  it('a new message reaches the callback with the row', async () => {
    const t = await load();
    const onMessage = vi.fn();
    t.service.subscribeToMessages('s1', onMessage);
    const msg = { id: 'm1', session_id: 's1', content: 'hello' };
    for (const ch of t.liveOf('s1', 'messages')) t.fire(ch, { new: msg });
    expect(onMessage).toHaveBeenCalledWith(msg);
  });

  it('a status change reaches the callback with the new status', async () => {
    const t = await load();
    const onStatus = vi.fn();
    t.service.subscribeToStatus('s1', onStatus);
    for (const ch of t.liveOf('s1', 'status')) t.fire(ch, { new: { id: 's1', status: 'active' } });
    expect(onStatus).toHaveBeenCalledWith('active');
  });

  it('a read update reaches the callback with the row', async () => {
    const t = await load();
    const onRead = vi.fn();
    t.service.subscribeToReadStatus('s1', onRead);
    const msg = { id: 'm1', session_id: 's1', is_read: true };
    for (const ch of t.liveOf('s1', 'read')) t.fire(ch, { new: msg });
    expect(onRead).toHaveBeenCalledWith(msg);
  });

  it('the message subscription listens to inserts of that session only', async () => {
    const t = await load();
    t.service.subscribeToMessages('s1', () => {});
    const h = t.liveOf('s1', 'messages')[0].handlers[0];
    expect(h.event).toBe('INSERT');
    expect(String(h.filter)).toContain('s1');
  });

  it('a channel opened outside the service survives unsubscribeAll', async () => {
    const t = await load();
    const foreign = t.sb.supabase.channel('soap:pet-1').subscribe();
    t.service.subscribeToMessages('s1', () => {});
    t.service.subscribeToStatus('s1', () => {});
    t.service.unsubscribeAll();
    expect(foreign.alive).toBe(true);
    expect(t.live()).toContain(foreign);
  });

  it('a channel opened outside the service survives unsubscribe of a session', async () => {
    const t = await load();
    const foreign = t.sb.supabase.channel('soap:pet-1').subscribe();
    t.service.subscribeToMessages('s1', () => {});
    t.service.unsubscribe('s1');
    expect(foreign.alive).toBe(true);
  });

  it('the subscribe methods hand back the channel', async () => {
    const t = await load();
    const ch = t.service.subscribeToStatus('s1', () => {});
    expect(t.live()).toContain(ch);
  });

  it('unsubscribe of an unknown session does nothing', async () => {
    const t = await load();
    t.service.subscribeToMessages('s1', () => {});
    expect(() => t.service.unsubscribe('nobody')).not.toThrow();
    expect(t.liveOf('s1').length).toBe(1);
  });
});
