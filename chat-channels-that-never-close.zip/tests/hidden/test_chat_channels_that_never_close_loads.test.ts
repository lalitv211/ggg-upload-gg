import { describe, it, expect, vi } from 'vitest';

vi.mock('@/lib/supabaseClient', () => ({
  supabase: {
    channel: () => ({ on() { return this; }, subscribe() { return this; }, unsubscribe() { return Promise.resolve('ok'); } }),
    removeChannel: () => Promise.resolve('ok'),
    removeAllChannels: () => Promise.resolve([]),
    getChannels: () => [],
  },
}));

describe('the modules the change touches still load', () => {
  it('the chat service module loads with its singleton', async () => {
    const mod: any = await import('@/features/telehealth/api/telehealthChatService');
    expect(typeof mod.telehealthChatService.subscribeToMessages).toBe('function');
    expect(typeof mod.telehealthChatService.unsubscribeAll).toBe('function');
  });

  it('the chat hook module loads', async () => {
    const mod: any = await import('@/features/telehealth/hooks/useTelehealthChat');
    expect(typeof mod.useTelehealthChat).toBe('function');
  });
});
