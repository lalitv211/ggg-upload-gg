"""What already works and has to keep working once the holes are closed."""

from src.domain.access.grant import Grant, grants_for, studios_visible_to
from src.domain.access.invitation import Invitation
from src.domain.access.policy import Actor, decide
from src.domain.access.session import ACCESS, REFRESH, Blacklist, TokenClaims, is_usable, refresh
from src.domain.adapters import models
from src.domain.core.errors import DomainError
from tests.support import DomainTestCase


class GrantedRolesTests(DomainTestCase):
    def test_producer_guest_and_viewer_grants_still_work(self):
        for role, right in (
            ("producer", "episodes:publish"),
            ("guest", "media:read"),
            ("viewer", "analytics:read"),
        ):
            grant = Grant("owner-1", "guest-1", role)
            self.assertEqual(role, grant.role)
            self.assertTrue(grant.allows(right), role)
            actor = Actor("guest-1", "viewer", "owner-1")
            self.assertTrue(decide(actor, right, [grant]).allowed, role)

    def test_a_grant_still_stops_at_its_role(self):
        self.assertFalse(Grant("owner-1", "guest-1", "guest").allows("episodes:delete"))

    def test_invitations_for_ordinary_roles_still_redeem(self):
        for role in ("producer", "guest", "viewer"):
            invitation = Invitation("owner-1", "guest@example.com", role, "2021-05-01")
            grant = invitation.to_grant("guest-1", "2021-05-02")
            self.assertEqual(role, grant.role)
            self.assertTrue(grant.is_active("2021-05-02"))

    def test_an_authorized_user_row_still_reads(self):
        row = {"owner_id": "owner-1", "user_id": "guest-1", "role": "producer"}
        self.assertTrue(models.to_grant(row).allows("episodes:publish"))

    def test_the_platform_administrator_is_still_an_administrator(self):
        self.assertTrue(decide(Actor("staff-1", "admin"), "users:delete").allowed)

    def test_an_owner_still_cannot_touch_platform_users(self):
        self.assertFalse(decide(Actor("owner-1", "owner"), "users:delete").allowed)


class InvitationTokenTests(DomainTestCase):
    def invitation(self, **overrides):
        payload = {
            "owner_id": "owner-1",
            "email": "guest@example.com",
            "role": "producer",
            "issued_on": "2021-05-01",
            "valid_days": 14,
        }
        payload.update(overrides)
        return Invitation(**payload)

    def test_a_link_verifies_against_its_own_invitation(self):
        self.assertTrue(self.invitation().verify(self.invitation().token))

    def test_the_token_survives_a_decision(self):
        invitation = self.invitation()
        self.assertEqual(invitation.token, invitation.decline().token)
        self.assertEqual(invitation.token, invitation.revoke().token)

    def test_editing_the_role_or_email_still_breaks_the_link(self):
        token = self.invitation().token
        self.assertFalse(self.invitation(role="guest").verify(token))
        self.assertFalse(self.invitation(email="x@example.com").verify(token))

    def test_the_payload_still_carries_the_token(self):
        invitation = self.invitation()
        self.assertEqual(invitation.token, invitation.to_dict()["token"])


class GrantDayTests(DomainTestCase):
    def test_a_grant_is_active_on_the_day_it_was_handed_out(self):
        grant = Grant("owner-1", "guest-1", "producer", None, "2021-06-10")
        self.assertTrue(grant.is_active("2021-06-10"))
        self.assertTrue(grant.allows("episodes:publish", on="2021-06-10"))
        self.assertTrue(grant.allows("episodes:publish", on="2021-09-01"))

    def test_a_grant_without_a_day_is_active_whenever(self):
        grant = Grant("owner-1", "guest-1", "producer")
        self.assertTrue(grant.is_active("1999-01-01"))
        self.assertTrue(grant.allows("episodes:publish", on="1999-01-01"))

    def test_an_expired_grant_is_still_expired(self):
        grant = Grant("owner-1", "guest-1", "producer", None, "2021-01-01", "2021-02-01")
        self.assertFalse(grant.is_active("2021-02-01"))
        self.assertTrue(grant.is_active("2021-01-31"))

    def test_the_day_ranges_still_filter_the_studio_list(self):
        current = Grant("owner-1", "guest-1", "producer", None, "2021-05-01")
        stale = Grant("owner-2", "guest-1", "guest", None, "2021-01-01", "2021-02-01")
        self.assertEqual(("owner-1",), studios_visible_to([current, stale], "guest-1", "2021-05-02"))
        self.assertEqual((current,), grants_for([current, stale], "guest-1", "2021-05-02"))

    def test_without_a_day_the_query_keeps_every_grant(self):
        stale = Grant("owner-2", "guest-1", "guest", None, "2021-01-01", "2021-02-01")
        self.assertEqual((stale,), grants_for([stale], "guest-1"))

    def test_a_redeemed_invitation_is_active_at_once(self):
        grant = Invitation("owner-1", "guest@example.com", "guest", "2021-05-01").to_grant(
            "guest-1", "2021-05-03"
        )
        self.assertTrue(grant.allows("episodes:read", on="2021-05-03"))


class TokenTests(DomainTestCase):
    def setUp(self):
        self.token = TokenClaims("u-1", REFRESH, "2021-05-01T00:00:00Z")

    def test_refresh_without_a_blacklist_still_mints(self):
        minted = refresh(self.token, "2021-05-02T00:00:00Z")
        self.assertEqual(ACCESS, minted.kind)

    def test_an_expired_refresh_token_still_fails_on_its_age(self):
        self.assertField("issued_at", refresh, self.token, "2021-07-01T00:00:00Z")

    def test_an_access_token_still_cannot_be_exchanged(self):
        access = TokenClaims("u-1", ACCESS, "2021-05-01T00:00:00Z")
        self.assertField("kind", refresh, access, "2021-05-01T00:01:00Z")

    def test_is_usable_still_reads_the_blacklist(self):
        book = Blacklist().with_revoked(self.token)
        self.assertFalse(is_usable(self.token, "2021-05-02T00:00:00Z", book))
        self.assertTrue(is_usable(self.token, "2021-05-02T00:00:00Z", Blacklist()))

    def test_a_domain_error_is_what_refresh_raises(self):
        with self.assertRaises(DomainError):
            refresh(self.token, "2021-07-01T00:00:00Z")


class NarrowingStillWorksTests(DomainTestCase):
    def test_a_grant_for_every_episode_narrows_to_any_of_them(self):
        narrowed = Grant("owner-1", "guest-1", "producer").narrowed_to(["e-7", "e-8"])
        self.assertEqual(("e-7", "e-8"), narrowed.episode_ids)
        self.assertFalse(narrowed.allows("episodes:read", "e-1"))

    def test_a_restricted_grant_narrows_to_part_of_what_it_covers(self):
        grant = Grant("owner-1", "guest-1", "producer", ["e-1", "e-2"])
        narrowed = grant.narrowed_to(["e-2"])
        self.assertEqual(("e-2",), narrowed.episode_ids)
        self.assertTrue(narrowed.allows("episodes:read", "e-2"))
        self.assertFalse(narrowed.allows("episodes:read", "e-1"))

    def test_narrowing_to_the_same_episodes_keeps_them(self):
        grant = Grant("owner-1", "guest-1", "guest", ["e-1"])
        self.assertEqual(("e-1",), grant.narrowed_to(["e-1"]).episode_ids)

    def test_narrowing_keeps_the_role_and_the_days(self):
        grant = Grant("owner-1", "guest-1", "producer", None, "2021-05-01", "2021-06-01")
        narrowed = grant.narrowed_to(["e-1"])
        self.assertEqual("producer", narrowed.role)
        self.assertEqual("2021-06-01", narrowed.expires_on.isoformat())


class StartsStillWorkTests(DomainTestCase):
    def test_a_token_is_usable_from_the_moment_it_was_issued(self):
        token = TokenClaims("u-1", ACCESS, "2021-05-01T12:00:00Z")
        self.assertTrue(is_usable(token, "2021-05-01T12:00:00Z"))
        self.assertTrue(is_usable(token, "2021-05-01T12:10:00Z"))

    def test_a_refresh_token_mints_from_the_moment_it_was_issued(self):
        token = TokenClaims("u-1", REFRESH, "2021-05-01T12:00:00Z")
        self.assertEqual(ACCESS, refresh(token, "2021-05-01T12:00:00Z").kind)

    def test_an_invitation_opens_on_the_day_it_was_sent(self):
        invitation = Invitation("owner-1", "guest@example.com", "guest", "2021-05-10")
        self.assertTrue(invitation.is_open("2021-05-10"))
        self.assertTrue(invitation.is_open())
        self.assertEqual("accepted", invitation.accept("2021-05-10").state)

    def test_an_invitation_without_a_day_is_open_whenever(self):
        invitation = Invitation("owner-1", "guest@example.com", "guest")
        self.assertTrue(invitation.is_open("1999-01-01"))

    def test_an_invitation_still_lapses_on_its_last_day(self):
        invitation = Invitation("owner-1", "guest@example.com", "guest", "2021-05-01")
        self.assertFalse(invitation.is_open("2021-05-08"))
        self.assertTrue(invitation.is_open("2021-05-07"))
        with self.assertRaises(DomainError):
            invitation.to_grant("guest-1", "2021-05-08")


class EndsStillWorkTests(DomainTestCase):
    def test_an_access_token_still_stops_at_its_expiry(self):
        token = TokenClaims("u-1", ACCESS, "2021-05-01T12:00:00Z")
        self.assertTrue(is_usable(token, "2021-05-01T12:14:59Z"))
        self.assertFalse(is_usable(token, "2021-05-01T12:15:00Z"))

    def test_a_grant_shows_its_studio_from_its_first_day(self):
        grant = Grant("owner-1", "guest-1", "producer", None, "2021-06-10")
        self.assertEqual(("owner-1",), studios_visible_to([grant], "guest-1", "2021-06-10"))
        self.assertEqual((grant,), grants_for([grant], "guest-1", "2021-06-11"))


class OtherSessionsTests(DomainTestCase):
    def setUp(self):
        self.login = TokenClaims("u-1", REFRESH, "2021-05-01T12:00:00Z")
        self.logged_out = Blacklist().with_revoked(self.login)

    def test_another_login_of_the_same_user_keeps_working(self):
        other = TokenClaims("u-1", REFRESH, "2021-05-01T08:00:00Z")
        minted = refresh(other, "2021-05-01T12:30:00Z")
        self.assertTrue(is_usable(minted, "2021-05-01T12:31:00Z", self.logged_out))
        self.assertTrue(is_usable(other, "2021-05-01T12:31:00Z", self.logged_out))

    def test_a_token_issued_at_login_is_not_ended_by_another_logout(self):
        access = TokenClaims("u-1", ACCESS, "2021-05-01T12:00:00Z")
        self.assertTrue(is_usable(access, "2021-05-01T12:01:00Z", self.logged_out))

    def test_a_minted_token_still_carries_the_subject_and_scopes(self):
        login = TokenClaims("u-1", REFRESH, "2021-05-01T12:00:00Z", scopes=["upload"])
        minted = refresh(login, "2021-05-01T12:30:00Z")
        payload = minted.to_dict()
        self.assertEqual("u-1", payload["sub"])
        self.assertEqual(["upload"], payload["scopes"])
        self.assertEqual(900, payload["exp"] - payload["iat"])
