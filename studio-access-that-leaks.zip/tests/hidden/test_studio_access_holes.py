"""The ways into a studio that the request closes.

Each hole is checked by what a caller sees, never by how it was closed: an
administrator grant may be refused when it is built or may be built and grant
nothing an owner lacks; a revoked refresh token may fail with any domain error.
"""

from src.domain.access.grant import Grant, grants_for, studios_visible_to
from src.domain.access.invitation import Invitation
from src.domain.access.policy import Actor, decide
from src.domain.access.session import (
    ACCESS,
    REFRESH,
    Blacklist,
    TokenClaims,
    is_usable,
    refresh,
)
from src.domain.adapters import models
from src.domain.core.errors import DomainError
from tests.support import DomainTestCase

# Rights only the platform holds: no studio owner has them, so no grant may pass them on.
PLATFORM_RIGHTS = ("users:delete", "users:update", "plans:update", "products:create", "blogs:delete")


def built_or_refused(factory, *args, **kwargs):
    """The grant ``factory`` builds, or None when it refuses with a domain error."""
    try:
        return factory(*args, **kwargs)
    except DomainError:
        return None


class AdministratorThroughAGrantTests(DomainTestCase):
    """Rule: nobody gets the administrator role through a grant or an invitation."""

    def assertGrantsNoPlatformRight(self, grant, subject="guest-1", owner="owner-1"):
        if grant is None:
            return
        actor = Actor(subject, "guest", owner)
        for right in PLATFORM_RIGHTS:
            self.assertFalse(grant.allows(right), right)
            self.assertFalse(decide(actor, right, [grant]).allowed, right)

    def test_a_grant_built_as_admin_opens_nothing_an_owner_lacks(self):
        self.assertGrantsNoPlatformRight(built_or_refused(Grant, "owner-1", "guest-1", "admin"))

    def test_the_role_name_in_capitals_is_the_same_role(self):
        for spelling in ("Admin", "ADMIN"):
            self.assertGrantsNoPlatformRight(
                built_or_refused(Grant, "owner-1", "guest-1", spelling)
            )

    def test_a_stored_admin_grant_opens_nothing_an_owner_lacks(self):
        payload = Grant("owner-1", "guest-1", "producer").to_dict()
        payload["role"] = "admin"
        self.assertGrantsNoPlatformRight(built_or_refused(Grant.from_dict, payload))

    def test_an_authorized_user_row_saved_as_admin_opens_nothing_an_owner_lacks(self):
        row = {"owner_id": "owner-1", "user_id": "guest-1", "role": "admin"}
        self.assertGrantsNoPlatformRight(built_or_refused(models.to_grant, row))

    def test_an_invitation_as_admin_leads_to_no_platform_right(self):
        invitation = built_or_refused(
            Invitation, "owner-1", "guest@example.com", "admin", "2021-05-01"
        )
        if invitation is None:
            return
        grant = built_or_refused(invitation.to_grant, "guest-1", "2021-05-02")
        self.assertGrantsNoPlatformRight(grant)
        if grant is not None:
            self.assertGrantsNoPlatformRight(grant.narrowed_to(["e-1"]))


class EditedLinkTests(DomainTestCase):
    """Rule: an invitation link that was edited does not verify."""

    def invitation(self, days):
        return Invitation("owner-1", "guest@example.com", "producer", "2021-05-01", days)

    def test_a_link_stretched_to_more_days_does_not_verify(self):
        self.assertFalse(self.invitation(90).verify(self.invitation(7).token))

    def test_every_length_has_its_own_token(self):
        tokens = {self.invitation(days).token for days in (1, 6, 7, 8, 30, 90)}
        self.assertEqual(6, len(tokens))


class GrantBeforeItsDayTests(DomainTestCase):
    """Rule: a grant handed out for a later day lets nothing through before that day."""

    def setUp(self):
        self.grant = Grant("owner-1", "guest-1", "producer", None, "2021-06-10", "2021-07-10")
        self.open_ended = Grant("owner-2", "guest-1", "guest", ["e-1"], "2021-06-10")
        self.actor = Actor("guest-1", "producer", "owner-1")

    def test_it_is_not_active_the_day_before(self):
        self.assertFalse(self.grant.is_active("2021-06-09"))
        self.assertFalse(self.open_ended.is_active("2021-06-09"))

    def test_it_allows_nothing_the_day_before(self):
        self.assertFalse(self.grant.allows("episodes:publish", on="2021-06-09"))
        self.assertFalse(self.open_ended.allows("episodes:read", "e-1", "2021-06-09"))

    def test_require_refuses_the_day_before(self):
        with self.assertRaises(DomainError):
            self.grant.require("episodes:publish", on="2021-06-09")

    def test_the_policy_refuses_the_day_before(self):
        decision = decide(self.actor, "episodes:publish", [self.grant], on="2021-06-09")
        self.assertFalse(decision.allowed)

    def test_it_is_not_among_the_person_s_grants_the_day_before(self):
        found = grants_for([self.grant, self.open_ended], "guest-1", "2021-06-09")
        self.assertEqual((), found)

    def test_the_studio_is_not_visible_the_day_before(self):
        found = studios_visible_to([self.grant, self.open_ended], "guest-1", "2021-06-09")
        self.assertEqual((), found)

    def test_a_much_later_grant_waits_as_well(self):
        later = Grant("owner-1", "guest-1", "producer", None, "2022-01-01")
        self.assertFalse(decide(self.actor, "episodes:read", [later], on="2021-06-09").allowed)


class LoggedOutRefreshTests(DomainTestCase):
    """Rule: a refresh token on the blacklist mints nothing; refresh takes ``blacklist``."""

    def setUp(self):
        self.token = TokenClaims("u-1", REFRESH, "2021-05-01T00:00:00Z")

    def test_a_revoked_refresh_token_mints_nothing(self):
        book = Blacklist().with_revoked(self.token)
        with self.assertRaises(DomainError):
            refresh(self.token, "2021-05-02T00:00:00Z", blacklist=book)

    def test_revoking_it_by_its_jti_is_the_same(self):
        book = Blacklist(["other", self.token.jti])
        with self.assertRaises(DomainError):
            refresh(self.token, "2021-05-02T00:00:00Z", blacklist=book)

    def test_an_unrelated_revocation_does_not_get_in_the_way(self):
        minted = refresh(self.token, "2021-05-02T00:00:00Z", blacklist=Blacklist(["other"]))
        self.assertEqual("access", minted.kind)
        self.assertEqual("u-1", minted.subject)

    def test_an_empty_blacklist_does_not_get_in_the_way(self):
        minted = refresh(self.token, "2021-05-02T00:00:00Z", 60, blacklist=Blacklist())
        self.assertEqual(60, minted.ttl_seconds)


class NarrowingOnlyNarrowsTests(DomainTestCase):
    """Rule: narrowing a grant can only take episodes away.

    Asking for more may be refused with a domain error or may quietly keep only
    what the grant already covered; either way nothing new becomes reachable.
    """

    def setUp(self):
        self.grant = Grant("owner-1", "guest-1", "producer", ["e-1", "e-2"])
        self.actor = Actor("guest-1", "producer", "owner-1")

    def assertReachesOnly(self, narrowed, allowed, refused):
        if narrowed is None:
            return
        for episode in allowed:
            self.assertTrue(narrowed.allows("episodes:read", episode), episode)
        for episode in refused:
            self.assertFalse(narrowed.allows("episodes:read", episode), episode)
            decision = decide(self.actor, "episodes:publish", [narrowed], episode_id=episode)
            self.assertFalse(decision.allowed, episode)

    def test_an_episode_the_grant_never_had_stays_out(self):
        narrowed = built_or_refused(self.grant.narrowed_to, ["e-3"])
        self.assertReachesOnly(narrowed, (), ("e-3",))

    def test_an_extra_episode_cannot_slip_in_next_to_a_covered_one(self):
        narrowed = built_or_refused(self.grant.narrowed_to, ["e-1", "e-3"])
        self.assertReachesOnly(narrowed, (), ("e-3", "e-9"))

    def test_a_restricted_grant_does_not_open_every_episode_again(self):
        for request in (None, "*"):
            narrowed = built_or_refused(self.grant.narrowed_to, request)
            self.assertReachesOnly(narrowed, (), ("e-3", "e-9"))
            if narrowed is not None:
                self.assertFalse(narrowed.covers_all_episodes)

    def test_narrowing_twice_does_not_widen_either(self):
        first = self.grant.narrowed_to(["e-1"])
        narrowed = built_or_refused(first.narrowed_to, ["e-1", "e-2"])
        self.assertReachesOnly(narrowed, (), ("e-2",))


class TokenBeforeItsMomentTests(DomainTestCase):
    """Rule: a token is no good before the moment it was issued."""

    def setUp(self):
        self.access = TokenClaims("u-1", ACCESS, "2021-05-01T12:00:00Z")
        self.refresh_token = TokenClaims("u-1", REFRESH, "2021-05-01T12:00:00Z")

    def test_an_access_token_is_not_usable_an_hour_early(self):
        self.assertFalse(is_usable(self.access, "2021-05-01T11:00:00Z"))

    def test_a_refresh_token_is_not_usable_a_day_early(self):
        self.assertFalse(is_usable(self.refresh_token, "2021-04-30T12:00:00Z"))

    def test_a_refresh_token_mints_nothing_an_hour_early(self):
        with self.assertRaises(DomainError):
            refresh(self.refresh_token, "2021-05-01T11:00:00Z")

    def test_a_refresh_token_mints_nothing_a_year_early(self):
        with self.assertRaises(DomainError):
            refresh(self.refresh_token, "2020-05-01T12:00:00Z", blacklist=Blacklist())


class InvitationBeforeItWasSentTests(DomainTestCase):
    """Rule: an invitation can't be opened or accepted before the day it was sent."""

    def setUp(self):
        self.later = Invitation("owner-1", "guest@example.com", "producer", "2021-05-10")

    def test_it_is_not_open_the_day_before(self):
        self.assertFalse(self.later.is_open("2021-05-09"))

    def test_it_cannot_be_accepted_the_day_before(self):
        with self.assertRaises(DomainError):
            self.later.accept("2021-05-09")

    def test_it_cannot_be_redeemed_the_day_before(self):
        with self.assertRaises(DomainError):
            self.later.to_grant("guest-1", "2021-05-09")

    def test_it_is_not_among_the_open_invitations_the_day_before(self):
        from src.domain.access.invitation import open_invitations

        self.assertEqual((), open_invitations([self.later], "2021-05-09"))


class LogoutEndsTheSessionTests(DomainTestCase):
    """Rule: logging out ends everything that came from that refresh token."""

    def setUp(self):
        self.login = TokenClaims("u-1", REFRESH, "2021-05-01T12:00:00Z")
        self.minted = refresh(self.login, "2021-05-01T12:30:00Z")
        self.logged_out = Blacklist().with_revoked(self.login)

    def test_the_access_token_already_minted_stops_working(self):
        self.assertFalse(is_usable(self.minted, "2021-05-01T12:31:00Z", self.logged_out))

    def test_revoking_the_refresh_token_by_its_jti_is_the_same(self):
        book = Blacklist(["other", self.login.jti])
        self.assertFalse(is_usable(self.minted, "2021-05-01T12:31:00Z", book))

    def test_every_access_token_of_that_login_stops_working(self):
        later = refresh(self.login, "2021-05-02T09:00:00Z")
        self.assertFalse(is_usable(later, "2021-05-02T09:01:00Z", self.logged_out))
