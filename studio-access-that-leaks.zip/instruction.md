Studio access leaks in a few places. An owner invited somebody as admin, and after accepting they had the whole platform, users and plans included. Somebody changed how many days their invitation link is valid and the link still passed. A producer the owner added from next month was already working on episodes this week. Narrowing a guest to some episodes gave them an episode they never had. And logging out doesn't log anybody out. We revoke the refresh token, but refresh still mints from it, and the access token the user already has keeps working.

An owner can only hand out what an owner has, whatever way the grant comes in. Editing any part of an invitation link should break it. Nothing should be good before its own start, the same way nothing is good after its end. Narrowing can only take episodes away. Logging out ends everything that came from that refresh token. Refresh should take the blacklist the same way the usable check does, as blacklist.

Things that work today stay as they are. Producer, guest and viewer grants and invitations keep working. The token still survives a decline or a revoke. Refresh without a blacklist still mints, and the errors for an expired token or the wrong kind of token don't change. Another login of the same user isn't touched by a logout. Platform admin is still admin.

Please add tests for every hole.
