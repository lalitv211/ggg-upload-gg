Permissions fall open. Client opens a patient profile and the edit button is on. Users page and clinics page under organization are open for whoever lands there. The permissions hook knows roles named vet, tech and admin, which nobody has, and everyone else gets admin. It also prints the whole user to the console on every render. Super admin is missing things as well.

What a user may do should come from the permissions they hold, never from the name of the role. Default role holds the flat list saved on the user, custom role the ones saved on it with its categories. Nothing known about a user means nothing allowed. Super admin may do everything. Organization permissions, the ones in the organization admin catalogue, belong to org admin only. Clinic admin has every clinic permission and none of the organization's.

Please put the rule in features/permissions/permissionsFor.ts as permissionsFor(user), giving the same fields the hook gives, and let the hook use it. View, edit and delete of patients are the matching patient permissions. Managing appointments is creating or editing them. Prescribing, vaccinations and labs are medical records to create. Weights, reminders, files and tasks go with editing the patient. Assigning owners goes with editing clients. Full admin is managing users.

Vet level by role name has to go. Custom role called Vet assistant with view permissions only is not clinical. Custom role is clinical when it can create medical records, then it may create meetings too. Default roles keep working as they are.

Cancelling an appointment is for whoever holds cancel appointments, the assigned vet and the owner.

Please add tests for all of it.
