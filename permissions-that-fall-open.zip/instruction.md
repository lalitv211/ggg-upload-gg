Permissions fall open. Clients see the edit button on patient profiles. Organization users and clinics pages open to anyone. The permissions hook knows roles vet, tech and admin, which nobody has, gives everyone else admin, and logs the whole user on every render.

What a user may do comes from the permissions they hold, never from the role name. Default role holds the flat list saved on the user, custom role its saved categories. No user, nothing saved, a null list or category means nothing held, never a crash or a fallback to a role table. Super admin may do everything. Org admin always holds the organization admin catalogue, nobody else does, even when saved on another role. Clinic admin has every clinic permission and none of the organization's.

Put the rule in features/permissions/permissionsFor.ts as permissionsFor(user), with the fields the hook gives, and let the hook use it, following user changes. Patient view, edit and delete match their permissions. Managing appointments is creating or editing them. Prescribing, vaccinations and labs are creating medical records. Weights, reminders, files and tasks go with editing patients, assigning owners with editing clients. Full admin is managing users. hasPermission keeps taking the hook's names like manage_appointments, tooltips keep their wording, and both work when pulled off the result.

roleCheck in lib/utils.ts goes by the same rule. Super admin passes it for anything, no user or nothing saved fails it.

Vet level by role name has to go. Custom role Vet assistant with view only is not clinical. Custom role that can create medical records is clinical and may create meetings. Default roles keep their vet level and meetings as they are, whatever they hold.

Cancelling is for whoever holds cancel appointments, the assigned vet and the owner.

Please add tests for all of it.
