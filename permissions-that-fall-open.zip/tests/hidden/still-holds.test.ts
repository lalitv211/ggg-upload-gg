/**
 * Hidden guards: what already holds at the base commit and has to keep holding.
 */
import { describe, expect, it } from 'vitest';
import { canUserCancelAppointment } from '@/features/appointments/utils/canCancelAppointment';
import { roleCheck } from '@/lib/utils';
import { canCreateTelehealthMeeting, getEffectiveRole, isVeterinarianOrStaff } from '@/utils/roleHelpers';

const flat = (role: string, permissions: string[] | undefined, isDefault = true): any => ({
  _uuid: 'user-1',
  id: 'user-1',
  role,
  role_isDefault: isDefault,
  role_permissions: permissions,
});

const custom = (name: string, categories: Record<string, string[]>): any => ({
  _uuid: 'user-1',
  id: 'user-1',
  role: 'custom_role',
  role_name: name,
  role_isDefault: false,
  role_permissions: {
    id: 'role-1',
    admin_controls: [],
    view_access: [],
    create_access: [],
    edit_access: [],
    cancel_access: [],
    delete_access: [],
    ...categories,
  },
});

describe('still holds > default roles are what they were', () => {
  it('a default veterinarian is clinical by its role', () => {
    expect(isVeterinarianOrStaff(flat('veterinarian', []))).toBe(true);
    expect(canCreateTelehealthMeeting(flat('veterinarian', []))).toBe(true);
  });

  it('a default receptionist is staff level but makes no meetings', () => {
    expect(isVeterinarianOrStaff(flat('receptionist', []))).toBe(true);
    expect(canCreateTelehealthMeeting(flat('receptionist', []))).toBe(false);
  });

  it('a client is not clinical', () => {
    expect(isVeterinarianOrStaff(flat('client', []))).toBe(false);
    expect(canCreateTelehealthMeeting(flat('client', []))).toBe(false);
  });

  it('a default receptionist holding create medical records still makes no meetings', () => {
    const desk = flat('receptionist', ['view_patients', 'create_medical_records']);
    expect(isVeterinarianOrStaff(desk)).toBe(true);
    expect(canCreateTelehealthMeeting(desk)).toBe(false);
  });

  it('a default client holding create medical records is still not clinical', () => {
    const owner = flat('client', ['create_medical_records']);
    expect(isVeterinarianOrStaff(owner)).toBe(false);
    expect(canCreateTelehealthMeeting(owner)).toBe(false);
  });

  it('the effective role still prefers the custom name', () => {
    expect(getEffectiveRole(custom('Lead Vet', {}))).toBe('Lead Vet');
    expect(getEffectiveRole(flat('staff', []))).toBe('staff');
  });
});

describe('still holds > who could already cancel', () => {
  const someoneElses = { vet_id: 'vet-9', client_id: 'client-9' };

  it('a custom role called Staff or Receptionist without cancel access may not cancel', () => {
    for (const name of ['Staff', 'Receptionist', 'Front desk staff']) {
      const user = custom(name, { view_access: ['view_appointments', 'view_patients'] });
      expect(canUserCancelAppointment(someoneElses, user)).toBe(false);
    }
  });

  it('a clinic admin may cancel anything', () => {
    expect(canUserCancelAppointment(someoneElses, flat('clinic_admin', ['cancel_appointments']))).toBe(true);
  });

  it('super admin may cancel anything', () => {
    expect(canUserCancelAppointment(someoneElses, flat('super_admin', undefined, false))).toBe(true);
  });

  it('the assigned vet may cancel', () => {
    expect(canUserCancelAppointment({ vet_id: 'user-1' }, flat('veterinarian', ['view_patients']))).toBe(true);
  });

  it('the owner may cancel', () => {
    const own = { vet_id: 'vet-9', pets: { clients: { user_id: 'user-1' } } };
    expect(canUserCancelAppointment(own, flat('client', []))).toBe(true);
  });

  it('the owner may cancel through the nested users record', () => {
    const own = { vet_id: 'vet-9', pets: { clients: { users: { id: 'user-1' } } } };
    expect(canUserCancelAppointment(own, flat('client', []))).toBe(true);
  });

  it('a client who is not the owner may not cancel', () => {
    expect(canUserCancelAppointment(someoneElses, flat('client', []))).toBe(false);
  });

  it('a custom role without cancel access may not cancel', () => {
    expect(canUserCancelAppointment(someoneElses, custom('Desk', { view_access: ['view_appointments'] }))).toBe(false);
  });

  it('nobody cancels without a user or an appointment', () => {
    expect(canUserCancelAppointment(null, flat('clinic_admin', []))).toBe(false);
    expect(canUserCancelAppointment(someoneElses, null)).toBe(false);
  });
});

describe('still holds > the role check', () => {
  it('still honours a default role s flat permissions', () => {
    expect(roleCheck(flat('staff', ['view_patients']), 'view_patients' as never)).toBe(true);
    expect(roleCheck(flat('staff', ['view_patients']), 'manage_users' as never)).toBe(false);
    expect(roleCheck(flat('staff', ['view_patients']), ['manage_users', 'view_patients'] as never)).toBe(true);
  });

  it('still honours a custom role s category', () => {
    const user = custom('Desk', { view_access: ['view_patients'] });
    expect(roleCheck(user, 'view_patients' as never, 'view_access')).toBe(true);
    expect(roleCheck(user, 'view_patients' as never, 'edit_access')).toBe(false);
    expect(roleCheck(user, 'view_patients' as never)).toBe(true);
  });

  it('still tolerates a custom role saved with some categories missing', () => {
    const thin = { ...custom('Thin', {}), role_permissions: { id: 'role-1', view_access: ['view_patients'] } };
    expect(roleCheck(thin, 'view_patients' as never)).toBe(true);
    expect(roleCheck(thin, 'view_patients' as never, 'edit_access')).toBe(false);
    expect(roleCheck(thin, ['edit_patients', 'view_patients'] as never)).toBe(true);
  });

  it('still refuses a custom role with nothing saved', () => {
    expect(roleCheck(flat('custom_role', undefined, false), 'view_patients' as never)).toBe(false);
  });
});
