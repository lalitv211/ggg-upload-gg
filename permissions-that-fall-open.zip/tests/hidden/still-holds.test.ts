/**
 * Hidden guards: what already holds at the base commit and has to keep holding.
 */
import { describe, expect, it } from 'vitest';
import { canUserCancelAppointment } from '@/features/appointments/utils/canCancelAppointment';
import { roleCheck } from '@/lib/utils';
import { canCreateTelehealthMeeting, getEffectiveRole, isVeterinarianOrStaff } from '@/utils/roleHelpers';

const flat = (role: string, permissions: string[] | undefined, isDefault = true): any => ({
  _uuid: 'user-1',
  id: 'user-1',
  role,
  role_isDefault: isDefault,
  role_permissions: permissions,
});

const custom = (name: string, categories: Record<string, string[]>): any => ({
  _uuid: 'user-1',
  id: 'user-1',
  role: 'custom_role',
  role_name: name,
  role_isDefault: false,
  role_permissions: {
    id: 'role-1',
    admin_controls: [],
    view_access: [],
    create_access: [],
    edit_access: [],
    cancel_access: [],
    delete_access: [],
    ...categories,
  },
});

describe('still holds > default roles are what they were', () => {
  it('a default veterinarian is clinical by its role', () => {
    expect(isVeterinarianOrStaff(flat('veterinarian', []))).toBe(true);
    expect(canCreateTelehealthMeeting(flat('veterinarian', []))).toBe(true);
  });

  it('a default receptionist is staff level but makes no meetings', () => {
    expect(isVeterinarianOrStaff(flat('receptionist', []))).toBe(true);
    expect(canCreateTelehealthMeeting(flat('receptionist', []))).toBe(false);
  });

  it('a client is not clinical', () => {
    expect(isVeterinarianOrStaff(flat('client', []))).toBe(false);
    expect(canCreateTelehealthMeeting(flat('client', []))).toBe(false);
  });

  it('a default receptionist holding create medical records still makes no meetings', () => {
    const desk = flat('receptionist', ['view_patients', 'create_medical_records']);
    expect(isVeterinarianOrStaff(desk)).toBe(true);
    expect(canCreateTelehealthMeeting(desk)).toBe(false);
  });

  it('a default client holding create medical records is still not clinical', () => {
    const owner = flat('client', ['create_medical_records']);
    expect(isVeterinarianOrStaff(owner)).toBe(false);
    expect(canCreateTelehealthMeeting(owner)).toBe(false);
  });

  it('the effective role still prefers the custom name', () => {
    expect(getEffectiveRole(custom('Lead Vet', {}))).toBe('Lead Vet');
    expect(getEffectiveRole(flat('staff', []))).toBe('staff');
  });
});

describe('still holds > who could already cancel', () => {
  const someoneElses = { vet_id: 'vet-9', client_id: 'client-9' };

  it('a default staff member without cancel appointments may not cancel another vet s appointment', () => {
    expect(canUserCancelAppointment(someoneElses, flat('staff', ['view_appointments']))).toBe(false);
  });

  it('a default receptionist without cancel appointments may not cancel another vet s appointment', () => {
    expect(canUserCancelAppointment(someoneElses, flat('receptionist', ['view_appointments']))).toBe(false);
  });

  it('a custom role called Staff or Receptionist without cancel access may not cancel', () => {
    for (const name of ['Staff', 'Receptionist', 'Front desk staff']) {
      const user = custom(name, { view_access: ['view_appointments', 'view_patients'] });
      expect(canUserCancelAppointment(someoneElses, user)).toBe(false);
    }
  });

  it('a clinic admin may cancel anything', () => {
    expect(canUserCancelAppointment(someoneElses, flat('clinic_admin', ['cancel_appointments']))).toBe(true);
  });

  it('super admin may cancel anything', () => {
    expect(canUserCancelAppointment(someoneElses, flat('super_admin', undefined, false))).toBe(true);
  });

  it('the assigned vet may cancel', () => {
    expect(canUserCancelAppointment({ vet_id: 'user-1' }, flat('veterinarian', ['view_patients']))).toBe(true);
  });

  it('the owner may cancel', () => {
    const own = { vet_id: 'vet-9', pets: { clients: { user_id: 'user-1' } } };
    expect(canUserCancelAppointment(own, flat('client', []))).toBe(true);
  });

  it('the owner may cancel through the nested users record', () => {
    const own = { vet_id: 'vet-9', pets: { clients: { users: { id: 'user-1' } } } };
    expect(canUserCancelAppointment(own, flat('client', []))).toBe(true);
  });

  it('a client who is not the owner may not cancel', () => {
    expect(canUserCancelAppointment(someoneElses, flat('client', []))).toBe(false);
  });

  it('a custom role without cancel access may not cancel', () => {
    expect(canUserCancelAppointment(someoneElses, custom('Desk', { view_access: ['view_appointments'] }))).toBe(false);
  });

  it('nobody cancels without a user or an appointment', () => {
    expect(canUserCancelAppointment(null, flat('clinic_admin', []))).toBe(false);
    expect(canUserCancelAppointment(someoneElses, null)).toBe(false);
  });
});

describe('still holds > the role check', () => {
  it('still honours a default role s flat permissions', () => {
    expect(roleCheck(flat('staff', ['view_patients']), 'view_patients' as never)).toBe(true);
    expect(roleCheck(flat('staff', ['view_patients']), 'manage_users' as never)).toBe(false);
    expect(roleCheck(flat('staff', ['view_patients']), ['manage_users', 'view_patients'] as never)).toBe(true);
  });

  it('still honours a custom role s category', () => {
    const user = custom('Desk', { view_access: ['view_patients'] });
    expect(roleCheck(user, 'view_patients' as never, 'view_access')).toBe(true);
    expect(roleCheck(user, 'view_patients' as never, 'edit_access')).toBe(false);
    expect(roleCheck(user, 'view_patients' as never)).toBe(true);
  });

  it('still tolerates a custom role saved with some categories missing', () => {
    const thin = { ...custom('Thin', {}), role_permissions: { id: 'role-1', view_access: ['view_patients'] } };
    expect(roleCheck(thin, 'view_patients' as never)).toBe(true);
    expect(roleCheck(thin, 'view_patients' as never, 'edit_access')).toBe(false);
    expect(roleCheck(thin, ['edit_patients', 'view_patients'] as never)).toBe(true);
  });

  it('still refuses a custom role with nothing saved', () => {
    expect(roleCheck(flat('custom_role', undefined, false), 'view_patients' as never)).toBe(false);
  });
});

describe('still holds > vet level and meetings beyond the role name', () => {
  it('a default televet keeps vet level and may create meetings', () => {
    const televet = { ...flat('televet', ['view_patients', 'create_medical_records']), role_name: 'Televet' };
    expect(isVeterinarianOrStaff(televet)).toBe(true);
    expect(canCreateTelehealthMeeting(televet)).toBe(true);
  });

  it('no user may create meetings', () => {
    expect(canCreateTelehealthMeeting(null)).toBe(false);
  });

  it('a default org admin is not clinical, whatever it holds', () => {
    expect(isVeterinarianOrStaff(flat('org_admin', ['view_patients', 'create_medical_records']))).toBe(false);
    expect(canCreateTelehealthMeeting(flat('org_admin', ['create_medical_records']))).toBe(false);
  });

  it('a custom role with nothing or little saved is not clinical and does not crash the helpers', () => {
    const empty = { ...custom('Blank', {}), role_permissions: undefined };
    const thin = { ...custom('Thin', {}), role_permissions: { id: 'role-1', view_access: ['view_patients'] } };
    expect(isVeterinarianOrStaff(empty)).toBe(false);
    expect(canCreateTelehealthMeeting(empty)).toBe(false);
    expect(isVeterinarianOrStaff(thin)).toBe(false);
    expect(canCreateTelehealthMeeting(thin)).toBe(false);
  });

  it('editing medical records, editing or creating appointments do not make a custom role clinical', () => {
    expect(isVeterinarianOrStaff(custom('Scribe', { edit_access: ['edit_medical_records'] }))).toBe(false);
    expect(canCreateTelehealthMeeting(custom('Scribe', { edit_access: ['edit_medical_records'] }))).toBe(false);
    expect(canCreateTelehealthMeeting(custom('Scheduler', { edit_access: ['edit_appointments'] }))).toBe(false);
    expect(isVeterinarianOrStaff(custom('Front desk', { create_access: ['create_appointments'] }))).toBe(false);
  });
});

describe('still holds > the role check callers rely on', () => {
  it('honours a default role s flat list when a category is named', () => {
    expect(roleCheck(flat('veterinarian', ['edit_patients']), 'edit_patients' as never, 'edit_access')).toBe(true);
    expect(roleCheck(flat('staff', ['create_appointments']), 'create_appointments' as never, 'create_access')).toBe(true);
    expect(roleCheck(flat('veterinarian', ['view_patients']), 'edit_patients' as never, 'edit_access')).toBe(false);
  });

  it('gives a clinic admin no organisation permission', () => {
    expect(roleCheck(flat('clinic_admin', ['view_patients']), 'view_all_clinics' as never)).toBe(false);
    expect(roleCheck(flat('clinic_admin', ['view_patients']), 'edit_organization' as never)).toBe(false);
  });
});

describe('still holds > cancelling beyond the usual fixtures', () => {
  const someoneElses = { vet_id: 'vet-9', client_id: 'client-9' };
  const ownedByUser = { vet_id: 'vet-9', pets: { clients: { user_id: 'user-1' } } };

  it('the assigned vet and the owner are matched on the users-table id, not the auth id', () => {
    expect(canUserCancelAppointment(ownedByUser, { ...flat('client', []), id: 'auth-1' })).toBe(true);
    expect(canUserCancelAppointment({ vet_id: 'user-1' }, { ...flat('veterinarian', ['view_patients']), id: 'auth-1' })).toBe(true);
    expect(canUserCancelAppointment({ vet_id: 'auth-1' }, { ...flat('veterinarian', ['view_patients']), id: 'auth-1' })).toBe(false);
  });

  it('a vet who is not assigned and holds no cancel permission may not cancel', () => {
    expect(canUserCancelAppointment(someoneElses, flat('veterinarian', ['view_patients']))).toBe(false);
    expect(canUserCancelAppointment(someoneElses, custom('Clinician', { create_access: ['create_medical_records'] }))).toBe(false);
  });

  it('the assigned vet may cancel whatever role it has', () => {
    expect(canUserCancelAppointment({ vet_id: 'user-1' }, custom('Locum', { view_access: ['view_appointments'] }))).toBe(true);
  });

  it('the owner may cancel whatever role it has', () => {
    expect(canUserCancelAppointment(ownedByUser, custom('Desk', { view_access: ['view_appointments'] }))).toBe(true);
    expect(canUserCancelAppointment(ownedByUser, flat('staff', ['view_appointments']))).toBe(true);
  });

  it('creating appointments does not let a custom role create meetings', () => {
    expect(canCreateTelehealthMeeting(custom('Front desk', { create_access: ['create_appointments'] }))).toBe(false);
  });
});

describe('still holds > org admin through the role check', () => {
  it('an org admin passes no clinic check its row lacks', () => {
    expect(roleCheck(flat('org_admin', []), 'view_patients' as never)).toBe(false);
    expect(roleCheck(flat('org_admin', ['view_patients']), 'edit_patients' as never)).toBe(false);
  });
});

describe('still holds > what does not let anyone cancel', () => {
  const someoneElses = { vet_id: 'vet-9', client_id: 'client-9' };

  it('creating or editing appointments is not cancelling them', () => {
    expect(canUserCancelAppointment(someoneElses, custom('Scheduler', { create_access: ['create_appointments'], edit_access: ['edit_appointments'] }))).toBe(false);
    expect(canUserCancelAppointment(someoneElses, flat('staff', ['view_appointments', 'create_appointments', 'edit_appointments']))).toBe(false);
  });

  it('managing users is not cancelling appointments', () => {
    expect(canUserCancelAppointment(someoneElses, custom('Office lead', { admin_controls: ['manage_users'] }))).toBe(false);
  });

  it('an org admin whose row lacks the cancel permission may not cancel', () => {
    expect(canUserCancelAppointment(someoneElses, flat('org_admin', []))).toBe(false);
  });

  it('a custom role with little or nothing saved is refused without a crash', () => {
    expect(canUserCancelAppointment(someoneElses, { ...custom('Thin', {}), role_permissions: { id: 'role-1', view_access: ['view_appointments'] } })).toBe(false);
    expect(canUserCancelAppointment(someoneElses, { ...custom('Blank', {}), role_permissions: undefined })).toBe(false);
  });

  it('default staff and clinic admin may still create meetings', () => {
    expect(canCreateTelehealthMeeting(flat('staff', []))).toBe(true);
    expect(canCreateTelehealthMeeting(flat('clinic_admin', []))).toBe(true);
  });
});
