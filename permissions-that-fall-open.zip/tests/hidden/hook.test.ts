/**
 * Hidden tests: the permissions hook itself, called under node with useAuth and React's hooks
 * stood in. The hook answers from what the signed-in user holds: a client or an unknown role gets
 * nothing, a default role gets its row, a custom role gets what was saved on it, and nothing is
 * printed to the console on the way.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const auth = vi.hoisted(() => ({ user: null as any }));

vi.mock('@/hooks/useAuth', () => ({
  useAuth: () => ({ user: auth.user, loading: false, session: null }),
}));

vi.mock('react', async (importActual) => {
  const actual = (await importActual()) as Record<string, unknown>;
  return {
    ...actual,
    useMemo: (compute: () => unknown) => compute(),
    useCallback: (callback: unknown) => callback,
    useRef: (value: unknown) => ({ current: value }),
    useState: (value: unknown) => [typeof value === 'function' ? (value as () => unknown)() : value, () => undefined],
    useEffect: () => undefined,
  };
});

import { usePermissions } from '@/hooks/usePermissions';

const flat = (role: string, permissions: string[] | undefined, isDefault = true): any => ({
  _uuid: 'user-1',
  id: 'user-1',
  role,
  role_isDefault: isDefault,
  role_permissions: permissions,
});

const custom = (name: string, categories: Record<string, string[]>): any => ({
  _uuid: 'user-1',
  id: 'user-1',
  role: 'custom_role',
  role_name: name,
  role_isDefault: false,
  role_permissions: {
    id: 'role-1',
    admin_controls: [],
    view_access: [],
    create_access: [],
    edit_access: [],
    cancel_access: [],
    delete_access: [],
    ...categories,
  },
});

const hook = (user: any) => {
  auth.user = user;
  return usePermissions();
};

describe('hook > the permissions hook answers from what the user holds', () => {
  beforeEach(() => {
    vi.spyOn(console, 'log').mockImplementation(() => undefined);
  });
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('a client holding nothing cannot edit patients', () => {
    const rights = hook(flat('client', []));
    expect(rights.canEdit).toBe(false);
    expect(rights.canView).toBe(false);
    expect(rights.isFullAdmin).toBe(false);
  });

  it('a role the hook has never heard of gets nothing', () => {
    const rights = hook(flat('intern', undefined, false));
    expect(rights.canView).toBe(false);
    expect(rights.canEdit).toBe(false);
    expect(rights.isFullAdmin).toBe(false);
    expect(rights.hasPermission('create_clinics')).toBe(false);
  });

  it('no user at all gets nothing', () => {
    const rights = hook(null);
    expect(rights.canView).toBe(false);
    expect(rights.hasPermission('edit_organization')).toBe(false);
  });

  it('a custom role is what was saved on it', () => {
    const rights = hook(custom('Nurse', { edit_access: ['edit_patients'] }));
    expect(rights.canEdit).toBe(true);
    expect(rights.canDelete).toBe(false);
    expect(rights.hasPermission('view_all_clinics')).toBe(false);
  });

  it('a custom role saved with some categories missing still answers', () => {
    const thin = { ...custom('Thin', {}), role_permissions: { id: 'role-1', edit_access: ['edit_patients'] } };
    const rights = hook(thin);
    expect(rights.canEdit).toBe(true);
    expect(rights.canView).toBe(false);
  });

  it('a default veterinarian saved with view patients only gets viewing and nothing more', () => {
    const vet = hook(flat('veterinarian', ['view_patients']));
    expect(vet.canView).toBe(true);
    expect(vet.canEdit).toBe(false);
    expect(vet.canDelete).toBe(false);
    expect(vet.canPrescribeMedications).toBe(false);
    expect(vet.canManageLabs).toBe(false);
    expect(vet.canManageVaccinations).toBe(false);
  });

  it('the tooltip explains a right the user lacks', () => {
    const rights = hook(flat('client', []));
    expect(rights.getPermissionTooltip('edit_patients').length).toBeGreaterThan(0);
    expect(hook(flat('staff', ['edit_patients'])).getPermissionTooltip('edit_patients')).toBe('');
  });

  it('the hook prints nothing to the console', () => {
    hook(flat('veterinarian', ['view_patients']));
    hook(custom('Nurse', { edit_access: ['edit_patients'] }));
    expect(console.log).not.toHaveBeenCalled();
  });
});
