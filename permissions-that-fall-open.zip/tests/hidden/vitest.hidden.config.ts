// Grader copy of apps/web/vitest.config.ts: the same node environment, defines and alias, but it
// collects only the grader's own test folders, so that the repository's config has no say in the run.
import path from 'path';
import { defineConfig } from 'vitest/config';

export default defineConfig({
  define: {
    'import.meta.env.VITE_SUPABASE_URL': JSON.stringify('http://127.0.0.1:54321'),
    'import.meta.env.VITE_SUPABASE_ANON_KEY': JSON.stringify('test-anon-key'),
  },
  test: {
    environment: 'node',
    include: ['src/__tests__/hidden/**/*.test.ts', 'src/__tests__/hidden-pristine/**/*.test.ts'],
    reporters: ['default'],
    fileParallelism: false,
    testTimeout: 20000,
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
});
