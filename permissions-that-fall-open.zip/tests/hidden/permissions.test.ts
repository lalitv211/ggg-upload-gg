/**
 * Hidden tests: what a user may do comes from the permissions they hold.
 *
 * permissionsFor(user) gives the same fields the permissions hook gives. A default role holds a
 * flat list of catalogue permissions, a custom role holds them by category. Nothing known means
 * nothing allowed, super admin may do everything, organisation permissions belong to org admin.
 * Vet level is never read from a role's name, and cancelling goes by the cancel permission.
 */
import { describe, expect, it } from 'vitest';
import * as permissionModule from '@/features/permissions/permissionsFor';
import { canUserCancelAppointment } from '@/features/appointments/utils/canCancelAppointment';
import { roleCheck } from '@/lib/utils';
import { canCreateTelehealthMeeting, isVeterinarianOrStaff } from '@/utils/roleHelpers';

const flat = (role: string, permissions: string[] | undefined, isDefault = true): any => ({
  _uuid: 'user-1',
  id: 'user-1',
  role,
  role_isDefault: isDefault,
  role_permissions: permissions,
});

const custom = (name: string, categories: Record<string, string[]>): any => ({
  _uuid: 'user-1',
  id: 'user-1',
  role: 'custom_role',
  role_name: name,
  role_isDefault: false,
  role_permissions: {
    id: 'role-1',
    admin_controls: [],
    view_access: [],
    create_access: [],
    edit_access: [],
    cancel_access: [],
    delete_access: [],
    ...categories,
  },
});

const ALL_CLINIC = [
  'manage_users', 'export_data', 'manage_roles', 'manage_schedules', 'manage_products_services',
  'clinic_settings', 'process_payments', 'messages',
  'view_patients', 'view_appointments', 'view_billing', 'view_medical_records', 'view_reports',
  'view_clients', 'view_own_schedule', 'view_all_schedules',
  'create_patients', 'create_appointments', 'create_invoices', 'create_medical_records',
  'create_clients', 'create_schedules',
  'edit_patients', 'edit_appointments', 'edit_medical_records', 'edit_clients', 'edit_own_schedule',
  'edit_all_schedules', 'cancel_appointments', 'delete_patients', 'delete_clients', 'delete_schedules',
];

const mod: any = permissionModule;

// The rule may answer a single permission as a method on what permissionsFor returns or as its
// own exported function taking the user; both shapes are read here.
const p = (user: any) => {
  const rights = mod.permissionsFor(user);
  const lookup = ['hasPermission', 'userHasPermission', 'hasPermissionFor', 'can', 'holds'].find(
    (name) => typeof mod[name] === 'function'
  );
  return {
    ...rights,
    hasPermission: (permission: string) =>
      typeof rights.hasPermission === 'function'
        ? rights.hasPermission(permission)
        : lookup
          ? mod[lookup](user, permission)
          : rights.hasPermission(permission),
  };
};

describe('permissions > nothing known means nothing allowed', () => {
  it('a client holding no permissions may do nothing', () => {
    const rights = p(flat('client', []));
    expect(rights.canView).toBe(false);
    expect(rights.canEdit).toBe(false);
    expect(rights.canDelete).toBe(false);
    expect(rights.canManageAppointments).toBe(false);
    expect(rights.isFullAdmin).toBe(false);
    expect(rights.hasPermission('view_patients')).toBe(false);
    expect(rights.hasPermission('view_all_clinics')).toBe(false);
  });

  it('a role the app has never heard of gets nothing', () => {
    const rights = p(flat('intern', undefined, false));
    expect(rights.canView).toBe(false);
    expect(rights.canEdit).toBe(false);
    expect(rights.isFullAdmin).toBe(false);
    expect(rights.hasPermission('edit_clinics')).toBe(false);
  });

  it('no user at all gets nothing', () => {
    expect(p(null).canView).toBe(false);
    expect(p(undefined).hasPermission('view_patients')).toBe(false);
    expect(p(undefined).isFullAdmin).toBe(false);
  });
});

describe('permissions > each right follows the permission the prompt names', () => {
  it('viewing patients gives viewing and nothing more', () => {
    const rights = p(custom('Viewer', { view_access: ['view_patients'] }));
    expect(rights.canView).toBe(true);
    expect(rights.canEdit).toBe(false);
    expect(rights.canDelete).toBe(false);
    expect(rights.canManageAppointments).toBe(false);
    expect(rights.hasPermission('view_patients')).toBe(true);
    expect(rights.hasPermission('edit_patients')).toBe(false);
  });

  it('editing patients gives editing, weights, reminders, files and tasks', () => {
    const rights = p(custom('Nurse', { edit_access: ['edit_patients'] }));
    expect(rights.canEdit).toBe(true);
    expect(rights.canAddWeights).toBe(true);
    expect(rights.canManageReminders).toBe(true);
    expect(rights.canManageFiles).toBe(true);
    expect(rights.canCreateTasks).toBe(true);
    expect(rights.canDelete).toBe(false);
  });

  it('deleting patients gives deleting', () => {
    const rights = p(custom('Archivist', { delete_access: ['delete_patients'] }));
    expect(rights.canDelete).toBe(true);
    expect(rights.hasPermission('delete_patients')).toBe(true);
  });

  it('creating or editing appointments gives managing them', () => {
    expect(p(custom('Booker', { create_access: ['create_appointments'] })).canManageAppointments).toBe(true);
    expect(p(custom('Fixer', { edit_access: ['edit_appointments'] })).canManageAppointments).toBe(true);
    expect(p(custom('Watcher', { view_access: ['view_appointments'] })).canManageAppointments).toBe(false);
  });

  it('creating medical records gives prescribing, vaccinations and labs', () => {
    const rights = p(custom('Clinician', { create_access: ['create_medical_records'] }));
    expect(rights.canPrescribeMedications).toBe(true);
    expect(rights.canManageVaccinations).toBe(true);
    expect(rights.canManageLabs).toBe(true);
    const viewer = p(custom('Reader', { view_access: ['view_medical_records'] }));
    expect(viewer.canPrescribeMedications).toBe(false);
    expect(viewer.canManageVaccinations).toBe(false);
    expect(viewer.canManageLabs).toBe(false);
  });

  it('editing clients gives assigning owners', () => {
    expect(p(custom('Desk', { edit_access: ['edit_clients'] })).canAssignOwners).toBe(true);
    expect(p(custom('Desk', { view_access: ['view_clients'] })).canAssignOwners).toBe(false);
  });

  it('managing users is full admin', () => {
    const lead = p(custom('Office lead', { admin_controls: ['manage_users'] }));
    expect(lead.isFullAdmin).toBe(true);
    expect(p(custom('Nurse', { view_access: ['view_patients'], edit_access: ['edit_patients'] })).isFullAdmin).toBe(false);
  });
});

describe('permissions > a custom role holds what was saved on it', () => {
  it('a custom role with view access only may view and nothing more', () => {
    const rights = p(custom('Vet assistant', { view_access: ['view_patients'] }));
    expect(rights.canView).toBe(true);
    expect(rights.canEdit).toBe(false);
    expect(rights.canPrescribeMedications).toBe(false);
    expect(rights.canManageAppointments).toBe(false);
    expect(rights.isFullAdmin).toBe(false);
  });

  it('a custom role with create access to medical records may prescribe', () => {
    const rights = p(custom('Clinician', { create_access: ['create_medical_records'] }));
    expect(rights.canPrescribeMedications).toBe(true);
    expect(rights.canManageVaccinations).toBe(true);
  });

  it('a custom role with nothing saved on it gets nothing', () => {
    const rights = p(flat('custom_role', undefined, false));
    expect(rights.canView).toBe(false);
    expect(rights.canEdit).toBe(false);
    expect(rights.isFullAdmin).toBe(false);
  });
});

describe('permissions > a default role holds the permissions of its row', () => {
  it('a clinic admin with its row holds every clinic permission and no organisation one', () => {
    const rights = p(flat('clinic_admin', ALL_CLINIC));
    expect(rights.hasPermission('view_patients')).toBe(true);
    expect(rights.hasPermission('delete_patients')).toBe(true);
    expect(rights.hasPermission('view_organization')).toBe(false);
  });
});

describe('permissions > organisation rights', () => {
  it('org admin holds the organisation catalogue', () => {
    const rights = p(flat('org_admin', ALL_CLINIC));
    expect(rights.hasPermission('view_all_clinics')).toBe(true);
    expect(rights.hasPermission('create_clinics')).toBe(true);
    expect(rights.hasPermission('manage_subscription')).toBe(true);
    expect(rights.hasPermission('edit_organization')).toBe(true);
    expect(rights.hasPermission('transfer_users')).toBe(true);
  });

  it('clinic admin holds every clinic permission and none of the organisation s', () => {
    const rights = p(flat('clinic_admin', ALL_CLINIC));
    expect(rights.isFullAdmin).toBe(true);
    expect(rights.canDelete).toBe(true);
    expect(rights.canPrescribeMedications).toBe(true);
    expect(rights.hasPermission('view_all_clinics')).toBe(false);
    expect(rights.hasPermission('manage_subscription')).toBe(false);
    expect(rights.hasPermission('edit_organization')).toBe(false);
  });

  it('a veterinarian has no organisation rights', () => {
    const rights = p(flat('veterinarian', ['view_patients', 'create_medical_records']));
    expect(rights.hasPermission('view_organization')).toBe(false);
    expect(rights.hasPermission('view_all_users')).toBe(false);
  });

  it('super admin may do everything', () => {
    const rights = p(flat('super_admin', undefined, false));
    expect(rights.canDelete).toBe(true);
    expect(rights.isFullAdmin).toBe(true);
    expect(rights.canPrescribeMedications).toBe(true);
    expect(rights.hasPermission('create_clinics')).toBe(true);
  });

  it('super admin passes the role check for anything', () => {
    const admin = flat('super_admin', undefined, false);
    expect(roleCheck(admin, 'manage_users' as never)).toBe(true);
    expect(roleCheck(admin, 'view_patients' as never, 'view_access')).toBe(true);
    expect(roleCheck(admin, ['create_appointments', 'edit_appointments'] as never)).toBe(true);
  });
});

describe('permissions > vet level is not read from the role name', () => {
  it('a custom role called Vet assistant with view access only is not clinical', () => {
    const user = custom('Vet assistant', { view_access: ['view_patients'] });
    expect(isVeterinarianOrStaff(user)).toBe(false);
    expect(canCreateTelehealthMeeting(user)).toBe(false);
  });

  it('a custom role called Televet with view access only is not clinical', () => {
    const user = custom('Televet', { view_access: ['view_patients', 'view_medical_records'] });
    expect(isVeterinarianOrStaff(user)).toBe(false);
    expect(canCreateTelehealthMeeting(user)).toBe(false);
  });

  it('a custom role that can create medical records is clinical whatever its name', () => {
    const user = custom('Clinician', { create_access: ['create_medical_records'] });
    expect(isVeterinarianOrStaff(user)).toBe(true);
    expect(canCreateTelehealthMeeting(user)).toBe(true);
  });
});

describe('permissions > cancelling goes by the cancel permission', () => {
  const someoneElses = { vet_id: 'vet-9', client_id: 'client-9' };

  it('a receptionist holding cancel appointments may cancel another vet s appointment', () => {
    expect(canUserCancelAppointment(someoneElses, flat('receptionist', ['cancel_appointments']))).toBe(true);
  });

  it('a staff member holding cancel appointments may cancel', () => {
    expect(canUserCancelAppointment(someoneElses, flat('staff', ['view_appointments', 'cancel_appointments']))).toBe(true);
  });

  it('a custom role with cancel access may cancel', () => {
    expect(canUserCancelAppointment(someoneElses, custom('Desk', { cancel_access: ['cancel_appointments'] }))).toBe(true);
  });
});
