/**
 * Build check: every module the change touches still loads under node.
 */
import { describe, expect, it } from 'vitest';

describe('load > the permission modules load', () => {
  it('loads the permission rule, the role helpers, the cancel check and the role check', async () => {
    const modules = await Promise.all([
      import('@/features/permissions/permissionsFor'),
      import('@/features/permissions/orgAdminPermissions'),
      import('@/utils/roleHelpers'),
      import('@/features/appointments/utils/canCancelAppointment'),
      import('@/lib/utils'),
    ]);
    for (const loaded of modules) {
      expect(typeof loaded).toBe('object');
    }
  });
});
