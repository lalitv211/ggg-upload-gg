/**
 * Hidden tests: the permissions hook is built from permissionsFor, as the description asks, and
 * does not keep a second copy of the rule. permissionsFor is wrapped so every call still reaches the
 * real rule; the tests then check that the hook asks it about the signed-in user and hands back what
 * it answers.
 */
import { afterEach, describe, expect, it, vi } from 'vitest';

const auth = vi.hoisted(() => ({ user: null as any }));

vi.mock('@/hooks/useAuth', () => ({
  useAuth: () => ({ user: auth.user, loading: false, session: null }),
}));

vi.mock('react', async (importActual) => {
  const actual = (await importActual()) as Record<string, unknown>;
  return {
    ...actual,
    useMemo: (compute: () => unknown) => compute(),
    useCallback: (callback: unknown) => callback,
    useRef: (value: unknown) => ({ current: value }),
    useState: (value: unknown) => [typeof value === 'function' ? (value as () => unknown)() : value, () => undefined],
    useEffect: () => undefined,
  };
});

vi.mock('@/features/permissions/permissionsFor', async (importActual) => {
  const actual = (await importActual()) as Record<string, any>;
  return { ...actual, permissionsFor: vi.fn(actual.permissionsFor) };
});

import * as rule from '@/features/permissions/permissionsFor';
import { usePermissions } from '@/hooks/usePermissions';

const spy = (rule as any).permissionsFor as ReturnType<typeof vi.fn>;
const real = spy.getMockImplementation()!;

const flat = (role: string, permissions: string[] | undefined): any => ({
  _uuid: 'user-1',
  id: 'user-1',
  role,
  role_isDefault: true,
  role_permissions: permissions,
});

const hook = (user: any) => {
  auth.user = user;
  return usePermissions() as any;
};

afterEach(() => {
  spy.mockClear();
  spy.mockImplementation(real);
});

describe('hook rule > the hook is built from permissionsFor', () => {
  it('asks permissionsFor about the signed-in user', () => {
    const user = flat('veterinarian', ['view_patients', 'edit_patients']);
    hook(user);
    expect(spy).toHaveBeenCalled();
    expect(spy.mock.calls.some(([asked]) => asked === user || asked?.id === user.id)).toBe(true);
  });

  it('gives what permissionsFor answers, not a rule of its own', () => {
    const client = flat('client', []);
    spy.mockImplementation((user: any) => ({ ...real(user), canEdit: true }));
    expect(hook(client).canEdit).toBe(true);

    const vet = flat('veterinarian', ['view_patients', 'edit_patients', 'delete_patients']);
    spy.mockImplementation((user: any) => ({ ...real(user), canDelete: false }));
    expect(hook(vet).canDelete).toBe(false);
  });
});
