/**
 * Hidden tests: the permissions hook follows the signed-in user. React's useMemo is stood in by a
 * version that keeps its value until a dependency changes (compared with Object.is), as React does,
 * so a hook memoised on the wrong dependencies keeps answering for the user it saw first.
 */
import { describe, expect, it, vi } from 'vitest';

const auth = vi.hoisted(() => ({ user: null as any }));
const memo = vi.hoisted(() => ({ deps: undefined as unknown[] | undefined, value: undefined as unknown }));

vi.mock('@/hooks/useAuth', () => ({
  useAuth: () => ({ user: auth.user, loading: false, session: null }),
}));

vi.mock('react', async (importActual) => {
  const actual = (await importActual()) as Record<string, unknown>;
  return {
    ...actual,
    useMemo: (compute: () => unknown, deps?: unknown[]) => {
      const same =
        deps !== undefined &&
        memo.deps !== undefined &&
        deps.length === memo.deps.length &&
        deps.every((dep, i) => Object.is(dep, memo.deps![i]));
      if (!same) {
        memo.value = compute();
        memo.deps = deps;
      }
      return memo.value;
    },
    useCallback: (callback: unknown) => callback,
    useRef: (value: unknown) => ({ current: value }),
    useState: (value: unknown) => [typeof value === 'function' ? (value as () => unknown)() : value, () => undefined],
    useEffect: () => undefined,
  };
});

import { usePermissions } from '@/hooks/usePermissions';

const flat = (role: string, permissions: string[] | undefined): any => ({
  _uuid: 'user-1',
  id: 'user-1',
  role,
  role_isDefault: true,
  role_permissions: permissions,
});

const hook = (user: any) => {
  auth.user = user;
  return usePermissions() as any;
};

describe('hook memo > the hook follows the signed-in user', () => {
  it('answers for the new user after sign-in and after the saved permissions change', () => {
    expect(hook(null).canEdit).toBe(false);
    expect(hook(flat('staff', [])).canEdit).toBe(false);
    expect(hook(flat('staff', ['edit_patients'])).canEdit).toBe(true);
    expect(hook(null).canEdit).toBe(false);
    const superAdmin = { _uuid: 'user-2', id: 'user-2', role: 'super_admin', role_isDefault: false, role_permissions: undefined };
    expect(hook(superAdmin).canEdit).toBe(true);
  });
});
