/**
 * Hidden guards: what the permissions hook already answered right at the base commit.
 */
import { describe, expect, it, vi } from 'vitest';

const auth = vi.hoisted(() => ({ user: null as any }));

vi.mock('@/hooks/useAuth', () => ({
  useAuth: () => ({ user: auth.user, loading: false, session: null }),
}));

vi.mock('react', async (importActual) => {
  const actual = (await importActual()) as Record<string, unknown>;
  return {
    ...actual,
    useMemo: (compute: () => unknown) => compute(),
    useCallback: (callback: unknown) => callback,
    useRef: (value: unknown) => ({ current: value }),
    useState: (value: unknown) => [typeof value === 'function' ? (value as () => unknown)() : value, () => undefined],
    useEffect: () => undefined,
  };
});

import { usePermissions } from '@/hooks/usePermissions';

const ALL_CLINIC = [
  'manage_users', 'export_data', 'manage_roles', 'manage_schedules', 'manage_products_services',
  'clinic_settings', 'process_payments', 'messages',
  'view_patients', 'view_appointments', 'view_billing', 'view_medical_records', 'view_reports',
  'view_clients', 'view_own_schedule', 'view_all_schedules',
  'create_patients', 'create_appointments', 'create_invoices', 'create_medical_records',
  'create_clients', 'create_schedules',
  'edit_patients', 'edit_appointments', 'edit_medical_records', 'edit_clients', 'edit_own_schedule',
  'edit_all_schedules', 'cancel_appointments', 'delete_patients', 'delete_clients', 'delete_schedules',
];

const hook = (user: any) => {
  auth.user = user;
  return usePermissions();
};

describe('hook guards > what the hook already got right', () => {
  it('org admin may manage clinics through the hook', () => {
    const rights = hook({ _uuid: 'user-1', id: 'user-1', role: 'org_admin', role_isDefault: true, role_permissions: ALL_CLINIC });
    expect(rights.hasPermission('view_all_clinics')).toBe(true);
    expect(rights.hasPermission('create_clinics')).toBe(true);
    expect(rights.hasPermission('manage_subscription')).toBe(true);
  });

  it('the tooltip stays empty for an organisation permission org admin holds', () => {
    const rights = hook({ _uuid: 'user-1', id: 'user-1', role: 'org_admin', role_isDefault: true, role_permissions: ALL_CLINIC });
    expect(rights.getPermissionTooltip('create_clinics')).toBe('');
    expect(rights.getPermissionTooltip('view_all_clinics')).toBe('');
  });

  it('the hook keeps its full set of flags', () => {
    const rights = hook({ _uuid: 'user-1', id: 'user-1', role: 'clinic_admin', role_isDefault: true, role_permissions: ALL_CLINIC });
    for (const flag of ['canView', 'canEdit', 'canDelete', 'canManageAppointments', 'canManageReminders', 'canAddWeights', 'canManageLabs', 'canPrescribeMedications', 'canManageVaccinations', 'canManageFiles', 'canCreateTasks', 'canAssignOwners', 'isFullAdmin']) {
      expect(typeof (rights as any)[flag]).toBe('boolean');
    }
    expect(typeof rights.hasPermission).toBe('function');
    expect(typeof rights.getPermissionTooltip).toBe('function');
  });
});
