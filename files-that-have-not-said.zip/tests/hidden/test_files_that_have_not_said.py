"""The files page promises checks and surveys the file commands keep.

``docs/files.md`` says a file with no claims is a file that has not
said, that a survey stops at nothing, and that a file is read as the
builder wrote it. The commands did not keep those promises:
``verdict`` called a file with nothing recomputed agreed, a survey
stopped at the first instrument it could not read and misreported the
line, ``census`` counted spellings as temperaments, ``convert`` wrote
before it refused, and a file that was not UTF-8 ended in a
traceback.

Every rule here is checked through ``run`` and the text it returns,
on files written under ``tmp_path`` (and the shipped examples where a
rule is about them). Only what the rule fixes is asserted: messages,
where a reason is printed, and the exit code of a survey with an
unreadable instrument are left to the change. Tables are read by
their first word, and the survey's columns are found by their
heading, so a column can sit wherever the change puts it.
"""

from __future__ import annotations

import pathlib
import re
import traceback

import pytest

from wolf.cli.main import run

ROOT = pathlib.Path(__file__).resolve().parent.parent
CATHEDRAL = str(ROOT / "examples" / "cathedral.stops")

#: The commands that read an instrument file.
FILE_COMMANDS = ["show", "claims", "verdict", "spec", "convert",
                 "survey", "census"]

#: Characters ``str.splitlines`` treats as line ends that a file does
#: not: a line ends at a newline only.
NOT_NEWLINES = {
    "form-feed": "\x0c",
    "u2028": "\u2028",
    "u2029": "\u2029",
    "u0085": "\x85",
    "u001c": "\x1c",
}


# ---------------------------------------------------------------- helpers


def ask(argv):
    """``run``, with an exception that escapes it turned into a
    failing answer so the assertion that follows fails cleanly."""

    try:
        return run([str(one) for one in argv])
    except Exception:  # noqa: BLE001 - the traceback is the finding
        return -1, traceback.format_exc()


def put(tmp_path, text, name="organ.stops"):
    """A file with exactly this text, as UTF-8, newlines untouched."""

    path = tmp_path / name
    path.write_bytes(text.encode("utf-8"))
    return str(path)


def figure_part(text):
    """The lines of a report's Figure part."""

    lines = text.splitlines()
    assert "Figure" in lines, text
    start = lines.index("Figure") + 1
    end = lines.index("Working") if "Working" in lines[start:] \
        else len(lines)
    return lines[start:end]


def heading_and_rows(text):
    """A table's heading words and its row lines."""

    part = [line for line in figure_part(text)
            if line.strip() and set(line.strip()) - {"-", " "}]
    assert part, text
    return part[0].split(), part[1:]


def cell(text, title, heading):
    """One survey cell: the row that starts with ``title``, under the
    column headed ``heading``."""

    headings, rows = heading_and_rows(text)
    assert heading in headings, (heading, text)
    found = [line for line in rows
             if line.split()[:len(title.split())] == title.split()]
    assert found, (title, text)
    rest = found[0].split()[len(title.split()):]
    where = headings.index(heading) - 1
    assert len(rest) > where, (title, heading, text)
    return rest[where]


def has_row(text, title):
    """Whether the table has a row starting with ``title``."""

    _, rows = heading_and_rows(text)
    return any(re.match(r"\s*" + re.escape(title) + r"\b", line)
               for line in rows)


def count_of(text, name):
    """A census row's count: the word after the temperament."""

    _, rows = heading_and_rows(text)
    found = [line.split() for line in rows
             if line.split()[:len(name.split())] == name.split()]
    assert len(found) == 1, (name, text)
    words = found[0]
    assert len(words) > len(name.split()), (name, text)
    return words[len(name.split())]


def verdict_row(text, name):
    """What a verdict's Figure says beside one name."""

    for line in figure_part(text):
        match = re.match(r"^" + re.escape(name) + r"\s+(.*\S)\s*$",
                         line)
        if match:
            return match.group(1)
    raise AssertionError(name + " has no row in\n" + text)


def claim_verdict(text, claim):
    """The verdict on one claim's row, the name matched without
    regard to case."""

    for line in figure_part(text):
        words = line.split()
        if words and words[0].lower() == claim.lower():
            return words[-1]
    raise AssertionError(claim + " has no row in\n" + text)


def spec_words(text, field):
    """The words after a field's name on a specification."""

    for line in text.split("\n"):
        words = line.split()
        if words and words[0] == field:
            return words[1:]
    raise AssertionError(field + " is not on the sheet\n" + text)


def flat(text):
    """The text with every run of white space one space, so a phrase
    a report wraps across two lines is still found."""

    return " ".join(str(text).split())


def no_traceback(code, text):
    """An answer, not a crash."""

    assert code != -1, text
    assert "Traceback" not in text, text


#: One instrument at A440 in equal temperament with one claim that
#: agrees.
PLAIN = "\n".join([
    "[instrument]",
    "builder = Hill",
    "",
    "[tuning]",
    "temperament = equal",
    "standard = a440",
    "",
    "[claims]",
    "a4 = 440",
    "",
])


# ------------------------------------------------------------ R1 encoding


@pytest.mark.parametrize("command", FILE_COMMANDS)
def test_a_file_that_is_not_utf8_is_refused_with_exit_two(
        tmp_path, command):
    """Latin-1 is asked wrongly, like a file that is not there: exit
    two and a message, never a traceback."""

    path = tmp_path / "latin.stops"
    path.write_bytes("[instrument]\nbuilder = Cavaill\xe9-Coll\n"
                     "[tuning]\ntemperament = equal\n"
                     .encode("latin-1"))
    code, text = ask([command, path])
    assert "Traceback" not in text, text
    assert code == 2, text
    assert text.strip(), text


def bommed(tmp_path, text, name="bom.stops"):
    """A file with a UTF-8 byte-order mark in front of the text."""

    path = tmp_path / name
    path.write_bytes(b"\xef\xbb\xbf" + text.encode("utf-8"))
    return str(path)


def test_a_byte_order_mark_is_not_content_to_show(tmp_path):
    """The file reads as if the mark were absent."""

    code, text = ask(["show", bommed(tmp_path, PLAIN)])
    assert code == 0, text
    assert "\ufeff" not in text, text
    assert "[instrument]" in text.split("\n"), text
    assert "builder = Hill" in text.split("\n"), text


def test_a_byte_order_mark_is_not_content_to_claims(tmp_path):
    """And the claims are checked."""

    code, text = ask(["claims", bommed(tmp_path, PLAIN)])
    assert code == 0, text
    assert claim_verdict(text, "a4") == "agrees", text


def test_a_byte_order_mark_is_not_content_to_spec(tmp_path):
    """The builder reaches the sheet."""

    code, text = ask(["spec", bommed(tmp_path, PLAIN)])
    assert code == 0, text
    assert spec_words(text, "builder") == ["Hill"], text
    assert "\ufeff" not in text, text


def test_a_byte_order_mark_is_not_content_to_verdict(tmp_path):
    """One claim recomputed, and it agrees."""

    code, text = ask(["verdict", bommed(tmp_path, PLAIN)])
    assert code == 0, text
    assert verdict_row(text, "agrees") == "1", text
    assert verdict_row(text, "agreed") == "yes", text


def test_a_byte_order_mark_is_not_content_to_convert(tmp_path):
    """Written back without the mark."""

    code, text = ask(["convert", bommed(tmp_path, PLAIN)])
    assert code == 0, text
    assert "\ufeff" not in text, text
    assert "[tuning]" in text.split("\n"), text


SURVEY_WITH_DEFAULTS = "\n".join([
    "[defaults]",
    "tuning.standard = a415",
    "---",
    "[instrument]",
    "place = Upper",
    "[tuning]",
    "temperament = equal",
    "[claims]",
    "a4 = 415",
    "---",
    "[instrument]",
    "place = Lower",
    "[tuning]",
    "temperament = quarter_comma",
    "[claims]",
    "a4 = 415",
    "",
])


def test_a_byte_order_mark_is_not_content_to_survey(tmp_path):
    """The defaults heading is the first line, mark or no mark."""

    code, text = ask(["survey", bommed(tmp_path, SURVEY_WITH_DEFAULTS)])
    assert code == 0, text
    for place in ("Upper", "Lower"):
        assert cell(text, place, "agrees") == "1", text
        assert cell(text, place, "disagrees") == "0", text


def test_a_byte_order_mark_is_not_content_to_census(tmp_path):
    """Both instruments are counted."""

    code, text = ask(["census", bommed(tmp_path, SURVEY_WITH_DEFAULTS)])
    assert code == 0, text
    assert count_of(text, "equal") == "1", text
    assert count_of(text, "quarter_comma") == "1", text


# --------------------------------------------- R2 lines end at a newline


def commented(char):
    """A file whose first line is a comment with ``char`` inside it,
    the text after ``char`` being no field at all."""

    return ("# retuned in 1902" + char + "and again in 1950\n"
            + PLAIN)


@pytest.mark.parametrize("char", list(NOT_NEWLINES.values()),
                         ids=list(NOT_NEWLINES))
def test_a_comment_holding_a_line_separator_is_one_line(tmp_path, char):
    """The comment is one line, so the file parses and its claim is
    checked."""

    code, text = ask(["claims", put(tmp_path, commented(char))])
    assert code == 0, text
    assert claim_verdict(text, "a4") == "agrees", text


@pytest.mark.parametrize("char", list(NOT_NEWLINES.values()),
                         ids=list(NOT_NEWLINES))
def test_a_value_holding_a_line_separator_is_one_value(tmp_path, char):
    """``builder = Father<sep>Smith`` is one field whose value is on
    one line of the sheet."""

    text = PLAIN.replace("builder = Hill",
                         "builder = Father" + char + "Smith")
    code, out = ask(["spec", put(tmp_path, text)])
    assert code == 0, out
    words = " ".join(spec_words(out, "builder"))
    assert "Father" in words and "Smith" in words, out


@pytest.mark.parametrize("char", list(NOT_NEWLINES.values()),
                         ids=list(NOT_NEWLINES))
def test_a_repeated_field_after_such_a_comment_is_at_its_true_line(
        tmp_path, char):
    """Line numbers count newlines only: the second ``temperament``
    is on line five, however many separators the comment holds."""

    text = "\n".join([
        "# retuned in 1902" + char + "# and again in 1950",
        "[tuning]",
        "temperament = equal",
        "standard = a440",
        "temperament = equal",
        "",
    ])
    code, out = ask(["show", put(tmp_path, text)])
    no_traceback(code, out)
    assert code == 2, out
    assert "line 5" in flat(out), out
    assert "line 6" not in flat(out), out


def test_a_survey_reads_past_a_form_feed_in_a_comment(tmp_path):
    """The bundle reader splits at newlines only as well."""

    text = "# diocesan survey\x0cpage two\n" + SURVEY_WITH_DEFAULTS
    code, out = ask(["survey", put(tmp_path, text)])
    assert code == 0, out
    assert cell(out, "Upper", "agrees") == "1", out
    assert cell(out, "Lower", "agrees") == "1", out


# ------------------------------------------- R3 a separator's comment


SEPARATORS = {
    "spaced": "--- # the second organ",
    "wide": "---   # rebuilt in 1902",
    "tight": "---# the second organ",
}


def two_organs(separator):
    """Two instruments, the separator between them given."""

    return "\n".join([
        "[instrument]",
        "place = Upper",
        "[tuning]",
        "temperament = equal",
        "standard = a440",
        "[claims]",
        "a4 = 440",
        separator,
        "[instrument]",
        "place = Lower",
        "[tuning]",
        "temperament = quarter_comma",
        "standard = a440",
        "[claims]",
        "wolf = 35.68",
        "worst_third = 41.06",
        "",
    ])


@pytest.mark.parametrize("separator", list(SEPARATORS.values()),
                         ids=list(SEPARATORS))
def test_a_separator_may_carry_a_comment(tmp_path, separator):
    """Both instruments are in the survey, each with its claims."""

    code, text = ask(["survey", put(tmp_path, two_organs(separator))])
    assert code == 0, text
    assert cell(text, "Upper", "claims") == "1", text
    assert cell(text, "Upper", "agrees") == "1", text
    assert cell(text, "Lower", "claims") == "2", text
    assert cell(text, "Lower", "agrees") == "2", text


def test_a_commented_separator_separates_for_the_census(tmp_path):
    """Two instruments, two temperaments."""

    code, text = ask(["census", put(tmp_path,
                                    two_organs("--- # the second"))])
    assert code == 0, text
    assert count_of(text, "equal") == "1", text
    assert count_of(text, "quarter_comma") == "1", text


# --------------------------------------- R4 defaults from where they stand


def test_defaults_in_the_first_instrument_s_chunk_reach_it_and_the_next(
        tmp_path):
    """The other sections of the defaults chunk are the first
    instrument, and the standard reaches it and the one after."""

    text = "\n".join([
        "[defaults]",
        "tuning.standard = a415",
        "",
        "[instrument]",
        "place = Upper",
        "[tuning]",
        "temperament = equal",
        "[claims]",
        "a4 = 415",
        "---",
        "[instrument]",
        "place = Lower",
        "[tuning]",
        "temperament = equal",
        "[claims]",
        "a4 = 415",
        "",
    ])
    code, out = ask(["survey", put(tmp_path, text)])
    assert code == 0, out
    for place in ("Upper", "Lower"):
        assert cell(out, place, "claims") == "1", out
        assert cell(out, place, "agrees") == "1", out
        assert cell(out, place, "disagrees") == "0", out


def test_in_the_same_chunk_the_instrument_s_own_field_still_wins(
        tmp_path):
    """The first says A440 itself and keeps it; the second takes the
    default."""

    text = "\n".join([
        "[defaults]",
        "tuning.standard = a415",
        "[instrument]",
        "place = Upper",
        "[tuning]",
        "temperament = equal",
        "standard = a440",
        "[claims]",
        "a4 = 440",
        "---",
        "[instrument]",
        "place = Lower",
        "[tuning]",
        "temperament = equal",
        "[claims]",
        "a4 = 415",
        "",
    ])
    code, out = ask(["survey", put(tmp_path, text)])
    assert code == 0, out
    assert cell(out, "Upper", "agrees") == "1", out
    assert cell(out, "Lower", "agrees") == "1", out
    assert cell(out, "Lower", "disagrees") == "0", out


def test_defaults_beside_an_unrelated_section_still_apply(tmp_path):
    """A ``[notes]`` section in the defaults chunk does not stop the
    defaults reaching the instruments after it."""

    text = "\n".join([
        "[defaults]",
        "tuning.standard = a415",
        "[notes]",
        "text = surveyed for the diocese in 1950",
        "---",
        "[instrument]",
        "place = Upper",
        "[tuning]",
        "temperament = equal",
        "[claims]",
        "a4 = 415",
        "---",
        "[instrument]",
        "place = Lower",
        "[tuning]",
        "temperament = quarter_comma",
        "[claims]",
        "a4 = 415",
        "",
    ])
    code, out = ask(["survey", put(tmp_path, text)])
    assert code == 0, out
    for place in ("Upper", "Lower"):
        assert cell(out, place, "agrees") == "1", out
        assert cell(out, place, "disagrees") == "0", out


def test_a_default_temperament_in_the_first_chunk_is_counted(tmp_path):
    """The census sees the temperament the defaults give both."""

    text = "\n".join([
        "[defaults]",
        "tuning.temperament = equal",
        "[instrument]",
        "place = Upper",
        "---",
        "[instrument]",
        "place = Lower",
        "",
    ])
    code, out = ask(["census", put(tmp_path, text)])
    assert code == 0, out
    assert count_of(out, "equal") == "2", out


# ----------------------------------------------- R5 a survey stops at nothing


#: The second instrument's chunk, unreadable in each of the ways a
#: chunk can be.
UNREADABLE = {
    "field-twice": ["[instrument]", "place = Beta", "place = Beta",
                    "[tuning]", "temperament = werckmeister_iii",
                    "[claims]", "a4 = 440"],
    "no-equals": ["[instrument]", "place = Beta", "[tuning]",
                  "temperament werckmeister_iii", "[claims]",
                  "a4 = 440"],
    "no-bracket": ["[instrument]", "place = Beta", "[tuning",
                   "temperament = werckmeister_iii", "[claims]",
                   "a4 = 440"],
    "field-first": ["place = Beta", "[instrument]", "[tuning]",
                    "temperament = werckmeister_iii", "[claims]",
                    "a4 = 440"],
}

ALPHA = ["[instrument]", "place = Alpha", "[tuning]",
         "temperament = equal", "[claims]", "a4 = 440",
         "middle_c = 261.6256"]
GAMMA = ["[instrument]", "place = Gamma", "[tuning]",
         "temperament = quarter_comma", "[claims]", "wolf = 0"]
DEFAULTS = ["[defaults]", "tuning.standard = a440"]


def bundle_of(*chunks):
    """Chunks joined by separator lines."""

    return "\n---\n".join("\n".join(one) for one in chunks) + "\n"


def the_reason(tmp_path, kind):
    """What the parser says about the bad chunk on its own."""

    if kind == "field-twice":
        return "a field given twice"
    code, text = ask(["show", put(tmp_path, "\n".join(UNREADABLE[kind])
                                  + "\n", "alone.stops")])
    assert code == 2, text
    return text.split(": ", 1)[1].split(" (")[0].strip()


def assert_the_good_ones(text):
    """Alpha's two claims agree and Gamma's wolf disagrees."""

    assert cell(text, "Alpha", "claims") == "2", text
    assert cell(text, "Alpha", "agrees") == "2", text
    assert cell(text, "Alpha", "disagrees") == "0", text
    assert cell(text, "Gamma", "claims") == "1", text
    assert cell(text, "Gamma", "agrees") == "0", text
    assert cell(text, "Gamma", "disagrees") == "1", text


@pytest.mark.parametrize("kind", list(UNREADABLE))
def test_a_survey_checks_the_instruments_around_an_unreadable_one(
        tmp_path, kind):
    """The first and third are read and checked."""

    path = put(tmp_path, bundle_of(DEFAULTS, ALPHA, UNREADABLE[kind],
                                   GAMMA))
    code, text = ask(["survey", path])
    no_traceback(code, text)
    assert code in (0, 2), text
    assert_the_good_ones(text)


@pytest.mark.parametrize("kind", list(UNREADABLE))
def test_a_survey_names_the_unreadable_instrument_and_why(
        tmp_path, kind):
    """It has a row as ``instrument 2`` (the defaults chunk is not an
    instrument), and the parser's reason is in the text."""

    reason = the_reason(tmp_path, kind)
    path = put(tmp_path, bundle_of(DEFAULTS, ALPHA, UNREADABLE[kind],
                                   GAMMA))
    code, text = ask(["survey", path])
    no_traceback(code, text)
    assert code in (0, 2), text
    assert has_row(text, "instrument 2"), text
    assert flat(reason) in flat(text), (reason, text)


@pytest.mark.parametrize("chunks,position", [
    ((UNREADABLE["field-twice"], ALPHA, GAMMA), 1),
    ((ALPHA, DEFAULTS, UNREADABLE["field-twice"], GAMMA), 2),
    ((ALPHA, DEFAULTS, GAMMA, UNREADABLE["field-twice"]), 3),
], ids=["first", "second-after-defaults", "third-after-defaults"])
def test_the_unreadable_instrument_is_numbered_by_position(
        tmp_path, chunks, position):
    """Counted among the instruments, defaults chunks left out,
    from one; the readable ones keep their rows."""

    code, text = ask(["survey", put(tmp_path, bundle_of(*chunks))])
    no_traceback(code, text)
    assert code in (0, 2), text
    assert has_row(text, "instrument {0}".format(position)), text
    assert cell(text, "Alpha", "claims") == "2", text
    assert cell(text, "Gamma", "claims") == "1", text


@pytest.mark.parametrize("kind", list(UNREADABLE))
def test_a_census_counts_the_instruments_around_an_unreadable_one(
        tmp_path, kind):
    """Equal and quarter-comma are each counted once."""

    path = put(tmp_path, bundle_of(DEFAULTS, ALPHA, UNREADABLE[kind],
                                   GAMMA))
    code, text = ask(["census", path])
    no_traceback(code, text)
    assert code in (0, 2), text
    assert count_of(text, "equal") == "1", text
    assert count_of(text, "quarter_comma") == "1", text


# ------------------------------------- R6 the file's line, survey's number


def test_an_unreadable_instrument_names_the_file_s_line(tmp_path):
    """The repeated field is on file line 13 (line 5 of its chunk),
    in the second instrument (the defaults chunk is not one)."""

    text = "\n".join([
        "[defaults]",                  # 1
        "tuning.standard = a415",      # 2
        "---",                         # 3
        "[instrument]",                # 4
        "place = Alpha",               # 5
        "[tuning]",                    # 6
        "temperament = equal",         # 7
        "---",                         # 8
        "[instrument]",                # 9
        "place = Beta",                # 10
        "[tuning]",                    # 11
        "temperament = equal",         # 12
        "temperament = equal",         # 13
        "",
    ])
    path = put(tmp_path, text, "bundle.stops")
    code, out = ask(["survey", path])
    no_traceback(code, out)
    assert "line 13" in flat(out), out
    assert "line 5" not in flat(out), out
    assert "instrument 2" in flat(out), out
    assert "instrument 3" not in flat(out), out
    assert "bundle.stops[" not in flat(out), out


BAD_DEFAULTS = "\n".join([
    "[instrument]",                    # 1
    "place = Alpha",                   # 2
    "[tuning]",                        # 3
    "temperament = equal",             # 4
    "standard = a440",                 # 5
    "[claims]",                        # 6
    "a4 = 440",                        # 7
    "---",                             # 8
    "# the rest are at choir pitch",   # 9
    "[defaults]",                      # 10
    "tuning.standard = a415",          # 11
    "tuning.tonic = C",                # 12
    "tuning.standard = a466",          # 13
    "---",
    "[instrument]",
    "place = Beta",
    "[tuning]",
    "temperament = equal",
    "",
])


def test_a_bad_defaults_line_names_the_file_s_line(tmp_path):
    """``tuning.standard`` given twice in a defaults chunk that starts
    on line 9: the survey says line 13, not the chunk's line 5."""

    code, out = ask(["survey", put(tmp_path, BAD_DEFAULTS,
                                   "bundle.stops")])
    no_traceback(code, out)
    assert code in (0, 2), out
    assert "line 13" in flat(out), out
    assert "line 5" not in flat(out), out


# ------------------------------------------- R7 the uncheckable column


MIXED = bundle_of(
    ["[instrument]", "place = Alpha", "[tuning]", "temperament = equal",
     "standard = a440", "[claims]", "a4 = 440", "wolf = 5",
     "smell = damp", "bottom_pipe = 11"],
    ["[instrument]", "place = Gamma", "[tuning]", "standard = a440",
     "[claims]", "wolf = 0", "key_range = 0"],
)


def test_the_survey_has_an_uncheckable_column(tmp_path):
    """Beside agrees, disagrees and unknown."""

    code, text = ask(["survey", put(tmp_path, MIXED)])
    assert code == 0, text
    headings, _ = heading_and_rows(text)
    assert "uncheckable" in headings, text
    for one in ("claims", "agrees", "disagrees", "unknown"):
        assert one in headings, text


def test_each_verdict_is_counted_in_its_own_column(tmp_path):
    """One claim of each kind, one in each column."""

    code, text = ask(["survey", put(tmp_path, MIXED)])
    assert code == 0, text
    for heading in ("agrees", "disagrees", "unknown", "uncheckable"):
        assert cell(text, "Alpha", heading) == "1", (heading, text)


def test_two_uncheckable_claims_show_two(tmp_path):
    """An instrument with no temperament can check neither its wolf
    nor its key range."""

    code, text = ask(["survey", put(tmp_path, MIXED)])
    assert code == 0, text
    assert cell(text, "Gamma", "uncheckable") == "2", text
    assert cell(text, "Gamma", "agrees") == "0", text


def test_the_claims_column_still_counts_every_claim(tmp_path):
    """Uncheckable and unknown claims are still claims."""

    code, text = ask(["survey", put(tmp_path, MIXED)])
    assert code == 0, text
    assert cell(text, "Alpha", "uncheckable") == "1", text
    assert cell(text, "Alpha", "claims") == "4", text
    assert cell(text, "Gamma", "claims") == "2", text


# ----------------------------------------------- R8 nothing recomputed


def unsaid(text):
    """The agreed row says neither yes nor no."""

    agreed = verdict_row(text, "agreed")
    assert agreed not in ("yes", "no"), text


def test_a_file_with_no_claims_has_not_said(tmp_path):
    """Nothing checked, and not agreed."""

    code, text = ask(["verdict", put(tmp_path, PLAIN.split("[claims]")[0])])
    assert code == 0, text
    assert verdict_row(text, "checked") == "0", text
    unsaid(text)


def test_the_cathedral_has_not_said():
    """The example the files page uses for a file that claims
    nothing."""

    code, text = ask(["verdict", CATHEDRAL])
    assert code == 0, text
    assert verdict_row(text, "checked") == "0", text
    unsaid(text)


ALL_UNCHECKABLE = "\n".join([
    "[instrument]",
    "builder = Hill",
    "[tuning]",
    "standard = a440",
    "[claims]",
    "wolf = 0",
    "key_range = 0",
    "",
])


def test_a_file_whose_every_claim_is_uncheckable_has_not_said(tmp_path):
    """No temperament, so neither claim could be worked out."""

    code, text = ask(["verdict", put(tmp_path, ALL_UNCHECKABLE)])
    assert code == 0, text
    assert verdict_row(text, "uncheckable") == "2", text
    unsaid(text)


def test_uncheckable_claims_are_not_counted_as_checked(tmp_path):
    """Checked is agrees plus disagrees."""

    code, text = ask(["verdict", put(tmp_path, ALL_UNCHECKABLE)])
    assert code == 0, text
    assert verdict_row(text, "checked") == "0", text


CHECKED = {
    "agrees-and-uncheckable": (["a4 = 440", "bottom_pipe = 11"],
                               "1", "yes"),
    "agrees-and-unknown": (["a4 = 440", "smell = damp"], "1", "no"),
    "one-of-each": (["a4 = 440", "wolf = 5", "smell = damp",
                     "bottom_pipe = 11"], "2", "no"),
}


@pytest.mark.parametrize("claims,checked,agreed", list(CHECKED.values()),
                         ids=list(CHECKED))
def test_checked_is_agrees_plus_disagrees(tmp_path, claims, checked,
                                          agreed):
    """Unknown and uncheckable claims were not recomputed; agreed is
    still yes or no once something was."""

    text = "\n".join(["[tuning]", "temperament = equal",
                      "standard = a440", "[claims]"] + claims) + "\n"
    code, out = ask(["verdict", put(tmp_path, text)])
    assert code == 0, out
    total = (int(verdict_row(out, "agrees"))
             + int(verdict_row(out, "disagrees")))
    assert verdict_row(out, "checked") == str(total), out
    assert verdict_row(out, "checked") == checked, out
    assert verdict_row(out, "agreed") == agreed, out


# ------------------------------------------------ R9 halfway agrees


def pipe_file(tmp_path, hertz, degrees, written):
    """An equal-tempered file with pipes and a bottom_pipe claim."""

    text = "\n".join(["[tuning]", "temperament = equal",
                      "standard = a440", "[pipes]",
                      "bottom_hertz = " + hertz,
                      "degrees = " + degrees, "[claims]",
                      "bottom_pipe = " + written]) + "\n"
    return put(tmp_path, text)


@pytest.mark.parametrize("written", ["11.2", "11.3"])
def test_exactly_halfway_agrees_either_way(tmp_path, written):
    """50 Hz at 20 degrees is exactly 11.25 feet, halfway between
    11.2 and 11.3."""

    code, text = ask(["claims", pipe_file(tmp_path, "50", "20", written)])
    assert code == 0, text
    assert claim_verdict(text, "bottom_pipe") == "agrees", text


@pytest.mark.parametrize("written", ["11", "12"])
def test_a_whole_number_within_exactly_half_agrees(tmp_path, written):
    """49 Hz at 21 degrees is 13552 / 49 / 2 / 12 inches over twelve:
    exactly 11.5 feet, half a unit from both 11 and 12."""

    code, text = ask(["claims", pipe_file(tmp_path, "49", "21", written)])
    assert code == 0, text
    assert claim_verdict(text, "bottom_pipe") == "agrees", text


def test_a_halfway_claim_makes_an_agreed_verdict(tmp_path):
    """Through ``verdict`` as well."""

    code, text = ask(["verdict", pipe_file(tmp_path, "50", "20", "11.2")])
    assert code == 0, text
    assert verdict_row(text, "agrees") == "1", text
    assert verdict_row(text, "agreed") == "yes", text


# ------------------------------------- R10 no standard is not a440


def unstandard(tmp_path, claims, temperament="equal"):
    """A file with a temperament and no standard and no tonic."""

    text = "\n".join(["[instrument]", "builder = Hill", "[tuning]",
                      "temperament = " + temperament, "[claims]"]
                     + claims) + "\n"
    return put(tmp_path, text)


@pytest.mark.parametrize("claim,written", [("a4", "440"),
                                           ("middle_c", "261.6256")])
def test_a_pitch_claim_without_a_standard_is_uncheckable(
        tmp_path, claim, written):
    """Never judged at A440."""

    code, text = ask(["claims", unstandard(tmp_path,
                                           [claim + " = " + written])])
    assert code == 0, text
    assert claim_verdict(text, claim) == "uncheckable", text


def test_a4_at_choir_pitch_without_a_standard_is_not_wrong(tmp_path):
    """415 is not a disagreement with a standard nobody wrote."""

    code, text = ask(["claims", unstandard(tmp_path, ["a4 = 415"])])
    assert code == 0, text
    assert claim_verdict(text, "a4") == "uncheckable", text


def test_without_standard_or_tonic_the_wolf_is_still_checked(tmp_path):
    """A missing tonic still means C; only the pitch claims go."""

    path = unstandard(tmp_path, ["wolf = 35.68", "a4 = 440"],
                      "quarter_comma")
    code, text = ask(["claims", path])
    assert code == 0, text
    assert claim_verdict(text, "wolf") == "agrees", text
    assert claim_verdict(text, "a4") == "uncheckable", text


def test_the_verdict_without_a_standard(tmp_path):
    """One recomputed and agreeing, one uncheckable."""

    path = unstandard(tmp_path, ["wolf = 35.68", "a4 = 440"],
                      "quarter_comma")
    code, text = ask(["verdict", path])
    assert code == 0, text
    assert verdict_row(text, "uncheckable") == "1", text
    assert verdict_row(text, "checked") == "1", text
    assert verdict_row(text, "agreed") == "yes", text


def test_a_survey_without_a_standard_counts_a4_uncheckable(tmp_path):
    """In the new column, not as agreeing."""

    text = bundle_of(["[instrument]", "place = Alpha", "[tuning]",
                      "temperament = equal", "[claims]", "a4 = 440"],
                     GAMMA)
    code, out = ask(["survey", put(tmp_path, text)])
    assert code == 0, out
    assert cell(out, "Alpha", "uncheckable") == "1", out
    assert cell(out, "Alpha", "agrees") == "0", out


# --------------------------------------------- R11 census by temperament


def census_of(tmp_path, temperaments):
    """A bundle of one instrument per temperament line given; None
    leaves the field out."""

    chunks = []
    for index, one in enumerate(temperaments, start=1):
        chunk = ["[instrument]", "place = Organ{0}".format(index)]
        if one is not None:
            chunk += ["[tuning]", "temperament = " + one]
        chunks.append(chunk)
    return put(tmp_path, bundle_of(*chunks))


def quarter_rows(text):
    """Every census row that spells quarter-comma somehow."""

    _, rows = heading_and_rows(text)
    return [line for line in rows
            if line.split() and line.split()[0].lower()
            .replace("-", "_").startswith("quarter")]


SPELLINGS = ["Quarter_Comma", "QUARTER_COMMA", "quarter-comma",
             "quarter comma"]


@pytest.mark.parametrize("spelling", SPELLINGS)
def test_a_spelling_is_counted_with_its_temperament(tmp_path, spelling):
    """One row for quarter-comma, holding both."""

    code, text = ask(["census", census_of(tmp_path, ["quarter_comma",
                                                     spelling])])
    assert code == 0, text
    assert count_of(text, "quarter_comma") == "2", text
    assert len(quarter_rows(text)) == 1, text


def test_four_spellings_are_one_row_of_four(tmp_path):
    """Whatever the case, hyphen or space."""

    code, text = ask(["census", census_of(tmp_path, SPELLINGS)])
    assert code == 0, text
    assert count_of(text, "quarter_comma") == "4", text
    assert len(quarter_rows(text)) == 1, text


def test_an_instrument_with_no_temperament_is_not_stated(tmp_path):
    """Counted, in a row of its own."""

    code, text = ask(["census", census_of(tmp_path, ["equal", None])])
    assert code == 0, text
    assert count_of(text, "equal") == "1", text
    assert count_of(text, "not stated") == "1", text


def test_a_blank_temperament_is_not_stated(tmp_path):
    """``temperament =`` names nothing to count it under."""

    code, text = ask(["census", census_of(tmp_path, ["equal", ""])])
    assert code == 0, text
    assert count_of(text, "equal") == "1", text
    assert count_of(text, "not stated") == "1", text


def test_absent_and_blank_share_the_not_stated_row(tmp_path):
    """Beside the temperaments that are written down."""

    code, text = ask(["census", census_of(
        tmp_path, ["equal", None, "Quarter_Comma", "", "quarter_comma"])])
    assert code == 0, text
    assert count_of(text, "equal") == "1", text
    assert count_of(text, "quarter_comma") == "2", text
    assert count_of(text, "not stated") == "2", text


# ---------------------------------------------- R12 blank on the sheet


BLANKS = [("instrument", "builder"), ("tuning", "temperament"),
          ("tuning", "wolf"), ("stops", "borrowed"), ("wind", "stable")]


@pytest.mark.parametrize("section,field", BLANKS,
                         ids=[one[1] for one in BLANKS])
def test_a_blank_value_is_shown_as_blank(tmp_path, section, field):
    """Somebody looked and wrote nothing, which is not nobody
    looking: the line says blank, or says nothing, never not stated."""

    path = put(tmp_path, "[{0}]\n{1} =\n".format(section, field))
    code, text = ask(["spec", path])
    assert code == 0, text
    words = spec_words(text, field)
    assert "stated" not in words, text
    assert words == [] or "blank" in words, text


def test_blank_and_absent_say_different_things(tmp_path):
    """``wolf =`` is blank; ``last_tuned_at``, not written, is still
    not stated."""

    path = put(tmp_path, "[tuning]\ntemperament = equal\nwolf =\n")
    code, text = ask(["spec", path])
    assert code == 0, text
    blank = spec_words(text, "wolf")
    assert blank == [] or "blank" in blank, text
    assert spec_words(text, "last_tuned_at") == ["not", "stated"], text


# ---------------------------------------- R13 convert refuses before writing


ORIGINAL = "# somebody else's file\n[tuning]\ntemperament = just\n"


@pytest.mark.parametrize("places", ["13", "-1", "twelve"])
def test_a_usage_error_leaves_the_out_file_untouched(tmp_path, places):
    """Refused before anything is written."""

    source = put(tmp_path, PLAIN)
    out = tmp_path / "out.stops"
    out.write_text(ORIGINAL, encoding="utf-8")
    code, text = ask(["convert", source, "--out", out,
                      "--places", places])
    no_traceback(code, text)
    assert code == 2, text
    assert out.read_text(encoding="utf-8") == ORIGINAL


def test_a_usage_error_creates_no_out_file(tmp_path):
    """Nothing written means nothing made either."""

    source = put(tmp_path, PLAIN)
    out = tmp_path / "new.stops"
    code, text = ask(["convert", source, "--out", out, "--places", "13"])
    no_traceback(code, text)
    assert code == 2, text
    assert not out.exists()


def test_writing_into_a_missing_directory_is_exit_two(tmp_path):
    """Like a file that cannot be read, which is still exit two."""

    source = put(tmp_path, PLAIN)
    code, text = ask(["convert", source, "--out",
                      tmp_path / "nowhere" / "out.stops"])
    no_traceback(code, text)
    assert code == 2, text
    code, text = ask(["show", tmp_path / "nowhere" / "in.stops"])
    assert code == 2, text


def test_writing_onto_a_directory_is_exit_two(tmp_path):
    """A path that is a directory is not somewhere to write."""

    source = put(tmp_path, PLAIN)
    (tmp_path / "folder").mkdir()
    code, text = ask(["convert", source, "--out", tmp_path / "folder"])
    no_traceback(code, text)
    assert code == 2, text


# ---------------------------------------------- R14 written back as written


EMPTY_CLAIMS = "[instrument]\nbuilder = Hill\n\n[tuning]\n" \
               "temperament = equal\n\n[claims]\n"


def test_an_empty_claims_section_is_shown(tmp_path):
    """The heading comes back."""

    code, text = ask(["show", put(tmp_path, EMPTY_CLAIMS)])
    assert code == 0, text
    assert "[claims]" in [one.strip() for one in text.split("\n")], text


def test_an_empty_claims_section_is_converted(tmp_path):
    """On the converted text as well."""

    code, text = ask(["convert", put(tmp_path, EMPTY_CLAIMS)])
    assert code == 0, text
    assert "[claims]" in [one.strip() for one in text.split("\n")], text


def test_an_empty_claims_section_survives_a_written_file(tmp_path):
    """The converted file still has the section to show."""

    out = tmp_path / "out.stops"
    code, text = ask(["convert", put(tmp_path, EMPTY_CLAIMS), "--out",
                      out])
    assert code == 0, text
    code, text = ask(["show", out, "--section", "claims"])
    assert code == 0, text


#: Claim names in other cases, with a value that agrees in a
#: quarter-comma file at A440.
CASED = [("Wolf", "35.68"), ("A4", "440"), ("Worst_Third", "41.06")]


def cased_file(tmp_path, name, written):
    """A quarter-comma file with one claim, its name in capitals."""

    text = "\n".join(["[tuning]", "Temperament = quarter_comma",
                      "standard = a440", "[claims]",
                      "{0} = {1}".format(name, written)]) + "\n"
    return put(tmp_path, text)


@pytest.mark.parametrize("name,written", CASED,
                         ids=[one[0] for one in CASED])
def test_a_claim_name_keeps_its_case_in_show(tmp_path, name, written):
    """As it was written; the other field names are still
    lowercased."""

    code, text = ask(["show", cased_file(tmp_path, name, written)])
    assert code == 0, text
    lines = [one.strip() for one in text.split("\n")]
    assert "{0} = {1}".format(name, written) in lines, text
    assert "{0} = {1}".format(name.lower(), written) not in lines, text
    assert "temperament = quarter_comma" in lines, text


@pytest.mark.parametrize("name,written", CASED,
                         ids=[one[0] for one in CASED])
def test_a_cased_claim_is_still_checked(tmp_path, name, written):
    """Kept as written, and still the claim it names."""

    path = cased_file(tmp_path, name, written)
    code, text = ask(["claims", path])
    assert code == 0, text
    assert claim_verdict(text, name) == "agrees", text
    code, text = ask(["show", path])
    assert "{0} = {1}".format(name, written) in \
        [one.strip() for one in text.split("\n")], text


def test_a_cased_claim_survives_a_written_file(tmp_path):
    """``Wolf = 1`` reads back as ``Wolf = 1`` from the converted
    file."""

    out = tmp_path / "out.stops"
    code, text = ask(["convert", cased_file(tmp_path, "Wolf", "1"),
                      "--out", out])
    assert code == 0, text
    written = [one.strip() for one in
               out.read_text(encoding="utf-8").split("\n")]
    assert "Wolf = 1" in written, written
    code, text = ask(["show", out])
    assert code == 0, text
    assert "Wolf = 1" in [one.strip() for one in text.split("\n")], text


def test_a_cased_claim_counts_in_the_verdict(tmp_path):
    """Not unknown, and the file agreed; its name kept."""

    path = cased_file(tmp_path, "Wolf", "35.68")
    code, text = ask(["verdict", path])
    assert code == 0, text
    assert verdict_row(text, "unknown") == "0", text
    assert verdict_row(text, "agreed") == "yes", text
    code, text = ask(["convert", path])
    assert "Wolf = 35.68" in [one.strip() for one in text.split("\n")], \
        text
