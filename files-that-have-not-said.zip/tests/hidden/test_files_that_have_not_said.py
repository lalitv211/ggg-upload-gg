"""The files page, the command-line page and the wolf/io docstrings, kept.

``docs/files.md`` says a file with no claims has not said, that a
survey stops at nothing, that defaults reach every instrument after
them, that ``#`` starts a comment and that a claim is compared to the
precision it was written at; ``docs/command-line.md`` says claims come
back exactly as they were and that ``run`` answers with an exit code;
the readers and writers in ``wolf/io`` say a parse failure names the
file and the line, that an unnamed instrument is reported by its
position and that a written file parses back to the record it came
from. The commands broke each of those.

Everything is checked through ``run`` and the text it returns, on
files written under ``tmp_path``. Only what a page or a docstring
promises is asserted: messages, where a reason is printed, column
order, row labels and exit codes the pages leave open are the
change's own.
"""

from __future__ import annotations

import pathlib
import re
import traceback

import pytest

from wolf.cli.main import run

ROOT = pathlib.Path(__file__).resolve().parent.parent
CATHEDRAL = str(ROOT / "examples" / "cathedral.stops")

#: The commands that read an instrument file.
FILE_COMMANDS = ["show", "claims", "verdict", "spec", "convert",
                 "survey", "census"]


# ---------------------------------------------------------------- helpers


def ask(argv):
    """``run``, with an exception that escapes it turned into a
    failing answer so the assertion that follows fails cleanly."""

    try:
        return run([str(one) for one in argv])
    except Exception:  # noqa: BLE001 - the traceback is the finding
        return -1, traceback.format_exc()


def put(tmp_path, text, name="organ.stops"):
    """A file with exactly this text, as UTF-8, newlines untouched."""

    path = tmp_path / name
    path.write_bytes(text.encode("utf-8"))
    return str(path)


def figure_part(text):
    """The lines of a report's Figure part."""

    lines = text.splitlines()
    assert "Figure" in lines, text
    start = lines.index("Figure") + 1
    end = lines.index("Working") if "Working" in lines[start:] \
        else len(lines)
    return lines[start:end]


def heading_and_rows(text):
    """A table's heading words and its row lines."""

    part = [line for line in figure_part(text)
            if line.strip() and set(line.strip()) - {"-", " "}]
    assert part, text
    return part[0].split(), part[1:]


def cell(text, title, heading):
    """One survey cell: the row that starts with ``title``, under the
    column headed ``heading``."""

    headings, rows = heading_and_rows(text)
    assert heading in headings, (heading, text)
    found = [line for line in rows
             if line.split()[:len(title.split())] == title.split()]
    assert found, (title, text)
    rest = found[0].split()[len(title.split()):]
    where = headings.index(heading) - 1
    assert len(rest) > where, (title, heading, text)
    return rest[where]


def count_of(text, name):
    """A census row's count: the word after the temperament."""

    _, rows = heading_and_rows(text)
    found = [line.split() for line in rows
             if line.split()[:len(name.split())] == name.split()]
    assert len(found) == 1, (name, text)
    words = found[0]
    assert len(words) > len(name.split()), (name, text)
    return words[len(name.split())]


def verdict_row(text, name):
    """What a verdict's Figure says beside one name."""

    for line in figure_part(text):
        match = re.match(r"^" + re.escape(name) + r"\s+(.*\S)\s*$",
                         line)
        if match:
            return match.group(1)
    raise AssertionError(name + " has no row in\n" + text)


def claim_verdict(text, claim):
    """The verdict on one claim's row, the name matched without
    regard to case."""

    for line in figure_part(text):
        words = line.split()
        if words and words[0].lower() == claim.lower():
            return words[-1]
    raise AssertionError(claim + " has no row in\n" + text)


def spec_words(text, field):
    """The words after a field's name on a specification."""

    for line in text.split("\n"):
        words = line.split()
        if words and words[0] == field:
            return words[1:]
    raise AssertionError(field + " is not on the sheet\n" + text)


def reported(text, position):
    """Whether the unreadable instrument, the one whose place is Beta,
    is reported: by its name if the survey could read one, or by its
    position among the instruments."""

    words = flat(text)
    return ("instrument {0}".format(position) in words
            or re.search(r"(?m)^\s*Beta\b", text) is not None)


def flat(text):
    """The text with every run of white space one space, so a phrase
    a report wraps across two lines is still found."""

    return " ".join(str(text).split())


def no_traceback(code, text):
    """An answer, not a crash."""

    assert code != -1, text
    assert "Traceback" not in text, text


#: One instrument at A440 in equal temperament with one claim that
#: agrees.
PLAIN = "\n".join([
    "[instrument]",
    "builder = Hill",
    "",
    "[tuning]",
    "temperament = equal",
    "standard = a440",
    "tonic = C",
    "",
    "[claims]",
    "a4 = 440",
    "",
])


# ------------------------------------------------------------ R1 encoding


@pytest.mark.parametrize("command", FILE_COMMANDS)
def test_a_file_that_is_not_utf8_gets_an_exit_code(tmp_path, command):
    """``run`` returns an exit code and a string: the file read as
    best it can be, or refused with a message, never a traceback."""

    path = tmp_path / "latin.stops"
    path.write_bytes("[instrument]\nbuilder = Cavaill\xe9-Coll\n"
                     "[tuning]\ntemperament = equal\n"
                     .encode("latin-1"))
    code, text = ask([command, path])
    assert "Traceback" not in text, text
    assert code in (0, 2, 3), text
    assert text.strip(), text


# --------------------------------------------- R2 lines end at a newline


# ------------------------------------------- R3 a separator's comment


SEPARATORS = {
    "spaced": "--- # the second organ",
    "wide": "---   # rebuilt in 1902",
    "tight": "---# the second organ",
}


def two_organs(separator):
    """Two instruments, the separator between them given."""

    return "\n".join([
        "[instrument]",
        "place = Upper",
        "[tuning]",
        "temperament = equal",
        "standard = a440",
        "tonic = C",
        "[claims]",
        "a4 = 440",
        separator,
        "[instrument]",
        "place = Lower",
        "[tuning]",
        "temperament = quarter_comma",
        "standard = a440",
        "tonic = C",
        "[claims]",
        "wolf = 35.68",
        "worst_third = 41.06",
        "",
    ])


@pytest.mark.parametrize("separator", list(SEPARATORS.values()),
                         ids=list(SEPARATORS))
def test_a_separator_may_carry_a_comment(tmp_path, separator):
    """Both instruments are in the survey, each with its claims."""

    code, text = ask(["survey", put(tmp_path, two_organs(separator))])
    assert code == 0, text
    assert cell(text, "Upper", "claims") == "1", text
    assert cell(text, "Upper", "agrees") == "1", text
    assert cell(text, "Lower", "claims") == "2", text
    assert cell(text, "Lower", "agrees") == "2", text


def test_a_commented_separator_separates_for_the_census(tmp_path):
    """Two instruments, two temperaments."""

    code, text = ask(["census", put(tmp_path,
                                    two_organs("--- # the second"))])
    assert code == 0, text
    assert count_of(text, "equal") == "1", text
    assert count_of(text, "quarter_comma") == "1", text


# --------------------------------------- R4 defaults from where they stand


def test_defaults_in_the_first_instrument_s_chunk_reach_it_and_the_next(
        tmp_path):
    """The other sections of the defaults chunk are the first
    instrument, and the standard reaches it and the one after."""

    text = "\n".join([
        "[defaults]",
        "tuning.standard = a415",
        "tuning.tonic = C",
        "",
        "[instrument]",
        "place = Upper",
        "[tuning]",
        "temperament = equal",
        "[claims]",
        "a4 = 415",
        "---",
        "[instrument]",
        "place = Lower",
        "[tuning]",
        "temperament = equal",
        "[claims]",
        "a4 = 415",
        "",
    ])
    code, out = ask(["survey", put(tmp_path, text)])
    assert code == 0, out
    for place in ("Upper", "Lower"):
        assert cell(out, place, "claims") == "1", out
        assert cell(out, place, "agrees") == "1", out
        assert cell(out, place, "disagrees") == "0", out


def test_in_the_same_chunk_the_instrument_s_own_field_still_wins(
        tmp_path):
    """The first says A440 itself and keeps it; the second takes the
    default."""

    text = "\n".join([
        "[defaults]",
        "tuning.standard = a415",
        "tuning.tonic = C",
        "[instrument]",
        "place = Upper",
        "[tuning]",
        "temperament = equal",
        "standard = a440",
        "tonic = C",
        "[claims]",
        "a4 = 440",
        "---",
        "[instrument]",
        "place = Lower",
        "[tuning]",
        "temperament = equal",
        "[claims]",
        "a4 = 415",
        "",
    ])
    code, out = ask(["survey", put(tmp_path, text)])
    assert code == 0, out
    assert cell(out, "Upper", "agrees") == "1", out
    assert cell(out, "Lower", "agrees") == "1", out
    assert cell(out, "Lower", "disagrees") == "0", out


def test_defaults_beside_an_unrelated_section_still_apply(tmp_path):
    """A ``[notes]`` section in the defaults chunk does not stop the
    defaults reaching the instruments after it."""

    text = "\n".join([
        "[defaults]",
        "tuning.standard = a415",
        "tuning.tonic = C",
        "[notes]",
        "text = surveyed for the diocese in 1950",
        "---",
        "[instrument]",
        "place = Upper",
        "[tuning]",
        "temperament = equal",
        "[claims]",
        "a4 = 415",
        "---",
        "[instrument]",
        "place = Lower",
        "[tuning]",
        "temperament = quarter_comma",
        "[claims]",
        "a4 = 415",
        "",
    ])
    code, out = ask(["survey", put(tmp_path, text)])
    assert code == 0, out
    for place in ("Upper", "Lower"):
        assert cell(out, place, "agrees") == "1", out
        assert cell(out, place, "disagrees") == "0", out


def test_a_default_temperament_in_the_first_chunk_is_counted(tmp_path):
    """The census sees the temperament the defaults give both."""

    text = "\n".join([
        "[defaults]",
        "tuning.temperament = equal",
        "[instrument]",
        "place = Upper",
        "---",
        "[instrument]",
        "place = Lower",
        "",
    ])
    code, out = ask(["census", put(tmp_path, text)])
    assert code == 0, out
    assert count_of(out, "equal") == "2", out


# ----------------------------------------------- R5 a survey stops at nothing


#: The second instrument's chunk, unreadable in each of the ways a
#: chunk can be.
UNREADABLE = {
    "field-twice": ["[instrument]", "place = Beta", "place = Beta",
                    "[tuning]", "temperament = werckmeister_iii",
                    "[claims]", "a4 = 440"],
    "no-equals": ["[instrument]", "place = Beta", "[tuning]",
                  "temperament werckmeister_iii", "[claims]",
                  "a4 = 440"],
    "no-bracket": ["[instrument]", "place = Beta", "[tuning",
                   "temperament = werckmeister_iii", "[claims]",
                   "a4 = 440"],
    "field-first": ["place = Beta", "[instrument]", "[tuning]",
                    "temperament = werckmeister_iii", "[claims]",
                    "a4 = 440"],
}

ALPHA = ["[instrument]", "place = Alpha", "[tuning]",
         "temperament = equal", "tonic = C", "[claims]",
         "a4 = 440",
         "middle_c = 261.6256"]
GAMMA = ["[instrument]", "place = Gamma", "[tuning]",
         "temperament = quarter_comma", "tonic = C", "[claims]",
         "wolf = 0"]
DEFAULTS = ["[defaults]", "tuning.standard = a440"]


def bundle_of(*chunks):
    """Chunks joined by separator lines."""

    return "\n---\n".join("\n".join(one) for one in chunks) + "\n"


def assert_the_good_ones(text):
    """Alpha's two claims agree and Gamma's wolf disagrees."""

    assert cell(text, "Alpha", "claims") == "2", text
    assert cell(text, "Alpha", "agrees") == "2", text
    assert cell(text, "Alpha", "disagrees") == "0", text
    assert cell(text, "Gamma", "claims") == "1", text
    assert cell(text, "Gamma", "agrees") == "0", text
    assert cell(text, "Gamma", "disagrees") == "1", text


@pytest.mark.parametrize("kind", list(UNREADABLE))
def test_a_survey_checks_the_instruments_around_an_unreadable_one(
        tmp_path, kind):
    """The first and third are read and checked."""

    path = put(tmp_path, bundle_of(DEFAULTS, ALPHA, UNREADABLE[kind],
                                   GAMMA))
    code, text = ask(["survey", path])
    no_traceback(code, text)
    assert code in (0, 2), text
    assert_the_good_ones(text)


@pytest.mark.parametrize("kind", list(UNREADABLE))
def test_a_survey_names_the_unreadable_instrument_by_position(
        tmp_path, kind):
    """An instrument is named or it is numbered: by the place it gives,
    or by its position, ``instrument 2``, the defaults chunk not being
    an instrument."""

    path = put(tmp_path, bundle_of(DEFAULTS, ALPHA, UNREADABLE[kind],
                                   GAMMA))
    code, text = ask(["survey", path])
    no_traceback(code, text)
    assert code in (0, 2), text
    assert reported(text, 2), text


@pytest.mark.parametrize("chunks,position", [
    ((UNREADABLE["field-twice"], ALPHA, GAMMA), 1),
    ((ALPHA, DEFAULTS, UNREADABLE["field-twice"], GAMMA), 2),
    ((ALPHA, DEFAULTS, GAMMA, UNREADABLE["field-twice"]), 3),
], ids=["first", "second-after-defaults", "third-after-defaults"])
def test_the_unreadable_instrument_is_numbered_by_position(
        tmp_path, chunks, position):
    """Counted among the instruments, defaults chunks left out,
    from one; the readable ones keep their rows."""

    code, text = ask(["survey", put(tmp_path, bundle_of(*chunks))])
    no_traceback(code, text)
    assert code in (0, 2), text
    assert reported(text, position), text
    assert cell(text, "Alpha", "claims") == "2", text
    assert cell(text, "Gamma", "claims") == "1", text


@pytest.mark.parametrize("kind", list(UNREADABLE))
def test_a_census_counts_the_instruments_around_an_unreadable_one(
        tmp_path, kind):
    """Equal and quarter-comma are each counted once."""

    path = put(tmp_path, bundle_of(DEFAULTS, ALPHA, UNREADABLE[kind],
                                   GAMMA))
    code, text = ask(["census", path])
    no_traceback(code, text)
    assert code in (0, 2), text
    assert count_of(text, "equal") == "1", text
    assert count_of(text, "quarter_comma") == "1", text


# ------------------------------------- R6 the file's line, survey's number


def test_an_unreadable_instrument_names_the_file_s_line(tmp_path):
    """The repeated field is on file line 13 (line 5 of its chunk),
    in the second instrument (the defaults chunk is not one)."""

    text = "\n".join([
        "[defaults]",                  # 1
        "tuning.standard = a415",      # 2
        "---",                         # 3
        "[instrument]",                # 4
        "place = Alpha",               # 5
        "[tuning]",                    # 6
        "temperament = equal",         # 7
        "---",                         # 8
        "[instrument]",                # 9
        "place = Beta",                # 10
        "[tuning]",                    # 11
        "temperament = equal",         # 12
        "temperament = equal",         # 13
        "",
    ])
    path = put(tmp_path, text, "bundle.stops")
    code, out = ask(["survey", path])
    no_traceback(code, out)
    assert "line 13" in flat(out), out
    assert reported(out, 2), out
    assert "instrument 3" not in flat(out), out


BAD_DEFAULTS = "\n".join([
    "[instrument]",                    # 1
    "place = Alpha",                   # 2
    "[tuning]",                        # 3
    "temperament = equal",             # 4
    "standard = a440",                 # 5
    "[claims]",                        # 6
    "a4 = 440",                        # 7
    "---",                             # 8
    "# the rest are at choir pitch",   # 9
    "[defaults]",                      # 10
    "tuning.standard = a415",          # 11
    "tuning.tonic = C",                # 12
    "tuning.standard = a466",          # 13
    "---",
    "[instrument]",
    "place = Beta",
    "[tuning]",
    "temperament = equal",
    "",
])


def test_a_bad_defaults_line_names_the_file_s_line(tmp_path):
    """``tuning.standard`` given twice in a defaults chunk that starts
    on line 9: the survey says line 13, not the chunk's line 5."""

    code, out = ask(["survey", put(tmp_path, BAD_DEFAULTS,
                                   "bundle.stops")])
    no_traceback(code, out)
    assert code in (0, 2), out
    assert "line 13" in flat(out), out


# ------------------------------------------- R7 the uncheckable column


# ----------------------------------------------- R8 nothing recomputed


def unsaid(text):
    """A file that has not said is not a file that agrees."""

    assert verdict_row(text, "agreed") != "yes", text


def test_a_file_with_no_claims_has_not_said(tmp_path):
    """Nothing checked, and not agreed."""

    code, text = ask(["verdict", put(tmp_path, PLAIN.split("[claims]")[0])])
    assert code == 0, text
    unsaid(text)


def test_the_cathedral_has_not_said():
    """The example the files page uses for a file that claims
    nothing."""

    code, text = ask(["verdict", CATHEDRAL])
    assert code == 0, text
    unsaid(text)


# ------------------------------------------------ R9 halfway agrees


def pipe_file(tmp_path, hertz, degrees, written):
    """An equal-tempered file with pipes and a bottom_pipe claim."""

    text = "\n".join(["[tuning]", "temperament = equal",
                      "standard = a440", "tonic = C", "[pipes]",
                      "bottom_hertz = " + hertz,
                      "degrees = " + degrees, "[claims]",
                      "bottom_pipe = " + written]) + "\n"
    return put(tmp_path, text)


def verdicts_of(tmp_path, hertz, degrees, claims):
    """The bottom_pipe verdict for each written claim."""

    out = []
    for written in claims:
        code, text = ask(["claims", pipe_file(tmp_path, hertz, degrees,
                                              written)])
        assert code == 0, text
        out.append(claim_verdict(text, "bottom_pipe"))
    return out


def test_exactly_halfway_one_of_the_two_places_agrees(tmp_path):
    """50 Hz at 20 degrees is exactly 11.25 feet. Compared to the one
    place it was written at, it is 11.2 or 11.3, whichever way a tie
    is rounded; a figure that agrees with neither has been compared
    to no precision at all."""

    found = verdicts_of(tmp_path, "50", "20", ["11.2", "11.3"])
    assert "agrees" in found, found


def test_exactly_halfway_one_of_the_two_whole_numbers_agrees(tmp_path):
    """49 Hz at 21 degrees is exactly 11.5 feet, half a unit from both
    11 and 12."""

    found = verdicts_of(tmp_path, "49", "21", ["11", "12"])
    assert "agrees" in found, found


# ------------------------------------- R10 no standard is not a440


def unstandard(tmp_path, claims, temperament="equal"):
    """A file with a temperament and no standard and no tonic."""

    text = "\n".join(["[instrument]", "builder = Hill", "[tuning]",
                      "temperament = " + temperament, "[claims]"]
                     + claims) + "\n"
    return put(tmp_path, text)


@pytest.mark.parametrize("claim,written", [("a4", "440"),
                                           ("middle_c", "261.6256")])
def test_a_pitch_claim_without_a_standard_is_uncheckable(
        tmp_path, claim, written):
    """Never judged at A440."""

    code, text = ask(["claims", unstandard(tmp_path,
                                           [claim + " = " + written])])
    assert code == 0, text
    assert claim_verdict(text, claim) == "uncheckable", text


def test_a4_at_choir_pitch_without_a_standard_is_not_wrong(tmp_path):
    """415 is not a disagreement with a standard nobody wrote."""

    code, text = ask(["claims", unstandard(tmp_path, ["a4 = 415"])])
    assert code == 0, text
    assert claim_verdict(text, "a4") == "uncheckable", text


# --------------------------------------------- R11 census by temperament


def census_of(tmp_path, temperaments):
    """A bundle of one instrument per temperament line given; None
    leaves the field out."""

    chunks = []
    for index, one in enumerate(temperaments, start=1):
        chunk = ["[instrument]", "place = Organ{0}".format(index)]
        if one is not None:
            chunk += ["[tuning]", "temperament = " + one]
        chunks.append(chunk)
    return put(tmp_path, bundle_of(*chunks))


def quarter_rows(text):
    """Every census row that spells quarter-comma somehow."""

    _, rows = heading_and_rows(text)
    return [line for line in rows
            if line.split() and line.split()[0].lower()
            .replace("-", "_").startswith("quarter")]


def total_of(text):
    """Every instrument the census counted, whatever its rows are
    called."""

    _, rows = heading_and_rows(text)
    return sum(int(line.split()[-1]) for line in rows
               if line.split() and line.split()[-1].isdigit())


def quarter_count(text):
    """The count on the one quarter-comma row, however the row is
    spelled: the request asks for one row, not for its label."""

    found = quarter_rows(text)
    assert len(found) == 1, text
    return found[0].split()[-1]


SPELLINGS = ["Quarter_Comma", "QUARTER_COMMA", "quarter-comma",
             "quarter comma"]


@pytest.mark.parametrize("spelling", SPELLINGS)
def test_a_spelling_is_counted_with_its_temperament(tmp_path, spelling):
    """One row for quarter-comma, holding both."""

    code, text = ask(["census", census_of(tmp_path, ["quarter_comma",
                                                     spelling])])
    assert code == 0, text
    assert quarter_count(text) == "2", text


def test_four_spellings_are_one_row_of_four(tmp_path):
    """Whatever the case, hyphen or space."""

    code, text = ask(["census", census_of(tmp_path, SPELLINGS)])
    assert code == 0, text
    assert quarter_count(text) == "4", text


def test_an_instrument_with_no_temperament_is_counted(tmp_path):
    """Counted, under whatever the census calls it."""

    code, text = ask(["census", census_of(tmp_path, ["equal", None])])
    assert code == 0, text
    assert count_of(text, "equal") == "1", text
    assert total_of(text) == 2, text


def test_absent_and_blank_are_counted_beside_the_rest(tmp_path):
    """Every instrument is in the census once."""

    code, text = ask(["census", census_of(
        tmp_path, ["equal", None, "Quarter_Comma", "", "quarter_comma"])])
    assert code == 0, text
    assert count_of(text, "equal") == "1", text
    assert quarter_count(text) == "2", text
    assert total_of(text) == 5, text


# ---------------------------------------------- R12 blank on the sheet


BLANKS = [("instrument", "builder"), ("tuning", "temperament"),
          ("tuning", "wolf"), ("stops", "borrowed"), ("wind", "stable")]


@pytest.mark.parametrize("section,field", BLANKS,
                         ids=[one[1] for one in BLANKS])
def test_a_blank_value_is_shown_as_blank(tmp_path, section, field):
    """Somebody looked and wrote nothing, which is not nobody
    looking: whatever the line says, it is not "not stated"."""

    path = put(tmp_path, "[{0}]\n{1} =\n".format(section, field))
    code, text = ask(["spec", path])
    assert code == 0, text
    assert spec_words(text, field) != ["not", "stated"], text


def test_blank_and_absent_say_different_things(tmp_path):
    """``wolf =`` is blank; ``last_tuned_at``, not written, is still
    not stated."""

    path = put(tmp_path, "[tuning]\ntemperament = equal\nwolf =\n")
    code, text = ask(["spec", path])
    assert code == 0, text
    assert spec_words(text, "wolf") != ["not", "stated"], text
    assert spec_words(text, "last_tuned_at") == ["not", "stated"], text


# ---------------------------------------- R13 convert refuses before writing


# ---------------------------------------------- R14 written back as written


EMPTY_CLAIMS = "[instrument]\nbuilder = Hill\n\n[tuning]\n" \
               "temperament = equal\n\n[claims]\n"


def test_an_empty_claims_section_is_shown(tmp_path):
    """The heading comes back."""

    code, text = ask(["show", put(tmp_path, EMPTY_CLAIMS)])
    assert code == 0, text
    assert "[claims]" in [one.strip() for one in text.split("\n")], text


def test_an_empty_claims_section_is_converted(tmp_path):
    """On the converted text as well."""

    code, text = ask(["convert", put(tmp_path, EMPTY_CLAIMS)])
    assert code == 0, text
    assert "[claims]" in [one.strip() for one in text.split("\n")], text


def test_an_empty_claims_section_survives_a_written_file(tmp_path):
    """The converted file still has the section to show."""

    out = tmp_path / "out.stops"
    code, text = ask(["convert", put(tmp_path, EMPTY_CLAIMS), "--out",
                      out])
    assert code == 0, text
    code, text = ask(["show", out, "--section", "claims"])
    assert code == 0, text


#: Claim names in other cases, with a value that agrees in a
#: quarter-comma file at A440.
CASED = [("Wolf", "35.68"), ("A4", "440"), ("Worst_Third", "41.06")]


def cased_file(tmp_path, name, written):
    """A quarter-comma file with one claim, its name in capitals."""

    text = "\n".join(["[tuning]", "Temperament = quarter_comma",
                      "standard = a440", "tonic = C", "[claims]",
                      "{0} = {1}".format(name, written)]) + "\n"
    return put(tmp_path, text)


@pytest.mark.parametrize("name,written", CASED,
                         ids=[one[0] for one in CASED])
def test_a_claim_name_keeps_its_case_in_show(tmp_path, name, written):
    """Claims come back exactly as they were."""

    code, text = ask(["show", cased_file(tmp_path, name, written)])
    assert code == 0, text
    lines = [one.strip() for one in text.split("\n")]
    assert "{0} = {1}".format(name, written) in lines, text
    assert "{0} = {1}".format(name.lower(), written) not in lines, text


@pytest.mark.parametrize("name,written", CASED,
                         ids=[one[0] for one in CASED])
def test_a_cased_claim_is_still_checked(tmp_path, name, written):
    """Kept as written, and still the claim it names."""

    path = cased_file(tmp_path, name, written)
    code, text = ask(["claims", path])
    assert code == 0, text
    assert claim_verdict(text, name) == "agrees", text
    code, text = ask(["show", path])
    assert "{0} = {1}".format(name, written) in \
        [one.strip() for one in text.split("\n")], text


def test_a_cased_claim_survives_a_written_file(tmp_path):
    """``Wolf = 1`` reads back as ``Wolf = 1`` from the converted
    file."""

    out = tmp_path / "out.stops"
    code, text = ask(["convert", cased_file(tmp_path, "Wolf", "1"),
                      "--out", out])
    assert code == 0, text
    written = [one.strip() for one in
               out.read_text(encoding="utf-8").split("\n")]
    assert "Wolf = 1" in written, written
    code, text = ask(["show", out])
    assert code == 0, text
    assert "Wolf = 1" in [one.strip() for one in text.split("\n")], text


def test_a_cased_claim_counts_in_the_verdict(tmp_path):
    """Not unknown, and the file agreed; its name kept."""

    path = cased_file(tmp_path, "Wolf", "35.68")
    code, text = ask(["verdict", path])
    assert code == 0, text
    assert verdict_row(text, "unknown") == "0", text
    assert verdict_row(text, "agreed") == "yes", text
    code, text = ask(["convert", path])
    assert "Wolf = 35.68" in [one.strip() for one in text.split("\n")], \
        text


# ------------------------------------------------ the changelog entry


#: Bulleted entries and non-blank lines in CHANGELOG.md at the base.
BASE_ENTRIES = 56
BASE_LINES = 223


def test_the_changelog_gains_an_entry():
    """The request asks for a changelog entry, so the changelog has
    more entries, or at least more lines, than it had."""

    text = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
    lines = [line for line in text.splitlines() if line.strip()]
    entries = [line for line in lines
               if line.lstrip().startswith(("- ", "* "))]
    assert len(entries) > BASE_ENTRIES or len(lines) > BASE_LINES, (
        len(entries), len(lines))
