"""What the file commands already do right and have to keep doing.

Comments are stripped wherever they start, a name given twice in one
file is refused with its line, a ``[defaults]`` chunk reaches the
instruments after it and an instrument's own field beats it, a
default with no section is refused, an unknown claim is unknown, and
a claim is compared at the precision it was written to. The shipped
examples still read, check and write back, the chapel still
disagrees and the village still agrees, and the survey example still
counts its temperaments. All of these pass before the change; they
are here so the change cannot be made by breaking them.

Driven through ``run`` and the text it returns, on the examples and
on files written under ``tmp_path``.
"""

from __future__ import annotations

import pathlib
import re
import traceback

import pytest

from wolf.cli.main import run

ROOT = pathlib.Path(__file__).resolve().parent.parent
EXAMPLES = ROOT / "examples"
SINGLE = ["cathedral", "chapel", "village"]
SURVEY = str(EXAMPLES / "survey.stops")


def ask(argv):
    """``run``, with an escaping exception turned into a failing
    answer."""

    try:
        return run([str(one) for one in argv])
    except Exception:  # noqa: BLE001 - the traceback is the finding
        return -1, traceback.format_exc()


def put(tmp_path, text, name="organ.stops"):
    """A file with exactly this text, as UTF-8, newlines untouched."""

    path = tmp_path / name
    path.write_bytes(text.encode("utf-8"))
    return str(path)


def flat(text):
    """Every run of white space as one space."""

    return " ".join(str(text).split())


def figure_part(text):
    """The lines of a report's Figure part."""

    lines = text.splitlines()
    assert "Figure" in lines, text
    start = lines.index("Figure") + 1
    end = lines.index("Working") if "Working" in lines[start:] \
        else len(lines)
    return lines[start:end]


def heading_and_rows(text):
    """A table's heading words and its row lines."""

    part = [line for line in figure_part(text)
            if line.strip() and set(line.strip()) - {"-", " "}]
    assert part, text
    return part[0].split(), part[1:]


def cell(text, title, heading):
    """One survey cell, by the row's title and the column's heading."""

    headings, rows = heading_and_rows(text)
    assert heading in headings, (heading, text)
    found = [line for line in rows
             if line.split()[:len(title.split())] == title.split()]
    assert found, (title, text)
    rest = found[0].split()[len(title.split()):]
    where = headings.index(heading) - 1
    assert len(rest) > where, (title, heading, text)
    return rest[where]


def count_of(text, name):
    """A census row's count."""

    _, rows = heading_and_rows(text)
    found = [line.split() for line in rows
             if line.split()[:len(name.split())] == name.split()]
    assert len(found) == 1, (name, text)
    return found[0][len(name.split())]


def verdict_row(text, name):
    """What a verdict's Figure says beside one name."""

    for line in figure_part(text):
        match = re.match(r"^" + re.escape(name) + r"\s+(.*\S)\s*$",
                         line)
        if match:
            return match.group(1)
    raise AssertionError(name + " has no row in\n" + text)


def claim_verdict(text, claim):
    """The verdict on one claim's row, the name matched in any case."""

    for line in figure_part(text):
        words = line.split()
        if words and words[0].lower() == claim.lower():
            return words[-1]
    raise AssertionError(claim + " has no row in\n" + text)


def field_lines(path):
    """Every ``name = value`` line of a file, comments and blanks
    left out."""

    out = []
    for raw in pathlib.Path(path).read_text(encoding="utf-8").split("\n"):
        line = raw.split("#", 1)[0].strip()
        if line and "=" in line and not line.startswith("["):
            name, _, value = line.partition("=")
            out.append("{0} = {1}".format(name.strip(),
                                          value.strip()).rstrip())
    return out


QUARTER = "\n".join([
    "[instrument]",
    "builder = Snetzler",
    "[tuning]",
    "temperament = quarter_comma",
    "standard = a440",
    "tonic = C",
    "[claims]",
    "wolf = {0}",
    "",
])


# ------------------------------------------------------------- comments


def test_a_comment_is_stripped_wherever_it_starts(tmp_path):
    """After a heading, a field and a claim, as well as on its own
    line."""

    text = "\n".join([
        "# the chapel organ",
        "[tuning]   # as found in 1950",
        "temperament = quarter_comma # meantone",
        "standard = a440#modern",
        "tonic = C",
        "[claims]",
        "wolf = 35.68 # measured",
        "",
    ])
    path = put(tmp_path, text)
    code, out = ask(["claims", path])
    assert code == 0, out
    assert claim_verdict(out, "wolf") == "agrees", out
    code, out = ask(["show", path])
    assert code == 0, out
    lines = out.split("\n")
    assert "temperament = quarter_comma" in lines, out
    assert "standard = a440" in lines, out
    for word in ("meantone", "measured", "modern", "1950"):
        assert word not in out, out


# ------------------------------------------------- a name given twice


TWICE = "[tuning]\ntemperament = equal\nstandard = a440\n" \
        "temperament = just\n"


@pytest.mark.parametrize("command",
                         ["show", "claims", "verdict", "spec", "convert"])
def test_a_name_given_twice_is_refused_with_its_line(tmp_path, command):
    """Two opinions in one file: exit two, naming line four."""

    code, text = ask([command, put(tmp_path, TWICE)])
    assert code == 2, text
    assert "line 4" in flat(text), text
    assert "Traceback" not in text, text


def test_crlf_lines_are_lines(tmp_path):
    """A file saved on Windows reads the same."""

    path = put(tmp_path, QUARTER.format("35.68").replace("\n", "\r\n"))
    code, text = ask(["claims", path])
    assert code == 0, text
    assert claim_verdict(text, "wolf") == "agrees", text


def test_crlf_line_numbers_count_each_line_once(tmp_path):
    """The repeated field is still on line four."""

    code, text = ask(["show", put(tmp_path, TWICE.replace("\n", "\r\n"))])
    assert code == 2, text
    assert "line 4" in flat(text), text


# --------------------------------------------------------------- defaults


OWN_CHUNK = "\n".join([
    "[defaults]",
    "tuning.standard = a415",
    "tuning.tonic = C",
    "tuning.temperament = equal",
    "---",
    "[instrument]",
    "place = Upper",
    "[claims]",
    "a4 = 415",
    "---",
    "[instrument]",
    "place = Lower",
    "[tuning]",
    "temperament = quarter_comma",
    "standard = a440",
    "tonic = C",
    "[claims]",
    "a4 = 440",
    "",
])


def test_defaults_in_their_own_chunk_reach_the_instruments(tmp_path):
    """The first takes the default standard and agrees at 415."""

    code, text = ask(["survey", put(tmp_path, OWN_CHUNK)])
    assert code == 0, text
    assert cell(text, "Upper", "agrees") == "1", text
    assert cell(text, "Upper", "disagrees") == "0", text


def test_an_instrument_s_own_field_beats_the_default(tmp_path):
    """The second says A440 and quarter-comma, and is held to them."""

    path = put(tmp_path, OWN_CHUNK)
    code, text = ask(["survey", path])
    assert code == 0, text
    assert cell(text, "Lower", "agrees") == "1", text
    code, text = ask(["census", path])
    assert code == 0, text
    assert count_of(text, "equal") == "1", text
    assert count_of(text, "quarter_comma") == "1", text


@pytest.mark.parametrize("command", ["survey", "census"])
def test_a_default_without_a_section_is_not_applied(tmp_path, command):
    """``standard = a415`` under ``[defaults]`` says nothing about
    which section it belongs to: it is reported, with no traceback,
    whether the survey refuses the file or goes on without it."""

    text = OWN_CHUNK.replace("tuning.standard = a415", "standard = a415")
    code, out = ask([command, put(tmp_path, text)])
    assert code in (0, 2), out
    assert "Traceback" not in out, out
    if command == "survey":
        assert "standard" in out, out


# ------------------------------------------------------------ the claims


def test_an_unknown_claim_is_unknown(tmp_path):
    """And makes the file disagree."""

    path = put(tmp_path, QUARTER.format("35.68") + "smell = damp\n")
    code, text = ask(["claims", path])
    assert code == 0, text
    assert claim_verdict(text, "smell") == "unknown", text
    code, text = ask(["verdict", path])
    assert code == 0, text
    assert verdict_row(text, "unknown") == "1", text
    assert verdict_row(text, "agreed") == "no", text


PRECISION = [("35.7", "agrees"), ("35.68", "agrees"),
             ("35.6823", "agrees"), ("35.69", "disagrees"),
             ("35.6824", "disagrees")]


@pytest.mark.parametrize("written,verdict", PRECISION,
                         ids=[one[0] for one in PRECISION])
def test_a_claim_is_held_to_the_places_it_was_written_to(
        tmp_path, written, verdict):
    """The quarter-comma wolf is 35.6823."""

    code, text = ask(["claims", put(tmp_path, QUARTER.format(written))])
    assert code == 0, text
    assert claim_verdict(text, "wolf") == verdict, text


@pytest.mark.parametrize("written,verdict", [("11.25", "agrees"),
                                             ("11.4", "disagrees")])
def test_a_pipe_claim_past_halfway_still_disagrees(tmp_path, written,
                                                   verdict):
    """50 Hz at 20 degrees is 11.25 feet."""

    text = "\n".join(["[tuning]", "temperament = equal",
                      "standard = a440", "tonic = C", "[pipes]",
                      "bottom_hertz = 50",
                      "degrees = 20", "[claims]",
                      "bottom_pipe = " + written]) + "\n"
    code, out = ask(["claims", put(tmp_path, text)])
    assert code == 0, out
    assert claim_verdict(out, "bottom_pipe") == verdict, out


def test_a4_is_checked_at_the_standard_written(tmp_path):
    """At A415 and at A440."""

    for standard, written in (("a415", "415"), ("a440", "440")):
        text = "\n".join(["[tuning]", "temperament = equal",
                          "standard = " + standard, "tonic = C",
                          "[claims]",
                          "a4 = " + written]) + "\n"
        code, out = ask(["claims", put(tmp_path, text)])
        assert code == 0, out
        assert claim_verdict(out, "a4") == "agrees", out


def test_a_claim_name_is_recognised_in_any_case(tmp_path):
    """``Wolf`` is the wolf claim, and not unknown."""

    path = put(tmp_path, QUARTER.format("35.68").replace("wolf =",
                                                         "Wolf ="))
    code, text = ask(["claims", path])
    assert code == 0, text
    assert claim_verdict(text, "wolf") == "agrees", text
    code, text = ask(["verdict", path])
    assert code == 0, text
    assert verdict_row(text, "unknown") == "0", text


# ---------------------------------------------------------- writing back


def test_a_blank_value_is_written_back_blank(tmp_path):
    """``wolf =`` stays a line with nothing after it."""

    code, text = ask(["show", put(tmp_path,
                                  "[tuning]\ntemperament = equal\n"
                                  "wolf =\n")])
    assert code == 0, text
    assert "wolf =" in [one.rstrip() for one in text.split("\n")], text


def test_a_converted_file_reads_back(tmp_path):
    """Its fields and claims as they were."""

    source = str(EXAMPLES / "chapel.stops")
    out = tmp_path / "written.stops"
    code, text = ask(["convert", source, "--out", out])
    assert code == 0, text
    code, text = ask(["show", out])
    assert code == 0, text
    for line in field_lines(source):
        assert line in text.split("\n"), (line, text)


@pytest.mark.parametrize("command", ["show", "claims", "convert",
                                     "survey"])
def test_a_missing_file_is_still_exit_two(tmp_path, command):
    """A failure to read is asked wrongly."""

    code, text = ask([command, tmp_path / "nonesuch.stops"])
    assert code == 2, text
    assert "Traceback" not in text, text


# ------------------------------------------------------------ the examples


ANSWERS = [(name, command) for name in SINGLE
           for command in ("show", "claims", "verdict", "spec",
                           "convert")]


@pytest.mark.parametrize("name,command", ANSWERS,
                         ids=["-".join(one) for one in ANSWERS])
def test_an_example_still_answers(name, command):
    """Exit nought, and the parts each command always printed."""

    path = str(EXAMPLES / (name + ".stops"))
    code, text = ask([command, path])
    assert code == 0, text
    if command in ("show", "convert"):
        lines = text.split("\n")
        for line in field_lines(path):
            assert line in lines, (line, text)
    elif command == "spec":
        assert "TUNING" in text.split("\n"), text
    else:
        assert "Figure" in text.split("\n"), text


def test_the_chapel_still_disagrees():
    """Its wolf is the Pythagorean comma."""

    code, text = ask(["verdict", str(EXAMPLES / "chapel.stops")])
    assert code == 0, text
    assert verdict_row(text, "agreed") == "no", text
    assert verdict_row(text, "disagrees") == "1", text
    code, text = ask(["claims", str(EXAMPLES / "chapel.stops")])
    assert claim_verdict(text, "a4") == "agrees", text
    assert claim_verdict(text, "wolf") == "disagrees", text
    assert claim_verdict(text, "worst_third") == "agrees", text


def test_the_village_still_agrees():
    """Four claims, four checked, all agreeing."""

    code, text = ask(["verdict", str(EXAMPLES / "village.stops")])
    assert code == 0, text
    assert verdict_row(text, "agreed") == "yes", text
    assert verdict_row(text, "agrees") == "4", text
    assert verdict_row(text, "checked") == "4", text


def test_the_survey_example_is_still_surveyed():
    """Three rows, the second disagreeing."""

    code, text = ask(["survey", SURVEY])
    assert code == 0, text
    assert cell(text, "Chapel of St Cuthbert", "agrees") == "1", text
    assert cell(text, "St Mary the Virgin", "disagrees") == "1", text
    assert cell(text, "Village hall", "agrees") == "1", text
    for title in ("Chapel of St Cuthbert", "St Mary the Virgin",
                  "Village hall"):
        assert cell(text, title, "claims") == "1", text


def test_the_survey_example_s_census():
    """One equal, two quarter-comma."""

    code, text = ask(["census", SURVEY])
    assert code == 0, text
    assert count_of(text, "equal") == "1", text
    assert count_of(text, "quarter_comma") == "2", text


# --------------------------------------------------- fields and sections


def test_the_blank_sheet_still_has_its_tuning_section():
    """Every tuning field, not stated."""

    code, text = ask(["fields"])
    assert code == 0, text
    lines = text.split("\n")
    assert "TUNING" in lines, text
    start = lines.index("TUNING") + 1
    found = {}
    for line in lines[start:]:
        if not line.strip():
            break
        words = line.split()
        found[words[0]] = " ".join(words[1:])
    for field in ("temperament", "standard", "tonic", "wolf",
                  "last_tuned_at"):
        assert found.get(field) == "not stated", text


def test_one_section_is_still_shown_on_its_own():
    """``--section tuning`` on the chapel."""

    code, text = ask(["show", str(EXAMPLES / "chapel.stops"),
                      "--section", "tuning"])
    assert code == 0, text
    assert text.split("\n") == ["temperament = quarter_comma",
                                "tonic = C", "standard = a415"], text


def test_a_section_the_file_has_not_got_is_still_refused():
    """Exit two, naming it."""

    code, text = ask(["show", str(EXAMPLES / "chapel.stops"),
                      "--section", "wind"])
    assert code == 2, text
    assert "wind" in text, text
