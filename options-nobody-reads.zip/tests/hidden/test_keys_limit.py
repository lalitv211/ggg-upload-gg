"""``wolf keys --limit``: the keys whose worst interval is past it.

``--limit`` was described in the temper group's help as "the worst
interval a key may hold, in cents" and nothing read it. ``keys`` now
does: given a limit it adds a column saying, for every key, whether
that key's worst interval is further from just than the limit, either
side. Without one the table is what it always was.

The keys expected past the limit come from the library's own
:func:`wolf.temper.wolf.unusable`, which has always taken a limit and
which no command called.
"""

from __future__ import annotations

import pathlib
import re
from fractions import Fraction

import pytest

from wolf.cli.main import run
from wolf.temper import table as temper_table
from wolf.temper import wolf as wolf_module

ROOT = pathlib.Path(__file__).resolve().parent.parent
COLUMN = "past the limit"


def figure_of(text):
    """The lines of a report's figure, heading and rule left out."""

    lines = text.splitlines()
    start = lines.index("Figure") + 2
    end = lines.index("Working")
    return [line for line in lines[start:end] if line.strip()]


def marked(text, notes):
    """Each key row's mark: True past the limit, False within it."""

    out = {}
    for line in figure_of(text):
        words = line.split()
        if not words or words[0] not in notes:
            continue
        said = [one for one in words if one in ("yes", "no")]
        assert len(said) == 1, line
        out[words[0]] = said[0] == "yes"
    return out


def expected(name, tonic, limit):
    """The keys the library says are past the limit."""

    made = temper_table.named(name, tonic)
    return made, set(wolf_module.unusable(made, Fraction(limit)))


CASES = [
    ("werckmeister_iii", "C", "20"),
    ("werckmeister_iii", "C", "21.5"),
    ("werckmeister_iii", "C", "21.51"),
    ("werckmeister_iii", "C", "22"),
    ("werckmeister_iii", "G", "20"),
    ("quarter_comma", "C", "20"),
    ("quarter_comma", "C", "41.5"),
    ("quarter_comma", "C", "0"),
    ("equal", "C", "10"),
    ("equal", "C", "13.7"),
    ("pythagorean", "C", "20"),
    ("kirnberger_iii", "C", "15"),
    ("just", "C", "20"),
    ("sixth_comma", "D", "12"),
]


@pytest.mark.parametrize("name,tonic,limit", CASES,
                         ids=["-".join(one) for one in CASES])
def test_a_limit_marks_every_key_past_it(name, tonic, limit):
    """One mark per key, yes for exactly the keys past the limit."""

    code, text = run(["keys", name, "--tonic", tonic, "--limit", limit])
    assert code == 0, text
    assert any(COLUMN in line for line in figure_of(text)), text
    made, past = expected(name, tonic, limit)
    found = marked(text, set(made.notes()))
    assert set(found) == set(made.notes()), text
    assert {one for one, mark in found.items() if mark} == past, text


def test_werckmeister_has_four_keys_past_twenty_cents():
    """The figure the temperament page gives in its prose."""

    text = run(["keys", "werckmeister_iii", "--limit", "20"])[1]
    found = marked(text, set(temper_table.named("werckmeister_iii")
                             .notes()))
    assert sorted(one for one, mark in found.items() if mark) == \
        ["A", "C#", "Eb", "G#"]


def test_quarter_comma_has_six_keys_past_twenty_cents():
    """The figure the changelog gives, more than the wolf alone
    touches."""

    text = run(["keys", "quarter_comma", "--limit", "20"])[1]
    found = marked(text, set(temper_table.named("quarter_comma")
                             .notes()))
    assert sum(found.values()) == 6


def test_a_decimal_limit_is_not_cut_to_a_whole_number():
    """21.5 cents passes four Werckmeister keys and 21 would pass
    the same four, but 21.51 passes none."""

    notes = set(temper_table.named("werckmeister_iii").notes())
    lower = marked(run(["keys", "werckmeister_iii", "--limit",
                        "21.5"])[1], notes)
    upper = marked(run(["keys", "werckmeister_iii", "--limit",
                        "21.51"])[1], notes)
    assert sum(lower.values()) == 4
    assert sum(upper.values()) == 0


def test_the_limit_and_places_go_together():
    """Two places on the figures and the same keys marked."""

    code, text = run(["keys", "quarter_comma", "--limit", "20",
                      "--places", "2"])
    assert code == 0, text
    assert "46.44" in text
    made, past = expected("quarter_comma", "C", "20")
    found = marked(text, set(made.notes()))
    assert {one for one, mark in found.items() if mark} == past


@pytest.mark.parametrize("given", ["lots", "twenty"])
def test_a_limit_that_is_not_a_number_is_asked_wrongly(given):
    """A word: exit two, naming the option."""

    code, text = run(["keys", "equal", "--limit", given])
    assert code == 2, text
    assert "--limit" in text
    assert "Traceback" not in text


def test_a_limit_below_nought_is_not_answered():
    """Nothing is nearer to just than just, so every key would be
    past it; that is a question asked wrongly or refused, not a
    table."""

    code, text = run(["keys", "equal", "--limit", "-5"])
    assert code in (2, 3), text
    assert COLUMN not in text


NUMBER_WORDS = {1: "one", 2: "two", 3: "three", 4: "four", 5: "five",
                6: "six", 7: "seven", 8: "eight", 9: "nine", 10: "ten",
                11: "eleven", 12: "twelve"}


def working_of(text):
    """The lines of a report's working part, heading and rule left out."""

    lines = text.splitlines()
    start = lines.index("Working") + 2
    end = lines.index("Limits") if "Limits" in lines else len(lines)
    return "\n".join(lines[start:end])


def says_a_count(words, count):
    """Whether a count is stated, as a figure or as a word."""

    figure = r"(?<![\d.]){0}(?![\d.])".format(count)
    word = r"\b{0}\b".format(NUMBER_WORDS[count])
    return bool(re.search(figure, words) or re.search(word, words, re.I))


COUNTED = [
    ("werckmeister_iii", "20"),
    ("quarter_comma", "41.5"),
    ("quarter_comma", "0"),
    ("pythagorean", "20"),
    ("kirnberger_iii", "15"),
    ("just", "20"),
]


@pytest.mark.parametrize("name,limit", COUNTED,
                         ids=["-".join(one) for one in COUNTED])
def test_the_working_says_how_many_keys_are_past(name, limit):
    """The report's working part states the count of keys past the
    limit, the count the library gives."""

    code, text = run(["keys", name, "--limit", limit])
    assert code == 0, text
    made, past = expected(name, "C", limit)
    assert past, (name, limit)
    assert says_a_count(working_of(text), len(past)), text


@pytest.mark.parametrize("given", ["lots", "twenty"])
def test_a_limit_asked_wrongly_shows_a_value_to_type(given):
    """As ``--places`` does: the refusal shows ``--limit`` with a
    number after it."""

    code, text = run(["keys", "equal", "--limit", given])
    assert code == 2, text
    assert re.search(r"--limit[ =]\d", text), text


def test_the_temperament_page_shows_keys_with_a_limit():
    """A console block on docs/temperament.md runs keys with a limit;
    the existing documentation test checks what it shows."""

    page = (ROOT / "docs" / "temperament.md").read_text(encoding="utf-8")
    assert any(re.match(r"\$ wolf keys\b.*--limit\b", line)
               for line in page.splitlines()), page
