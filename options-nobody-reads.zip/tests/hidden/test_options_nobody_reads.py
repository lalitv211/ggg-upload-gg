"""A command refuses the options it never reads.

Each group of commands used to hand its whole option table to every
command in it, and ``--quiet`` and ``--exact`` were handed to every
command in the package, so ``wolf hertz A4 --instrument horn_in_f``
answered at concert pitch with exit nought. Every command here is
given every option of its group that its own code never reads, and
both of the flags nothing reads, and has to refuse each one as asked
wrongly, saying which commands do take a real option.

Driven through ``run`` only, so it holds whatever shape the option
tables take inside.
"""

from __future__ import annotations

import pathlib
import re

import pytest

from wolf.cli.main import run

ROOT = pathlib.Path(__file__).resolve().parent.parent
CHAPEL = str(ROOT / "examples" / "chapel.stops")
SURVEY = str(ROOT / "examples" / "survey.stops")
READINGS = ["263.18", "275", "294.25", "314.84", "328.98", "352.4",
            "368.18", "393.55", "411.22", "439.99", "470.78", "492.14"]

#: A command line that answers, for every command.
ASKED = {
    "size": ["size", "3:2"],
    "stack": ["stack", "3:2", "4:3"],
    "commas": ["commas"],
    "part": ["part", "--part", "1/4"],
    "circle": ["circle", "12"],
    "names": ["names", "5"],
    "addnames": ["addnames", "3", "3"],
    "just": ["just"],
    "trip": ["trip", "4:3"],
    "hertz": ["hertz", "A4"],
    "scale": ["scale"],
    "standards": ["standards"],
    "rounding": ["rounding", "-1"],
    "beats": ["beats", "C", "G"],
    "spell": ["spell", "C#4", "Db4"],
    "instruments": ["instruments"],
    "sounds": ["sounds", "C4"],
    "parts": ["parts", "C4"],
    "temperaments": ["temperaments"],
    "tuning": ["tuning", "quarter_comma"],
    "wolves": ["wolves", "quarter_comma"],
    "keys": ["keys", "werckmeister_iii"],
    "intervals": ["intervals", "quarter_comma", "--steps", "4"],
    "spread": ["spread", "equal", "--steps", "4"],
    "chain": ["chain", "quarter_comma"],
    "compare": ["compare", "equal", "quarter_comma"],
    "meantone": ["meantone", "--part", "1/4"],
    "pipe": ["pipe", "65.41"],
    "ends": ["ends", "65.41"],
    "warming": ["warming", "15", "25"],
    "stops": ["stops"],
    "draw": ["draw", "65.41"],
    "scales": ["scales"],
    "rank": ["rank"],
    "unit": ["unit"],
    "thinning": ["thinning", "24", "36"],
    "show": ["show", CHAPEL],
    "claims": ["claims", CHAPEL],
    "verdict": ["verdict", CHAPEL],
    "spec": ["spec", CHAPEL],
    "convert": ["convert", CHAPEL],
    "fields": ["fields"],
    "survey": ["survey", SURVEY],
    "census": ["census", SURVEY],
    "which": ["which"] + READINGS,
    "harmonics": ["harmonics"],
    "divisions": ["divisions"],
    "divide": ["divide", "31"],
    "scaleof": ["scaleof", "C"],
    "character": ["character", "--temperament", "werckmeister_iii"],
    "bearings": ["bearings", "equal"],
    "chord": ["chord", "major"],
    "roots": ["roots", "major"],
    "mixture": ["mixture", "mixture_iv"],
    "picture": ["picture", "--temperament", "quarter_comma"],
    "optimum": ["optimum", "--weights", "fifth=1,major_third=1"],
    "optima": ["optima"],
}

#: Each group's commands and the options its table has always
#: described.
GROUPS = {
    "interval": (("size", "stack", "commas", "part", "circle", "names",
                  "addnames", "just", "trip"),
                 ("--against", "--comma", "--part")),
    "pitch": (("hertz", "scale", "standards", "rounding", "beats",
               "spell", "instruments", "sounds", "parts"),
              ("--instrument", "--octave", "--standard",
               "--temperament", "--tonic")),
    "temper": (("temperaments", "tuning", "wolves", "keys",
                "intervals", "spread", "chain", "compare", "meantone"),
               ("--comma", "--just", "--limit", "--part", "--steps",
                "--tonic")),
    "pipe": (("pipe", "ends", "warming", "stops", "draw", "scales",
              "rank", "unit", "thinning"),
             ("--bottom", "--compass", "--degrees", "--diameter",
              "--end", "--halving", "--stops")),
    "files": (("show", "claims", "verdict", "spec", "convert",
               "fields", "survey", "census", "which"),
              ("--out", "--section")),
    "more": (("harmonics", "divisions", "divide", "scaleof",
              "character", "bearings", "chord", "roots", "mixture",
              "picture", "optimum", "optima"),
             ("--against", "--ceiling", "--compass", "--how",
              "--octave", "--root", "--scale", "--standard",
              "--temperament", "--tonic", "--weights")),
}

#: What each command's own code reads, besides ``--places``; for
#: ``keys`` that includes the ``--limit`` it is asked to read.
READS = {
    "size": ("--against",),
    "part": ("--comma", "--part"),
    "hertz": ("--standard", "--temperament", "--tonic"),
    "scale": ("--octave", "--standard", "--temperament", "--tonic"),
    "beats": ("--octave", "--standard", "--temperament", "--tonic"),
    "sounds": ("--instrument",),
    "tuning": ("--tonic",),
    "wolves": ("--tonic",),
    "keys": ("--limit", "--tonic"),
    "intervals": ("--just", "--steps", "--tonic"),
    "spread": ("--just", "--steps", "--tonic"),
    "chain": ("--tonic",),
    "compare": ("--tonic",),
    "meantone": ("--comma", "--part"),
    "pipe": ("--degrees", "--diameter", "--end"),
    "ends": ("--degrees",),
    "draw": ("--stops",),
    "rank": ("--bottom", "--compass", "--halving"),
    "unit": ("--compass", "--stops"),
    "thinning": ("--compass", "--stops"),
    "show": ("--section",),
    "convert": ("--out",),
    "scaleof": ("--scale", "--temperament", "--tonic"),
    "character": ("--scale", "--temperament", "--tonic"),
    "bearings": ("--octave", "--standard"),
    "chord": ("--root", "--temperament", "--tonic"),
    "roots": ("--temperament", "--tonic"),
    "mixture": ("--ceiling", "--compass"),
    "picture": ("--against", "--temperament", "--tonic"),
    "optimum": ("--how", "--weights"),
    "optima": ("--how",),
}

#: A value each option could sensibly be given.
VALUES = {
    "--against": "3:2",
    "--bottom": "6",
    "--ceiling": "8000",
    "--comma": "pythagorean",
    "--compass": "56",
    "--degrees": "15",
    "--diameter": "3",
    "--end": "stopped",
    "--halving": "normal",
    "--how": "total",
    "--instrument": "horn_in_f",
    "--just": "5:4",
    "--limit": "20",
    "--octave": "5",
    "--out": "written.stops",
    "--part": "1/6",
    "--root": "D",
    "--scale": "minor",
    "--section": "tuning",
    "--standard": "a415",
    "--stops": "8,4",
    "--steps": "4",
    "--temperament": "quarter_comma",
    "--tonic": "G",
    "--weights": "fifth=1",
}

OPTION_LINE = re.compile(r"^\s+(--[a-z]+)\b")
AN_OPTION = re.compile(r"--[a-z]+")


def takers(option):
    """Every command whose own code reads an option."""

    return sorted(name for name, read in READS.items()
                  if option in read)


def unread():
    """Every command, with each option of its group it never reads."""

    out = []
    for names, options in GROUPS.values():
        for name in names:
            for option in options:
                if option not in READS.get(name, ()):
                    out.append((name, option))
    return out


def names_a_command(text, commands):
    """Whether a refusal names one of these commands.

    Option names are taken out first, so ``--scale`` in a list of
    known options is not mistaken for the ``scale`` command.
    """

    words = AN_OPTION.sub(" ", text)
    return any(re.search(r"(?<![\w-])" + re.escape(one) + r"(?![\w-])",
                         words) for one in commands)


@pytest.fixture(autouse=True)
def somewhere_else(tmp_path, monkeypatch):
    """Nothing a refused command line names is written here."""

    monkeypatch.chdir(tmp_path)
    yield
    assert not (tmp_path / "written.stops").exists()


@pytest.mark.parametrize("name,option", unread(),
                         ids=["{0}-{1}".format(*one) for one in unread()])
def test_an_option_the_command_never_reads_is_refused(name, option):
    """Exit two, naming the option and a command that does take it."""

    code, text = run(ASKED[name] + [option, VALUES[option]])
    assert code == 2, (name, option, text)
    assert option in text, (name, option, text)
    assert "Traceback" not in text
    assert names_a_command(text, takers(option)), (name, option, text)


@pytest.mark.parametrize("flag", ["--quiet", "--exact"])
@pytest.mark.parametrize("name", sorted(ASKED))
def test_a_flag_nothing_reads_is_refused(name, flag):
    """``--quiet`` and ``--exact`` were taken everywhere and read
    nowhere."""

    code, text = run(ASKED[name] + [flag])
    assert code == 2, (name, flag, text)
    assert flag in text, (name, flag, text)


@pytest.mark.parametrize("name", sorted(ASKED))
def test_help_lists_what_the_command_takes(name):
    """And nothing it would refuse."""

    code, text = run(["help", name])
    assert code == 0
    listed = {found.group(1) for found in
              (OPTION_LINE.match(line) for line in text.splitlines())
              if found}
    assert listed == set(READS.get(name, ())) | {"--places"}, name


def test_hertz_does_not_answer_for_a_horn():
    """The case that started it: a horn part read at concert pitch."""

    code, text = run(["hertz", "A4", "--instrument", "horn_in_f"])
    assert code == 2, text
    assert "--instrument" in text
    assert names_a_command(text, ["sounds"]), text


def test_a_refused_option_is_refused_before_the_command_runs():
    """``wolf show`` is not a way to write a file."""

    code, text = run(["show", CHAPEL, "--out", "written.stops"])
    assert code == 2, text
    assert names_a_command(text, ["convert"]), text


def test_the_limit_is_refused_by_every_temper_command_but_keys():
    """``--limit`` belongs to ``keys`` and nothing else."""

    for name in GROUPS["temper"][0]:
        code, text = run(ASKED[name] + ["--limit", "20"])
        if name == "keys":
            assert code == 0, text
        else:
            assert code == 2, (name, text)
            assert names_a_command(text, ["keys"]), (name, text)
