"""What already holds and has to keep holding.

Every option a command's own code reads is still taken by that
command, ``--places`` is still taken by every command, a misspelled
option still gets its suggestion, and ``keys`` without a limit is the
table it always was. All of these pass before the change; they are
here so the fix cannot be made by refusing too much.
"""

from __future__ import annotations

import pathlib

import pytest

from wolf.cli.main import run

ROOT = pathlib.Path(__file__).resolve().parent.parent
CHAPEL = str(ROOT / "examples" / "chapel.stops")
SURVEY = str(ROOT / "examples" / "survey.stops")
READINGS = ["263.18", "275", "294.25", "314.84", "328.98", "352.4",
            "368.18", "393.55", "411.22", "439.99", "470.78", "492.14"]

#: A command line that answers, for every command.
ASKED = {
    "size": ["size", "3:2"],
    "stack": ["stack", "3:2", "4:3"],
    "commas": ["commas"],
    "part": ["part", "--part", "1/4"],
    "circle": ["circle", "12"],
    "names": ["names", "5"],
    "addnames": ["addnames", "3", "3"],
    "just": ["just"],
    "trip": ["trip", "4:3"],
    "hertz": ["hertz", "A4"],
    "scale": ["scale"],
    "standards": ["standards"],
    "rounding": ["rounding", "-1"],
    "beats": ["beats", "C", "G"],
    "spell": ["spell", "C#4", "Db4"],
    "instruments": ["instruments"],
    "sounds": ["sounds", "C4"],
    "parts": ["parts", "C4"],
    "temperaments": ["temperaments"],
    "tuning": ["tuning", "quarter_comma"],
    "wolves": ["wolves", "quarter_comma"],
    "keys": ["keys", "werckmeister_iii"],
    "intervals": ["intervals", "quarter_comma", "--steps", "4"],
    "spread": ["spread", "equal", "--steps", "4"],
    "chain": ["chain", "quarter_comma"],
    "compare": ["compare", "equal", "quarter_comma"],
    "meantone": ["meantone", "--part", "1/4"],
    "pipe": ["pipe", "65.41"],
    "ends": ["ends", "65.41"],
    "warming": ["warming", "15", "25"],
    "stops": ["stops"],
    "draw": ["draw", "65.41"],
    "scales": ["scales"],
    "rank": ["rank"],
    "unit": ["unit"],
    "thinning": ["thinning", "24", "36"],
    "show": ["show", CHAPEL],
    "claims": ["claims", CHAPEL],
    "verdict": ["verdict", CHAPEL],
    "spec": ["spec", CHAPEL],
    "convert": ["convert", CHAPEL],
    "fields": ["fields"],
    "survey": ["survey", SURVEY],
    "census": ["census", SURVEY],
    "which": ["which"] + READINGS,
    "harmonics": ["harmonics"],
    "divisions": ["divisions"],
    "divide": ["divide", "31"],
    "scaleof": ["scaleof", "C"],
    "character": ["character", "--temperament", "werckmeister_iii"],
    "bearings": ["bearings", "equal"],
    "chord": ["chord", "major"],
    "roots": ["roots", "major"],
    "mixture": ["mixture", "mixture_iv"],
    "picture": ["picture", "--temperament", "quarter_comma"],
    "optimum": ["optimum", "--weights", "fifth=1,major_third=1"],
    "optima": ["optima"],
}

#: Each group's commands and the options its table has always
#: described.
GROUPS = {
    "interval": (("size", "stack", "commas", "part", "circle", "names",
                  "addnames", "just", "trip"),
                 ("--against", "--comma", "--part")),
    "pitch": (("hertz", "scale", "standards", "rounding", "beats",
               "spell", "instruments", "sounds", "parts"),
              ("--instrument", "--octave", "--standard",
               "--temperament", "--tonic")),
    "temper": (("temperaments", "tuning", "wolves", "keys",
                "intervals", "spread", "chain", "compare", "meantone"),
               ("--comma", "--just", "--limit", "--part", "--steps",
                "--tonic")),
    "pipe": (("pipe", "ends", "warming", "stops", "draw", "scales",
              "rank", "unit", "thinning"),
             ("--bottom", "--compass", "--degrees", "--diameter",
              "--end", "--halving", "--stops")),
    "files": (("show", "claims", "verdict", "spec", "convert",
               "fields", "survey", "census", "which"),
              ("--out", "--section")),
    "more": (("harmonics", "divisions", "divide", "scaleof",
              "character", "bearings", "chord", "roots", "mixture",
              "picture", "optimum", "optima"),
             ("--against", "--ceiling", "--compass", "--how",
              "--octave", "--root", "--scale", "--standard",
              "--temperament", "--tonic", "--weights")),
}

#: What each command's own code reads, besides ``--places``; for
#: ``keys`` that includes the ``--limit`` it is asked to read.
READS = {
    "size": ("--against",),
    "part": ("--comma", "--part"),
    "hertz": ("--standard", "--temperament", "--tonic"),
    "scale": ("--octave", "--standard", "--temperament", "--tonic"),
    "beats": ("--octave", "--standard", "--temperament", "--tonic"),
    "sounds": ("--instrument",),
    "tuning": ("--tonic",),
    "wolves": ("--tonic",),
    "keys": ("--limit", "--tonic"),
    "intervals": ("--just", "--steps", "--tonic"),
    "spread": ("--just", "--steps", "--tonic"),
    "chain": ("--tonic",),
    "compare": ("--tonic",),
    "meantone": ("--comma", "--part"),
    "pipe": ("--degrees", "--diameter", "--end"),
    "ends": ("--degrees",),
    "draw": ("--stops",),
    "rank": ("--bottom", "--compass", "--halving"),
    "unit": ("--compass", "--stops"),
    "thinning": ("--compass", "--stops"),
    "show": ("--section",),
    "convert": ("--out",),
    "scaleof": ("--scale", "--temperament", "--tonic"),
    "character": ("--scale", "--temperament", "--tonic"),
    "bearings": ("--octave", "--standard"),
    "chord": ("--root", "--temperament", "--tonic"),
    "roots": ("--temperament", "--tonic"),
    "mixture": ("--ceiling", "--compass"),
    "picture": ("--against", "--temperament", "--tonic"),
    "optimum": ("--how", "--weights"),
    "optima": ("--how",),
}

#: A value each option could sensibly be given.
VALUES = {
    "--against": "3:2",
    "--bottom": "6",
    "--ceiling": "8000",
    "--comma": "pythagorean",
    "--compass": "56",
    "--degrees": "15",
    "--diameter": "3",
    "--end": "stopped",
    "--halving": "normal",
    "--how": "total",
    "--instrument": "horn_in_f",
    "--just": "5:4",
    "--limit": "20",
    "--octave": "5",
    "--out": "written.stops",
    "--part": "1/6",
    "--root": "D",
    "--scale": "minor",
    "--section": "tuning",
    "--standard": "a415",
    "--stops": "8,4",
    "--steps": "4",
    "--temperament": "quarter_comma",
    "--tonic": "G",
    "--weights": "fifth=1",
}

#: Where the value in VALUES is not one this command can answer.
OWN_VALUE = {
    ("picture", "--against"): "equal",
    ("convert", "--out"): "written.stops",
}


def read_pairs():
    """Every command, with each option its own code reads."""

    return [(name, option) for name in sorted(READS)
            for option in READS[name]]


@pytest.fixture(autouse=True)
def somewhere_else(tmp_path, monkeypatch):
    """``convert --out`` writes, so it writes here."""

    monkeypatch.chdir(tmp_path)


def test_every_command_is_covered():
    """So the tables shared with the other file are the whole
    command line."""

    listed = [name for names, _ in GROUPS.values() for name in names]
    assert sorted(listed) == sorted(ASKED)
    assert len(listed) == 57
    assert set(READS) <= set(ASKED)
    for name, read in READS.items():
        group = [options for names, options in GROUPS.values()
                 if name in names][0]
        assert set(read) <= set(group), name


@pytest.mark.parametrize("name", sorted(ASKED))
def test_every_command_still_answers(name):
    """The command lines the other file builds on."""

    code, text = run(ASKED[name])
    assert code == 0, (name, text)


@pytest.mark.parametrize(
    "name,option", read_pairs(),
    ids=["{0}-{1}".format(*one) for one in read_pairs()])
def test_an_option_the_command_reads_is_still_taken(name, option):
    """Answered, or refused for what the value says; never asked
    wrongly for the option itself."""

    given = OWN_VALUE.get((name, option), VALUES[option])
    code, text = run(ASKED[name] + [option, given])
    assert code in (0, 3), (name, option, text)
    assert "has not got" not in text


@pytest.mark.parametrize("name", sorted(ASKED))
def test_places_is_still_taken_by_every_command(name):
    """Including the ones that print no figure."""

    code, text = run(ASKED[name] + ["--places", "2"])
    assert code == run(ASKED[name])[0], (name, text)


@pytest.mark.parametrize("name", sorted(ASKED))
def test_help_still_lists_places_and_the_group(name):
    """What every command's help has always said."""

    code, text = run(["help", name])
    assert code == 0
    assert "--places" in text
    group = [one for one, (names, _) in GROUPS.items()
             if name in names][0]
    assert group in text


def test_a_misspelled_option_still_gets_its_suggestion():
    """``--standrd`` is a typo for an option ``hertz`` takes."""

    code, text = run(["hertz", "A4", "--standrd", "a415"])
    assert code == 2
    assert "--standard" in text


def test_an_option_nobody_has_is_still_refused():
    """With exit two and its name."""

    code, text = run(["size", "3:2", "--zzz", "1"])
    assert code == 2
    assert "--zzz" in text


def test_an_option_that_is_read_still_changes_the_answer():
    """``--standard`` on ``hertz`` and ``--instrument`` on
    ``sounds``."""

    assert "415" in run(["hertz", "A4", "--standard", "a415"])[1]
    assert run(["sounds", "C4", "--instrument", "horn_in_f"])[1] != \
        run(["sounds", "C4"])[1]


def test_an_option_after_two_dashes_is_still_a_word():
    """``--`` ends the options, so ``--quiet`` after it is a ratio
    that does not parse, and not a flag."""

    code, text = run(["size", "--", "--quiet"])
    assert code in (2, 3)
    assert "an option this command has not got" not in text


def test_keys_without_a_limit_is_the_table_it_was():
    """Three columns and no marks."""

    code, text = run(["keys", "werckmeister_iii"])
    assert code == 0
    assert "past the limit" not in text
    heading = [line for line in text.splitlines()
               if line.startswith("key ")][0]
    assert heading.split() == ["key", "worst", "interval", "total",
                               "error"]


@pytest.mark.parametrize("name", ["werckmeister_iii", "quarter_comma",
                                  "equal", "kirnberger_iii"])
def test_a_limit_keeps_every_row_and_figure_in_order(name):
    """The rows a limit marks are the rows there were, worst first,
    with the same figures."""

    def rows(text):
        out = []
        for line in text.splitlines():
            words = [one for one in line.split()
                     if one not in ("yes", "no")]
            if len(words) == 3 and words[0][:1].isupper() and \
                    words[1].lstrip("-").replace(".", "").isdigit():
                out.append(words)
        return out

    plain = rows(run(["keys", name])[1])
    limited = rows(run(["keys", name, "--limit", "20"])[1])
    assert len(plain) == 12
    assert limited == plain


#: The commands that have always counted their words.
COUNTED = ["addnames", "bearings", "beats", "census", "chain", "chord",
           "claims", "compare", "convert", "divide", "draw", "ends",
           "hertz", "intervals", "keys", "mixture", "parts", "pipe",
           "roots", "scaleof", "show", "size", "sounds", "spec", "spell",
           "spread", "survey", "trip", "tuning", "verdict", "warming",
           "wolves"]


@pytest.mark.parametrize("name", COUNTED)
def test_a_word_too_many_is_still_refused(name):
    """The commands that counted their words still do, with exit two."""

    code, text = run(ASKED[name] + ["extra"])
    assert code == 2, (name, text)
