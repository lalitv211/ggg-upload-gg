Commands accept options which they don't read. wolf hertz A4 --instrument horn_in_f answers 440 with exit zero. Same in each group. Also --quiet and --exact, each command takes them, nothing reads them. And --limit is in temper help but no command uses it.

wolf temperaments extra prints the table anyway, many commands do this. wolf help nonsense prints general help, wolf help hertz extra ignores extra word. Survey file with --- at the end gets an extra empty instrument, census counts an empty temperament.

Each command should take only options its own code reads. --places stays on each command like now. Any other option should be refused with exit two, same as misspelled option. Error text has to name the option and which command takes it. wolf help for one command should list only what it takes. Please remove --quiet and --exact. Words a command doesn't read should be refused the same way, commands which count arguments already do. wolf help with a name that is not a command should say so, like wolf nonsense. Separator with nothing after it shouldn't make an instrument.

--limit was meant for keys, please wire it there. It's worst interval a key may hold, in cents. With --limit keys table gets column "past the limit", yes or no for each key. Key is past when its worst interval is further from just than limit, sharp or flat. Working part should also say how many keys are past. Library has this check already, please reuse it. Without --limit keys table doesn't change. Limit is a number, decimals are fine. A word is asked wrongly, exit two with example to type like --places does. A limit below zero should be refused too.

Please add tests and changelog entry, and show keys with limit on temperament page.
