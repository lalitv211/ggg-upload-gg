Calendar says a slot is busy when it isn't. Receptionist clicks the slot of a cancelled appointment and is told it is already booked. No-show is the same. The availability check in slotAvailability counts them as conflicts too, warns about gaps next to them, and the occupied slots list them. Cancelled and no-show appointments hold no slot anywhere.

The click also goes through when it shouldn't. Half past four for an hour is accepted when the doctor leaves at five. Same with the day's frames, eleven for an hour against a frame ending half past eleven. Availability check has the same issue with frames. An appointment has to fit inside the hours of that day from start to end, frames or default hours. Frames past midnight count too, the way the painter already paints them.

The check and the calendar don't agree on the hours. Calendar page paints the day frames green but never hands them to the availability check. The slot list ignores frames as well. One rule for which hours a day has, used by the painter, the click, the check and the slot list, please.

Painter paints only the first week of the range it gets. It also pushes default hours into an empty frame list, so the doctor's frames change just by painting.

Patient page counts upcoming and cancelled with words backend never sends. Counts are zero, next appointment never found. Use the statuses from appointments api types. Upcoming is anything still ahead that is not cancelled or no-show, same for next.

Week label crashes with less than seven days, take the last day given. Appointment at five past nine is in no slot, it belongs to the nine o'clock quarter. formatDate documents compact style, 1/1/24, but gives short.

Please add tests for all of it.
