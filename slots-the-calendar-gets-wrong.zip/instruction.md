Calendar calls slots busy that aren't. Receptionist clicks a cancelled appointment's slot, told it's booked. No-show same. The check in slotAvailability counts them as conflicts, warns about gaps next to them, occupied slots list them. Cancelled and no-show appointments hold no slot anywhere.

The click goes through when it shouldn't. Half past four for an hour is accepted when doctor leaves at five. Same with frames, eleven for an hour against a frame ending half past eleven, in the check too. Appointment has to fit inside the hours of that day, start to end, frames or default. Hours past midnight count, frames, day hours or default, like the painter paints them: bookable next morning, listed with the day they start.

Week view is worse. Two doctors selected, first has a patient at ten, click goes to him and is refused as booked, second is free. It should go to the first selected doctor who is free, hours and bookings both.

Calendar page paints day frames green but never hands them to the check. Slot list ignores frames too. One rule for which hours a day has, used by the painter, the click, the check and the slot list.

Painter paints only the first week of its range, and pushes default hours into an empty frame list, so doctor's frames change by painting.

Patient page counts upcoming and cancelled with words backend never sends, counts are zero, next appointment never found. Use the statuses from appointments api types. Upcoming is anything still ahead that is not cancelled or no-show, same for next.

Week label crashes with less than seven days, take the last day. Five past nine is in no slot, it belongs to the nine o'clock quarter. formatDate documents compact style, 1/1/24, gives short.

Add tests for all of it.
