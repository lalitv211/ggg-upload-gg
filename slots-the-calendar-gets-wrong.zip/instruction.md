Click a cancelled appointment's slot, told it's booked. No-show same. The check counts them as conflicts, warns about gaps beside them, lists them occupied. Cancelled and no-show hold no slot anywhere.

Click goes through when it shouldn't, an hour accepted on a day that ends before the hour is up. Frames same, check too. Appointment fits the day's hours, start to end. Hours past midnight count, frames, day hours or default, the way the painter paints them.

Week view: two doctors selected, first has a patient at ten, click goes to him, refused as booked, second free. Goes to the first selected doctor who is free, hours and bookings both.

Calendar page paints day frames green, never hands them to the check. Slot list ignores frames too. One rule for which hours a day has: painter, click, check, slot list.

Painter paints only the first week of its range, pushes default hours into an empty frame list, changing the doctor's frames.

Hours get converted to the viewer's zone once, with today's offset, so dates on the other side of a clock change sit an hour off. Convert for the date shown, on the doctor's clock and on the viewer's. Crossing midnight moves the day too. A day's hours are the doctor's hours starting that day as the viewer sees them, same rule.

Patient page counts upcoming and cancelled with words backend never sends, counts zero, next never found. Statuses from appointments api types. Upcoming is anything ahead not cancelled or no-show, same for next.

Week label crashes under seven days, take the last. Five past nine belongs to the nine o'clock quarter. formatDate documents compact style, 1/1/24, gives short.

Add tests for all of it.
