/**
 * Hidden tests: the hours of a day are the doctor's hours of that date, as the viewer sees them.
 *
 * The calendar page builds its resources from the doctors' schedules, written in each doctor's own
 * time zone, and the check, the slot list and the painter read a day's hours from them. Converting
 * once with today's offset puts every date on the other side of a clock change an hour off, and a
 * conversion that crosses midnight lands the hours on the wrong day. The page hook is rendered with
 * React's server renderer and its data hooks replaced by fixed data; the resources hook is the real
 * one, with its effects run in place so the resources it builds are there. The viewer is in UTC.
 */
process.env.TZ = 'UTC';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import React from 'react';
import moment from 'moment';
import { renderToString } from 'react-dom/server';

const WEEKDAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];

const doctor = (id: string, name: string, over: Record<string, unknown>, schedule: Record<string, unknown>) => ({
  id,
  full_name: name,
  email: `${id}@example.com`,
  role: 'veterinarian',
  ...over,
  schedules: [
    {
      availability_days: WEEKDAYS,
      availability_hours_start: '09:00:00',
      availability_hours_end: '17:00:00',
      ...schedule,
    },
  ],
});

/** Nine to five in New York, Monday to Friday, with a Tuesday frame two till six. */
const NEW_YORK = doctor('doc-ny', 'Ann Vet', { timezone: 'America/New_York' }, {
  additionals: {
    dayTimeFrames: {
      tuesday: [{ id: 'f1', startTime: '14:00', endTime: '18:00', services: ['Exam'] }],
    },
  },
});
/** Six till two in Manila, Monday to Friday. */
const MANILA = doctor('doc-mnl', 'Ben Vet', { timezone: 'Asia/Manila' }, {
  availability_hours_start: '06:00:00',
  availability_hours_end: '14:00:00',
});
/** Nine to five with no zone of their own: the viewer's. */
const HERE = doctor('doc-here', 'Cy Vet', {}, {});
const DOCTORS = [NEW_YORK, MANILA, HERE];

const effects = vi.hoisted(() => ({ inline: false }));

vi.mock('react', async (importOriginal) => {
  const actual: any = await importOriginal();
  const sameDeps = (a: unknown[], b?: unknown[]) =>
    !!b && a.length === b.length && a.every((value, i) => Object.is(value, b[i]));
  // The server renderer runs no effects. While the resources hook renders, run its effects in place,
  // once per change of their dependencies, so the resources it builds in state are there.
  const useEffect = (effect: () => void | (() => void), deps?: unknown[]) => {
    const ran = actual.useRef(null);
    if (!effects.inline) return;
    if (ran.current && sameDeps(ran.current, deps)) return;
    ran.current = deps ?? [];
    effect();
  };
  return { ...actual, default: { ...(actual.default ?? actual), useEffect }, useEffect };
});

vi.mock('@/hooks/useAuth', () => ({
  useAuth: () => ({
    user: { _uuid: 'doc-ny', id: 'doc-ny', clinic_id: 'clinic-1', role: 'veterinarian' },
  }),
}));
vi.mock('@/hooks/useNotification', () => ({
  useNotification: () => ({ showNotification: () => undefined }),
}));
vi.mock('react-router-dom', () => ({
  useLocation: () => ({ pathname: '/calendar', search: '', hash: '', state: null, key: 'k' }),
  useSearchParams: () => [new URLSearchParams(), () => undefined],
  useNavigate: () => () => undefined,
}));
vi.mock('@tanstack/react-query', () => ({
  useQueryClient: () => ({
    invalidateQueries: async () => undefined,
    setQueryData: () => undefined,
    getQueryData: () => undefined,
  }),
}));
vi.mock('@/features/appointments/hooks/useBackendVeterinarians', () => ({
  useBackendVeterinarians: () => ({ data: DOCTORS, isLoading: false }),
}));
vi.mock('@/features/appointments/hooks/useBackendClinicUsersForCalendar', () => ({
  useBackendClinicUsersForCalendar: () => ({
    data: DOCTORS,
    isLoading: false,
    refetch: async () => undefined,
  }),
}));
vi.mock('@/features/appointments/hooks/useBackendAppointments', () => ({
  useBackendAppointments: () => ({
    data: [],
    isLoading: false,
    refetch: async () => undefined,
    updateStatusAsync: async () => undefined,
    isUpdatingStatus: false,
  }),
}));
vi.mock('@/hooks/calendar', async (importActual) => {
  const actual: any = await importActual();
  return {
    ...actual,
    useCalendarResources: (doctors: unknown[]) => {
      effects.inline = true;
      try {
        return actual.useCalendarResources(doctors);
      } finally {
        effects.inline = false;
      }
    },
    useUserSelection: () => ({
      selectedUserIds: DOCTORS.map((d) => d.id),
      selectedUsers: DOCTORS,
      availableUsersForSelection: [],
      filteredDoctorsForCalendar: DOCTORS,
      comboboxKey: 0,
      handleAddUser: () => undefined,
      handleRemoveUser: () => undefined,
    }),
  };
});

async function pageData(): Promise<any> {
  const { useCalendarPageData } = await import('@/components/calendar/useCalendarPageData');
  let captured: any = null;
  const Probe = () => {
    captured = useCalendarPageData();
    return null;
  };
  renderToString(React.createElement(Probe));
  return captured;
}

async function slotStarts(page: any, id: string, date: Date, minutes: number): Promise<string[]> {
  const { useSlotAvailability } = await import(
    '@/components/calendar/features/slotAvailability/useSlotAvailability'
  );
  const { getAvailableSlots } = useSlotAvailability({ appointments: [], resources: page.resources });
  return getAvailableSlots(id, date, minutes).map((slot: any) => moment(slot.start).format('YYYY-MM-DD HH:mm'));
}

async function paintedStarts(page: any, id: string, day: string): Promise<string[]> {
  const { generateCalendarEvents } = await import('@/components/calendar/utils/generateCalendarEvents');
  const events = generateCalendarEvents({
    resources: page.resources,
    filteredEvents: [],
    dateRangeStart: '2027-07-11T00:00:00',
    dateRangeEnd: '2027-07-17T23:59:59',
  });
  return events
    .filter((event: any) => event.resourceId === id && (event.classNames || []).includes('fc-available-slot'))
    .map((event: any) => moment(event.start as string).format('YYYY-MM-DD HH:mm'))
    .filter((start) => start.startsWith(day))
    .sort();
}

const utc = (y: number, m: number, d: number, h: number, min = 0) => new Date(Date.UTC(y, m, d, h, min));

describe('the hours of a day are converted for that date', () => {
  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(utc(2027, 0, 11, 6)); // a January morning: New York is five hours behind
  });
  afterEach(() => vi.useRealTimers());

  it('the check takes nine in New York as one in the afternoon on a July Monday', async () => {
    const page = await pageData();
    expect(page.checkSlotAvailability('doc-ny', utc(2027, 6, 12, 13), 60).isAvailable).toBe(true);
  });

  it('the check refuses a July Monday slot that ends after five in New York', async () => {
    const page = await pageData();
    expect(page.checkSlotAvailability('doc-ny', utc(2027, 6, 12, 20, 30), 60).isAvailable).toBe(false);
  });

  it('the Tuesday frame runs from six to ten in July', async () => {
    const page = await pageData();
    expect(page.checkSlotAvailability('doc-ny', utc(2027, 6, 13, 18), 60).isAvailable).toBe(true);
    expect(page.checkSlotAvailability('doc-ny', utc(2027, 6, 13, 17), 60).isAvailable).toBe(false);
  });

  it('the slot list of a July Monday starts at one', async () => {
    const page = await pageData();
    const starts = await slotStarts(page, 'doc-ny', utc(2027, 6, 12, 0), 60);
    expect(starts[0]).toBe('2027-07-12 13:00');
  });

  it('the painter paints the July Monday from one', async () => {
    const page = await pageData();
    expect((await paintedStarts(page, 'doc-ny', '2027-07-12'))[0]).toBe('2027-07-12 13:00');
  });
});

describe('hours that cross midnight when converted move to the day they start on', () => {
  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(utc(2027, 0, 11, 6));
  });
  afterEach(() => vi.useRealTimers());

  it('Manila\'s Monday morning begins on the viewer\'s Sunday evening', async () => {
    const page = await pageData();
    expect(page.checkSlotAvailability('doc-mnl', utc(2027, 6, 11, 23), 60).isAvailable).toBe(true);
  });

  it('the viewer\'s Friday night is Manila\'s Saturday, which is off', async () => {
    const page = await pageData();
    expect(page.checkSlotAvailability('doc-mnl', utc(2027, 6, 16, 23), 60).isAvailable).toBe(false);
  });

  it('the Sunday slot list runs from ten in the evening into Monday', async () => {
    const page = await pageData();
    expect(await slotStarts(page, 'doc-mnl', utc(2027, 6, 11, 0), 120)).toEqual([
      '2027-07-11 22:00',
      '2027-07-12 00:00',
      '2027-07-12 02:00',
      '2027-07-12 04:00',
    ]);
  });

  it('the painter paints Manila\'s Monday on the viewer\'s Sunday', async () => {
    const page = await pageData();
    expect((await paintedStarts(page, 'doc-mnl', '2027-07-11'))[0]).toBe('2027-07-11 22:00');
  });
});

describe('converted hours still hold', () => {
  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(utc(2027, 0, 11, 6));
  });
  afterEach(() => vi.useRealTimers());

  it('nine in New York is two in the afternoon on a January Monday', async () => {
    const page = await pageData();
    expect(page.checkSlotAvailability('doc-ny', utc(2027, 0, 11, 14), 60).isAvailable).toBe(true);
  });

  it('one in the afternoon on a January Monday is before nine in New York', async () => {
    const page = await pageData();
    expect(page.checkSlotAvailability('doc-ny', utc(2027, 0, 11, 13), 60).isAvailable).toBe(false);
  });

  it('a doctor with no zone of their own keeps the hours as entered', async () => {
    const page = await pageData();
    expect(page.checkSlotAvailability('doc-here', utc(2027, 6, 12, 9), 60).isAvailable).toBe(true);
  });
});
