/**
 * Hidden guards: what already holds at the base commit and has to keep holding.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import moment from 'moment';
import { useSlotAvailability } from '@/components/calendar/features/slotAvailability/useSlotAvailability';
import { createDateSelectHandler } from '@/components/calendar/handlers/dateSelectionHandler';
import { generateCalendarEvents } from '@/components/calendar/utils/generateCalendarEvents';
import {
  calculateAppointmentStats,
  getNextUpcomingAppointment,
} from '@/features/appointments/api/backendPatientAppointmentService';
import { formatDate } from '@/lib/utils';
import { getAppointmentsForSlot } from '@/utils/appointmentUtils';
import { formatWeekRange } from '@/utils/calendarUtils';

const vet: any = { id: 'vet-1', _uuid: 'vet-1', role: 'veterinarian', role_isDefault: true, role_permissions: ['create_appointments'] };
const client: any = { id: 'client-1', _uuid: 'client-1', role: 'client', role_isDefault: true, role_permissions: [] };

const doctor = (over: Record<string, unknown> = {}) => ({
  id: 'doc-1',
  title: 'Dr. Ann Vet',
  availableDays: [1, 2, 3, 4, 5],
  availableHours: { start: '09:00', end: '17:00' },
  breakHours: [],
  ...over,
});

const appointment = (time: string, status: string, minutes = 30) => ({
  id: `apt-${time}-${status}`,
  vet_id: 'doc-1',
  appointment_time: time,
  estimated_duration: minutes,
  status,
  service_type: 'Exam',
});

const click = (start: string) =>
  ({ start: new Date(start), end: new Date(start), resource: { id: 'doc-1', title: 'Dr. Ann Vet' } }) as any;

const lateFrame = { 1: [{ service: 'Evening', start: '20:00', end: '23:30' }] };
const afternoon = doctor({
  availableHours: { start: '09:00', end: '12:00' },
  dayServiceTimeRanges: { 1: [{ service: 'Exam', start: '14:00', end: '18:00' }] },
});

function handlerWith(user: any, resources: any[], appointments: any[], duration: number) {
  const booked: string[] = [];
  const refused: string[] = [];
  const handle = createDateSelectHandler({
    user,
    resources,
    selectedUsers: [{ id: 'doc-1', full_name: 'Ann Vet' }],
    selectedDuration: duration,
    allAppointments: appointments,
    checkSlotAvailability: () => ({ isAvailable: true, conflicts: [], warnings: [] }),
    setSelectedSlot: () => undefined,
    handleTimeSlotClick: (doctorId) => booked.push(doctorId),
    showNotification: (message) => refused.push(message),
  });
  return { handle, booked, refused };
}

describe('still holds > slots that were already right', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  it('a click inside the hours with nothing booked goes through', () => {
    const { handle, booked } = handlerWith(vet, [doctor()], [], 30);
    handle(click('2027-03-01T10:00:00'));
    expect(booked).toEqual(['doc-1']);
  });

  it('a click on a scheduled appointment is refused', () => {
    const { handle, booked, refused } = handlerWith(vet, [doctor()], [appointment('2027-03-01T10:00:00', 'scheduled')], 30);
    handle(click('2027-03-01T10:00:00'));
    expect(booked).toEqual([]);
    expect(refused.length).toBe(1);
  });

  it('a click overlapping a checked-in appointment is refused', () => {
    const { handle, booked } = handlerWith(vet, [doctor()], [appointment('2027-03-01T10:00:00', 'checked_in', 60)], 30);
    handle(click('2027-03-01T10:30:00'));
    expect(booked).toEqual([]);
  });

  it('a click in the past is refused', () => {
    const { handle, booked, refused } = handlerWith(vet, [doctor()], [], 30);
    handle(click('2027-02-26T10:00:00'));
    expect(booked).toEqual([]);
    expect(refused.length).toBe(1);
  });

  it('a click on a day the provider does not work is refused', () => {
    const { handle, booked } = handlerWith(vet, [doctor()], [], 30);
    handle(click('2027-03-06T10:00:00'));
    expect(booked).toEqual([]);
  });

  it('a click before the hours start is refused', () => {
    const { handle, booked } = handlerWith(vet, [doctor()], [], 30);
    handle(click('2027-03-01T08:30:00'));
    expect(booked).toEqual([]);
  });

  it('a user without the permission books nothing', () => {
    const { handle, booked, refused } = handlerWith(client, [doctor()], [], 30);
    handle(click('2027-03-01T10:00:00'));
    expect(booked).toEqual([]);
    expect(refused).toEqual([]);
  });

  it('a click at half past eleven for an hour goes through when the frame runs to two in the morning', () => {
    const night = doctor({ dayServiceTimeRanges: { 1: [{ service: 'Night', start: '20:00', end: '02:00' }] } });
    const { handle, booked } = handlerWith(vet, [night], [], 60);
    handle(click('2027-03-01T23:30:00'));
    expect(booked).toEqual(['doc-1']);
  });

  it('the availability check refuses half past one on Tuesday for an hour against a Monday frame ending at two', () => {
    const night = doctor({ dayServiceTimeRanges: { 1: [{ service: 'Night', start: '20:00', end: '02:00' }] } });
    const { checkSlotAvailability } = useSlotAvailability({ appointments: [], resources: [night] as any });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 2, 1, 30), 60).isAvailable).toBe(false);
  });

  it('a click at half past one on Tuesday for an hour is refused against a Monday frame ending at two', () => {
    const night = doctor({ dayServiceTimeRanges: { 1: [{ service: 'Night', start: '20:00', end: '02:00' }] } });
    const { handle, booked } = handlerWith(vet, [night], [], 60);
    handle(click('2027-03-02T01:30:00'));
    expect(booked).toEqual([]);
  });

  it('the availability check refuses an hour at half past four against hours ending at five', () => {
    const { checkSlotAvailability } = useSlotAvailability({ appointments: [], resources: [doctor()] as any });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 16, 30), 60).isAvailable).toBe(false);
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 16, 30), 30).isAvailable).toBe(true);
  });

  it('the availability check refuses a scheduled conflict', () => {
    const { checkSlotAvailability } = useSlotAvailability({
      appointments: [appointment('2027-03-01T10:00:00', 'scheduled')] as any,
      resources: [doctor()] as any,
    });
    const check = checkSlotAvailability('doc-1', new Date(2027, 2, 1, 10, 15), 30);
    expect(check.isAvailable).toBe(false);
    expect(check.conflicts.length).toBe(1);
  });

  it('the availability check warns about a short gap after a scheduled appointment', () => {
    const { checkSlotAvailability } = useSlotAvailability({
      appointments: [appointment('2027-03-01T10:00:00', 'scheduled')] as any,
      resources: [doctor()] as any,
    });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 10, 30), 30).warnings.length).toBe(1);
  });

  it('the availability check refuses a day the provider does not work', () => {
    const { checkSlotAvailability } = useSlotAvailability({ appointments: [], resources: [doctor()] as any });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 6, 10, 0), 30).isAvailable).toBe(false);
  });

  it('the availability check accepts half past eleven for an hour when the frame runs to two in the morning', () => {
    const night = doctor({ dayServiceTimeRanges: { 1: [{ service: 'Night', start: '20:00', end: '02:00' }] } });
    const { checkSlotAvailability } = useSlotAvailability({ appointments: [], resources: [night] as any });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 23, 30), 60).isAvailable).toBe(true);
  });

  it('the occupied slots of a day list the scheduled appointments', () => {
    const { getOccupiedSlots } = useSlotAvailability({
      appointments: [appointment('2027-03-01T10:00:00', 'scheduled'), appointment('2027-03-02T10:00:00', 'scheduled')] as any,
      resources: [doctor()] as any,
    });
    expect(getOccupiedSlots('doc-1', new Date(2027, 2, 1)).length).toBe(1);
  });

  it('the slot list of a plain day runs over the default hours', () => {
    const { getAvailableSlots } = useSlotAvailability({ appointments: [], resources: [doctor()] as any });
    const starts = getAvailableSlots('doc-1', new Date(2027, 2, 1), 120).map((slot) => moment(slot.start).format('HH:mm'));
    expect(starts).toEqual(['09:00', '11:00', '13:00', '15:00']);
  });

  it('the slot list of a day off is empty', () => {
    const { getAvailableSlots } = useSlotAvailability({ appointments: [], resources: [doctor()] as any });
    expect(getAvailableSlots('doc-1', new Date(2027, 2, 6), 60)).toEqual([]);
  });

  it('a click at half past four for half an hour still goes through', () => {
    const { handle, booked } = handlerWith(vet, [doctor()], [], 30);
    handle(click('2027-03-01T16:30:00'));
    expect(booked).toEqual(['doc-1']);
  });

  it('a click at eleven for half an hour fits the evening frame', () => {
    const { handle, booked } = handlerWith(vet, [doctor({ dayServiceTimeRanges: lateFrame })], [], 30);
    handle(click('2027-03-01T23:00:00'));
    expect(booked).toEqual(['doc-1']);
  });

  it('the availability check refuses an hour at nine in the evening against default hours ending at ten', () => {
    const { checkSlotAvailability } = useSlotAvailability({
      appointments: [],
      resources: [doctor({ availableHours: { start: '20:00', end: '22:00' } })] as any,
    });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 21, 30), 60).isAvailable).toBe(false);
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 21, 0), 60).isAvailable).toBe(true);
  });

  it('a click on the slot of a cancelled appointment still fails on a scheduled one beside it', () => {
    const { handle, booked, refused } = handlerWith(
      vet,
      [doctor()],
      [appointment('2027-03-01T10:00:00', 'cancelled'), appointment('2027-03-01T10:15:00', 'scheduled')],
      30
    );
    handle(click('2027-03-01T10:00:00'));
    expect(booked).toEqual([]);
    expect(refused.length).toBe(1);
  });

  it('a day without a frame of its own still lists the default hours', () => {
    const { getAvailableSlots } = useSlotAvailability({ appointments: [], resources: [afternoon] as any });
    const starts = getAvailableSlots('doc-1', new Date(2027, 2, 2), 60).map((slot) => moment(slot.start).format('HH:mm'));
    expect(starts).toEqual(['09:00', '10:00', '11:00']);
  });
});

describe('still holds > the painted week', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  const has = (event: any, className: string) => Array.isArray(event.classNames) && event.classNames.includes(className);
  const day = (event: any) => moment(event.start).format('YYYY-MM-DD');
  const weekdays = (over: Record<string, unknown> = {}) => ({ id: 'doc-1', title: 'Dr. Ann Vet', availableDays: [1, 2, 3, 4, 5], availableHours: { start: '09:00', end: '17:00' }, ...over });
  const paint = (resource: any, start: string, end: string) =>
    generateCalendarEvents({ resources: [resource], filteredEvents: [], dateRangeStart: start, dateRangeEnd: end });
  const paintedOn = (events: any[], className: string, which: string) => events.filter((event) => has(event, className) && day(event) === which);

  it('a working day gets available hours and a day off is marked unavailable', () => {
    const events = generateCalendarEvents({
      resources: [doctor()] as any,
      filteredEvents: [],
      dateRangeStart: '2027-03-01T00:00:00',
      dateRangeEnd: '2027-03-07T23:59:59',
    });
    expect(events.some((event) => has(event, 'fc-available-slot') && day(event) === '2027-03-02')).toBe(true);
    expect(events.some((event) => has(event, 'fc-unavailable-slot') && day(event) === '2027-03-06')).toBe(true);
  });

  it('a frame is painted with its service as the title', () => {
    const events = generateCalendarEvents({
      resources: [doctor({ dayServiceTimeRanges: { 1: [{ service: 'Exam', start: '14:00', end: '18:00' }] } })] as any,
      filteredEvents: [],
      dateRangeStart: '2027-03-01T00:00:00',
      dateRangeEnd: '2027-03-07T23:59:59',
    });
    const monday = events.filter((event) => has(event, 'fc-available-slot') && day(event) === '2027-03-01');
    expect(monday.length).toBe(1);
    expect(monday[0].title).toBe('Exam');
    expect(moment(monday[0].start).format('HH:mm')).toBe('14:00');
  });

  it('the appointments handed in come back in front of the background', () => {
    const booked = { id: 'apt-1', resourceId: 'doc-1', start: '2027-03-01T10:00:00', end: '2027-03-01T10:30:00' };
    const events = generateCalendarEvents({
      resources: [doctor()] as any,
      filteredEvents: [booked],
      dateRangeStart: '2027-03-01T00:00:00',
      dateRangeEnd: '2027-03-07T23:59:59',
    });
    expect(events[0]).toBe(booked);
  });

  it('days already gone are not painted', () => {
    const events = generateCalendarEvents({
      resources: [doctor()] as any,
      filteredEvents: [],
      dateRangeStart: '2027-02-22T00:00:00',
      dateRangeEnd: '2027-02-28T23:59:59',
    });
    expect(events.filter((event) => has(event, 'fc-available-slot'))).toEqual([]);
  });

  it('a day with a frame keeps exactly that frame after painting', () => {
    const resource = weekdays({ dayServiceTimeRanges: { 1: [{ service: 'Exam', start: '14:00', end: '18:00' }] } });
    paint(resource, '2027-03-01T00:00:00', '2027-03-07T23:59:59');
    expect(resource.dayServiceTimeRanges).toEqual({ 1: [{ service: 'Exam', start: '14:00', end: '18:00' }] });
  });

  it('painting twice gives the same picture', () => {
    const resource = weekdays({ dayServiceTimeRanges: { 1: [], 2: [{ service: 'Exam', start: '14:00', end: '18:00' }] } });
    const first = paint(resource, '2027-03-01T00:00:00', '2027-03-07T23:59:59');
    const second = paint(resource, '2027-03-01T00:00:00', '2027-03-07T23:59:59');
    expect(second.length).toBe(first.length);
    expect(second.map((event) => event.id)).toEqual(first.map((event) => event.id));
  });

  it('an empty frame list falls back to the default hours once, not once per painting', () => {
    const resource = weekdays({ dayServiceTimeRanges: { 1: [] } });
    paint(resource, '2027-03-01T00:00:00', '2027-03-07T23:59:59');
    const events = paint(resource, '2027-03-01T00:00:00', '2027-03-07T23:59:59');
    expect(paintedOn(events, 'fc-available-slot', '2027-03-01').length).toBe(1);
  });
});

describe('still holds > counts and labels that were already right', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  const visit = (id: string, time: string, status: string): any => ({
    id, appointment_time: time, service_type: 'Exam', status, pet_id: 'pet-1', client_id: 'client-1', clinic_id: 'clinic-1',
    created_at: '2027-01-01T00:00:00', updated_at: '2027-01-01T00:00:00',
  });

  const visits = [
    visit('scheduled-ahead', '2027-03-05T10:00:00', 'scheduled'),
    visit('confirmed-ahead', '2027-03-06T10:00:00', 'confirmed'),
    visit('requested-ahead', '2027-03-04T10:00:00', 'requested'),
    visit('cancelled-ahead', '2027-03-03T10:00:00', 'cancelled'),
    visit('cancelled-past', '2027-02-05T10:00:00', 'cancelled'),
    visit('no-show-past', '2027-02-06T10:00:00', 'no_show'),
    visit('completed-past', '2027-02-07T10:00:00', 'completed'),
    visit('scheduled-past', '2027-02-08T10:00:00', 'scheduled'),
  ];
  const slotAppointments = [
    { id: 'five-past', vet_id: 'doc-1', appointment_time: '2027-03-01T09:05:00' },
    { id: 'quarter-past', vet_id: 'doc-1', appointment_time: '2027-03-01T09:15:00' },
    { id: 'twenty-nine-past', vet_id: 'doc-1', appointment_time: '2027-03-01T09:29:00' },
  ];
  const ids = (slot: string) => getAppointmentsForSlot(slotAppointments, 'doc-1', new Date(2027, 2, 1), slot).map((apt) => apt.id);

  it('no appointments give zero counts', () => {
    expect(calculateAppointmentStats([])).toEqual({ upcoming: 0, canceled: 0, noShow: 0, total: 0 });
  });

  it('a confirmed appointment behind us is not upcoming', () => {
    expect(calculateAppointmentStats([visit('a', '2027-02-01T10:00:00', 'confirmed')]).upcoming).toBe(0);
  });

  it('a no-show counts once', () => {
    expect(calculateAppointmentStats([visit('a', '2027-02-01T10:00:00', 'no_show')]).noShow).toBe(1);
  });

  it('the next appointment is the earliest confirmed one ahead', () => {
    const two = [visit('later', '2027-03-09T10:00:00', 'confirmed'), visit('sooner', '2027-03-08T10:00:00', 'confirmed')];
    expect(getNextUpcomingAppointment(two)?.id).toBe('sooner');
  });

  it('there is no next appointment when nothing is ahead', () => {
    expect(getNextUpcomingAppointment([visit('a', '2027-02-01T10:00:00', 'confirmed')])).toBeNull();
  });

  it('a seven-day week is labelled from its first to its seventh day', () => {
    const days = Array.from({ length: 7 }, (_, i) => new Date(2027, 2, 1 + i));
    expect(formatWeekRange(days)).toBe('Mar 1 - Mar 7, 2027');
  });

  it('no days give an empty label', () => {
    expect(formatWeekRange([])).toBe('');
  });

  it('an appointment on the quarter is in its own slot and in no other', () => {
    const appointments = [{ id: 'a', vet_id: 'doc-1', appointment_time: '2027-03-01T09:15:00' }];
    expect(getAppointmentsForSlot(appointments, 'doc-1', new Date(2027, 2, 1), '09:15').map((apt) => apt.id)).toEqual(['a']);
    expect(getAppointmentsForSlot(appointments, 'doc-1', new Date(2027, 2, 1), '09:00')).toEqual([]);
    expect(getAppointmentsForSlot(appointments, 'doc-1', new Date(2027, 2, 1), '09:30')).toEqual([]);
  });

  it('another doctor or another day is not in the slot', () => {
    const appointments = [{ id: 'a', vet_id: 'doc-2', appointment_time: '2027-03-01T09:00:00' }, { id: 'b', vet_id: 'doc-1', appointment_time: '2027-03-02T09:00:00' }];
    expect(getAppointmentsForSlot(appointments, 'doc-1', new Date(2027, 2, 1), '09:00')).toEqual([]);
  });

  it('the short and numeric date styles are unchanged', () => {
    expect(formatDate(new Date(2027, 2, 1, 10, 0))).toBe('Mar 1, 2027');
    expect(formatDate(new Date(2027, 2, 1, 10, 0), { style: 'numeric' })).toBe('03/01/2027');
    expect(formatDate(new Date(2027, 2, 1, 10, 0), { style: 'long' })).toBe('March 1, 2027');
  });

  it('a missing date falls back', () => {
    expect(formatDate(null, { style: 'compact' })).toBe('N/A');
    expect(formatDate('not a date', { style: 'compact', fallback: '-' })).toBe('-');
  });

  it('a no-show is counted as a no-show', () => {
    expect(calculateAppointmentStats(visits).noShow).toBe(1);
  });

  it('every appointment is in the total', () => {
    expect(calculateAppointmentStats(visits).total).toBe(8);
  });

  it('there is no next appointment when every one ahead is cancelled', () => {
    expect(getNextUpcomingAppointment([visit('cancelled-ahead', '2027-03-03T10:00:00', 'cancelled')])).toBeNull();
  });

  it('the half past slot holds nothing of these', () => {
    expect(ids('09:30')).toEqual([]);
  });
});
