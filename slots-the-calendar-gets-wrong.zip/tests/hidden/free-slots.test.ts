/**
 * Hidden tests: which slots the calendar calls free.
 *
 * The click handler (createDateSelectHandler), the availability check (useSlotAvailability) and the
 * slot list have to agree: an appointment fits a slot only when all of it lies inside the provider's
 * hours for that day, whether those hours are the day's frames or the default hours, and a cancelled
 * or no-show appointment holds no slot. Every assertion is about what the caller sees: whether the
 * click went through, whether a slot is available, which slots are listed. Nothing about messages.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import moment from 'moment';
import { useSlotAvailability } from '@/components/calendar/features/slotAvailability/useSlotAvailability';
import { createDateSelectHandler } from '@/components/calendar/handlers/dateSelectionHandler';

const vet: any = {
  id: 'vet-1',
  _uuid: 'vet-1',
  role: 'veterinarian',
  role_isDefault: true,
  role_permissions: ['create_appointments'],
};

const doctor = (over: Record<string, unknown> = {}) => ({
  id: 'doc-1',
  title: 'Dr. Ann Vet',
  availableDays: [1, 2, 3, 4, 5],
  availableHours: { start: '09:00', end: '17:00' },
  breakHours: [],
  ...over,
});

const appointment = (time: string, status: string, minutes = 30, over: Record<string, unknown> = {}) => ({
  id: `apt-${time}-${status}`,
  vet_id: 'doc-1',
  appointment_time: time,
  estimated_duration: minutes,
  status,
  service_type: 'Exam',
  ...over,
});

const click = (start: string) =>
  ({ start: new Date(start), end: new Date(start), resource: { id: 'doc-1', title: 'Dr. Ann Vet' } }) as any;

function handlerWith(resources: any[], appointments: any[], duration: number) {
  const booked: string[] = [];
  const refused: string[] = [];
  const handle = createDateSelectHandler({
    user: vet,
    resources,
    selectedUsers: [{ id: 'doc-1', full_name: 'Ann Vet' }],
    selectedDuration: duration,
    allAppointments: appointments,
    checkSlotAvailability: () => ({ isAvailable: true, conflicts: [], warnings: [] }),
    setSelectedSlot: () => undefined,
    handleTimeSlotClick: (doctorId) => booked.push(doctorId),
    showNotification: (message) => refused.push(message),
  });
  return { handle, booked, refused };
}

const lateFrame = { 1: [{ service: 'Evening', start: '20:00', end: '23:30' }] };

describe('free slots > the whole appointment has to fit the hours', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  it('a click at half past four for an hour is refused when the day ends at five', () => {
    const { handle, booked, refused } = handlerWith([doctor()], [], 60);
    handle(click('2027-03-01T16:30:00'));
    expect(booked).toEqual([]);
    expect(refused.length).toBe(1);
  });

  it('a click at eleven for an hour is refused when the evening frame ends at half past eleven', () => {
    const { handle, booked, refused } = handlerWith([doctor({ dayServiceTimeRanges: lateFrame })], [], 60);
    handle(click('2027-03-01T23:00:00'));
    expect(booked).toEqual([]);
    expect(refused.length).toBe(1);
  });

  it('the availability check refuses an hour at eleven against a frame ending at half past eleven', () => {
    const { checkSlotAvailability } = useSlotAvailability({
      appointments: [],
      resources: [doctor({ dayServiceTimeRanges: lateFrame })] as any,
    });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 23, 0), 60).isAvailable).toBe(false);
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 23, 0), 30).isAvailable).toBe(true);
  });

  const nightFrame = { 1: [{ service: 'Night', start: '20:00', end: '02:00' }] };

  it('a click at one in the morning on Tuesday fits the Monday frame that runs to two', () => {
    const { handle, booked } = handlerWith([doctor({ dayServiceTimeRanges: nightFrame })], [], 30);
    handle(click('2027-03-02T01:00:00'));
    expect(booked).toEqual(['doc-1']);
  });

  it('the availability check accepts one in the morning on Tuesday inside the Monday frame that runs to two', () => {
    const { checkSlotAvailability } = useSlotAvailability({
      appointments: [],
      resources: [doctor({ dayServiceTimeRanges: nightFrame })] as any,
    });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 2, 1, 0), 30).isAvailable).toBe(true);
  });

});

describe('free slots > a cancelled or no-show appointment holds no slot', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  it('a click on the slot of a cancelled appointment goes through', () => {
    const { handle, booked } = handlerWith([doctor()], [appointment('2027-03-01T10:00:00', 'cancelled')], 30);
    handle(click('2027-03-01T10:00:00'));
    expect(booked).toEqual(['doc-1']);
  });

  it('a click on the slot of a no-show appointment goes through', () => {
    const { handle, booked } = handlerWith([doctor()], [appointment('2027-03-01T10:00:00', 'no_show')], 30);
    handle(click('2027-03-01T10:00:00'));
    expect(booked).toEqual(['doc-1']);
  });

  it('the availability check sees no conflict in a cancelled appointment', () => {
    const { checkSlotAvailability } = useSlotAvailability({
      appointments: [appointment('2027-03-01T10:00:00', 'cancelled')] as any,
      resources: [doctor()] as any,
    });
    const check = checkSlotAvailability('doc-1', new Date(2027, 2, 1, 10, 0), 30);
    expect(check.isAvailable).toBe(true);
    expect(check.conflicts).toEqual([]);
  });

  it('the availability check sees no conflict in a no-show appointment', () => {
    const { checkSlotAvailability } = useSlotAvailability({
      appointments: [appointment('2027-03-01T10:00:00', 'no_show')] as any,
      resources: [doctor()] as any,
    });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 10, 0), 30).isAvailable).toBe(true);
  });

  it('a cancelled appointment gives no warning about the gap before or after it', () => {
    const { checkSlotAvailability } = useSlotAvailability({
      appointments: [appointment('2027-03-01T10:00:00', 'cancelled')] as any,
      resources: [doctor()] as any,
    });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 10, 30), 30).warnings).toEqual([]);
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 9, 30), 30).warnings).toEqual([]);
  });

  it('the occupied slots of a day leave out cancelled and no-show appointments', () => {
    const { getOccupiedSlots } = useSlotAvailability({
      appointments: [
        appointment('2027-03-01T10:00:00', 'cancelled'),
        appointment('2027-03-01T11:00:00', 'no_show'),
        appointment('2027-03-01T14:00:00', 'scheduled'),
      ] as any,
      resources: [doctor()] as any,
    });
    const starts = getOccupiedSlots('doc-1', new Date(2027, 2, 1)).map((slot) => moment(slot.start).format('HH:mm'));
    expect(starts).toEqual(['14:00']);
  });
});

describe('free slots > the slot list follows the frames of the day', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  const afternoon = doctor({
    availableHours: { start: '09:00', end: '12:00' },
    dayServiceTimeRanges: { 1: [{ service: 'Exam', start: '14:00', end: '18:00' }] },
  });

  it('a day with an afternoon frame lists afternoon slots, not the default morning', () => {
    const { getAvailableSlots } = useSlotAvailability({ appointments: [], resources: [afternoon] as any });
    const starts = getAvailableSlots('doc-1', new Date(2027, 2, 1), 60).map((slot) => moment(slot.start).format('HH:mm'));
    expect(starts).toEqual(['14:00', '15:00', '16:00', '17:00']);
  });

  it('a slot whose appointment was cancelled is listed as available', () => {
    const { getAvailableSlots } = useSlotAvailability({
      appointments: [appointment('2027-03-01T14:00:00', 'cancelled', 60), appointment('2027-03-01T15:00:00', 'scheduled', 60)] as any,
      resources: [afternoon] as any,
    });
    const slots = getAvailableSlots('doc-1', new Date(2027, 2, 1), 60);
    const byStart = Object.fromEntries(slots.map((slot) => [moment(slot.start).format('HH:mm'), slot.isAvailable]));
    expect(byStart['14:00']).toBe(true);
    expect(byStart['15:00']).toBe(false);
  });
});

describe('free slots > the week view goes to a doctor who is free', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  const second = { ...doctor(), id: 'doc-2', title: 'Dr. Bo Vet' };
  const booked = (vetId: string, status = 'scheduled') => ({ ...appointment('2027-03-01T10:00:00', status), id: `apt-${vetId}`, vet_id: vetId });

  function weekClick(appointments: any[]) {
    const chosen: string[] = [];
    const handle = createDateSelectHandler({
      user: vet,
      resources: [doctor(), second],
      selectedUsers: [{ id: 'doc-1', full_name: 'Ann Vet' }, { id: 'doc-2', full_name: 'Bo Vet' }],
      selectedDuration: 30,
      allAppointments: appointments,
      checkSlotAvailability: () => ({ isAvailable: true, conflicts: [], warnings: [] }),
      setSelectedSlot: () => undefined,
      handleTimeSlotClick: (doctorId) => chosen.push(doctorId),
      showNotification: () => undefined,
    });
    handle({ start: new Date('2027-03-01T10:00:00'), end: new Date('2027-03-01T10:00:00'), resource: undefined } as any);
    return chosen;
  }

  it('a slot booked for the first doctor goes to the second doctor who is free', () => {
    expect(weekClick([booked('doc-1')])).toEqual(['doc-2']);
  });

  it('a slot the first doctor had cancelled goes to the first doctor', () => {
    expect(weekClick([booked('doc-1', 'cancelled')])).toEqual(['doc-1']);
  });
});
