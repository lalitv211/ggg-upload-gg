/**
 * Hidden tests: which slots the calendar calls free.
 *
 * The click handler (createDateSelectHandler), the availability check (useSlotAvailability) and the
 * slot list have to agree: an appointment fits a slot only when all of it lies inside the provider's
 * hours for that day, whether those hours are the day's frames or the default hours, and a cancelled
 * or no-show appointment holds no slot. Every assertion is about what the caller sees: whether the
 * click went through, whether a slot is available, which slots are listed. Nothing about messages.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import moment from 'moment';
import { useSlotAvailability } from '@/components/calendar/features/slotAvailability/useSlotAvailability';
import { createDateSelectHandler } from '@/components/calendar/handlers/dateSelectionHandler';

const vet: any = {
  id: 'vet-1',
  _uuid: 'vet-1',
  role: 'veterinarian',
  role_isDefault: true,
  role_permissions: ['create_appointments'],
};

/** The check the page really hands the handler: the one from useSlotAvailability, over the same data. */
const realCheck = (resources: any[], appointments: any[]) =>
  useSlotAvailability({ appointments, resources } as any).checkSlotAvailability;

const doctor = (over: Record<string, unknown> = {}) => ({
  id: 'doc-1',
  title: 'Dr. Ann Vet',
  availableDays: [1, 2, 3, 4, 5],
  availableHours: { start: '09:00', end: '17:00' },
  breakHours: [],
  ...over,
});

const appointment = (time: string, status: string, minutes = 30, over: Record<string, unknown> = {}) => ({
  id: `apt-${time}-${status}`,
  vet_id: 'doc-1',
  appointment_time: time,
  estimated_duration: minutes,
  status,
  service_type: 'Exam',
  ...over,
});

const click = (start: string) =>
  ({ start: new Date(start), end: new Date(start), resource: { id: 'doc-1', title: 'Dr. Ann Vet' } }) as any;

function handlerWith(resources: any[], appointments: any[], duration: number) {
  const booked: string[] = [];
  const refused: string[] = [];
  const handle = createDateSelectHandler({
    user: vet,
    resources,
    selectedUsers: [{ id: 'doc-1', full_name: 'Ann Vet' }],
    selectedDuration: duration,
    allAppointments: appointments,
    checkSlotAvailability: realCheck(resources, appointments),
    setSelectedSlot: () => undefined,
    handleTimeSlotClick: (doctorId) => booked.push(doctorId),
    showNotification: (message) => refused.push(message),
  });
  return { handle, booked, refused };
}

const lateFrame = { 1: [{ service: 'Evening', start: '20:00', end: '23:30' }] };

describe('free slots > the whole appointment has to fit the hours', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  it('a click at half past four for an hour is refused when the day ends at five', () => {
    const { handle, booked, refused } = handlerWith([doctor()], [], 60);
    handle(click('2027-03-01T16:30:00'));
    expect(booked).toEqual([]);
    expect(refused.length).toBe(1);
  });

  it('a click at eleven for an hour is refused when the evening frame ends at half past eleven', () => {
    const { handle, booked, refused } = handlerWith([doctor({ dayServiceTimeRanges: lateFrame })], [], 60);
    handle(click('2027-03-01T23:00:00'));
    expect(booked).toEqual([]);
    expect(refused.length).toBe(1);
  });

  it('the availability check refuses an hour at eleven against a frame ending at half past eleven', () => {
    const { checkSlotAvailability } = useSlotAvailability({
      appointments: [],
      resources: [doctor({ dayServiceTimeRanges: lateFrame })] as any,
    });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 23, 0), 60).isAvailable).toBe(false);
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 23, 0), 30).isAvailable).toBe(true);
  });

});

describe('free slots > a cancelled or no-show appointment holds no slot', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  it('a click on the slot of a cancelled appointment goes through', () => {
    const { handle, booked } = handlerWith([doctor()], [appointment('2027-03-01T10:00:00', 'cancelled')], 30);
    handle(click('2027-03-01T10:00:00'));
    expect(booked).toEqual(['doc-1']);
  });

  it('a click on the slot of a no-show appointment goes through', () => {
    const { handle, booked } = handlerWith([doctor()], [appointment('2027-03-01T10:00:00', 'no_show')], 30);
    handle(click('2027-03-01T10:00:00'));
    expect(booked).toEqual(['doc-1']);
  });

  it('the availability check sees no conflict in a cancelled appointment', () => {
    const { checkSlotAvailability } = useSlotAvailability({
      appointments: [appointment('2027-03-01T10:00:00', 'cancelled')] as any,
      resources: [doctor()] as any,
    });
    const check = checkSlotAvailability('doc-1', new Date(2027, 2, 1, 10, 0), 30);
    expect(check.isAvailable).toBe(true);
    expect(check.conflicts).toEqual([]);
  });

  it('the availability check sees no conflict in a no-show appointment', () => {
    const { checkSlotAvailability } = useSlotAvailability({
      appointments: [appointment('2027-03-01T10:00:00', 'no_show')] as any,
      resources: [doctor()] as any,
    });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 10, 0), 30).isAvailable).toBe(true);
  });

  it('a no-show appointment gives no warning about the gap before or after it', () => {
    const { checkSlotAvailability } = useSlotAvailability({
      appointments: [appointment('2027-03-01T10:00:00', 'no_show')] as any,
      resources: [doctor()] as any,
    });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 10, 30), 30).warnings).toEqual([]);
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 9, 30), 30).warnings).toEqual([]);
  });

  it('a cancelled appointment gives no warning about the gap before or after it', () => {
    const { checkSlotAvailability } = useSlotAvailability({
      appointments: [appointment('2027-03-01T10:00:00', 'cancelled')] as any,
      resources: [doctor()] as any,
    });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 10, 30), 30).warnings).toEqual([]);
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 9, 30), 30).warnings).toEqual([]);
  });

  it('the occupied slots of a day leave out cancelled and no-show appointments', () => {
    const { getOccupiedSlots } = useSlotAvailability({
      appointments: [
        appointment('2027-03-01T10:00:00', 'cancelled'),
        appointment('2027-03-01T11:00:00', 'no_show'),
        appointment('2027-03-01T14:00:00', 'scheduled'),
      ] as any,
      resources: [doctor()] as any,
    });
    const starts = getOccupiedSlots('doc-1', new Date(2027, 2, 1)).map((slot) => moment(slot.start).format('HH:mm'));
    expect(starts).toEqual(['14:00']);
  });
});

describe('free slots > the slot list follows the frames of the day', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  const afternoon = doctor({
    availableHours: { start: '09:00', end: '12:00' },
    dayServiceTimeRanges: { 1: [{ service: 'Exam', start: '14:00', end: '18:00' }] },
  });

  it('a day with an afternoon frame lists afternoon slots, not the default morning', () => {
    const { getAvailableSlots } = useSlotAvailability({ appointments: [], resources: [afternoon] as any });
    const starts = getAvailableSlots('doc-1', new Date(2027, 2, 1), 60).map((slot) => moment(slot.start).format('HH:mm'));
    expect(starts).toEqual(['14:00', '15:00', '16:00', '17:00']);
  });

  it('a slot whose appointment was cancelled is listed as available', () => {
    const { getAvailableSlots } = useSlotAvailability({
      appointments: [appointment('2027-03-01T14:00:00', 'cancelled', 60), appointment('2027-03-01T15:00:00', 'scheduled', 60)] as any,
      resources: [afternoon] as any,
    });
    const slots = getAvailableSlots('doc-1', new Date(2027, 2, 1), 60);
    const byStart = Object.fromEntries(slots.map((slot) => [moment(slot.start).format('HH:mm'), slot.isAvailable]));
    expect(byStart['14:00']).toBe(true);
    expect(byStart['15:00']).toBe(false);
  });
});

describe('free slots > a frame past midnight keeps its tail', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  const night = doctor({ dayServiceTimeRanges: { 1: [{ service: 'Night', start: '20:00', end: '02:00' }] } });

  it('the availability check takes half past midnight on Tuesday for an hour, inside the Monday night frame', () => {
    const { checkSlotAvailability } = useSlotAvailability({ appointments: [], resources: [night] as any });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 2, 0, 30), 60).isAvailable).toBe(true);
  });

  it('a click at half past midnight on Tuesday for an hour goes through', () => {
    const { handle, booked } = handlerWith([night], [], 60);
    handle(click('2027-03-02T00:30:00'));
    expect(booked).toEqual(['doc-1']);
  });

  it('the availability check refuses half past midnight on Monday, whose night frame only starts that evening', () => {
    const { checkSlotAvailability } = useSlotAvailability({ appointments: [], resources: [night] as any });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 0, 30), 60).isAvailable).toBe(false);
  });

  it('the slot list of the night frame runs on past midnight', () => {
    const { getAvailableSlots } = useSlotAvailability({ appointments: [], resources: [night] as any });
    const starts = getAvailableSlots('doc-1', new Date(2027, 2, 1), 60).map((slot) => moment(slot.start).format('ddd HH:mm'));
    expect(starts).toEqual(['Mon 20:00', 'Mon 21:00', 'Mon 22:00', 'Mon 23:00', 'Tue 00:00', 'Tue 01:00']);
  });

  it('the slots after midnight are listed as available when nothing is booked', () => {
    const { getAvailableSlots } = useSlotAvailability({ appointments: [], resources: [night] as any });
    const afterMidnight = getAvailableSlots('doc-1', new Date(2027, 2, 1), 60).filter((slot) => moment(slot.start).day() === 2);
    expect(afterMidnight.length).toBe(2);
    expect(afterMidnight.every((slot) => slot.isAvailable)).toBe(true);
  });
});

describe('free slots > legacy day hours count like frames', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  // Monday has legacy per-day hours 12:00-20:00 and no frames; the default hours are 09:00-17:00.
  const legacyMonday = doctor({ dayTimes: { 1: { start: '12:00', end: '20:00' } } });

  it('the availability check takes six in the evening for an hour inside the legacy hours', () => {
    const { checkSlotAvailability } = useSlotAvailability({ appointments: [], resources: [legacyMonday] as any });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 18, 0, 0), 60).isAvailable).toBe(true);
  });

  it('the availability check refuses ten in the morning, inside the default hours but outside the legacy hours', () => {
    const { checkSlotAvailability } = useSlotAvailability({ appointments: [], resources: [legacyMonday] as any });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 1, 10, 0, 0), 60).isAvailable).toBe(false);
  });

  it('a click at six in the evening for an hour goes through', () => {
    const { handle, booked } = handlerWith([legacyMonday], [], 60);
    handle(click('2027-03-01T18:00:00'));
    expect(booked).toEqual(['doc-1']);
  });

  it('a click at ten in the morning is refused on a day with legacy hours from noon', () => {
    const { handle, booked, refused } = handlerWith([legacyMonday], [], 60);
    handle(click('2027-03-01T10:00:00'));
    expect(booked).toEqual([]);
    expect(refused.length).toBe(1);
  });

  it('the slot list follows the legacy hours of the day', () => {
    const { getAvailableSlots } = useSlotAvailability({ appointments: [], resources: [legacyMonday] as any });
    const starts = getAvailableSlots('doc-1', new Date(2027, 2, 1), 120).map((slot) => moment(slot.start).format('HH:mm'));
    expect(starts).toEqual(['12:00', '14:00', '16:00', '18:00']);
  });
});

describe('free slots > default hours past midnight keep their tail', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  const nightDefault = doctor({ availableHours: { start: '20:00', end: '02:00' } });

  it('the availability check takes half past midnight on Tuesday for an hour, inside the Monday night hours', () => {
    const { checkSlotAvailability } = useSlotAvailability({ appointments: [], resources: [nightDefault] as any });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 2, 0, 30, 0), 60).isAvailable).toBe(true);
  });

  it('a click at half past midnight on Tuesday for an hour goes through', () => {
    const { handle, booked } = handlerWith([nightDefault], [], 60);
    handle(click('2027-03-02T00:30:00'));
    expect(booked).toEqual(['doc-1']);
  });

  it('the slot list of the night hours runs on past midnight', () => {
    const { getAvailableSlots } = useSlotAvailability({ appointments: [], resources: [nightDefault] as any });
    const starts = getAvailableSlots('doc-1', new Date(2027, 2, 1), 60).map((slot) => moment(slot.start).format('ddd HH:mm'));
    expect(starts).toEqual(['Mon 20:00', 'Mon 21:00', 'Mon 22:00', 'Mon 23:00', 'Tue 00:00', 'Tue 01:00']);
  });
});

describe('free slots > legacy day hours past midnight keep their tail', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  const nightLegacy = doctor({ dayTimes: { 1: { start: '20:00', end: '02:00' } } });

  it('the availability check takes half past midnight on Tuesday for an hour, inside the Monday night hours', () => {
    const { checkSlotAvailability } = useSlotAvailability({ appointments: [], resources: [nightLegacy] as any });
    expect(checkSlotAvailability('doc-1', new Date(2027, 2, 2, 0, 30, 0), 60).isAvailable).toBe(true);
  });

  it('the slot list of the night hours runs on past midnight', () => {
    const { getAvailableSlots } = useSlotAvailability({ appointments: [], resources: [nightLegacy] as any });
    const starts = getAvailableSlots('doc-1', new Date(2027, 2, 1), 60).map((slot) => moment(slot.start).format('ddd HH:mm'));
    expect(starts).toEqual(['Mon 20:00', 'Mon 21:00', 'Mon 22:00', 'Mon 23:00', 'Tue 00:00', 'Tue 01:00']);
  });
});

describe('free slots > the week view click goes to the first selected doctor who is free', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  const two = [doctor(), doctor({ id: 'doc-2', title: 'Dr. Bo Vet' })];
  const forDoctor = (id: string, time: string, status: string) => ({ ...appointment(time, status, 60), id: `${id}-${time}`, vet_id: id });
  // A click in the week view carries no resource; the handler has to pick the doctor.
  const weekClick = (start: string) => ({ start: new Date(start), end: new Date(start), resource: undefined }) as any;

  function weekHandler(appointments: any[]) {
    const booked: string[] = [];
    const refused: string[] = [];
    const handle = createDateSelectHandler({
      user: vet,
      resources: two,
      selectedUsers: [{ id: 'doc-1', full_name: 'Ann Vet' }, { id: 'doc-2', full_name: 'Bo Vet' }],
      selectedDuration: 60,
      allAppointments: appointments,
      checkSlotAvailability: realCheck(two, appointments),
      setSelectedSlot: () => undefined,
      handleTimeSlotClick: (doctorId) => booked.push(doctorId),
      showNotification: (message) => refused.push(message),
    });
    return { handle, booked, refused };
  }

  it('goes to the second doctor when the first is booked at that time', () => {
    const { handle, booked } = weekHandler([forDoctor('doc-1', '2027-03-01T10:00:00', 'scheduled')]);
    handle(weekClick('2027-03-01T10:00:00'));
    expect(booked).toEqual(['doc-2']);
  });

  it('is refused when every selected doctor is booked at that time', () => {
    const { handle, booked, refused } = weekHandler([
      forDoctor('doc-1', '2027-03-01T10:00:00', 'scheduled'),
      forDoctor('doc-2', '2027-03-01T10:00:00', 'confirmed'),
    ]);
    handle(weekClick('2027-03-01T10:00:00'));
    expect(booked).toEqual([]);
    expect(refused.length).toBe(1);
  });

  it('goes to the first doctor when their appointment at that time was cancelled', () => {
    const { handle, booked } = weekHandler([forDoctor('doc-1', '2027-03-01T10:00:00', 'cancelled')]);
    handle(weekClick('2027-03-01T10:00:00'));
    expect(booked).toEqual(['doc-1']);
  });

  it('goes to the second doctor when the first does not work at that hour', () => {
    const { handle, booked } = weekHandler([]);
    handle(weekClick('2027-03-01T16:30:00'));
    expect(booked).toEqual([]);
    const { handle: handle2, booked: booked2 } = (() => {
      const booked2: string[] = [];
      const shortDay = [doctor({ availableHours: { start: '09:00', end: '12:00' } }), doctor({ id: 'doc-2', title: 'Dr. Bo Vet' })];
      const handle2 = createDateSelectHandler({
        user: vet,
        resources: shortDay,
        selectedUsers: [{ id: 'doc-1', full_name: 'Ann Vet' }, { id: 'doc-2', full_name: 'Bo Vet' }],
        selectedDuration: 60,
        allAppointments: [],
        checkSlotAvailability: realCheck(shortDay, []),
        setSelectedSlot: () => undefined,
        handleTimeSlotClick: (doctorId) => booked2.push(doctorId),
        showNotification: () => undefined,
      });
      return { handle: handle2, booked: booked2 };
    })();
    handle2(weekClick('2027-03-01T14:00:00'));
    expect(booked2).toEqual(['doc-2']);
  });
});

describe('free slots > a day with two frames', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  // Monday has a morning frame and an afternoon frame; the default hours cover neither afternoon.
  const twoFrames = doctor({
    availableHours: { start: '08:00', end: '10:00' },
    dayServiceTimeRanges: {
      1: [
        { service: 'Exam', start: '09:00', end: '12:00' },
        { service: 'Surgery', start: '14:00', end: '17:00' },
      ],
    },
  });

  it('the slot list of the day lists both frames', () => {
    const { getAvailableSlots } = useSlotAvailability({ appointments: [], resources: [twoFrames] as any });
    const starts = getAvailableSlots('doc-1', new Date(2027, 2, 1), 60).map((slot) => moment(slot.start).format('HH:mm'));
    expect(starts).toEqual(['09:00', '10:00', '11:00', '14:00', '15:00', '16:00']);
  });
});
