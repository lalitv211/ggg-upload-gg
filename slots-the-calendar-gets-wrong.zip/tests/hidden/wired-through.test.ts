/**
 * Hidden tests: the fixes reach the places the app really goes through.
 *
 * The calendar page builds the availability check from the provider resources; the frames the
 * painter paints have to reach that check. The patient appointments module filters its tabs with
 * the statuses the backend sends, and the sibling patient service counts with them too.
 * The page hook and the module are rendered with React's server renderer, with their data hooks
 * replaced by fixed data; nothing about markup beyond which appointments are listed.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import React from 'react';
import { renderToString } from 'react-dom/server';

const DOCTOR = {
  id: 'doc-1',
  full_name: 'Ann Vet',
  email: 'ann@example.com',
  role: 'veterinarian',
  schedules: [
    {
      availability_days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
      availability_hours_start: '09:00:00',
      availability_hours_end: '12:00:00',
    },
  ],
};

/** What useCalendarResources builds for that doctor: a Monday afternoon frame, legacy Tuesday hours 12:00-20:00, default 09:00-12:00. */
const RESOURCES = [
  {
    id: 'doc-1',
    title: 'Dr. Ann Vet',
    availableDays: [1, 2, 3, 4, 5],
    availableHours: { start: '09:00', end: '12:00' },
    dayTimes: { 2: { start: '12:00', end: '20:00' } },
    dayServiceTimeRanges: { 1: [{ service: 'Exam', start: '14:00', end: '18:00' }] },
  },
];

const visit = (id: string, time: string, status: string, service: string) => ({
  id,
  appointment_time: time,
  service_type: service,
  status,
  pet_id: 'pet-1',
  client_id: 'client-1',
  clinic_id: 'clinic-1',
  created_at: '2027-01-01T00:00:00',
  updated_at: '2027-01-01T00:00:00',
});

const VISITS = [
  visit('v1', '2027-03-03T10:00:00', 'scheduled', 'Vaccination booster'),
  visit('v2', '2027-03-04T10:00:00', 'cancelled', 'Dental cleaning'),
  visit('v3', '2027-03-05T10:00:00', 'no_show', 'Nail trim'),
  visit('v4', '2027-02-10T10:00:00', 'completed', 'Annual checkup'),
];

vi.mock('@/hooks/useAuth', () => ({
  useAuth: () => ({
    user: { _uuid: 'doc-1', id: 'doc-1', clinic_id: 'clinic-1', role: 'veterinarian' },
  }),
}));
vi.mock('@/hooks/useNotification', () => ({
  useNotification: () => ({ showNotification: () => undefined }),
}));
vi.mock('react-router-dom', () => ({
  useLocation: () => ({ pathname: '/calendar', search: '', hash: '', state: null, key: 'k' }),
  useSearchParams: () => [new URLSearchParams(), () => undefined],
  useNavigate: () => () => undefined,
}));
vi.mock('@tanstack/react-query', () => ({
  useQueryClient: () => ({
    invalidateQueries: async () => undefined,
    setQueryData: () => undefined,
    getQueryData: () => undefined,
  }),
}));
vi.mock('@/features/appointments/hooks/useBackendVeterinarians', () => ({
  useBackendVeterinarians: () => ({ data: [DOCTOR], isLoading: false }),
}));
vi.mock('@/features/appointments/hooks/useBackendClinicUsersForCalendar', () => ({
  useBackendClinicUsersForCalendar: () => ({
    data: [DOCTOR],
    isLoading: false,
    refetch: async () => undefined,
  }),
}));
vi.mock('@/features/appointments/hooks/useBackendAppointments', () => ({
  useBackendAppointments: () => ({
    data: [],
    isLoading: false,
    refetch: async () => undefined,
    updateStatusAsync: async () => undefined,
    isUpdatingStatus: false,
  }),
}));
vi.mock('@/features/appointments/hooks/useBackendPatientAppointments', () => ({
  useBackendPatientAppointments: () => ({
    appointments: VISITS,
    stats: { total: 4, upcoming: 1, completed: 1, cancelled: 1, canceled: 1 },
    nextUpcoming: VISITS[0],
    error: null,
    isLoading: false,
  }),
}));
vi.mock('@/hooks/calendar', async (importActual) => {
  const actual: any = await importActual();
  return {
    ...actual,
    useCalendarResources: () => RESOURCES,
    useUserSelection: () => ({
      selectedUserIds: ['doc-1'],
      selectedUsers: [DOCTOR],
      availableUsersForSelection: [],
      filteredDoctorsForCalendar: [DOCTOR],
      comboboxKey: 0,
      handleAddUser: () => undefined,
      handleRemoveUser: () => undefined,
    }),
  };
});

async function pageData(): Promise<any> {
  const { useCalendarPageData } = await import('@/components/calendar/useCalendarPageData');
  let captured: any = null;
  const Probe = () => {
    captured = useCalendarPageData();
    return null;
  };
  renderToString(React.createElement(Probe));
  return captured;
}

async function moduleHtml(): Promise<string> {
  const { default: PatientAppointmentsModule } = await import(
    '@/features/appointments/components/PatientAppointmentsModule'
  );
  return renderToString(React.createElement(PatientAppointmentsModule, { petId: 'pet-1' }));
}

describe('wired through', () => {
  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  describe('the calendar page hands the frames of the day to the availability check', () => {
    it('a slot inside the afternoon frame is available through the page', async () => {
      const page = await pageData();
      const result = page.checkSlotAvailability('doc-1', new Date(2027, 2, 1, 15, 0, 0), 60);
      expect(result.isAvailable).toBe(true);
    });

    it('a slot in the default morning hours is not available on a day that has frames', async () => {
      const page = await pageData();
      const result = page.checkSlotAvailability('doc-1', new Date(2027, 2, 1, 10, 0, 0), 60);
      expect(result.isAvailable).toBe(false);
    });

    it('a slot inside the legacy hours of Tuesday is available through the page', async () => {
      const page = await pageData();
      const result = page.checkSlotAvailability('doc-1', new Date(2027, 2, 2, 18, 0, 0), 60);
      expect(result.isAvailable).toBe(true);
    });
  });

  describe('the patient appointments module filters its tabs with the statuses the backend sends', () => {
    it('the upcoming tab lists the scheduled visit ahead', async () => {
      expect(await moduleHtml()).toContain('Vaccination booster');
    });

    it('the upcoming tab leaves out the cancelled visit ahead', async () => {
      expect(await moduleHtml()).not.toContain('Dental cleaning');
    });

    it('the upcoming tab leaves out the no-show visit ahead', async () => {
      expect(await moduleHtml()).not.toContain('Nail trim');
    });

    it('the upcoming count is one', async () => {
      expect(await moduleHtml()).toContain('Upcoming (1)');
    });

    it('the past count is three', async () => {
      expect(await moduleHtml()).toContain('Past (3)');
    });
  });

  describe('the sibling patient service counts with the statuses the backend sends', () => {
    it('upcoming counts the scheduled visit ahead', async () => {
      const { calculateAppointmentStats } = await import(
        '@/features/appointments/api/patientAppointmentService'
      );
      expect(calculateAppointmentStats(VISITS as any).upcoming).toBe(1);
    });

    it('the next appointment is the scheduled one, not the cancelled one', async () => {
      const { getNextUpcomingAppointment } = await import(
        '@/features/appointments/api/patientAppointmentService'
      );
      const ahead = [VISITS[1], VISITS[2], VISITS[0]];
      expect(getNextUpcomingAppointment(ahead as any)?.id).toBe('v1');
    });
  });
});
