// The grader's own vitest configuration: the repository's settings (node environment, the "@" alias,
// the Supabase defines) with nothing to import, so vite can load it from wherever it is copied,
// outside node_modules, and it collects only the grader's own test folders.
import path from 'path';

export default {
  define: {
    'import.meta.env.VITE_SUPABASE_URL': JSON.stringify('http://127.0.0.1:54321'),
    'import.meta.env.VITE_SUPABASE_ANON_KEY': JSON.stringify('test-anon-key'),
  },
  test: {
    environment: 'node',
    include: ['src/__tests__/hidden/**/*.test.ts', 'src/__tests__/hidden-pristine/**/*.test.ts'],
    reporters: ['default'],
    fileParallelism: false,
    testTimeout: 20000,
  },
  resolve: {
    alias: {
      '@': path.resolve(process.cwd(), 'src'),
    },
  },
};
