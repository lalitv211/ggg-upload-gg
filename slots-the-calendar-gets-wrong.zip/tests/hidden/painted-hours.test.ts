/**
 * Hidden tests: the hours the calendar paints.
 *
 * generateCalendarEvents paints the provider's hours as background events. It has to cover every
 * day of the range it is given, leave the provider's frames exactly as they were, and paint the same
 * picture every time it is asked. The assertions look at the painted events through the class names
 * the stylesheet already keys on (fc-available-slot, fc-unavailable-slot) and their start days.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import moment from 'moment';
import { generateCalendarEvents } from '@/components/calendar/utils/generateCalendarEvents';

const weekdays = (over: Record<string, unknown> = {}) => ({
  id: 'doc-1',
  title: 'Dr. Ann Vet',
  availableDays: [1, 2, 3, 4, 5],
  availableHours: { start: '09:00', end: '17:00' },
  ...over,
});

const has = (event: any, className: string) =>
  Array.isArray(event.classNames) ? event.classNames.includes(className) : event.classNames === className;

const paintedOn = (events: any[], className: string, day: string) =>
  events.filter((event) => has(event, className) && moment(event.start).format('YYYY-MM-DD') === day);

const paint = (resource: any, start: string, end: string, filteredEvents: any[] = []) =>
  generateCalendarEvents({ resources: [resource], filteredEvents, dateRangeStart: start, dateRangeEnd: end });

describe('painted hours > every day of the range is painted', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  it('a month-long range gets available hours in its third week', () => {
    const events = paint(weekdays(), '2027-03-01T00:00:00', '2027-03-31T23:59:59');
    expect(paintedOn(events, 'fc-available-slot', '2027-03-15').length).toBeGreaterThan(0);
    expect(paintedOn(events, 'fc-available-slot', '2027-03-30').length).toBeGreaterThan(0);
  });

  it('a month-long range marks a Saturday in its third week unavailable', () => {
    const events = paint(weekdays(), '2027-03-01T00:00:00', '2027-03-31T23:59:59');
    expect(paintedOn(events, 'fc-unavailable-slot', '2027-03-20').length).toBeGreaterThan(0);
  });

  it('a range that starts midweek still paints its last day', () => {
    const events = paint(weekdays(), '2027-03-03T00:00:00', '2027-03-12T23:59:59');
    expect(paintedOn(events, 'fc-available-slot', '2027-03-12').length).toBeGreaterThan(0);
  });
});

describe('painted hours > the frames are left as they were', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  it('a day whose frame list is empty keeps an empty list after painting', () => {
    const resource = weekdays({ dayServiceTimeRanges: { 1: [] } });
    paint(resource, '2027-03-01T00:00:00', '2027-03-07T23:59:59');
    expect(resource.dayServiceTimeRanges).toEqual({ 1: [] });
  });

});
