/**
 * Build check: every module the change touches still loads under node.
 */
import { describe, expect, it } from 'vitest';

describe('load > the calendar and appointment modules load', () => {
  it('loads the slot availability, handlers, painter, services and helpers', async () => {
    const modules = await Promise.all([
      import('@/components/calendar/features/slotAvailability/useSlotAvailability'),
      import('@/components/calendar/handlers/dateSelectionHandler'),
      import('@/components/calendar/utils/generateCalendarEvents'),
      import('@/components/calendar/utils'),
      import('@/components/calendar/handlers'),
      import('@/features/appointments/api/backendPatientAppointmentService'),
      import('@/features/appointments/api/patientAppointmentService'),
      import('@/features/appointments/api/types'),
      import('@/utils/appointmentUtils'),
      import('@/utils/calendarUtils'),
      import('@/lib/utils'),
    ]);
    for (const loaded of modules) {
      expect(typeof loaded).toBe('object');
    }
  });
});
