/**
 * Hidden tests: the counts and labels around appointments.
 *
 * The patient page's counts use the status words the backend sends (scheduled, requested, confirmed,
 * checked_in, in_progress, completed, cancelled, no_show): upcoming is anything still ahead that is
 * neither cancelled nor a no-show, and so is the next appointment. The week label takes the last day
 * it is given, an appointment belongs to the quarter-hour slot it starts in, and the compact date
 * style the helper documents gives a short numeric date.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  calculateAppointmentStats,
  getNextUpcomingAppointment,
} from '@/features/appointments/api/backendPatientAppointmentService';
import { formatDate } from '@/lib/utils';
import { getAppointmentsForSlot } from '@/utils/appointmentUtils';
import { formatWeekRange } from '@/utils/calendarUtils';

const visit = (id: string, time: string, status: string): any => ({
  id,
  appointment_time: time,
  service_type: 'Exam',
  status,
  pet_id: 'pet-1',
  client_id: 'client-1',
  clinic_id: 'clinic-1',
  created_at: '2027-01-01T00:00:00',
  updated_at: '2027-01-01T00:00:00',
});

describe('counts and labels > the patient page counts the statuses the backend sends', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date(2027, 2, 1, 6, 0, 0));
  });
  afterEach(() => vi.useRealTimers());

  const visits = [
    visit('scheduled-ahead', '2027-03-05T10:00:00', 'scheduled'),
    visit('confirmed-ahead', '2027-03-06T10:00:00', 'confirmed'),
    visit('requested-ahead', '2027-03-04T10:00:00', 'requested'),
    visit('cancelled-ahead', '2027-03-03T10:00:00', 'cancelled'),
    visit('cancelled-past', '2027-02-05T10:00:00', 'cancelled'),
    visit('no-show-past', '2027-02-06T10:00:00', 'no_show'),
    visit('completed-past', '2027-02-07T10:00:00', 'completed'),
    visit('scheduled-past', '2027-02-08T10:00:00', 'scheduled'),
  ];

  it('scheduled, confirmed and requested appointments ahead are upcoming', () => {
    expect(calculateAppointmentStats(visits).upcoming).toBe(3);
  });

  it('cancelled appointments are counted as cancelled, ahead or behind', () => {
    expect(calculateAppointmentStats(visits).canceled).toBe(2);
  });

  it('the next appointment is the earliest one ahead that is neither cancelled nor a no-show', () => {
    expect(getNextUpcomingAppointment(visits)?.id).toBe('requested-ahead');
  });

  it('a cancelled appointment ahead of every other one is never the next appointment', () => {
    const only = [visit('cancelled-ahead', '2027-03-03T10:00:00', 'cancelled'), visit('scheduled-ahead', '2027-03-05T10:00:00', 'scheduled')];
    expect(getNextUpcomingAppointment(only)?.id).toBe('scheduled-ahead');
  });

});

describe('counts and labels > the week label takes the last day it is given', () => {
  it('a five-day week is labelled from its first to its fifth day', () => {
    const days = Array.from({ length: 5 }, (_, i) => new Date(2027, 2, 1 + i));
    expect(formatWeekRange(days)).toBe('Mar 1 - Mar 5, 2027');
  });

  it('a three-day range is labelled from its first to its third day', () => {
    const days = Array.from({ length: 3 }, (_, i) => new Date(2027, 2, 1 + i));
    expect(formatWeekRange(days)).toBe('Mar 1 - Mar 3, 2027');
  });
});

describe('counts and labels > an appointment belongs to the quarter it starts in', () => {
  const appointments = [
    { id: 'five-past', vet_id: 'doc-1', appointment_time: '2027-03-01T09:05:00' },
    { id: 'quarter-past', vet_id: 'doc-1', appointment_time: '2027-03-01T09:15:00' },
    { id: 'twenty-nine-past', vet_id: 'doc-1', appointment_time: '2027-03-01T09:29:00' },
  ];
  const day = new Date(2027, 2, 1);
  const ids = (slot: string) => getAppointmentsForSlot(appointments, 'doc-1', day, slot).map((apt) => apt.id);

  it('five past nine is in the nine o clock slot', () => {
    expect(ids('09:00')).toEqual(['five-past']);
  });

  it('the quarter past slot holds what starts from a quarter past up to half past', () => {
    expect(ids('09:15')).toEqual(['quarter-past', 'twenty-nine-past']);
  });

});

describe('counts and labels > the compact date style', () => {
  it('gives the short numeric date the helper documents', () => {
    expect(formatDate(new Date(2027, 2, 1, 10, 0), { style: 'compact' })).toBe('3/1/27');
  });

  it('gives it for a date string too', () => {
    expect(formatDate('2027-12-24T10:00:00', { style: 'compact' })).toBe('12/24/27');
  });
});
