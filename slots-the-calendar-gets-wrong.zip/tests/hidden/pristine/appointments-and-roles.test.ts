import { describe, expect, it } from 'vitest';
import { formatDoctorName } from '@/components/calendar/utils/doctorNameFormatter';
import { canUserCancelAppointment } from '@/features/appointments/utils/canCancelAppointment';
import {
  calculateAppointmentStats,
  getNextUpcomingAppointment,
  type PatientAppointment,
} from '@/features/appointments/api/patientAppointmentService';
import { getOrgAdminPermissions, hasOrgAdminPermission } from '@/features/permissions/orgAdminPermissions';
import { customRoleCheck, defaultRoleCheck, roleCheck } from '@/lib/utils';
import {
  calculateAppointmentPosition,
  getAppointmentsForSlot,
  getAppointmentsForTimeRange,
  getConditionalStatus,
  getStatusStyles,
  processAppointmentsWithStatus,
} from '@/utils/appointmentUtils';
import { extractErrorMessage, getDefaultErrorMessage } from '@/utils/errorHandler';
import {
  canCreateTelehealthMeeting,
  getEffectiveRole,
  isVeterinarianOrStaff,
} from '@/utils/roleHelpers';
import type { User } from '@/types/common';

function makeUser(overrides: Partial<User> = {}): User {
  return {
    _uuid: 'user-1',
    id: 'user-1',
    role: 'veterinarian',
    ...overrides,
  };
}

function makeAppointment(overrides: Partial<PatientAppointment> = {}): PatientAppointment {
  return {
    id: 'apt-1',
    appointment_time: '2099-01-15T15:00:00',
    service_type: 'Exam',
    status: 'upcoming',
    pet_id: 'pet-1',
    client_id: 'client-1',
    clinic_id: 'clinic-1',
    created_at: '2099-01-01T00:00:00',
    updated_at: '2099-01-01T00:00:00',
    ...overrides,
  };
}

describe('appointment status styles', () => {
  it('returns the scheduled palette for scheduled appointments', () => {
    expect(getStatusStyles('scheduled')).toMatchObject({
      bgcolor: '#F3F4F6',
      color: '#374151',
    });
  });

  it('returns the completed palette for completed appointments', () => {
    expect(getStatusStyles('completed').bgcolor).toBe('#8B5CF6');
  });

  it('falls back to scheduled styles for an unknown status', () => {
    expect(getStatusStyles('not-real' as 'scheduled')).toEqual(getStatusStyles('scheduled'));
  });

  it('returns the database status unchanged from getConditionalStatus', () => {
    expect(getConditionalStatus({ status: 'checked_in' })).toBe('checked_in');
  });
});

describe('appointment layout helpers', () => {
  it('places a 9:30 appointment two 15-minute slots below a 9:00 start hour', () => {
    const position = calculateAppointmentPosition('2024-01-15T09:30:00', 9, 60);
    expect(position.top).toBe(120);
    expect(position.minute).toBe(30);
  });

  it('filters appointments to the assigned veterinarian, date, and hour window', () => {
    const date = new Date(2024, 0, 15);
    const appointments = [
      { id: '1', vet_id: 'vet-a', appointment_time: '2024-01-15T10:00:00' },
      { id: '2', vet_id: 'vet-b', appointment_time: '2024-01-15T10:00:00' },
      { id: '3', vet_id: 'vet-a', appointment_time: '2024-01-16T10:00:00' },
      { id: '4', vet_id: 'vet-a', appointment_time: '2024-01-15T19:00:00' },
    ];
    const result = getAppointmentsForTimeRange(appointments, 'vet-a', date, 8, 18);
    expect(result.map((apt: { id: string }) => apt.id)).toEqual(['1']);
  });

  it('matches an appointment only in the exact starting slot', () => {
    const date = new Date(2024, 0, 15);
    const appointments = [
      { id: '1', vet_id: 'vet-a', appointment_time: '2024-01-15T10:15:00' },
      { id: '2', vet_id: 'vet-a', appointment_time: '2024-01-15T10:00:00' },
    ];
    expect(getAppointmentsForSlot(appointments, 'vet-a', date, '10:15').map((a) => a.id)).toEqual([
      '1',
    ]);
  });

  it('labels block appointments with N/A pet and owner names', () => {
    const [block] = processAppointmentsWithStatus([
      { id: 'b1', service_type: 'Block', status: 'scheduled' },
    ]);
    expect(block.pet_name).toBe('N/A');
    expect(block.owner_name).toBe('N/A');
  });

  it('uses related pet and client names for non-block appointments', () => {
    const [exam] = processAppointmentsWithStatus([
      {
        id: 'e1',
        service_type: 'Exam',
        status: 'scheduled',
        pets: { name: 'Fido', clients: { users: { full_name: 'Pat Owner' } } },
        users: { full_name: 'Dr Vet' },
      },
    ]);
    expect(exam.pet_name).toBe('Fido');
    expect(exam.owner_name).toBe('Pat Owner');
    expect(exam.vet_name).toBe('Dr Vet');
  });
});

describe('appointment stats and next upcoming', () => {
  it('returns the earliest future upcoming appointment', () => {
    const later = makeAppointment({ id: 'later', appointment_time: '2099-12-01T10:00:00' });
    const sooner = makeAppointment({ id: 'sooner', appointment_time: '2099-06-01T10:00:00' });
    const past = makeAppointment({ id: 'past', appointment_time: '2001-01-01T10:00:00' });
    expect(getNextUpcomingAppointment([later, past, sooner])?.id).toBe('sooner');
  });

  it('returns null when there is no future upcoming appointment', () => {
    expect(
      getNextUpcomingAppointment([
        makeAppointment({ status: 'completed', appointment_time: '2099-06-01T10:00:00' }),
      ])
    ).toBeNull();
  });
});

describe('canUserCancelAppointment', () => {
  it('returns false when the appointment or user is missing', () => {
    expect(canUserCancelAppointment(null, makeUser())).toBe(false);
    expect(canUserCancelAppointment({ vet_id: 'vet-1' }, null)).toBe(false);
  });

  it('allows a clinic admin to cancel any appointment', () => {
    expect(
      canUserCancelAppointment({ vet_id: 'other' }, makeUser({ role: 'clinic_admin' }))
    ).toBe(true);
  });

  it('allows the assigned veterinarian to cancel', () => {
    expect(canUserCancelAppointment({ vet_id: 'user-1' }, makeUser())).toBe(true);
  });

  it('allows the owning client to cancel via pets.clients.user_id', () => {
    expect(
      canUserCancelAppointment(
        { pets: { clients: { user_id: 'user-1' } } },
        makeUser({ role: 'client' })
      )
    ).toBe(true);
  });

  it('rejects an unrelated staff member', () => {
    expect(
      canUserCancelAppointment({ vet_id: 'someone-else' }, makeUser({ role: 'staff' }))
    ).toBe(false);
  });
});

describe('role helpers', () => {
  it('treats veterinarian, staff, clinic_admin, and receptionist as vet/staff', () => {
    expect(isVeterinarianOrStaff(makeUser({ role: 'veterinarian' }))).toBe(true);
    expect(isVeterinarianOrStaff(makeUser({ role: 'staff' }))).toBe(true);
    expect(isVeterinarianOrStaff(makeUser({ role: 'clinic_admin' }))).toBe(true);
    expect(isVeterinarianOrStaff(makeUser({ role: 'receptionist' }))).toBe(true);
  });

  it('treats a custom Televet role_name as veterinarian-level access', () => {
    expect(isVeterinarianOrStaff(makeUser({ role: 'client', role_name: 'Televet' }))).toBe(true);
  });

  it('returns false for a missing user or a client without a vet role name', () => {
    expect(isVeterinarianOrStaff(null)).toBe(false);
    expect(isVeterinarianOrStaff(makeUser({ role: 'client' }))).toBe(false);
  });

  it('does not let a receptionist create telehealth meetings', () => {
    expect(canCreateTelehealthMeeting(makeUser({ role: 'receptionist' }))).toBe(false);
  });

  it('lets veterinarians create telehealth meetings', () => {
    expect(canCreateTelehealthMeeting(makeUser({ role: 'veterinarian' }))).toBe(true);
  });

  it('prefers role_name from getEffectiveRole and falls back to role', () => {
    expect(getEffectiveRole(makeUser({ role_name: 'Lead Vet' }))).toBe('Lead Vet');
    expect(getEffectiveRole(makeUser())).toBe('veterinarian');
    expect(getEffectiveRole(null)).toBe('client');
  });
});

describe('permission checks', () => {
  it('allows a default role when the permission string is present', () => {
    const user = makeUser({
      role_isDefault: true,
      role_permissions: ['view_appointments', 'manage_users'],
    });
    expect(defaultRoleCheck(user, 'manage_users' as never)).toBe(true);
    expect(defaultRoleCheck(user, 'clinic_settings' as never)).toBe(false);
  });

  it('checks custom role permissions across all categories when no category is given', () => {
    const user = makeUser({
      role_isDefault: false,
      role_permissions: {
        id: 'r1',
        admin_controls: [],
        view_access: ['view_appointments' as never],
        create_access: [],
        edit_access: [],
        cancel_access: [],
        delete_access: [],
      },
    });
    expect(customRoleCheck(user, 'view_appointments' as never)).toBe(true);
    expect(customRoleCheck(user, 'manage_users' as never)).toBe(false);
  });

  it('returns false for a custom role with missing permissions', () => {
    expect(customRoleCheck(makeUser({ role_isDefault: false, role_permissions: undefined }), 'manage_users' as never)).toBe(
      false
    );
  });

  it('routes default-role array checks through roleCheck', () => {
    const user = makeUser({
      role_isDefault: true,
      role_permissions: ['view_appointments'],
    });
    expect(roleCheck(user, ['view_appointments', 'manage_users'] as never)).toBe(true);
  });

  it('includes organization admin catalog ids from getOrgAdminPermissions', () => {
    const ids = getOrgAdminPermissions();
    expect(ids).toContain('view_organization');
    expect(ids).toContain('create_clinics');
    expect(hasOrgAdminPermission('view_organization')).toBe(true);
    expect(hasOrgAdminPermission('not_a_real_permission')).toBe(false);
  });
});

describe('error message extraction', () => {
  it('reads the message from a standard Error', () => {
    expect(extractErrorMessage(new Error('boom'))).toBe('boom');
  });

  it('joins field-level API validation errors', () => {
    expect(
      extractErrorMessage({
        message: 'ignored',
        errors: [{ field: 'email', messages: ['required', 'invalid'] }],
      })
    ).toBe('email: required, invalid');
  });

  it('joins NestJS array messages', () => {
    expect(extractErrorMessage({ message: ['first', 'second'] })).toBe('first, second');
  });

  it('reads axios-style response.data.message', () => {
    expect(extractErrorMessage({ response: { data: { message: 'nope' } } })).toBe('nope');
  });

  it('returns the default message for unknown values', () => {
    expect(extractErrorMessage(42, 'fallback')).toBe('fallback');
  });

  it('builds operation-specific default messages', () => {
    expect(getDefaultErrorMessage('create', 'appointment')).toBe(
      'Failed to create appointment. Please try again.'
    );
    expect(getDefaultErrorMessage('fetch', 'invoice')).toBe(
      'Failed to fetch invoice. Please try again.'
    );
  });
});

describe('formatDoctorName stability', () => {
  it('trims surrounding whitespace before formatting', () => {
    expect(formatDoctorName('  sam lee  ')).toBe('Dr. Sam Lee');
  });
});
