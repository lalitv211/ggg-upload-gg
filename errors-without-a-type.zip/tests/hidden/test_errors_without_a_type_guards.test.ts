// Hidden guards: what the backend HTTP client already did right at the base keeps working.
// Every test here passes on the base, on the golden and on the alternative.
import { beforeEach, describe, expect, it, vi } from 'vitest';

const session = { token: 'guard-token' as string | null, throwOnRead: false, signOuts: 0 };

vi.mock('@/lib/supabaseClient', () => ({
  supabase: {
    auth: {
      getSession: async () => {
        if (session.throwOnRead) throw new Error('session store unavailable');
        return {
          data: { session: session.token ? { access_token: session.token } : null },
        };
      },
      signOut: async () => {
        session.signOuts += 1;
      },
    },
  },
}));

type Verb = 'get' | 'post' | 'patch' | 'put' | 'delete';
type FetchInit = RequestInit & { signal?: AbortSignal };

const VERBS: Verb[] = ['get', 'post', 'patch', 'put', 'delete'];

const win: { location: { origin: string; pathname: string; href: string } } = {
  location: { origin: 'http://app.local', pathname: '/dashboard', href: '' },
};
const storage: Record<string, unknown> = {
  removeItem(key: string) {
    delete storage[key];
  },
};

let lastUrl = '';
let lastInit: FetchInit | null = null;

function stubFetch(impl: (url: string, init: FetchInit) => Promise<Response>) {
  vi.stubGlobal(
    'fetch',
    vi.fn(async (url: string, init: FetchInit) => {
      lastUrl = url;
      lastInit = init;
      return impl(url, init);
    })
  );
}

function abortError(): Error {
  if (typeof DOMException === 'function') {
    return new DOMException('This operation was aborted', 'AbortError');
  }
  return Object.assign(new Error('This operation was aborted'), { name: 'AbortError' });
}

function hungFetch() {
  return (_url: string, init: FetchInit) =>
    new Promise<Response>((_resolve, reject) => {
      const signal = init.signal;
      if (!signal) return;
      if (signal.aborted) {
        reject(abortError());
        return;
      }
      signal.addEventListener('abort', () => reject(abortError()));
    });
}

function textResponse(status: number, body: string, contentType = 'text/plain') {
  return new Response(body, { status, headers: { 'content-type': contentType } });
}

function jsonResponse(status: number, body: unknown, contentType = 'application/json') {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': contentType } });
}

interface Caught {
  threw: boolean;
  error: unknown;
  code: unknown;
  message: unknown;
}

async function caught(promise: Promise<unknown>): Promise<Caught> {
  try {
    await promise;
    return { threw: false, error: undefined, code: undefined, message: undefined };
  } catch (error) {
    const e = error as { code?: unknown; message?: unknown };
    return { threw: true, error, code: e?.code, message: e?.message };
  }
}

async function makeClient(timeout = 60, baseURL = 'http://api.local') {
  const mod = await import('@/services/api/httpClient');
  return new mod.HttpClient(baseURL, timeout);
}

function send(client: any, verb: Verb, path: string, options?: Record<string, unknown>) {
  if (verb === 'get' || verb === 'delete') return client[verb](path, options);
  return client[verb](path, { name: 'Fluffy' }, options);
}

function headerOf(name: string): string | null {
  return new Headers((lastInit?.headers ?? {}) as HeadersInit).get(name);
}

function storageKeys(): string[] {
  return Object.keys(storage).filter((key) => key !== 'removeItem');
}

beforeEach(() => {
  vi.stubGlobal('window', win);
  vi.stubGlobal('localStorage', storage);
  win.location.href = '';
  win.location.pathname = '/dashboard';
  session.token = 'guard-token';
  session.throwOnRead = false;
  session.signOuts = 0;
  for (const key of storageKeys()) delete storage[key];
  lastUrl = '';
  lastInit = null;
});

describe('the module keeps its public surface', () => {
  it('exports the HttpClient class as a named export and as the default', async () => {
    const mod = await import('@/services/api/httpClient');
    expect(typeof mod.HttpClient).toBe('function');
    expect(mod.default).toBe(mod.HttpClient);
  });

  it('exports a ready httpClient singleton with the five methods', async () => {
    const mod = await import('@/services/api/httpClient');
    expect(mod.httpClient).toBeInstanceOf(mod.HttpClient);
    for (const verb of VERBS) {
      expect(typeof (mod.httpClient as any)[verb]).toBe('function');
    }
  });
});

describe('connection failures that were already typed', () => {
  it('get with the backend down throws CONNECTION_ERROR', async () => {
    const client = await makeClient();
    stubFetch(async () => {
      throw new TypeError('Failed to fetch');
    });
    const result = await caught(client.get('/api/pets'));
    expect(result.code).toBe('CONNECTION_ERROR');
  });

  it('get with the backend down keeps its message', async () => {
    const client = await makeClient();
    stubFetch(async () => {
      throw new TypeError('Failed to fetch');
    });
    const result = await caught(client.get('/api/pets'));
    expect(String(result.message)).toContain('Unable to connect to server');
  });
});

describe('timeouts without a caller signal', () => {
  it.each(VERBS)(
    '%s on a hung backend throws TIMEOUT',
    async (verb) => {
      const client = await makeClient(5000);
      stubFetch(hungFetch());
      const result = await caught(send(client, verb, '/api/pets', { timeout: 30 }));
      expect(result.code).toBe('TIMEOUT');
      expect(result.message).toBe('Request timeout');
    },
    1500
  );

  it(
    'the client default timeout applies when the call gives none',
    async () => {
      const client = await makeClient(30);
      stubFetch(hungFetch());
      const result = await caught(client.get('/api/pets'));
      expect(result.code).toBe('TIMEOUT');
    },
    1500
  );

  it('a request that answers in time does not time out', async () => {
    const client = await makeClient(30);
    stubFetch(async () => jsonResponse(200, { id: 1 }));
    await expect(client.get('/api/pets/1')).resolves.toEqual({ id: 1 });
  });
});

describe('an unauthorized answer still signs the user out', () => {
  it.each(['get', 'post'] as Verb[])('%s on a 401 throws HTTP_401', async (verb) => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(401, { message: 'expired' }));
    const result = await caught(send(client, verb, '/api/pets'));
    expect(result.code).toBe('HTTP_401');
    expect(String(result.message)).toContain('Unauthorized');
  });

  it('a 401 signs out of supabase', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(401, { message: 'expired' }));
    await caught(client.get('/api/pets'));
    expect(session.signOuts).toBe(1);
  });

  it('a 401 clears auth entries from local storage and keeps the rest', async () => {
    storage['sb-vetly-auth-token'] = 'x';
    storage['supabase.session'] = 'y';
    storage.theme = 'dark';
    const client = await makeClient();
    stubFetch(async () => jsonResponse(401, { message: 'expired' }));
    await caught(client.delete('/api/pets/1'));
    expect(storageKeys()).toEqual(['theme']);
  });

  it('a 401 sends the browser to the login page', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(401, { message: 'expired' }));
    await caught(client.get('/api/pets'));
    expect(win.location.href).toBe('/login');
  });

  it('a 401 on the login page itself does not navigate again', async () => {
    win.location.pathname = '/login';
    const client = await makeClient();
    stubFetch(async () => jsonResponse(401, { message: 'expired' }));
    await caught(client.get('/api/pets'));
    expect(win.location.href).toBe('');
  });
});

describe('error bodies that already produced a message', () => {
  it('a JSON message string is the error message', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(400, { message: 'name is required' }));
    const result = await caught(client.post('/api/pets', {}));
    expect(result.code).toBe('HTTP_400');
    expect(result.message).toBe('name is required');
  });

  it('a JSON message array is joined with commas', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(400, { message: ['name is required', 'species is short'] }));
    const result = await caught(client.post('/api/pets', {}));
    expect(result.message).toBe('name is required, species is short');
  });

  it('a JSON error string is the error message', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(409, { error: 'already exists' }));
    const result = await caught(client.post('/api/pets', {}));
    expect(result.code).toBe('HTTP_409');
    expect(result.message).toBe('already exists');
  });

  it('field errors are passed through beside the message', async () => {
    const client = await makeClient();
    stubFetch(async () =>
      jsonResponse(422, {
        message: 'Validation failed',
        errors: [{ field: 'email', messages: ['must be an email', 'is required'] }],
      })
    );
    const result = await caught(client.patch('/api/clients/1', {}));
    expect(result.code).toBe('HTTP_422');
    expect(result.message).toBe('Validation failed');
    expect((result.error as { errors?: unknown }).errors).toEqual([
      { field: 'email', messages: ['must be an email', 'is required'] },
    ]);
  });

  it('field errors without a message are joined by field', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(422, { errors: [{ field: 'email', messages: ['is required'] }] }));
    const result = await caught(client.put('/api/clients/1', {}));
    expect(result.message).toBe('email: is required');
  });

  it('a status text present on the response is still usable', async () => {
    const client = await makeClient();
    stubFetch(
      async () =>
        new Response('x', {
          status: 500,
          statusText: 'Internal Server Error',
          headers: { 'content-type': 'text/plain' },
        })
    );
    const result = await caught(client.get('/api/pets'));
    expect(result.code).toBe('HTTP_500');
    expect(String(result.message)).toMatch(/500/);
  });

  it('the code names the status for every failure', async () => {
    const client = await makeClient();
    for (const status of [400, 403, 404, 429, 500, 503]) {
      stubFetch(async () => jsonResponse(status, { message: `status ${status}` }));
      const result = await caught(client.get('/api/pets'));
      expect(result.code).toBe(`HTTP_${status}`);
    }
  });
});

describe('successful answers are parsed as before', () => {
  it('a JSON body is parsed', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, { id: 7, name: 'Fluffy' }));
    await expect(client.get('/api/pets/7')).resolves.toEqual({ id: 7, name: 'Fluffy' });
  });

  it('a JSON content type with a charset is still parsed', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(201, { id: 8 }, 'application/json; charset=utf-8'));
    await expect(client.post('/api/pets', { name: 'Rex' })).resolves.toEqual({ id: 8 });
  });

  it('an empty JSON body resolves to null', async () => {
    const client = await makeClient();
    stubFetch(async () => new Response('', { status: 200, headers: { 'content-type': 'application/json' } }));
    await expect(client.get('/api/pets')).resolves.toBeNull();
  });

  it('a body that is not valid JSON resolves to null', async () => {
    const client = await makeClient();
    stubFetch(async () => textResponse(200, '{not json', 'application/json'));
    await expect(client.get('/api/pets')).resolves.toBeNull();
  });

  it('a text body resolves to the text', async () => {
    const client = await makeClient();
    stubFetch(async () => textResponse(200, 'pong'));
    await expect(client.get('/api/health')).resolves.toBe('pong');
  });

  it('a JSON array body is parsed', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, [{ id: 1 }, { id: 2 }]));
    await expect(client.get('/api/pets')).resolves.toEqual([{ id: 1 }, { id: 2 }]);
  });
});

describe('requests are built as before', () => {
  it('sends the bearer token from the supabase session', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, {}));
    await client.get('/api/pets');
    expect(headerOf('authorization')).toBe('Bearer guard-token');
  });

  it('sends no authorization header without a session', async () => {
    session.token = null;
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, {}));
    await client.get('/api/pets');
    expect(headerOf('authorization')).toBeNull();
  });

  it('still sends the request when the session cannot be read', async () => {
    session.throwOnRead = true;
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, { ok: true }));
    await expect(client.get('/api/pets')).resolves.toEqual({ ok: true });
    expect(headerOf('authorization')).toBeNull();
  });

  it('defaults the content type to JSON', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, {}));
    await client.post('/api/pets', { name: 'Rex' });
    expect(headerOf('content-type')).toBe('application/json');
  });

  it('keeps custom headers from the caller', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, {}));
    await client.get('/api/pets', { headers: { 'X-Clinic': 'c1', 'Content-Type': 'text/csv' } });
    expect(headerOf('x-clinic')).toBe('c1');
    expect(headerOf('content-type')).toBe('text/csv');
  });

  it('serializes the body as JSON with the method', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, {}));
    await client.patch('/api/pets/1', { name: 'Rex' });
    expect(lastInit?.method).toBe('PATCH');
    expect(lastInit?.body).toBe(JSON.stringify({ name: 'Rex' }));
  });

  it('uses the verb as the method for get and delete', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, {}));
    await client.get('/api/pets');
    expect(lastInit?.method).toBe('GET');
    await client.delete('/api/pets/1');
    expect(lastInit?.method).toBe('DELETE');
  });

  it('appends query parameters and skips undefined ones', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, []));
    await client.get('/api/pets', { params: { clinicId: 'c1', page: 2, archived: false, q: undefined } });
    expect(lastUrl).toBe('http://api.local/api/pets?clinicId=c1&page=2&archived=false');
  });

  it('encodes query parameter values', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, []));
    await client.get('/api/search', { params: { q: 'max & co' } });
    expect(lastUrl).toBe('http://api.local/api/search?q=max+%26+co');
  });

  it('trims a trailing slash from the base URL', async () => {
    const client = await makeClient(60, 'http://api.local/');
    stubFetch(async () => jsonResponse(200, []));
    await client.get('/api/pets');
    expect(lastUrl).toBe('http://api.local/api/pets');
  });

  it('uses an absolute endpoint as given', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, []));
    await client.get('https://files.example.com/report.pdf', { params: { token: 't' } });
    expect(lastUrl).toBe('https://files.example.com/report.pdf?token=t');
  });

  it('passes other fetch options through', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, []));
    await client.get('/api/pets', { credentials: 'include', cache: 'no-store' });
    expect(lastInit?.credentials).toBe('include');
    expect(lastInit?.cache).toBe('no-store');
  });

  it('hands fetch a signal on every request', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(200, {}));
    for (const verb of VERBS) {
      await send(client, verb, '/api/pets');
      expect(lastInit?.signal).toBeInstanceOf(AbortSignal);
    }
  });
});

describe('the error helper still reads these errors', () => {
  it('reads the message of a typed client error', async () => {
    const { extractErrorMessage } = await import('@/utils/errorHandler');
    expect(extractErrorMessage({ message: 'Request timeout', code: 'TIMEOUT' })).toBe('Request timeout');
  });

  it('prefers field errors when present', async () => {
    const { extractErrorMessage } = await import('@/utils/errorHandler');
    expect(
      extractErrorMessage({
        message: 'Validation failed',
        code: 'HTTP_422',
        errors: [{ field: 'name', messages: ['is required'] }],
      })
    ).toBe('name: is required');
  });

  it('falls back to the default for an unknown value', async () => {
    const { extractErrorMessage } = await import('@/utils/errorHandler');
    expect(extractErrorMessage(42, 'fallback')).toBe('fallback');
  });
});
