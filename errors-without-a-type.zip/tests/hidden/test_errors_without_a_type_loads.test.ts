// Build check: the modules the change touches still load under vitest with their public names.
import { describe, expect, it, vi } from 'vitest';

vi.mock('@/lib/supabaseClient', () => ({
  supabase: { auth: { getSession: async () => ({ data: { session: null } }), signOut: async () => {} } },
}));

describe('the touched modules load', () => {
  it('the http client module loads with its public names', async () => {
    const mod = await import('@/services/api/httpClient');
    expect(typeof mod.HttpClient).toBe('function');
    expect(mod.httpClient).toBeInstanceOf(mod.HttpClient);
    expect(mod.default).toBe(mod.HttpClient);
  });

  it('a client can be built with a base URL and a timeout', async () => {
    const { HttpClient } = await import('@/services/api/httpClient');
    const client = new HttpClient('http://api.local', 1000);
    for (const verb of ['get', 'post', 'patch', 'put', 'delete']) {
      expect(typeof (client as any)[verb]).toBe('function');
    }
  });

  it('the error helper module loads', async () => {
    const mod = await import('@/utils/errorHandler');
    expect(typeof mod.extractErrorMessage).toBe('function');
    expect(typeof mod.getDefaultErrorMessage).toBe('function');
  });

  it('the shared types module loads', async () => {
    const mod = await import('@/types/common');
    expect(mod).toBeTruthy();
  });

  it('the api configuration still names the base URL and timeout', async () => {
    const { API_CONFIG } = await import('@/config/constants');
    expect(typeof API_CONFIG.BASE_URL).toBe('string');
    expect(API_CONFIG.TIMEOUT).toBeGreaterThan(0);
  });
});
