// Hidden fail-to-pass tests: the backend HTTP client's errors are typed on every request.
// Every test here fails on the unchanged base.
import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('@/lib/supabaseClient', () => ({
  supabase: {
    auth: {
      getSession: async () => ({ data: { session: { access_token: 'hidden-token' } } }),
      signOut: async () => {},
    },
  },
}));

type Verb = 'get' | 'post' | 'patch' | 'put' | 'delete';
type FetchInit = RequestInit & { signal?: AbortSignal };

const VERBS: Verb[] = ['get', 'post', 'patch', 'put', 'delete'];
const WRITE_VERBS: Verb[] = ['post', 'patch', 'put', 'delete'];

const win: { location: { origin: string; pathname: string; href: string } } = {
  location: { origin: 'http://app.local', pathname: '/dashboard', href: '' },
};
const storage: Record<string, unknown> = {
  theme: 'dark',
  removeItem(key: string) {
    delete storage[key];
  },
};

let lastInit: FetchInit | null = null;

function stubFetch(impl: (url: string, init: FetchInit) => Promise<Response>) {
  vi.stubGlobal(
    'fetch',
    vi.fn(async (url: string, init: FetchInit) => {
      lastInit = init;
      return impl(url, init);
    })
  );
}

function abortError(): Error {
  if (typeof DOMException === 'function') {
    return new DOMException('This operation was aborted', 'AbortError');
  }
  return Object.assign(new Error('This operation was aborted'), { name: 'AbortError' });
}

/** A fetch that never answers on its own and rejects like the real one once its signal aborts. */
function hungFetch() {
  return (_url: string, init: FetchInit) =>
    new Promise<Response>((_resolve, reject) => {
      const signal = init.signal;
      if (!signal) return;
      if (signal.aborted) {
        reject(abortError());
        return;
      }
      signal.addEventListener('abort', () => reject(abortError()));
    });
}

function textResponse(status: number, body: string, contentType = 'text/plain') {
  return new Response(body, { status, headers: { 'content-type': contentType } });
}

function jsonResponse(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' },
  });
}

interface Caught {
  threw: boolean;
  error: unknown;
  code: unknown;
  message: unknown;
}

async function caught(promise: Promise<unknown>): Promise<Caught> {
  try {
    await promise;
    return { threw: false, error: undefined, code: undefined, message: undefined };
  } catch (error) {
    const e = error as { code?: unknown; message?: unknown };
    return { threw: true, error, code: e?.code, message: e?.message };
  }
}

async function makeClient(timeout = 60) {
  const mod = await import('@/services/api/httpClient');
  return new mod.HttpClient('http://api.local', timeout);
}

function send(client: any, verb: Verb, path: string, options?: Record<string, unknown>) {
  if (verb === 'get' || verb === 'delete') return client[verb](path, options);
  return client[verb](path, { name: 'Fluffy' }, options);
}

/** The words of a failure message once the status prefix is taken off. */
function wordsAfterStatus(message: unknown, status: number): string {
  const text = String(message ?? '');
  return text.replace(new RegExp(`HTTP\\s*${status}\\s*:?`, 'i'), '').trim();
}

beforeEach(() => {
  vi.stubGlobal('window', win);
  vi.stubGlobal('localStorage', storage);
  win.location.href = '';
  lastInit = null;
});

describe('a connection failure is typed on every request', () => {
  it.each(WRITE_VERBS)('%s with the backend down throws CONNECTION_ERROR', async (verb) => {
    const client = await makeClient();
    stubFetch(async () => {
      throw new TypeError('Failed to fetch');
    });
    const result = await caught(send(client, verb, '/api/pets'));
    expect(result.threw).toBe(true);
    expect(result.code).toBe('CONNECTION_ERROR');
  });

  it.each(VERBS)('%s types the Safari wording Load failed', async (verb) => {
    const client = await makeClient();
    stubFetch(async () => {
      throw new TypeError('Load failed');
    });
    const result = await caught(send(client, verb, '/api/pets'));
    expect(result.code).toBe('CONNECTION_ERROR');
  });

  it('get types a network failure worded without the word fetch', async () => {
    const client = await makeClient();
    stubFetch(async () => {
      throw new TypeError('network connection was lost');
    });
    const result = await caught(client.get('/api/pets'));
    expect(result.code).toBe('CONNECTION_ERROR');
  });

  it('post types the Node wording fetch failed', async () => {
    const client = await makeClient();
    stubFetch(async () => {
      throw new TypeError('fetch failed');
    });
    const result = await caught(client.post('/api/pets', { name: 'Rex' }));
    expect(result.code).toBe('CONNECTION_ERROR');
  });

  it('delete types the Firefox wording', async () => {
    const client = await makeClient();
    stubFetch(async () => {
      throw new TypeError('NetworkError when attempting to fetch resource.');
    });
    const result = await caught(client.delete('/api/pets/1'));
    expect(result.code).toBe('CONNECTION_ERROR');
  });

  it('put with the backend down does not leak the raw TypeError', async () => {
    const client = await makeClient();
    stubFetch(async () => {
      throw new TypeError('Failed to fetch');
    });
    const result = await caught(client.put('/api/pets/1', { name: 'Rex' }));
    expect(result.error instanceof TypeError).toBe(false);
  });
});

describe('a caller signal works together with the timeout', () => {
  it.each(VERBS)(
    '%s cancelled by the caller is not reported as a timeout',
    async (verb) => {
      const client = await makeClient(5000);
      stubFetch(hungFetch());
      const controller = new AbortController();
      const pending = caught(send(client, verb, '/api/pets', { signal: controller.signal }));
      setTimeout(() => controller.abort(), 5);
      const result = await pending;
      expect(result.threw).toBe(true);
      expect(result.code).not.toBe('TIMEOUT');
      expect(result.message).not.toBe('Request timeout');
    },
    1500
  );

  it.each(VERBS)(
    '%s still times out when the caller passes a signal',
    async (verb) => {
      const client = await makeClient(5000);
      stubFetch(hungFetch());
      const controller = new AbortController();
      const result = await caught(
        send(client, verb, '/api/pets', { signal: controller.signal, timeout: 40 })
      );
      expect(result.threw).toBe(true);
      expect(result.code).toBe('TIMEOUT');
    },
    1500
  );

  it(
    'get with a caller signal uses the default timeout when none is given',
    async () => {
      const client = await makeClient(40);
      stubFetch(hungFetch());
      const controller = new AbortController();
      const result = await caught(client.get('/api/pets', { signal: controller.signal }));
      expect(result.code).toBe('TIMEOUT');
      expect(result.message).toBe('Request timeout');
    },
    1500
  );

  it.each(['get', 'post'] as Verb[])(
    '%s whose body outlives the timeout is a TIMEOUT error, not a success',
    async (verb) => {
      const client = await makeClient(40);
      // headers arrive at once, the body never finishes; a real fetch errors the body stream on abort
      stubFetch(async (_url, init) => {
        let streamController: ReadableStreamDefaultController | undefined;
        const body = new ReadableStream({
          start(controller) {
            streamController = controller;
          },
        });
        init.signal?.addEventListener('abort', () => {
          try {
            streamController?.error(abortError());
          } catch {
            // already closed
          }
        });
        return new Response(body, { status: 200, headers: { 'content-type': 'application/json' } });
      });
      const result = await caught(send(client, verb, '/api/pets'));
      expect(result.threw).toBe(true);
      expect(result.code).toBe('TIMEOUT');
    },
    1500
  );

  it(
    'a signal already aborted before the call rejects without a timeout label',
    async () => {
      const client = await makeClient(5000);
      stubFetch(hungFetch());
      const controller = new AbortController();
      controller.abort();
      const result = await caught(client.get('/api/pets', { signal: controller.signal }));
      expect(result.threw).toBe(true);
      expect(result.code).not.toBe('TIMEOUT');
    },
    1500
  );
});

describe('a failed response says what failed', () => {
  it.each(VERBS)('%s on a 500 with a text body and no status text', async (verb) => {
    const client = await makeClient();
    stubFetch(async () => textResponse(500, 'database is down'));
    const result = await caught(send(client, verb, '/api/pets'));
    expect(result.code).toBe('HTTP_500');
    expect(String(result.message)).toMatch(/500/);
    expect(wordsAfterStatus(result.message, 500).length).toBeGreaterThan(0);
  });

  it.each(['get', 'post'] as Verb[])(
    '%s on a 404 whose JSON body has no message',
    async (verb) => {
      const client = await makeClient();
      stubFetch(async () => jsonResponse(404, { statusCode: 404, path: '/api/pets/9' }));
      const result = await caught(send(client, verb, '/api/pets/9'));
      expect(result.code).toBe('HTTP_404');
      expect(String(result.message)).toMatch(/404/);
      expect(wordsAfterStatus(result.message, 404).length).toBeGreaterThan(0);
    }
  );

  it('patch on a 502 html page from a proxy', async () => {
    const client = await makeClient();
    stubFetch(async () => textResponse(502, '<html><body>Bad Gateway</body></html>', 'text/html'));
    const result = await caught(client.patch('/api/pets/1', { name: 'Rex' }));
    expect(result.code).toBe('HTTP_502');
    expect(wordsAfterStatus(result.message, 502).length).toBeGreaterThan(0);
  });

  it('put on a 503 whose JSON body only carries a status number', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(503, { status: 503 }));
    const result = await caught(client.put('/api/pets/1', { name: 'Rex' }));
    expect(result.code).toBe('HTTP_503');
    expect(wordsAfterStatus(result.message, 503).length).toBeGreaterThan(0);
  });

  it('delete on a 500 with an empty body', async () => {
    const client = await makeClient();
    stubFetch(async () => new Response(null, { status: 500 }));
    const result = await caught(client.delete('/api/pets/1'));
    expect(result.code).toBe('HTTP_500');
    expect(wordsAfterStatus(result.message, 500).length).toBeGreaterThan(0);
  });

  it('get on a 500 whose JSON message is an empty array', async () => {
    const client = await makeClient();
    stubFetch(async () => jsonResponse(500, { message: [] }));
    const result = await caught(client.get('/api/pets'));
    expect(result.code).toBe('HTTP_500');
    expect(wordsAfterStatus(result.message, 500).length).toBeGreaterThan(0);
  });

  it('the failure message is never just the status and a colon', async () => {
    const client = await makeClient();
    stubFetch(async () => textResponse(500, ''));
    const result = await caught(client.get('/api/pets'));
    expect(String(result.message).trim()).not.toMatch(/^HTTP\s*500\s*:?$/i);
  });
});
