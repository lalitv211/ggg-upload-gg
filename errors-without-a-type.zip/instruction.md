Backend client errors come without type in most cases. Create a client while backend is down, toast says TypeError: Failed to fetch. Update and delete say the same. Only GET gives connection error with its code, users service even checks ERR_CONNECTION_REFUSED by hand since then. On Safari it is worse, there even GET shows Load failed, as browser words it differently.

Own signal is broken too. When caller passes own signal and cancels, Request timeout comes back instead. And when signal is given, timeout doesn't work at all, request can hang forever.

Production runs on HTTP/2 and there is no status text. Toast says HTTP 500: and nothing after colon. Json error without message does the same.

Each request should throw typed error, whatever the browser calls the failure. Caller's signal should work together with timeout, and cancel is not timeout. Message of failed response should always carry status and reason. When backend sends its own message, it shows as it is, like now. Codes stay as they are, TIMEOUT, CONNECTION_ERROR and HTTP_ with status. Login redirect on 401 stays, json parsing stays the same. Please keep readme of services/api in line. Please add tests for all of it.
