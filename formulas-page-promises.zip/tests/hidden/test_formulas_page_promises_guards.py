"""What already holds, and must go on holding once the formulas page is kept.

Numbers that read keep reading and keep their spelling, values shown in a cell keep fifteen digits,
ranges given to functions still work and ranges where one value belongs are still #VALUE!, ROW and
COLUMN with nothing in the brackets are still about the cell asking, plain sheet names stay bare,
a rectangle across two sheets is still refused, and the exit codes stay what they are.
Standard library only: unittest, one method per case.
"""

import io
import os
import re
import signal
import unittest

from trestle import Desk
from trestle.book import Book
from trestle.cli.main import main
from trestle.errors import FormulaError
from trestle.formula import parse, rendered_cell
from trestle.recalc import recalculate
from trestle.refs import read_span
from trestle.sheet import Sheet, filled_across, removed_rows
from trestle.values import number, span

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BOOK = """trestle-book 1
name Promises
sheet Main
  A1 1
  A2 2
  A3 3
  B1 10
  B2 20
  C1 x
sheet Other
  A1 100
  A5 5
  C1 7
  D9 9
"""


def _stop(signum, frame):
    raise AssertionError("took too long")


class _Guarded(unittest.TestCase):
    """A test that hangs fails rather than waits."""

    def setUp(self):
        signal.signal(signal.SIGALRM, _stop)
        signal.alarm(60)

    def tearDown(self):
        signal.alarm(0)


def run(*argv):
    """The command line, run in this process, with what it printed."""
    stream = io.StringIO()
    code = main(list(argv), stream)
    return code, stream.getvalue().rstrip("\n")


def desk_with(formula, where="Z1", sheet="Main"):
    """The book above with one more formula typed into it, worked out."""
    desk = Desk.of_text(BOOK)
    desk.put(where, formula, sheet)
    desk.recalculate()
    return desk


def slug(text):
    """A method name suffix made of a formula: letters, digits and underscores only."""
    spelled = {
        "$": " held ", "+": " plus ", "-": " minus ", "(": " open ", ")": " close ", ":": " to ",
        "!": " bang ", "%": " pct ", "*": " times ", "/": " over ", "^": " pow ", "=": " eq ",
        "<": " lt ", ">": " gt ", "&": " amp ", '"': " q ", "'": " qq ", ".": " dot ",
    }
    held = "".join(spelled.get(letter, letter) for letter in text)
    held = re.sub(r"[^A-Za-z0-9]+", "_", held).strip("_")
    return held or "formula"


def each(cls, prefix, cases, body):
    """Give a class one test method per case, named after the case."""
    seen = set()
    for case in cases:
        key = case if isinstance(case, str) else case[0]
        name = "%s_%s" % (prefix, slug(key))
        assert name not in seen, name
        seen.add(name)

        def method(self, case=case):
            body(self, case)

        method.__name__ = name
        setattr(cls, name, method)


NUMBERS_THAT_READ = [
    ("=1e3", "1000"),
    ("=1E3", "1000"),
    ("=1e+3", "1000"),
    ("=1e-3", "0.001"),
    ("=.5", "0.5"),
    ("=5.", "5"),
    ("=1.5e-3", "0.0015"),
    ("=1e21", "1e+21"),
    ("=2.675", "2.675"),
    ("=1/3", "0.333333333333333"),
    ("=0.1+0.2", "0.3"),
    ("=2^0.5", "1.4142135623731"),
    ("=100000000000000000000", "1e+20"),
]

SPELLINGS_THAT_STAY = [
    ("=1e3", "=1000"),
    ("=1.5e-3", "=0.0015"),
    ("=1e21", "=1e+21"),
    ("=0.5", "=0.5"),
    ("=2.675", "=2.675"),
    ("=-1", "=-1"),
    ("=50%", "=50%"),
    ("=Costs!A1", "=Costs!A1"),
    ("=Sheet1!A1:B2", "=Sheet1!A1:B2"),
    ("=a_b!A1", "=a_b!A1"),
    ("=SUM(A1:B2)*2", "=SUM(A1:B2)*2"),
    ("=\"say \"\"so\"\"\"", "=\"say \"\"so\"\"\""),
]

SHORT_NUMBERS_ROUND_TRIP = [
    "=1e-7",
    "=0.1000000000000000055511151231257827",
    "=2.675",
    "=0.1",
    "=1e21",
    "=123456789012345",
    "=A1*0.3",
]

RANGES_TO_FUNCTIONS = [
    ("=SUM(A1:A3)", "6"),
    ("=INDEX(A1:A3,2)", "2"),
    ("=ROWS(A1:B2)", "2"),
    ("=COLUMNS(Other!A1:C1)", "3"),
    ("=COUNT(A1:B2)", "4"),
    ("=MAX(Other!A1:D9)", "100"),
    ("=ROWS(A1)", "1"),
    ("=ROWS(A1:B3)", "3"),
    ("=COLUMNS(A1:B3)", "2"),
    ("=IF(A1=1,SUM(A1:A3),0)", "6"),
]

NOT_REFERENCES = [
    "=ROW(1)",
    "=ROW(\"A1\")",
    "=ROW(A1+0)",
    "=ROW(TRUE)",
    "=ROW(2.5)",
    "=COLUMN(SUM(A1:A2))",
    "=COLUMN(\"B\")",
    "=COLUMN(A1&\"\")",
]

ONE_VALUE_WANTED = [
    "=A1:A3+1",
    "=IF(A1:A3,1,2)",
    "=-A1:A3",
    "=A1:A3%",
    "=A1:A3&\"x\"",
    "=A1:A3=1",
    "=ABS(A1:A3)",
]

REFUSED_AS_WRITTEN = [
    "=Main!A1:Other!B2",
    "=A1:'Old Costs'!B2",
    "=0.5e2.5",
    "=1/",
    "=(",
    "=\"unterminated",
    "=A1:",
    "=1 2",
]


class NumbersTest(_Guarded):
    """Numbers that read keep reading, and a value shown keeps fifteen digits."""

    def test_a_third_is_shown_with_fifteen_digits(self):
        self.assertEqual(number(1 / 3).written(), "0.333333333333333")

    def test_a_tenth_and_two_tenths_show_as_three_tenths(self):
        self.assertEqual(number(0.1 + 0.2).written(), "0.3")

    def test_a_span_does_not_fit_in_a_cell(self):
        self.assertFalse(span("A1:B2").fits_in_a_cell)

    def test_a_number_fits_in_a_cell(self):
        self.assertTrue(number(1).fits_in_a_cell)


def _reads(self, case):
    formula, said = case
    self.assertEqual(desk_with(formula).value_at("Z1", "Main").written(), said)


def _spelling(self, case):
    formula, said = case
    self.assertEqual(rendered_cell(parse(formula)), said)


def _round_trip(self, formula):
    self.assertEqual(parse(rendered_cell(parse(formula))), parse(formula))


each(NumbersTest, "test_a_number_still_reads", NUMBERS_THAT_READ, _reads)
each(NumbersTest, "test_a_spelling_stays", SPELLINGS_THAT_STAY, _spelling)
each(NumbersTest, "test_a_short_number_still_reads_back", SHORT_NUMBERS_ROUND_TRIP, _round_trip)


class RangesTest(_Guarded):
    """Ranges given to functions work; ranges where one value belongs are #VALUE!."""

    def test_the_cell_asking_knows_its_row(self):
        self.assertEqual(desk_with("=ROW()", "C7").value_at("C7", "Main").written(), "7")

    def test_the_cell_asking_knows_its_column(self):
        self.assertEqual(desk_with("=COLUMN()", "C7").value_at("C7", "Main").written(), "3")

    def test_a_filled_reference_still_moves(self):
        sheet = Sheet("S", {"A1": "1", "A2": "2", "B1": "=A1*2"})
        filled_across(sheet, "B1", "B1:B2")
        self.assertEqual(recalculate(sheet).value_at("B2").written(), "4")

    def test_renaming_to_a_plain_name_writes_it_bare(self):
        book = Book("Names")
        book.add(Sheet("Main", {"B1": "=Costs!A1*2"}))
        book.add(Sheet("Costs", {"A1": "5"}))
        book.rename("Costs", "Spend")
        self.assertEqual(book.sheet_named("Main").text_at("B1"), "=Spend!A1*2")

    def test_a_rectangle_with_its_sheet_in_front_reads(self):
        self.assertEqual(read_span("Costs!A1:B2").sheet, "Costs")

    def test_removing_the_row_a_reference_names_is_a_reference_error(self):
        sheet = removed_rows(Sheet("S", {"B5": "=ROW(A1)"}), 1, 1)
        self.assertEqual(recalculate(sheet).value_at("B4").written(), "#REF!")

    def test_an_unreadable_formula_is_a_broken_cell(self):
        self.assertTrue(desk_with("=1/").sheet("Main").cell_at("Z1").is_broken)


def _works(self, case):
    formula, said = case
    self.assertEqual(desk_with(formula).value_at("Z1", "Main").written(), said)


def _value_error(self, formula):
    self.assertEqual(desk_with(formula).value_at("Z1", "Main").written(), "#VALUE!")


def _refused(self, formula):
    with self.assertRaises(FormulaError):
        parse(formula)


each(RangesTest, "test_a_range_given_to_a_function_works", RANGES_TO_FUNCTIONS, _works)
each(RangesTest, "test_a_range_where_one_value_belongs", ONE_VALUE_WANTED, _value_error)
each(RangesTest, "test_not_a_reference_is_a_value_error", NOT_REFERENCES, _value_error)
each(RangesTest, "test_a_formula_that_cannot_be_read_is_refused", REFUSED_AS_WRITTEN, _refused)


class CommandLineTest(_Guarded):
    """The exit codes stay what the page says."""

    def test_eval_of_a_formula_that_will_not_read_exits_two(self):
        self.assertEqual(run("eval", "=1/")[0], 2)

    def test_eval_of_an_error_exits_three(self):
        self.assertEqual(run("eval", "=1/0"), (3, "#DIV/0!"))

    def test_eval_of_a_sum_exits_nought(self):
        self.assertEqual(run("eval", "=1+1"), (0, "2"))

    def test_the_budget_works_out_cleanly(self):
        self.assertEqual(run("calc", os.path.join(ROOT, "examples", "budget.book"))[0], 0)

    def test_the_broken_book_exits_three(self):
        self.assertEqual(run("calc", os.path.join(ROOT, "examples", "broken.book"))[0], 3)

    def test_the_broken_book_has_something_to_review(self):
        self.assertEqual(run("review", os.path.join(ROOT, "examples", "broken.book"))[0], 1)

    def test_the_budget_left_sheet_is_what_the_readme_shows(self):
        self.assertEqual(run("value", os.path.join(ROOT, "examples", "budget.book"), "Left!B3"), (0, "1090"))


if __name__ == "__main__":
    unittest.main()
