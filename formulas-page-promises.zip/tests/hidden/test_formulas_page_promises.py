"""What the formulas page promises and the engine did not keep.

Four promises from docs/formulas.md and docs/functions.md: a formula that cannot be read is
refused rather than crashing; one cell holds one value, so a formula that comes to a range is
#VALUE! wherever a cell is shown; ROW and COLUMN give the row and column of the reference they are
given; a formula written back out reads to the same tree, whatever number or sheet name is in it.

Every assertion compares against the same thing written the plain way, a tree parsed from the
original text, or a value the page states. No message, spelling or internal is pinned.
Standard library only: unittest, one method per case, so that every case has an id of its own.
"""

import io
import os
import re
import signal
import tempfile
import unittest

from trestle import Desk
from trestle.book import Book
from trestle.cli.main import main
from trestle.errors import FormulaError
from trestle.formula import parse, references_in, rendered_cell
from trestle.recalc import recalculate, recalculated_after
from trestle.sheet import Sheet, filled_across, inserted_rows
from trestle.store import read_book
from trestle.values import number

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BOOK = """trestle-book 1
name Promises
sheet Main
  A1 1
  A2 2
  A3 3
  B1 10
  B2 20
  C1 x
sheet Other
  A1 100
  A5 5
  C1 7
  D9 9
"""


def _stop(signum, frame):
    raise AssertionError("took too long")


class _Guarded(unittest.TestCase):
    """A test that hangs fails rather than waits."""

    def setUp(self):
        signal.signal(signal.SIGALRM, _stop)
        signal.alarm(60)

    def tearDown(self):
        signal.alarm(0)


def run(*argv):
    """The command line, run in this process, with what it printed."""
    stream = io.StringIO()
    code = main(list(argv), stream)
    return code, stream.getvalue().rstrip("\n")


def written(text, name="promises.book"):
    """A file holding some text, in a directory of its own."""
    path = os.path.join(tempfile.mkdtemp(), name)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return path


def desk_with(formula, where="Z1", sheet="Main"):
    """The book above with one more formula typed into it, worked out."""
    desk = Desk.of_text(BOOK)
    desk.put(where, formula, sheet)
    desk.recalculate()
    return desk


def slug(text):
    """A method name suffix made of a formula: letters, digits and underscores only."""
    spelled = {
        "$": " held ", "+": " plus ", "-": " minus ", "(": " open ", ")": " close ", ":": " to ",
        "!": " bang ", "%": " pct ", "*": " times ", "/": " over ", "^": " pow ", "=": " eq ",
        "<": " lt ", ">": " gt ", "&": " amp ", '"': " q ", "'": " qq ", ".": " dot ",
    }
    held = "".join(spelled.get(letter, letter) for letter in text)
    held = re.sub(r"[^A-Za-z0-9]+", "_", held).strip("_")
    return held or "formula"


def each(cls, prefix, cases, body):
    """Give a class one test method per case, named after the case."""
    seen = set()
    for case in cases:
        key = case if isinstance(case, str) else case[0]
        name = "%s_%s" % (prefix, slug(key))
        assert name not in seen, name
        seen.add(name)

        def method(self, case=case):
            body(self, case)

        method.__name__ = name
        setattr(cls, name, method)


# ---------------------------------------------------------------------------------------------
# R1. A formula that cannot be read is refused, never a crash.

NOT_NUMBERS = [
    "=1e3.5",
    "=.1e1e3",
    "=1e3e4",
    "=11e2.5",
    "=1E3.5",
    "=1e+3.5",
    "=1e3.5+1",
    "=SUM(1e3.5)",
    "=A1*1e3.5",
]


class ReadingTest(_Guarded):
    """Text that is not a number is a formula that cannot be read."""

    def test_a_cell_typed_with_such_a_formula_is_unreadable_and_the_rest_works_out(self):
        desk = desk_with("=1e3.5")
        self.assertTrue(desk.sheet("Main").cell_at("Z1").is_broken)
        self.assertEqual(desk.value_at("B1", "Main").written(), "10")

    def test_a_book_file_holding_such_a_formula_still_opens(self):
        book = read_book(BOOK + "  Z1 =1e3.5\n", "promises.book")
        self.assertTrue(book.sheet_named("Other").cell_at("Z1").is_broken)

    def test_a_table_holding_such_a_formula_still_reads(self):
        desk = Desk.of_table("=1e3.5,2\n")
        desk.recalculate()
        self.assertEqual(desk.value_at("B1").written(), "2")

    def test_the_review_warns_that_it_is_unreadable(self):
        path = written(BOOK + "  Z1 =1e3.5\n")
        code, text = run("review", path, "--only", "unreadable")
        self.assertEqual(code, 1)
        self.assertIn("Z1", text)

    def test_eval_says_so_and_exits_two(self):
        code, text = run("eval", "=1e3.5")
        self.assertEqual(code, 2)
        self.assertTrue(text.startswith("trestle:"), text)

    def test_calc_of_a_book_holding_it_exits_three(self):
        path = written(BOOK + "  Z1 =1e3.5\n")
        code, _ = run("calc", path)
        self.assertEqual(code, 3)


def _refused(self, formula):
    with self.assertRaises(FormulaError):
        parse(formula)


each(ReadingTest, "test_text_that_is_not_a_number_is_refused", NOT_NUMBERS, _refused)


# ---------------------------------------------------------------------------------------------
# R2. One cell holds one value.

RANGE_ANSWERS = [
    "=A1:A3",
    "=Other!A1:A5",
    "=A1:B2",
    "=(A1:A3)",
    "=CHOOSE(1,A1:A3)",
    "=CHOOSE(2,0,A1:A3)",
    "=IF(TRUE,A1:A3,0)",
    "=IF(FALSE,0,A1:A3)",
    "=IF(A1=1,Other!A1:C1,0)",
    "=IFERROR(A1:A3,0)",
    "=IFBLANK(A1:A3,0)",
    "=SWITCH(1,1,A1:A3)",
    "=SWITCH(2,1,0,A1:A3)",
]


class OneValueTest(_Guarded):
    """A formula that comes to a range comes to #VALUE! in its cell."""

    def test_the_sheet_engine_stores_an_error_value(self):
        sheet = Sheet("S", {"A1": "1", "A2": "2", "B1": "=A1:A2"})
        held = recalculate(sheet)
        self.assertEqual(held.value_at("B1").written(), "#VALUE!")

    def test_the_sheet_engine_stores_an_error_value_through_a_function(self):
        sheet = Sheet("S", {"A1": "1", "A2": "2", "B1": "=CHOOSE(1,A1:A2)"})
        held = recalculate(sheet)
        self.assertEqual(held.value_at("B1").written(), "#VALUE!")

    def test_working_out_only_what_changed_stores_an_error_value(self):
        sheet = Sheet("S", {"A1": "1", "A2": "2", "B1": "=A1+1"})
        recalculate(sheet)
        sheet.put("B1", "=A1:A2")
        held = recalculated_after(sheet, ["B1"])
        self.assertEqual(held.value_at("B1").written(), "#VALUE!")

    def test_the_grid_draws_the_error(self):
        desk = desk_with("=A1:A3", "C2")
        drawn = "\n".join(desk.grid("Main"))
        self.assertIn("#VALUE!", drawn)
        self.assertNotIn("Value(", drawn)

    def test_the_value_command_prints_the_error_and_exits_three(self):
        path = written(BOOK + "  C2 =A1:A3\n")
        self.assertEqual(run("value", path, "Other!C2"), (3, "#VALUE!"))

    def test_the_table_holds_the_error(self):
        desk = desk_with("=A1:A3", "C2")
        table = desk.as_table("Main")
        self.assertIn("#VALUE!", table)
        self.assertNotIn("Value(", table)

    def test_the_cells_report_shows_the_error(self):
        path = written(BOOK + "  C2 =A1:A3\n")
        code, text = run("cells", path, "--sheet", "Other")
        self.assertIn("#VALUE!", text)
        self.assertNotIn("Value(", text)

    def test_calc_counts_it_as_an_error_and_exits_three(self):
        path = written(BOOK + "  C2 =A1:A3\n")
        code, text = run("calc", path)
        self.assertEqual(code, 3)
        self.assertIn("Other!C2", text)

    def test_the_trace_lists_it_among_the_errors(self):
        desk = desk_with("=A1:A3", "C2")
        held = [step.at.written() for step in desk.trace().errors()]
        self.assertIn("Main!C2", held)

    def test_the_review_warns_about_it_as_an_error(self):
        path = written(BOOK + "  C2 =A1:A3\n")
        code, text = run("review", path, "--only", "errors")
        self.assertEqual(code, 1)
        self.assertIn("C2", text)

    def test_eval_with_a_book_prints_the_error_and_exits_three(self):
        path = written(BOOK)
        self.assertEqual(run("eval", "=A1:A3", "--book", path), (3, "#VALUE!"))

    def test_eval_through_a_function_prints_the_error_and_exits_three(self):
        path = written(BOOK)
        self.assertEqual(run("eval", "=CHOOSE(1,Other!A1:A5)", "--book", path), (3, "#VALUE!"))

    def test_eval_without_a_book_prints_the_error_and_exits_three(self):
        self.assertEqual(run("eval", "=A1:A3"), (3, "#VALUE!"))


def _one_value(self, formula):
    desk = desk_with(formula)
    self.assertEqual(desk.value_at("Z1", "Main").written(), "#VALUE!")


each(OneValueTest, "test_a_range_in_a_cell_is_a_value_error", RANGE_ANSWERS, _one_value)


# ---------------------------------------------------------------------------------------------
# R3. ROW and COLUMN of a reference.

ROWS_AND_COLUMNS = [
    ("=ROW(A1)", "1"),
    ("=ROW($A$2)", "2"),
    ("=ROW(A$2)", "2"),
    ("=ROW(Other!A5)", "5"),
    ("=ROW(Other!D9)", "9"),
    ("=ROW(Z99)", "99"),
    ("=ROW(C1)", "1"),
    ("=ROW(A3:B5)", "3"),
    ("=ROW(B5:A3)", "3"),
    ("=ROW(Other!C1:D9)", "1"),
    ("=ROW(A1)*10", "10"),
    ("=ROW(A1)+COLUMN(B1)", "3"),
    ("=IF(ROW(A2)=2,\"yes\",\"no\")", "yes"),
    ("=row(a1)", "1"),
    ("=COLUMN(B3)", "2"),
    ("=COLUMN($B3)", "2"),
    ("=COLUMN(Other!C1)", "3"),
    ("=COLUMN(AB1)", "28"),
    ("=COLUMN(Z99)", "26"),
    ("=COLUMN(C1)", "3"),
    ("=COLUMN(B3:C4)", "2"),
    ("=COLUMN(Other!C1:D9)", "3"),
    ("=COLUMN(D1:B1)", "2"),
]



class RowColumnTest(_Guarded):
    """ROW and COLUMN say where the reference they are given is."""

    def test_eval_without_a_book_knows_the_row_of_a_reference(self):
        self.assertEqual(run("eval", "=ROW(A1)"), (0, "1"))

    def test_eval_without_a_book_knows_the_column_of_a_reference(self):
        self.assertEqual(run("eval", "=COLUMN(AB1)"), (0, "28"))

    def test_a_sheet_on_its_own_knows_the_row(self):
        sheet = Sheet("S", {"B1": "=ROW(A7)"})
        self.assertEqual(recalculate(sheet).value_at("B1").written(), "7")

    def test_filling_down_moves_the_reference_and_the_answer_follows(self):
        sheet = Sheet("S", {"B1": "=ROW(A1)"})
        filled_across(sheet, "B1", "B1:B3")
        held = recalculate(sheet)
        self.assertEqual(
            [held.value_at("B%d" % row).written() for row in (1, 2, 3)], ["1", "2", "3"]
        )

    def test_inserting_a_row_above_moves_the_reference_and_the_answer_follows(self):
        sheet = inserted_rows(Sheet("S", {"B5": "=ROW(A1)"}), 1, 1)
        held = recalculate(sheet)
        self.assertEqual(held.value_at("B6").written(), "2")


def _row_or_column(self, case):
    formula, said = case
    desk = desk_with(formula)
    self.assertEqual(desk.value_at("Z1", "Main").written(), said)


each(RowColumnTest, "test_the_row_or_column_of_a_reference", ROWS_AND_COLUMNS, _row_or_column)


# ---------------------------------------------------------------------------------------------
# R4. A formula written back reads to the same tree.

LONG_NUMBERS = [
    "=123456789012345678",
    "=0.30000000000000004",
    "=1.0000000000000002",
    "=9007199254740993",
    "=1.0000000000000002e-7",
    "=1.2345678901234567e+25",
    "=-0.30000000000000004",
    "=A1*0.30000000000000004",
    "=SUM(A1:A3)+1.0000000000000002",
    "=ROUND(0.30000000000000004,2)",
]

SAME_ANSWER = [
    ("=0.30000000000000004=0.1+0.2", "TRUE"),
    ("=1.0000000000000002>1", "TRUE"),
    ("=0.30000000000000004-0.3>0", "TRUE"),
]

NAMES_NEEDING_QUOTES = [
    "Old Costs",
    "2024",
    "1st",
    "a-b",
    "a+b",
    "a b c",
    "(x)",
    "x!y",
    "x:y",
    "été",
    "Sheet 1",
]

HALF_NAMED = [
    "=A1:S!B2",
    "=SUM(A1:Costs!B2)",
    "=$A$1:Other!B2",
    "=Other!A1:B2+A1:Other!B2",
]


def _book_with(name, main):
    """A book with a Main sheet and one more sheet called whatever is asked."""
    book = Book("Names")
    book.add(Sheet("Main", main))
    book.add(Sheet(name, {"A1": "5", "A2": "7"}))
    return book


class WrittenBackTest(_Guarded):
    """What is written out reads back to the same tree and the same answer."""

    def test_a_filled_formula_keeps_every_digit_of_its_number(self):
        sheet = Sheet("S", {"A1": "0", "A2": "0", "B1": "=A1+0.1+0.2=A1+0.30000000000000004"})
        filled_across(sheet, "B1", "B1:B2")
        held = recalculate(sheet)
        self.assertEqual(held.value_at("B2").written(), "TRUE")

    def test_an_inserted_row_keeps_every_digit_of_a_number(self):
        sheet = inserted_rows(Sheet("S", {"B2": "=A1*0.30000000000000004"}), 1, 1)
        self.assertEqual(parse(sheet.text_at("B3")), parse("=A2*0.30000000000000004"))

    def test_a_filled_formula_naming_a_quoted_sheet_still_reads(self):
        book = _book_with("Old Costs", {"B1": "='Old Costs'!A1*2"})
        filled_across(book.sheet_named("Main"), "B1", "B1:B2")
        book.recalculate()
        self.assertEqual(book.value_at("Main!B2").written(), "14")

    def test_an_inserted_row_keeps_a_quoted_sheet_name_readable(self):
        sheet = inserted_rows(Sheet("Main", {"B3": "='Old Costs'!A1*2"}), 1, 1)
        named = [one.sheet for one in references_in(parse(sheet.text_at("B4")))]
        self.assertEqual(named, ["Old Costs"])

    def test_an_inserted_row_keeps_a_quoted_sheet_name_working(self):
        book = Book("Names")
        book.add(inserted_rows(Sheet("Main", {"B3": "='Old Costs'!A1*2"}), 1, 1))
        book.add(Sheet("Old Costs", {"A1": "5", "A2": "5"}))
        book.recalculate()
        self.assertEqual(book.value_at("Main!B4").written(), "10")

    def test_a_cell_typed_with_a_sheet_on_one_corner_is_unreadable(self):
        desk = desk_with("=A1:Other!B2")
        self.assertTrue(desk.sheet("Main").cell_at("Z1").is_broken)


def _same_tree(self, formula):
    self.assertEqual(parse(rendered_cell(parse(formula))), parse(formula))


def _same_answer(self, case):
    formula, said = case
    path = written(BOOK)
    self.assertEqual(run("eval", formula, "--book", path), (0, said))
    self.assertEqual(run("eval", rendered_cell(parse(formula)), "--book", path), (0, said))


def _quoted_name_reads_back(self, name):
    for formula in ("='%s'!A1" % name, "='%s'!A1:B2" % name, "=SUM('%s'!A1:B2)*2" % name):
        self.assertEqual(parse(rendered_cell(parse(formula))), parse(formula), formula)


def _renamed_to_it_still_reads(self, name):
    book = Book("Names")
    book.add(Sheet("Main", {"B1": "=Costs!A1*2", "B2": "=SUM(Costs!A1:A2)"}))
    book.add(Sheet("Costs", {"A1": "5", "A2": "7"}))
    book.rename("Costs", name)
    main = book.sheet_named("Main")
    self.assertEqual(parse(main.text_at("B1")), parse("='%s'!A1*2" % name))
    self.assertEqual(parse(main.text_at("B2")), parse("=SUM('%s'!A1:A2)" % name))
    book.recalculate()
    self.assertEqual(book.value_at("Main!B1").written(), "10")
    self.assertEqual(book.value_at("Main!B2").written(), "12")


def _half_named_is_refused(self, formula):
    with self.assertRaises(FormulaError):
        parse(formula)


each(WrittenBackTest, "test_a_long_number_reads_back_to_the_same_tree", LONG_NUMBERS, _same_tree)
each(WrittenBackTest, "test_a_long_number_comes_to_the_same_after_writing", SAME_ANSWER, _same_answer)
each(
    WrittenBackTest,
    "test_a_sheet_name_that_needs_quotes_reads_back",
    NAMES_NEEDING_QUOTES,
    _quoted_name_reads_back,
)
each(
    WrittenBackTest,
    "test_renaming_a_sheet_to_a_name_that_needs_quotes_keeps_formulas_readable",
    NAMES_NEEDING_QUOTES,
    _renamed_to_it_still_reads,
)
each(WrittenBackTest, "test_a_sheet_on_one_corner_is_refused", HALF_NAMED, _half_named_is_refused)


# ---------------------------------------------------------------------------------------------
# R5. The changelog.


class ChangelogTest(unittest.TestCase):
    """The change is recorded."""

    def test_the_changelog_gains_an_entry(self):
        with open(os.path.join(ROOT, "CHANGELOG.md"), encoding="utf-8") as handle:
            bullets = [line for line in handle if line.startswith("- ")]
        self.assertGreater(len(bullets), 37)


if __name__ == "__main__":
    unittest.main()
