Formulas page says a formula written out and read again gives the same tree. It doesn't hold. Rename Costs to Old Costs and each formula that named it turns into text that won't read. Same thing after fill or insert on a sheet with 'Old Costs'!A1 in it. Please make write back keep to the page, whatever is in the formula, exactly. Name that would not read bare gets quotes, plain name stays bare.

Few more promises from the same page are broken. Page says what raises is a formula that cannot be read at all. Type =1e3.5 into a cell and you get Python traceback. Book file with such cell can't be opened at all, eval also crashes. It should be refused like =1/ is, cell is unreadable, review warns about it, calc exits with three.

One cell holds one value, page says so. Put =A1:A3 in a cell and show prints Python tuple, value exits with zero, calc sees no error. Same when function hands the range back, CHOOSE for one. It should be #VALUE! in the cell everywhere a cell is shown. Eval command prints #VALUE! as well.

ROW(A1) is #VALUE!, COLUMN(B3) too. Functions page promises row of a reference. Rectangle gives its first row and first column, sheet name in front is fine. Not a reference stays #VALUE!. With nothing in brackets it is about the cell asking, like now.

Rectangle takes its sheet in front. =A1:S!B2 is accepted now and written back unreadable. Please refuse it like rectangle across two sheets.

Please add tests for all of it and changelog entry. Version is up to you.
