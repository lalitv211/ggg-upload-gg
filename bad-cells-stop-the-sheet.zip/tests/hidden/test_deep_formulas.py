"""Hidden tests: a formula may nest two hundred deep, as docs/formulas.md says, and never crashes.

The depth is the depth of the tree, the way trestle already counts it: ``=-1`` nests twice (the
minus and the number), so a call wrapped 199 times around a cell nests two hundred deep and is
allowed, and 200 times is refused when it is read. At the base commit nested calls crashed with
RecursionError from about a hundred and brackets from about a hundred and fifty. Brackets are
not part of the tree, so how many of them may be written beyond that is the solution's call:
past two hundred the tests accept either an answer or a refusal, but never a crash.

Standard library only: one test method per case, so that every case keeps an id.
"""

import re
import subprocess
import sys
import unittest

from trestle import Desk
from trestle.book import Book
from trestle.formula import parse, rendered_cell
from trestle.recalc import recalculate
from trestle.report import review
from trestle.sheet import Sheet, filled_across, inserted_rows
from trestle.store import compared_books, read_book, write_book

ALLOWED = 199


def wrapped(kind, times):
    """A formula with one call or bracket wrapped ``times`` times around a cell."""
    if kind == "ABS":
        return "=" + "ABS(" * times + "B1" + ")" * times
    if kind == "SUM":
        return "=" + "SUM(" * times + "B1" + ")" * times
    if kind == "IF":
        return "=" + "IF(TRUE," * times + "B1" + ",0)" * times
    if kind == "MAX":
        return "=" + "MAX(0," * times + "B1" + ")" * times
    if kind == "brackets":
        return "=" + "(" * times + "B1" + ")" * times
    if kind == "mixed":
        return "=" + "ABS(-(" * (times // 2) + "B1" + "))" * (times // 2)
    raise AssertionError(kind)


KINDS = ["ABS", "SUM", "IF", "MAX", "brackets", "mixed"]
CALLS = ["ABS", "SUM", "IF", "MAX"]


def each(cls, prefix, cases, body):
    """One test method per case, named after it, so that every case keeps an id."""
    for index, case in enumerate(cases, start=1):
        slug = re.sub(r"[^0-9a-zA-Z]+", "_", str(case)).strip("_").lower()[:50]
        name = "test_%s_%02d_%s" % (prefix, index, slug)

        def method(self, case=case):
            body(self, case)

        method.__name__ = name
        setattr(cls, name, method)


def worked_out(formula):
    sheet = Sheet("S", {"B1": 7, "A1": formula, "C1": "=2+2"})
    recalculate(sheet)
    return sheet


def cell(sheet, where):
    return sheet.cell_at(sheet.address_of(where))


class DeepFormulaTest(unittest.TestCase):
    """As deep as allowed works out; one call deeper is refused; brackets never crash."""


def _as_deep_as_allowed(self, kind):
    sheet = worked_out(wrapped(kind, ALLOWED))
    held = cell(sheet, "A1")
    self.assertTrue(held.is_formula, held.trouble)
    self.assertEqual(held.value.written(), "7")
    self.assertEqual(cell(sheet, "C1").value.written(), "4")


def _one_call_deeper(self, kind):
    sheet = worked_out(wrapped(kind, ALLOWED + 1))
    held = cell(sheet, "A1")
    self.assertTrue(held.trouble, "a formula nesting 201 deep was not refused")
    self.assertFalse(held.is_formula)
    self.assertEqual(cell(sheet, "C1").value.written(), "4")


def _brackets_far_past(self, times):
    sheet = worked_out(wrapped("brackets", times))
    held = cell(sheet, "A1")
    self.assertTrue(held.trouble or held.value.written() == "7")
    self.assertEqual(cell(sheet, "C1").value.written(), "4")


def _written_back(self, kind):
    tree = parse(wrapped(kind, ALLOWED))
    self.assertEqual(parse(rendered_cell(tree)), tree)


each(DeepFormulaTest, "as_deep_as_allowed_works_out", KINDS, _as_deep_as_allowed)
each(DeepFormulaTest, "one_call_deeper_is_refused", CALLS, _one_call_deeper)
each(DeepFormulaTest, "brackets_far_past_the_limit_never_crash", [250, 1000], _brackets_far_past)
each(DeepFormulaTest, "written_back_into_the_same_tree", ["ABS", "IF", "brackets"], _written_back)


class DeepFormulaEverywhereTest(unittest.TestCase):
    """A deep formula goes everywhere a formula goes."""

    def test_a_deep_formula_is_saved_and_read_back(self):
        book = Book("Deep")
        book.add(Sheet("S", {"B1": 7, "A1": wrapped("IF", ALLOWED)}))
        book.recalculate()

        again = read_book(write_book(book), "Deep")
        again.recalculate()

        self.assertEqual(again.value_at("S!A1").written(), "7")

    def test_a_deep_formula_is_filled_down(self):
        sheet = Sheet("S", {"B1": 7, "B2": 8, "B3": 9, "A1": wrapped("ABS", ALLOWED)})
        filled_across(sheet, "A1", "A1:A3")
        recalculate(sheet)

        self.assertEqual(
            [cell(sheet, "A%d" % row).value.written() for row in (1, 2, 3)], ["7", "8", "9"]
        )

    def test_a_deep_formula_moves_when_a_row_goes_in(self):
        after = inserted_rows(Sheet("S", {"B1": 7, "A1": wrapped("SUM", ALLOWED)}), 1, 1)
        recalculate(after)

        self.assertTrue(cell(after, "A2").is_formula)
        self.assertEqual(cell(after, "A2").value.written(), "7")

    def test_a_book_with_a_deep_formula_can_be_looked_over(self):
        book = Book("Deep")
        book.add(Sheet("S", {"B1": 7, "A1": wrapped("mixed", ALLOWED), "A2": wrapped("MAX", ALLOWED)}))
        book.recalculate()

        found = list(review(book))

        self.assertTrue(all(one.where for one in found))

    def test_a_desk_answers_a_deep_formula(self):
        desk = Desk.empty()
        desk.put("B1", 7)
        desk.put("A1", wrapped("brackets", ALLOWED))

        self.assertEqual(desk.value_at("A1").written(), "7")

    def test_nothing_touches_the_recursion_limit_while_a_deep_formula_is_read_or_worked_out(self):
        """The prompt asks for no change to the limit; not even a raise that is put back afterwards."""
        touched = []
        kept = sys.setrecursionlimit

        def refuse(limit):
            touched.append(limit)
            raise AssertionError("sys.setrecursionlimit(%r) was called" % (limit,))

        sys.setrecursionlimit = refuse
        try:
            desk = Desk.empty()
            desk.put("B1", 7)
            desk.put("A1", wrapped("IF", ALLOWED))
            desk.put("A2", wrapped("brackets", ALLOWED))
            parse(rendered_cell(parse(wrapped("ABS", ALLOWED))))
            self.assertEqual(desk.value_at("A1").written(), "7")
            self.assertEqual(desk.value_at("A2").written(), "7")
        finally:
            sys.setrecursionlimit = kept
        self.assertEqual(touched, [])

    def test_working_deep_formulas_out_leaves_the_recursion_limit_alone(self):
        """The prompt asks for no change to Python's recursion limit; a fresh interpreter tells."""
        script = (
            "import sys\n"
            "before = sys.getrecursionlimit()\n"
            "from trestle import Desk\n"
            "desk = Desk.empty()\n"
            "desk.put('B1', 7)\n"
            "desk.put('A1', '=' + 'ABS(' * 199 + 'B1' + ')' * 199)\n"
            "assert desk.value_at('A1').written() == '7'\n"
            "print(before, sys.getrecursionlimit())\n"
        )
        done = subprocess.run(
            [sys.executable, "-c", script], capture_output=True, text=True, timeout=60
        )

        self.assertEqual(done.returncode, 0, done.stderr[-600:])
        before, after = done.stdout.split()
        self.assertEqual(before, after)


def a_book_reading_deep():
    book = Book("Across")
    book.add(Sheet("Costs", {"B1": 7}))
    book.add(Sheet("Left", {"A1": "=" + "ABS(" * ALLOWED + "Costs!B1" + ")" * ALLOWED}))
    return book


class DeepFormulaAcrossABookTest(unittest.TestCase):
    """A deep formula across sheets: reading, renaming, comparing."""

    def test_a_deep_formula_reads_another_sheet(self):
        book = a_book_reading_deep()
        book.recalculate()

        self.assertEqual(book.value_at("Left!A1").written(), "7")

    def test_renaming_the_sheet_a_deep_formula_reads_keeps_it_a_formula(self):
        book = a_book_reading_deep()
        book.rename("Costs", "Spend")
        book.recalculate()
        left = book.sheet_named("Left")
        held = left.cell_at(left.address_of("A1"))

        self.assertTrue(held.is_formula)
        self.assertEqual(book.value_at("Left!A1").written(), "7")

    def test_two_books_with_deep_formulas_can_be_compared(self):
        before, after = a_book_reading_deep(), a_book_reading_deep()
        after.put("Costs!B1", 8)
        before.recalculate()
        after.recalculate()

        self.assertTrue(compared_books(before, after))




# ------------------------------------------------ no walk over a formula leans on the stack

LOW = 300


def with_limit(limit, fn):
    kept = sys.getrecursionlimit()
    sys.setrecursionlimit(limit)
    try:
        return fn()
    finally:
        sys.setrecursionlimit(kept)


class NoWalkLeansOnTheStackTest(unittest.TestCase):
    """With Python's limit at three hundred, two hundred deep still reads, works out, writes back, fills and saves."""


def _under_a_low_limit(self, kind):
    text = wrapped(kind, ALLOWED)

    def everything():
        tree = parse(text)
        self.assertEqual(parse(rendered_cell(tree)), tree)
        filled_across(Sheet("S", {"B1": 7, "B2": 8, "A1": text}), "A1", "A1:A2")
        after = inserted_rows(Sheet("S", {"B1": 7, "A1": text}), 1, 1)
        recalculate(after)
        self.assertEqual(cell(after, "A2").value.written(), "7")
        book = Book("Deep")
        book.add(Sheet("Costs", {"B1": 7}))
        book.add(Sheet("Left", {"A1": text.replace("B1", "Costs!B1")}))
        book.rename("Costs", "Spend")
        book.recalculate()
        self.assertEqual(book.value_at("Left!A1").written(), "7")
        again = read_book(write_book(book), "Deep")
        again.recalculate()
        self.assertEqual(again.value_at("Left!A1").written(), "7")
        self.assertTrue(all(one.where for one in review(book)))
        self.assertIsNotNone(compared_books(book, again))

    with_limit(LOW, everything)


each(NoWalkLeansOnTheStackTest, "two_hundred_deep_under_a_limit_of_three_hundred", KINDS, _under_a_low_limit)


if __name__ == "__main__":
    unittest.main()
