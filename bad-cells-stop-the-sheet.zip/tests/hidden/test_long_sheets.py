"""Hidden tests: a long chain of cells is an ordinary sheet.

The performance page's ``chain 4k`` is a column where each cell adds one to the cell above it,
and it is worked out in a fraction of a second. The same column read the other way round, each
cell adding one to the cell below it, crashed the recalculation with RecursionError at the base
commit from about a thousand rows, and so did a ring of as many cells, which the docs promise is
``#CYCLE!`` all the way round. The prompt: every formula comes out as a value or an error value
and the rest is worked out as always, however big the book, and nothing leans on the stack or
touches the recursion limit.
"""

import io
import os
import sys
import tempfile
import unittest

from trestle import Desk
from trestle.book import Book
from trestle.graph import cycles_in, links_of
from trestle.recalc import recalculate, recalculated_after
from trestle.sheet import Sheet

ROWS = 2000


def column_reading_the_row_below(rows=ROWS, below="A%d", sheet="S"):
    """``A1 =A2+1``, ``A2 =A3+1`` and so on, with a number in the last row."""
    cells = {"A%d" % rows: 1}
    for row in range(1, rows):
        cells["A%d" % row] = "=" + (below % (row + 1)) + "+1"
    return Sheet(sheet, cells)


def ring(rows=ROWS):
    """``A1 =A2000``, ``A2 =A1``, ``A3 =A2`` and so on round to ``A2000 =A1999``."""
    cells = {"A1": "=A%d" % rows}
    for row in range(2, rows + 1):
        cells["A%d" % row] = "=A%d" % (row - 1)
    return Sheet("S", cells)


def value(sheet, where):
    return sheet.value_at(sheet.address_of(where)).written()


class LongColumnTest(unittest.TestCase):
    """A column where every cell reads the cell below it, thousands of rows long."""

    def test_a_column_where_every_cell_reads_the_one_below_is_worked_out(self):
        sheet = column_reading_the_row_below()
        recalculate(sheet)

        self.assertEqual(value(sheet, "A1"), str(ROWS))

    def test_changing_the_bottom_cell_works_such_a_column_out_again(self):
        sheet = column_reading_the_row_below()
        recalculate(sheet)
        sheet.put("A%d" % ROWS, 11)
        recalculated_after(sheet, ["A%d" % ROWS])

        self.assertEqual(value(sheet, "A1"), str(ROWS + 10))

    def test_the_performance_pages_chain_read_the_other_way_round_is_ordinary(self):
        desk = Desk.empty()
        for where, cell in column_reading_the_row_below(4000).cells():
            desk.put(where.without_sheet().written(), cell.text)

        self.assertEqual(desk.value_at("A1").written(), "4000")

    def test_a_chain_that_crosses_between_two_sheets_is_worked_out(self):
        rows = 900
        book = Book("Across")
        book.add(Sheet("L", {"A%d" % row: "=R!A%d+1" % row for row in range(1, rows + 1)}))
        right = {"A%d" % row: "=L!A%d+1" % (row + 1) for row in range(1, rows)}
        right["A%d" % rows] = 1
        book.add(Sheet("R", right))
        book.recalculate()

        self.assertEqual(book.value_at("L!A1").written(), str(2 * rows))

    def test_a_book_with_such_a_column_can_be_looked_over(self):
        from trestle.report import review

        book = Book("Long")
        book.add(column_reading_the_row_below())
        book.recalculate()

        self.assertEqual([one for one in review(book) if one.check == "cycles"], [])
        self.assertEqual(book.value_at("S!A1").written(), str(ROWS))

    def test_the_command_line_works_such_a_book_out(self):
        from trestle.cli.main import main
        from trestle.store import write_book

        book = Book("Long")
        book.add(column_reading_the_row_below())
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "long.book")
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(write_book(book))
            out = io.StringIO()

            self.assertEqual(main(["calc", path], out), 0)
            self.assertEqual(main(["value", path, "S!A1"], out), 0)
        self.assertIn(str(ROWS), out.getvalue())

    def test_nothing_touches_the_recursion_limit_while_a_long_column_is_worked_out(self):
        kept = sys.setrecursionlimit

        def refuse(limit):
            raise AssertionError("sys.setrecursionlimit(%r) was called" % (limit,))

        sys.setrecursionlimit = refuse
        try:
            sheet = column_reading_the_row_below()
            recalculate(sheet)
            self.assertEqual(value(sheet, "A1"), str(ROWS))
        finally:
            sys.setrecursionlimit = kept


class LongRingTest(unittest.TestCase):
    """A ring of cells that read each other round is #CYCLE! all the way round."""

    def test_a_ring_of_two_thousand_cells_is_a_cycle_all_the_way_round(self):
        sheet = ring()
        recalculate(sheet)

        self.assertEqual(
            {value(sheet, "A%d" % row) for row in range(1, ROWS + 1)}, {"#CYCLE!"}
        )

    def test_a_cell_reading_a_long_ring_reads_the_cycle_error(self):
        sheet = ring()
        sheet.put("B1", "=A1+1")
        sheet.put("B2", "=2+2")
        recalculate(sheet)

        self.assertEqual(value(sheet, "B1"), "#CYCLE!")
        self.assertEqual(value(sheet, "B2"), "4")

    def test_the_cells_of_a_long_ring_are_one_group(self):
        groups = cycles_in(links_of(ring()))

        self.assertEqual(len(groups), 1)
        self.assertEqual(len(groups[0]), ROWS)

    def test_a_ring_across_two_sheets_is_a_cycle(self):
        rows = 900
        book = Book("Ring")
        book.add(Sheet("L", {"A%d" % row: "=R!A%d" % row for row in range(1, rows + 1)}))
        right = {"A%d" % row: "=L!A%d" % (row + 1) for row in range(1, rows)}
        right["A%d" % rows] = "=L!A1"
        book.add(Sheet("R", right))
        book.recalculate()

        self.assertEqual(book.value_at("L!A1").written(), "#CYCLE!")
        self.assertEqual(book.value_at("R!A%d" % rows).written(), "#CYCLE!")

    def test_looking_over_a_long_ring_finds_every_cell_of_it(self):
        from trestle.report import review

        book = Book("Ring")
        book.add(ring())
        book.recalculate()

        self.assertEqual(len([one for one in review(book) if one.check == "cycles"]), ROWS)


if __name__ == "__main__":
    unittest.main()
