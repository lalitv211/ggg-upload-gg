"""Hidden tests: a number in a cell is never NaN or Infinity, and a cell takes the numbers a formula takes.

At the base commit typing ``nan``, ``inf`` or ``1e999`` stored NaN or Infinity, the comma
separated reader did the same, text saying so was read as that number in arithmetic and in
VALUE, and a handful of operations overflowed into Infinity where ``2^2000`` and ``EXP(1000)``
already gave ``#NUM!``. Rounding to absurd places raised. And the cell reader took whatever
Python's ``float`` takes, ``1_000`` and digits from other scripts among them, which the formula
language refuses. The prompt fixes each answer below.

Standard library only: one test method per case, so that every case keeps an id.
"""

import math
import re
import unittest

from trestle import Desk
from trestle.recalc import recalculate
from trestle.sheet import Sheet
from trestle.store import read_book, read_table, write_table

NOT_NUMBERS = ["nan", "NaN", "inf", "-inf", "Infinity", "INF", "1e999", "-1e999"]

#: Words Python's float reads that the formula language does not (=1_000 is refused).
NOT_FORMULA_NUMBERS = ["1_000", "1_0.5", "١٢", "２３", "٣e2", "1_000e1"]

TEXT_USED_AS_NUMBER = [
    '="nan"+1',
    '="inf"*2',
    '="1e999"+0',
    '=-"Infinity"',
    "=A1+1",
    "=A2*1",
    '=VALUE("nan")',
    '=VALUE("inf")',
    '=VALUE("1e999")',
    '=VALUE("-Infinity")',
]

TOO_BIG_RESULTS = [
    "=1E308*10",
    "=-1E308*10",
    "=1E308+1E308",
    "=1/1E-320",
    "=PRODUCT(1E200,1E200)",
    "=A3*10",
    "=-A3*-10",
    "=(1E308*10)-(1E308*10)",
]

ROUNDING_FAR = [
    ("=ROUND(1.5,400)", 1.5),
    ("=ROUND(-2.5,400)", -2.5),
    ("=ROUND(1.5,1E9)", 1.5),
    ("=ROUNDUP(1.25,400)", 1.25),
    ("=ROUNDDOWN(1.25,400)", 1.25),
    ("=ROUND(123,-400)", 0.0),
    ("=ROUNDDOWN(987,-400)", 0.0),
    ("=ROUNDDOWN(-987,-400)", 0.0),
    ("=ROUNDUP(0,-400)", 0.0),
]

WORDS_USED_AS_NUMBER = ['="1_000"+1', '=VALUE("1_000")', '=VALUE("١٢")', '="٣"*2', "=A1*1"]


def each(cls, prefix, cases, body):
    """One test method per case, named after it, so that every case keeps an id."""
    for index, case in enumerate(cases, start=1):
        label = case[0] if isinstance(case, tuple) else case
        slug = re.sub(r"[^0-9a-zA-Z]+", "_", str(label)).strip("_").lower()[:50]
        name = "test_%s_%02d_%s" % (prefix, index, slug)

        def method(self, case=case):
            body(self, case)

        method.__name__ = name
        setattr(cls, name, method)


def worked_out(cells):
    sheet = Sheet("S", cells)
    recalculate(sheet)
    return sheet


def value(sheet, where):
    return sheet.value_at(sheet.address_of(where))


def typed(text):
    sheet = Sheet("S", {"A1": text})
    return sheet.cell_at(sheet.address_of("A1")).value


def _typed_stays_text(self, word):
    held = typed(word)
    self.assertTrue(held.is_text, "%r became %s %s" % (word, held.kind, held.written()))
    self.assertEqual(held.written(), word)


# ------------------------------------------------------------- typed, read, imported


class TypedWordsTest(unittest.TestCase):
    """A word that float would read as NaN or Infinity stays text, typed or read."""

    def test_comma_separated_text_keeps_those_words_text(self):
        sheet = read_table("nan,inf,1e999,12\n", "S")
        kinds = [cell.value.kind for _, cell in sheet.cells()]

        self.assertEqual(kinds[:3], ["text"] * 3)
        self.assertEqual(kinds[3], "number")

    def test_a_book_file_keeps_those_words_text(self):
        book = read_book("trestle-book 1\nname b\nsheet S\n  A1 inf\n  A2 nan\n  A3 7\n")
        sheet = book.sheet_named("S")

        self.assertTrue(sheet.cell_at(sheet.address_of("A1")).value.is_text)
        self.assertTrue(sheet.cell_at(sheet.address_of("A2")).value.is_text)
        self.assertTrue(sheet.cell_at(sheet.address_of("A3")).value.is_number)

    def test_those_words_go_out_and_come_back_as_text(self):
        sheet = Sheet("S", {"A1": "inf", "B1": "nan", "C1": 4})
        again = read_table(write_table(sheet), "S")

        self.assertEqual([cell.value.kind for _, cell in again.cells()], ["text", "text", "number"])
        desk = Desk.of_table("1e999,2\n")
        self.assertTrue(desk.value_at("A1").is_text)
        self.assertEqual(desk.value_at("B1").written(), "2")


each(TypedWordsTest, "typing_keeps_text", NOT_NUMBERS, _typed_stays_text)


# --------------------------------------------------------------- text used as a number


class TextUsedAsNumberTest(unittest.TestCase):
    """Text saying nan, infinity or a number too big is #VALUE! when used as a number."""


def _text_used_as_number(self, formula):
    sheet = worked_out({"A1": "nan", "A2": "1e999", "B1": formula})
    self.assertEqual(value(sheet, "B1").written(), "#VALUE!")


each(TextUsedAsNumberTest, "used_as_number_is_value", TEXT_USED_AS_NUMBER, _text_used_as_number)


# --------------------------------------------------------- results too big for a float


class TooBigResultTest(unittest.TestCase):
    """A result too big for a float is #NUM!, and no cell holds NaN or Infinity."""

    def test_a_number_written_too_big_into_a_formula_is_not_infinity(self):
        sheet = worked_out({"B1": "=1E400", "B2": "=1E400-1"})

        for where in ("B1", "B2"):
            held = sheet.cell_at(sheet.address_of(where))
            self.assertTrue(
                held.trouble or held.value.is_error, "%s came to %s" % (where, held.value.written())
            )

    def test_no_cell_of_a_sheet_of_odd_numbers_holds_nan_or_infinity(self):
        cells = {"A%d" % row: word for row, word in enumerate(NOT_NUMBERS, start=1)}
        cells.update(
            {
                "B1": "=1E308*10",
                "B2": "=PRODUCT(1E200,1E200)",
                "B3": '=VALUE("inf")',
                "B4": "=A1+A3",
                "B5": "=MAX(1E308,1E308*10)",
                "B6": "=1E400",
                "B7": "=1/1E-320",
            }
        )
        sheet = worked_out(cells)

        self.assertTrue(
            all(math.isfinite(cell.value.held) for _, cell in sheet.cells() if cell.value.is_number)
        )


def _too_big_result(self, formula):
    sheet = worked_out({"A3": "1e308", "B1": formula})
    self.assertEqual(value(sheet, "B1").written(), "#NUM!")


each(TooBigResultTest, "too_big_is_num", TOO_BIG_RESULTS, _too_big_result)


# ----------------------------------------------------------------------- rounding far


class RoundingFarTest(unittest.TestCase):
    """Rounding to far more places or tens than a number has."""


def _rounding_far(self, case):
    formula, wanted = case
    sheet = worked_out({"B1": formula})
    held = value(sheet, "B1")
    self.assertTrue(held.is_number, "%s came to %s" % (formula, held.written()))
    self.assertEqual(held.held, wanted)


each(RoundingFarTest, "rounding_far", ROUNDING_FAR, _rounding_far)


# ------------------------------------------ a cell takes the numbers a formula takes


class FormulaNumbersTest(unittest.TestCase):
    """The prompt: a number in a cell is what a formula calls a number; a formula refuses these."""

    def test_comma_separated_text_keeps_such_words_text(self):
        kinds = [cell.value.kind for _, cell in read_table("1_000,١٢,12\n", "S").cells()]

        self.assertEqual(kinds, ["text", "text", "number"])

    def test_a_book_file_keeps_such_a_word_text(self):
        book = read_book("trestle-book 1\nname b\nsheet S\n  A1 1_000\n  A2 12\n")
        sheet = book.sheet_named("S")

        self.assertTrue(sheet.cell_at(sheet.address_of("A1")).value.is_text)
        self.assertTrue(sheet.cell_at(sheet.address_of("A2")).value.is_number)


each(FormulaNumbersTest, "only_float_reads_it_stays_text", NOT_FORMULA_NUMBERS, _typed_stays_text)


def _word_used_as_number(self, formula):
    sheet = worked_out({"A1": "1_000", "B1": formula})
    self.assertEqual(value(sheet, "B1").written(), "#VALUE!")


each(FormulaNumbersTest, "such_a_word_used_as_number_is_value", WORDS_USED_AS_NUMBER, _word_used_as_number)


if __name__ == "__main__":
    unittest.main()
