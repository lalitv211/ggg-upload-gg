"""Hidden tests: a function whose true answer a float holds gives it.

The prompt: too big for a float is #NUM!, but only what is truly too big. A function
whose answer a float holds gives it, however far the working strayed on the way.
Operators stay plain floats, so =1E308+1E308-1E308 is #NUM! while SUM of the same is
1E308.

The working can stray either way: squaring the distance of two numbers near 1E-200
from their mean leaves nought in a float, although their spread is an ordinary number.

At the base commit every formula below either raised OverflowError out of the
recalculation, left Infinity in the cell, or came to nought where a small number belonged. The cells H1:H2 hold 1e308 twice and J1:J3
hold 1e308, 1e308 and -1e308.

Standard library only: one test method per case, so that every case keeps an id.
"""

import math
import re
import unittest

from trestle.recalc import recalculate
from trestle.sheet import Sheet

#: Formulas with an exact answer a float holds, although the working runs past one.
EXACT = [
    ("=SUM(1E308,1E308,-1E308)", "1e+308"),
    ("=SUM(J1:J3)", "1e+308"),
    ("=SUM(J1:J3,1)", "1e+308"),
    ('=SUMIF(J1:J3,"<>0")', "1e+308"),
    ("=AVERAGE(1E308,1E308)", "1e+308"),
    ("=AVERAGE(H1:H2)", "1e+308"),
    ("=AVERAGE(1E308,1E308,1E308)", "1e+308"),
    ('=AVERAGEIF(H1:H2,">0")', "1e+308"),
    ("=MEDIAN(H1:H2)", "1e+308"),
    ("=MEDIAN(1E308,1E308,1E308,1E308)", "1e+308"),
    ("=STDEV(1E308,1E308)", "0"),
    ("=VAR(1E308,1E308)", "0"),
    ("=STDEV(1E308,1E308,1E308)", "0"),
    ("=CEILING(5,1E-320)", "5"),
    ("=FLOOR(5,1E-320)", "5"),
    ("=FLOOR(-5,1E-320)", "-5"),
    ("=PRODUCT(1E200,1E200,1E-200)", "1e+200"),
    ("=PRODUCT(H1:H2,1E-308)", "1e+308"),
    ("=PRODUCT(1E-200,1E-200,1E200,1E200)", "1"),
    ("=PRODUCT(1E-300,1E-300,1E300,1E300)", "1"),
    ("=ROUND(1E308,2)", "1e+308"),
    ("=ROUNDUP(1E308,2)", "1e+308"),
    ("=ROUNDDOWN(1E308,2)", "1e+308"),
]

#: Formulas whose answer a float holds, to within a float's own rounding.
NEAR = [
    ("=STDEV(1E308,-1E308)", math.sqrt(2) * 1e308),
    ("=STDEV(J1:J3)", math.sqrt(4 / 3) * 1e308),
    ("=STDEV(1E-200,3E-200)", math.sqrt(2) * 1e-200),
    ("=STDEV(1E-170,3E-170,5E-170)", 2e-170),
]

#: Formulas whose true answer no float holds, which are #NUM! and not Infinity.
TRULY_TOO_BIG = [
    "=1E308+1E308-1E308",
    "=SUM(H1:H2)",
    '=SUMIF(J1:J3,">0")',
    "=VAR(1E308,-1E308)",
    "=PRODUCT(1E200,1E200)",
]


def each(cls, prefix, cases, body):
    """One test method per case, named after it, so that every case keeps an id."""
    for index, case in enumerate(cases, start=1):
        formula = case[0] if isinstance(case, tuple) else case
        slug = re.sub(r"[^0-9a-zA-Z]+", "_", formula).strip("_").lower()[:50]
        name = "test_%s_%02d_%s" % (prefix, index, slug)

        def method(self, case=case):
            body(self, case)

        method.__name__ = name
        setattr(cls, name, method)


def worked_out(formula):
    sheet = Sheet(
        "S",
        {
            "H1": "1e308",
            "H2": "1e308",
            "J1": "1e308",
            "J2": "1e308",
            "J3": "-1e308",
            "A1": formula,
            "C1": "=2+2",
        },
    )
    recalculate(sheet)
    return sheet


def value(sheet, where):
    return sheet.value_at(sheet.address_of(where))


class _Beside(unittest.TestCase):
    def assert_the_rest_was_worked_out(self, sheet):
        self.assertEqual(value(sheet, "C1").written(), "4")


class ExactAnswerTest(_Beside):
    """The working runs past a float; the answer does not, and is given exactly."""


def _exact(self, case):
    formula, want = case
    sheet = worked_out(formula)
    self.assertEqual(value(sheet, "A1").written(), want)
    self.assert_the_rest_was_worked_out(sheet)


each(ExactAnswerTest, "exact", EXACT, _exact)


class NearAnswerTest(_Beside):
    """An answer with a root in it, to within a float's rounding."""


def _near(self, case):
    formula, want = case
    sheet = worked_out(formula)
    held = value(sheet, "A1")
    self.assertTrue(held.is_number, held.written())
    self.assertTrue(math.isclose(held.held, want, rel_tol=1e-12), (held.held, want))
    self.assert_the_rest_was_worked_out(sheet)


each(NearAnswerTest, "near", NEAR, _near)


class TrulyTooBigTest(_Beside):
    """An answer no float holds is #NUM!, never Infinity, and stops nothing."""


def _truly_too_big(self, formula):
    sheet = worked_out(formula)
    self.assertEqual(value(sheet, "A1").written(), "#NUM!")
    self.assert_the_rest_was_worked_out(sheet)


each(TrulyTooBigTest, "truly_too_big", TRULY_TOO_BIG, _truly_too_big)


if __name__ == "__main__":
    unittest.main()
