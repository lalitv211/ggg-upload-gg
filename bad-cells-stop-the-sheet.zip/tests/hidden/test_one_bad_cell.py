"""Hidden tests: one bad cell never stops a sheet or a book.

Every formula below raised a Python exception out of the recalculation at the base commit, so
nothing after it was worked out. The prompt: every formula comes out as a value or an error
value, and the rest is worked out as always. Where the prompt fixes the answer (text that says
nan, infinity or a number too big is #VALUE!; a result too big for a float is #NUM!) the tests
check it; where it does not (the mean or the spread of two huge numbers, whose true answers a
float can hold), any finite number or any error value is accepted.

Standard library only: one test method per case, so that every case keeps an id.
"""

import io
import math
import os
import re
import tempfile
import unittest

from trestle import Desk
from trestle.book import Book
from trestle.recalc import recalculate
from trestle.sheet import Sheet

#: Formulas that read text saying nan, infinity or a number too big as a number.
TEXT_AS_NUMBER = [
    '=INT("1e999")',
    '=TRUNC("nan")',
    '=LEFT("abc","1e999")',
    '=MID("abc","inf",2)',
    '=INDEX(B1:B3,"nan")',
    '=GCD("1e999")',
    '=LARGE(B1:B3,"nan")',
    '=MATCH(1,B1:B3,"nan")',
    '=ROUND("nan")',
    '=REPT("x","inf")',
    '=MOD("1e999",3)',
]

#: Formulas whose result is too big for a float.
TOO_BIG = [
    "=SUM(1E308,1E308)",
    "=ROUNDUP(5,-400)",
]

#: Formulas whose true answer a float can hold, but whose working out overflowed.
HELD_BUT_OVERFLOWED = [
    "=AVERAGE(1E308,1E308)",
    "=STDEV(1E308,1E308)",
    "=VAR(1E308,1E308)",
]

#: Counts nobody means, which used to build the text or raise ten to the billion.
SILLY_COUNTS = ['=REPT("x",1E18)', '=REPT("x",1E308)', "=ROUND(1.5,1E9)"]


def each(cls, prefix, cases, body):
    """One test method per case, named after it, so that every case keeps an id."""
    for index, case in enumerate(cases, start=1):
        slug = re.sub(r"[^0-9a-zA-Z]+", "_", str(case)).strip("_").lower()[:50]
        name = "test_%s_%02d_%s" % (prefix, index, slug)

        def method(self, case=case):
            body(self, case)

        method.__name__ = name
        setattr(cls, name, method)


def sheet_with(formula):
    return Sheet("S", {"B1": 1, "B2": 2, "B3": 3, "A1": formula, "C1": "=2+2", "C2": "=SUM(B1:B3)"})


def worked_out(sheet):
    recalculate(sheet)
    return sheet


def value(sheet, where):
    return sheet.value_at(sheet.address_of(where))


class _Beside(unittest.TestCase):
    def assert_the_rest_was_worked_out(self, sheet):
        self.assertEqual(value(sheet, "C1").written(), "4")
        self.assertEqual(value(sheet, "C2").written(), "6")


class TextAsNumberTest(_Beside):
    """Text that is not a number, read as one, is #VALUE! and stops nothing."""


def _text_as_number(self, formula):
    sheet = worked_out(sheet_with(formula))
    self.assertEqual(value(sheet, "A1").written(), "#VALUE!")
    self.assert_the_rest_was_worked_out(sheet)


each(TextAsNumberTest, "text_as_number_is_value", TEXT_AS_NUMBER, _text_as_number)


class TooBigTest(_Beside):
    """A result too big for a float is #NUM! and stops nothing."""


def _too_big(self, formula):
    sheet = worked_out(sheet_with(formula))
    self.assertEqual(value(sheet, "A1").written(), "#NUM!")
    self.assert_the_rest_was_worked_out(sheet)


each(TooBigTest, "too_big_is_num", TOO_BIG, _too_big)


class OverflowOnTheWayTest(_Beside):
    """An overflow on the way comes out as a value and stops nothing."""


def _overflow_on_the_way(self, formula):
    sheet = worked_out(sheet_with(formula))
    held = value(sheet, "A1")
    if held.is_number:
        self.assertTrue(math.isfinite(held.held))
    else:
        self.assertTrue(held.is_error, held.written())
    self.assert_the_rest_was_worked_out(sheet)


each(OverflowOnTheWayTest, "overflow_on_the_way", HELD_BUT_OVERFLOWED, _overflow_on_the_way)


class SillyCountTest(_Beside):
    """REPT used to try to build the text and ROUND to raise ten to the billion."""


def _silly_count(self, formula):
    sheet = worked_out(sheet_with(formula))
    held = value(sheet, "A1")
    self.assertTrue(held.is_error or held.is_number, held.written()[:40])
    self.assert_the_rest_was_worked_out(sheet)


each(SillyCountTest, "silly_count", SILLY_COUNTS, _silly_count)


class WholeSheetTest(unittest.TestCase):
    """Many bad cells together still leave everything worked out."""

    def test_a_sheet_full_of_bad_cells_still_works_everything_out(self):
        cells = {"B1": 1, "B2": 2, "B3": 3, "Z1": "=2+2"}
        bad = TEXT_AS_NUMBER + TOO_BIG + HELD_BUT_OVERFLOWED
        for row, formula in enumerate(bad, start=1):
            cells["A%d" % row] = formula
        sheet = worked_out(Sheet("S", cells))

        self.assertEqual(value(sheet, "Z1").written(), "4")
        for row in range(1, len(bad) + 1):
            held = value(sheet, "A%d" % row)
            self.assertTrue(
                held.is_error or (held.is_number and math.isfinite(held.held)), (row, held.written())
            )

    def test_one_bad_cell_does_not_stop_the_other_sheets_of_a_book(self):
        book = Book("Two")
        book.add(Sheet("Bad", {"A1": "=ROUND(1.5,400)", "A2": '=INT("1e999")'}))
        book.add(Sheet("Good", {"A1": "=1+1", "A2": "=Bad!A1*2"}))

        book.recalculate()

        self.assertEqual(book.value_at("Good!A1").written(), "2")
        self.assertEqual(book.value_at("Good!A2").written(), "3")

    def test_a_desk_answers_next_to_a_bad_cell(self):
        desk = Desk.empty()
        desk.put("A1", "=SUM(1E308,1E308)")
        desk.put("A2", "=ROUNDDOWN(-987,-400)")
        desk.put("A3", "=10*3")

        self.assertEqual(desk.value_at("A3").written(), "30")
        self.assertEqual(desk.value_at("A1").written(), "#NUM!")


def a_book_with_bad_cells():
    book = Book("Bad")
    book.add(
        Sheet(
            "S",
            {
                "A1": "=ROUND(1.5,400)",
                "A2": '=INT("1e999")',
                "A3": "=SUM(1E308,1E308)",
                "A4": "=1+1",
                "A5": "=A3*2",
                "A6": '=IFERROR(INT("nan"),"caught")',
            },
        )
    )
    return book


class AroundABadCellTest(unittest.TestCase):
    """Everything else around a bad cell: errors travel, reports, the command line."""

    def test_an_error_from_a_bad_cell_travels_like_any_other_error(self):
        book = a_book_with_bad_cells()
        book.recalculate()

        self.assertEqual(book.value_at("S!A5").written(), "#NUM!")
        self.assertEqual(book.value_at("S!A6").written(), "caught")

    def test_a_book_with_bad_cells_can_be_looked_over_and_summed_up(self):
        from trestle.report import review
        from trestle.store import digest_of_values

        book = a_book_with_bad_cells()
        book.recalculate()
        errors = [one.where for one in review(book) if one.check == "errors"]

        self.assertIn("S!A3", errors)
        self.assertTrue(digest_of_values(book))
        self.assertIn("errors:", Desk(a_book_with_bad_cells()).summary())

    def test_the_command_line_works_a_book_with_a_bad_cell_out(self):
        """The command line says the book worked out with an error in it, which has its own code."""
        from trestle.cli.exits import TROUBLE
        from trestle.cli.main import main
        from trestle.store import write_book

        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, "bad.book")
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(write_book(a_book_with_bad_cells()))

            self.assertEqual(main(["calc", path], io.StringIO()), TROUBLE)
            self.assertIn(main(["value", path, "S!A4"], io.StringIO()), (0, TROUBLE))


if __name__ == "__main__":
    unittest.main()
