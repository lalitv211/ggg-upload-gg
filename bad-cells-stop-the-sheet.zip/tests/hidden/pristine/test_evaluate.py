"""Working out what a formula comes to."""

import unittest

from trestle.errors import FormulaError, ReferenceError_
from trestle.evaluate import Context, Plain, evaluate, evaluated_text, setting_for
from trestle.formula import parse
from trestle.refs import read_address, read_span
from trestle.values import (
    DIVIDED,
    MISSING,
    NAME,
    NUMBER,
    WRONG,
    blank,
    boolean,
    error,
    number,
    text,
)

CELLS = {"A1": 1, "A2": 2, "A3": 3, "B1": "x", "B2": True, "B3": None}


def worked(formula, cells=None, here="C1"):
    """One formula worked out against a few cells."""
    context = Plain(cells if cells is not None else CELLS, here=read_address(here))
    return evaluated_text(formula, context)


class ContextTest(unittest.TestCase):
    def test_an_empty_context_answers_blank(self):
        self.assertEqual(Context().value_at(read_address("A1")), blank())

    def test_a_plain_context_holds_what_it_was_given(self):
        held = Plain({"A1": 1})
        self.assertEqual(held.value_at(read_address("A1")), number(1))
        self.assertEqual(len(held), 1)

    def test_a_cell_nobody_filled_is_blank(self):
        self.assertEqual(Plain({"A1": 1}).value_at(read_address("Z9")), blank())

    def test_a_span_comes_back_row_by_row(self):
        held = Plain({"A1": 1, "B1": 2, "A2": 3, "B2": 4})
        rows = held.values_in(read_span("A1:B2"))
        self.assertEqual([one.written() for one in rows[0]], ["1", "2"])
        self.assertEqual([one.written() for one in rows[1]], ["3", "4"])

    def test_asking_about_something_that_is_not_an_address(self):
        with self.assertRaises(ReferenceError_):
            Plain().value_at("A1")

    def test_moving_a_context_to_another_cell(self):
        held = Plain({"A1": 1}).at(read_address("B2"))
        self.assertEqual(held.here, read_address("B2"))
        self.assertEqual(held.value_at(read_address("A1")), number(1))

    def test_what_a_function_is_told(self):
        held = Plain({}, here=read_address("C3"), sheet="Costs")
        setting = setting_for(held)
        self.assertEqual(setting.here, read_address("C3"))
        self.assertEqual(setting.sheet, "Costs")

    def test_which_sheets_it_knows(self):
        held = Plain({"Costs!A1": 1}, sheet="Main")
        self.assertTrue(held.knows_sheet("Main"))
        self.assertTrue(held.knows_sheet(""))
        self.assertTrue(held.knows_sheet("Costs"))
        self.assertFalse(held.knows_sheet("Nowhere"))


class LiteralTest(unittest.TestCase):
    def test_numbers_text_and_booleans(self):
        self.assertEqual(worked("=1"), number(1))
        self.assertEqual(worked('="a"'), text("a"))
        self.assertEqual(worked("=TRUE"), boolean(True))

    def test_an_error_written_out(self):
        self.assertEqual(worked("=#N/A"), error(MISSING))

    def test_a_reference(self):
        self.assertEqual(worked("=A1"), number(1))

    def test_a_reference_to_a_cell_nobody_filled(self):
        self.assertEqual(worked("=Z9"), blank())


class ArithmeticTest(unittest.TestCase):
    def test_the_four_operations(self):
        self.assertEqual(worked("=1+2"), number(3))
        self.assertEqual(worked("=5-2"), number(3))
        self.assertEqual(worked("=3*4"), number(12))
        self.assertEqual(worked("=12/4"), number(3))

    def test_dividing_by_nought(self):
        self.assertEqual(worked("=1/0"), error(DIVIDED))

    def test_raising_to_a_power(self):
        self.assertEqual(worked("=2^10"), number(1024))

    def test_a_power_that_cannot_be_worked_out(self):
        self.assertEqual(worked("=(-1)^0.5"), error(NUMBER))

    def test_a_minus_in_front(self):
        self.assertEqual(worked("=-A1"), number(-1))

    def test_a_percent_after(self):
        self.assertEqual(worked("=50%"), number(0.5))
        self.assertEqual(worked("=A2*50%"), number(1))

    def test_a_blank_counts_as_nought(self):
        self.assertEqual(worked("=B3+1"), number(1))

    def test_a_boolean_counts_as_one_or_nought(self):
        self.assertEqual(worked("=B2+1"), number(2))

    def test_text_that_is_not_a_number(self):
        self.assertEqual(worked("=B1+1"), error(WRONG))

    def test_an_error_spreads(self):
        self.assertEqual(worked("=#N/A+1"), error(MISSING))
        self.assertEqual(worked("=1+#DIV/0!"), error(DIVIDED))

    def test_the_order_the_operators_bind(self):
        self.assertEqual(worked("=1+2*3"), number(7))
        self.assertEqual(worked("=(1+2)*3"), number(9))
        self.assertEqual(worked("=-2^2"), number(4))


class TextOperatorTest(unittest.TestCase):
    def test_joining(self):
        self.assertEqual(worked('="a"&"b"'), text("ab"))

    def test_joining_a_number(self):
        self.assertEqual(worked('=A1&"x"'), text("1x"))

    def test_joining_a_blank(self):
        self.assertEqual(worked('=B3&"x"'), text("x"))

    def test_joining_an_error(self):
        self.assertEqual(worked('=#N/A&"x"'), error(MISSING))


class ComparisonTest(unittest.TestCase):
    def test_the_six_comparisons(self):
        self.assertEqual(worked("=1=1"), boolean(True))
        self.assertEqual(worked("=1<>1"), boolean(False))
        self.assertEqual(worked("=1<2"), boolean(True))
        self.assertEqual(worked("=1<=1"), boolean(True))
        self.assertEqual(worked("=2>1"), boolean(True))
        self.assertEqual(worked("=1>=2"), boolean(False))

    def test_comparing_text_ignores_the_case(self):
        self.assertEqual(worked('="a"="A"'), boolean(True))

    def test_a_number_is_below_text(self):
        self.assertEqual(worked('=9999<"a"'), boolean(True))

    def test_comparing_against_a_blank(self):
        self.assertEqual(worked("=B3=0"), boolean(True))

    def test_an_error_spreads(self):
        self.assertEqual(worked("=#REF!=1"), error("#REF!"))


class SpanTest(unittest.TestCase):
    def test_a_span_given_to_a_function(self):
        self.assertEqual(worked("=SUM(A1:A3)"), number(6))

    def test_a_span_where_one_value_belongs(self):
        self.assertEqual(worked("=A1:A3+1"), error(WRONG))

    def test_a_span_of_one_cell(self):
        self.assertEqual(worked("=SUM(A1:A1)"), number(1))

    def test_a_span_that_reaches_empty_cells(self):
        self.assertEqual(worked("=SUM(A1:A9)"), number(6))

    def test_counting_over_a_span(self):
        self.assertEqual(worked("=COUNT(A1:B3)"), number(3))
        self.assertEqual(worked("=COUNTA(A1:B3)"), number(5))


class CallTest(unittest.TestCase):
    def test_a_function_nobody_has(self):
        self.assertEqual(worked("=NOSUCH(1)"), error(NAME))

    def test_the_wrong_number_of_arguments(self):
        self.assertEqual(worked("=ABS(1,2)"), error(WRONG))

    def test_an_error_in_an_argument_spreads(self):
        self.assertEqual(worked("=ABS(#N/A)"), error(MISSING))

    def test_the_functions_that_are_asked_about_errors_are_given_them(self):
        self.assertEqual(worked("=ISERROR(#N/A)"), boolean(True))
        self.assertEqual(worked("=IFERROR(#N/A,0)"), number(0))

    def test_a_function_that_knows_where_it_is(self):
        self.assertEqual(worked("=ROW()", here="C7"), number(7))
        self.assertEqual(worked("=COLUMN()", here="C7"), number(3))

    def test_a_call_inside_a_call(self):
        self.assertEqual(worked("=SUM(ABS(-1),ABS(-2))"), number(3))

    def test_a_call_with_no_arguments(self):
        self.assertEqual(worked("=TRUE()"), boolean(True))


class OtherSheetTest(unittest.TestCase):
    def test_a_reference_to_another_sheet(self):
        held = Plain({"Costs!A1": 5}, sheet="Main")
        self.assertEqual(evaluated_text("=Costs!A1", held), number(5))

    def test_a_reference_with_no_sheet_means_this_one(self):
        held = Plain({"A1": 5}, sheet="Main")
        self.assertEqual(evaluated_text("=A1", held), number(5))

    def test_a_span_in_another_sheet(self):
        held = Plain({"Costs!A1": 1, "Costs!A2": 2}, sheet="Main")
        self.assertEqual(evaluated_text("=SUM(Costs!A1:A2)", held), number(3))


class BadTreeTest(unittest.TestCase):
    def test_something_that_is_not_a_tree(self):
        with self.assertRaises(FormulaError):
            evaluate("1+1")

    def test_a_formula_that_will_not_read(self):
        with self.assertRaises(FormulaError):
            evaluated_text("=1+")
