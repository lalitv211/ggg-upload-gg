"""Values: the kinds, the errors, coercion, comparison and formatting."""

import unittest

from trestle.errors import ValueError_
from trestle.values import (
    BLANK,
    CYCLE,
    DIVIDED,
    FAILURES,
    FALSE,
    Failure,
    IN_A_CELL,
    KINDS,
    MISSING,
    TRUE,
    Value,
    WRONG,
    blank,
    boolean,
    compared,
    equal,
    error,
    failure_named,
    failure_names,
    is_failure_name,
    is_kind,
    is_number_text,
    kind_note,
    kinds,
    matches,
    number,
    read_typed,
    sort_key,
    span,
    text,
    value_of,
    written,
    written_row,
)


class KindTest(unittest.TestCase):
    def test_there_are_six(self):
        self.assertEqual(len(kinds()), 6)
        self.assertEqual(len(KINDS), 6)

    def test_five_of_them_fit_in_a_cell(self):
        self.assertEqual(len(IN_A_CELL), 5)
        self.assertNotIn("span", IN_A_CELL)

    def test_every_kind_says_what_it_is(self):
        for name in kinds():
            with self.subTest(kind=name):
                self.assertGreater(len(kind_note(name)), 10)

    def test_a_kind_nobody_has(self):
        self.assertFalse(is_kind("date"))
        with self.assertRaises(ValueError_):
            kind_note("date")


class FailureTest(unittest.TestCase):
    def test_there_are_seven(self):
        self.assertEqual(len(FAILURES), 7)
        self.assertEqual(len(failure_names()), 7)

    def test_every_one_is_written_with_a_hash(self):
        for held in FAILURES:
            with self.subTest(failure=held.name):
                self.assertTrue(held.name.startswith("#"))

    def test_every_one_says_what_it_means(self):
        for held in FAILURES:
            with self.subTest(failure=held.name):
                self.assertGreater(len(held.note), 10)

    def test_looking_one_up(self):
        self.assertIs(failure_named("#n/a"), MISSING)

    def test_one_nobody_has(self):
        with self.assertRaises(ValueError_):
            failure_named("#NONSENSE!")

    def test_asking_whether_some_text_is_one(self):
        self.assertTrue(is_failure_name("#DIV/0!"))
        self.assertFalse(is_failure_name("DIV/0"))

    def test_one_that_is_not_written_with_a_hash(self):
        with self.assertRaises(ValueError_):
            Failure("OOPS", "no hash")

    def test_the_cycle_error_is_this_packages_own(self):
        self.assertEqual(CYCLE.name, "#CYCLE!")


class ValueTest(unittest.TestCase):
    def test_the_six_kinds(self):
        self.assertTrue(blank().is_blank)
        self.assertTrue(number(1).is_number)
        self.assertTrue(text("a").is_text)
        self.assertTrue(boolean(True).is_boolean)
        self.assertTrue(error(WRONG).is_error)
        self.assertTrue(span("A1:B2").is_span)

    def test_only_five_fit_in_a_cell(self):
        self.assertTrue(number(1).fits_in_a_cell)
        self.assertFalse(span("A1:B2").fits_in_a_cell)

    def test_a_kind_nobody_has(self):
        with self.assertRaises(ValueError_):
            Value("date", 1)

    def test_a_number_is_held_as_a_float(self):
        self.assertIsInstance(number(1).held, float)
        self.assertEqual(number(1), number(1.0))

    def test_two_values_the_same_are_equal(self):
        self.assertEqual(text("a"), text("a"))
        self.assertNotEqual(text("a"), text("b"))
        self.assertEqual(len({number(1), number(1)}), 1)

    def test_the_booleans_are_shared(self):
        self.assertIs(boolean(True), TRUE)
        self.assertIs(boolean(0), FALSE)

    def test_an_error_can_be_made_from_its_name(self):
        self.assertEqual(error("#DIV/0!"), error(DIVIDED))


class ReadingTest(unittest.TestCase):
    def test_a_blank_read_as_a_number_is_nought(self):
        self.assertEqual(blank().as_number(), number(0))

    def test_a_boolean_read_as_a_number(self):
        self.assertEqual(TRUE.as_number(), number(1))
        self.assertEqual(FALSE.as_number(), number(0))

    def test_text_that_looks_like_a_number(self):
        self.assertEqual(text(" 12.5 ").as_number(), number(12.5))

    def test_text_that_does_not(self):
        self.assertEqual(text("hello").as_number(), error(WRONG))

    def test_empty_text_read_as_a_number_is_nought(self):
        self.assertEqual(text("  ").as_number(), number(0))

    def test_an_error_stays_itself(self):
        held = error(MISSING)
        self.assertEqual(held.as_number(), held)
        self.assertEqual(held.as_text(), held)
        self.assertEqual(held.as_boolean(), held)

    def test_a_number_read_as_text(self):
        self.assertEqual(number(2.5).as_text(), text("2.5"))
        self.assertEqual(number(2).as_text(), text("2"))

    def test_a_blank_read_as_text_is_nothing(self):
        self.assertEqual(blank().as_text(), text(""))

    def test_a_boolean_read_as_text(self):
        self.assertEqual(TRUE.as_text(), text("TRUE"))

    def test_text_read_as_a_boolean(self):
        self.assertEqual(text("true").as_boolean(), TRUE)
        self.assertEqual(text("F").as_boolean(), FALSE)
        self.assertEqual(text("maybe").as_boolean(), error(WRONG))

    def test_a_number_read_as_a_boolean(self):
        self.assertEqual(number(0).as_boolean(), FALSE)
        self.assertEqual(number(-1).as_boolean(), TRUE)

    def test_a_number_or_something_else(self):
        self.assertEqual(text("x").number_or(9), 9)
        self.assertEqual(number(3).number_or(9), 3)

    def test_a_value_reads_as_true_or_false_in_python(self):
        self.assertTrue(bool(number(1)))
        self.assertFalse(bool(number(0)))


class WritingTest(unittest.TestCase):
    def test_a_whole_number_has_no_point(self):
        self.assertEqual(number(2).written(), "2")

    def test_a_number_that_does_not_divide(self):
        self.assertEqual(number(0.1 + 0.2).written(), "0.3")

    def test_a_very_large_number(self):
        self.assertEqual(number(1e20).written(), "1e+20")

    def test_a_number_that_is_not_a_number(self):
        self.assertEqual(number(float("nan")).written(), "NaN")
        self.assertEqual(number(float("inf")).written(), "Infinity")

    def test_a_blank_is_written_as_nothing(self):
        self.assertEqual(blank().written(), "")

    def test_an_error_is_written_as_its_name(self):
        self.assertEqual(error(DIVIDED).written(), "#DIV/0!")

    def test_padding(self):
        self.assertEqual(written(number(2.5), 8, right=True), "     2.5")
        self.assertEqual(written(text("ab"), 4), "ab  ")

    def test_padding_something_too_wide(self):
        self.assertEqual(written(text("abcdef"), 3), "abc")

    def test_a_row_of_values(self):
        self.assertEqual(written_row([number(1), text("a")], 4), "   1 a")


class FromPythonTest(unittest.TestCase):
    def test_the_obvious_readings(self):
        self.assertEqual(value_of(1), number(1))
        self.assertEqual(value_of(2.5), number(2.5))
        self.assertEqual(value_of("a"), text("a"))
        self.assertEqual(value_of(True), TRUE)
        self.assertEqual(value_of(None), BLANK)

    def test_a_value_comes_straight_back(self):
        held = number(1)
        self.assertIs(value_of(held), held)

    def test_text_written_like_an_error(self):
        self.assertEqual(value_of("#REF!"), error("#REF!"))

    def test_a_failure_itself(self):
        self.assertEqual(value_of(DIVIDED), error(DIVIDED))


class TypedTest(unittest.TestCase):
    def test_what_looks_like_a_number(self):
        self.assertEqual(read_typed("12"), number(12))
        self.assertEqual(read_typed(" -1.5 "), number(-1.5))

    def test_what_does_not(self):
        self.assertEqual(read_typed("12a"), text("12a"))

    def test_the_booleans(self):
        self.assertEqual(read_typed("true"), TRUE)
        self.assertEqual(read_typed("FALSE"), FALSE)

    def test_an_error(self):
        self.assertEqual(read_typed("#N/A"), error(MISSING))

    def test_nothing_at_all(self):
        self.assertEqual(read_typed(""), BLANK)
        self.assertEqual(read_typed(None), BLANK)

    def test_asking_whether_text_is_a_number(self):
        self.assertTrue(is_number_text("1e3"))
        self.assertFalse(is_number_text("one"))
        self.assertFalse(is_number_text(""))


class CompareTest(unittest.TestCase):
    def test_two_numbers(self):
        self.assertEqual(compared(number(1), number(2)), number(-1))
        self.assertEqual(compared(number(2), number(2)), number(0))
        self.assertEqual(compared(number(3), number(2)), number(1))

    def test_two_pieces_of_text_ignore_case(self):
        self.assertEqual(compared(text("a"), text("A")), number(0))
        self.assertEqual(compared(text("a"), text("b")), number(-1))

    def test_a_number_is_below_text(self):
        self.assertEqual(compared(number(9999), text("a")), number(-1))

    def test_text_is_below_a_boolean(self):
        self.assertEqual(compared(text("zzz"), FALSE), number(-1))

    def test_false_is_below_true(self):
        self.assertEqual(compared(FALSE, TRUE), number(-1))

    def test_a_blank_takes_the_shape_of_the_other_side(self):
        self.assertEqual(compared(blank(), number(0)), number(0))
        self.assertEqual(compared(blank(), text("")), number(0))
        self.assertEqual(compared(blank(), FALSE), number(0))

    def test_two_blanks_are_equal(self):
        self.assertEqual(compared(blank(), blank()), number(0))

    def test_an_error_on_either_side_is_the_answer(self):
        self.assertEqual(compared(error(WRONG), number(1)), error(WRONG))
        self.assertEqual(compared(number(1), error(MISSING)), error(MISSING))

    def test_a_span_cannot_be_compared(self):
        with self.assertRaises(ValueError_):
            compared(span("A1:B2"), number(1))

    def test_equality(self):
        self.assertEqual(equal(number(1), number(1)), TRUE)
        self.assertEqual(equal(text("a"), text("b")), FALSE)
        self.assertEqual(equal(error(WRONG), number(1)), error(WRONG))

    def test_matching_something_written_plainly(self):
        self.assertTrue(matches(text("Apple"), "apple"))
        self.assertFalse(matches(number(1), 2))

    def test_the_key_a_value_sorts_by(self):
        held = sorted([text("b"), number(2), TRUE, text("a")], key=sort_key)
        self.assertEqual([one.written() for one in held], ["2", "a", "b", "TRUE"])

    def test_an_error_has_no_place_in_an_order(self):
        with self.assertRaises(ValueError_):
            sort_key(error(WRONG))
