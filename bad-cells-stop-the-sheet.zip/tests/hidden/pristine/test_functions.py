"""The function library: the table, and what each group does."""

import unittest

from trestle.errors import FunctionError
from trestle.functions import (
    FUNCTIONS,
    Function,
    GROUPS,
    Setting,
    check_count,
    describe_functions,
    each_value,
    function_named,
    function_names,
    functions_in_group,
    is_function,
    numbers_in,
    rows_of,
)
from trestle.refs import read_address
from trestle.values import (
    DIVIDED,
    MISSING,
    NUMBER,
    REFERENCE,
    WRONG,
    blank,
    boolean,
    error,
    number,
    span,
    text,
)

HERE = Setting(read_address("C3"))


def call(name, *arguments, setting=None):
    """One function, called with values."""
    held = function_named(name)
    return held.call(list(arguments), setting or Setting())


def rows(*lines):
    """A span value from rows of plain Python."""
    from trestle.values import value_of

    return span(tuple(tuple(value_of(one) for one in line) for line in lines))


class TableTest(unittest.TestCase):
    def test_there_are_plenty_of_functions(self):
        self.assertGreater(len(FUNCTIONS), 70)

    def test_every_function_is_in_a_group(self):
        for held in FUNCTIONS.values():
            with self.subTest(function=held.name):
                self.assertIn(held.group, GROUPS)

    def test_every_group_has_functions_in_it(self):
        for group in GROUPS:
            with self.subTest(group=group):
                self.assertGreater(len(functions_in_group(group)), 5)

    def test_every_function_says_what_it_does(self):
        for held in FUNCTIONS.values():
            with self.subTest(function=held.name):
                self.assertGreater(len(held.note), 10)

    def test_every_name_is_in_capitals(self):
        for name in function_names():
            with self.subTest(function=name):
                self.assertEqual(name, name.upper())

    def test_looking_one_up(self):
        self.assertEqual(function_named("sum").name, "SUM")

    def test_one_nobody_has(self):
        with self.assertRaises(FunctionError):
            function_named("FROBNICATE")

    def test_asking_whether_a_name_is_one(self):
        self.assertTrue(is_function("sum"))
        self.assertFalse(is_function("A1"))

    def test_how_many_arguments_each_takes(self):
        self.assertEqual(function_named("ABS").wants(), "1")
        self.assertEqual(function_named("SUM").wants(), "1 or more")
        self.assertEqual(function_named("ROUND").wants(), "1 to 2")

    def test_a_call_with_the_wrong_number_of_arguments(self):
        with self.assertRaises(FunctionError):
            check_count(function_named("ABS"), 2)

    def test_a_group_nobody_has(self):
        with self.assertRaises(FunctionError):
            functions_in_group("dates")

    def test_the_description_of_every_function(self):
        held = describe_functions()
        self.assertEqual(len(held), len(FUNCTIONS))
        self.assertEqual(sorted(one[0] for one in held), sorted(function_names()))

    def test_a_function_needs_a_name(self):
        with self.assertRaises(FunctionError):
            Function("  ", 1, 1, "maths", "x", lambda a, s: None)

    def test_a_function_cannot_take_fewer_than_none(self):
        with self.assertRaises(FunctionError):
            Function("X", -1, 1, "maths", "x", lambda a, s: None)

    def test_a_function_whose_most_is_below_its_least(self):
        with self.assertRaises(FunctionError):
            Function("X", 2, 1, "maths", "x", lambda a, s: None)


class HelperTest(unittest.TestCase):
    def test_a_span_opens_out_into_values(self):
        self.assertEqual(len(list(each_value([rows([1, 2], [3, 4])]))), 4)

    def test_a_single_value_is_one_row_of_one(self):
        self.assertEqual(rows_of(number(1)), ((number(1),),))

    def test_the_numbers_in_a_span_leave_out_the_text(self):
        self.assertEqual(numbers_in([rows([1, "a"], [2, None])]), (1.0, 2.0))

    def test_a_value_given_directly_is_read_as_a_number(self):
        self.assertEqual(numbers_in([text("2")]), (2.0,))

    def test_an_error_anywhere_stops_it(self):
        self.assertEqual(numbers_in([rows([1, error(WRONG)])]), error(WRONG))


class MathsTest(unittest.TestCase):
    def test_adding_up(self):
        self.assertEqual(call("SUM", number(1), number(2), number(3)), number(6))
        self.assertEqual(call("SUM", rows([1, 2], [3, "x"])), number(6))

    def test_multiplying(self):
        self.assertEqual(call("PRODUCT", number(2), number(3)), number(6))

    def test_the_sign_and_the_size(self):
        self.assertEqual(call("ABS", number(-2)), number(2))
        self.assertEqual(call("SIGN", number(-2)), number(-1))
        self.assertEqual(call("SIGN", number(0)), number(0))

    def test_rounding_half_away_from_nought(self):
        self.assertEqual(call("ROUND", number(2.5)), number(3))
        self.assertEqual(call("ROUND", number(-2.5)), number(-3))
        self.assertEqual(call("ROUND", number(2.345), number(2)), number(2.35))

    def test_rounding_up_and_down(self):
        self.assertEqual(call("ROUNDUP", number(2.01)), number(3))
        self.assertEqual(call("ROUNDDOWN", number(2.99)), number(2))
        self.assertEqual(call("ROUNDUP", number(-2.01)), number(-3))

    def test_the_whole_number_below(self):
        self.assertEqual(call("INT", number(-2.5)), number(-3))
        self.assertEqual(call("TRUNC", number(-2.5)), number(-2))

    def test_what_is_left_after_dividing(self):
        self.assertEqual(call("MOD", number(7), number(3)), number(1))
        self.assertEqual(call("MOD", number(-3), number(2)), number(1))
        self.assertEqual(call("MOD", number(3), number(-2)), number(-1))

    def test_dividing_by_nought(self):
        self.assertEqual(call("MOD", number(1), number(0)), error(DIVIDED))

    def test_powers_and_roots(self):
        self.assertEqual(call("POWER", number(2), number(10)), number(1024))
        self.assertEqual(call("SQRT", number(9)), number(3))
        self.assertEqual(call("SQRT", number(-1)), error(NUMBER))

    def test_logarithms(self):
        self.assertEqual(call("LOG10", number(1000)), number(3))
        self.assertEqual(call("LOG", number(8), number(2)), number(3))
        self.assertEqual(call("LN", number(0)), error(NUMBER))

    def test_up_and_down_to_a_multiple(self):
        self.assertEqual(call("CEILING", number(2.1), number(0.5)), number(2.5))
        self.assertEqual(call("FLOOR", number(2.9), number(0.5)), number(2.5))

    def test_divisors_and_multiples(self):
        self.assertEqual(call("GCD", number(12), number(18)), number(6))
        self.assertEqual(call("LCM", number(4), number(6)), number(12))
        self.assertEqual(call("GCD", number(-1)), error(NUMBER))

    def test_text_that_is_not_a_number(self):
        self.assertEqual(call("ABS", text("x")), error(WRONG))


class StatsTest(unittest.TestCase):
    def setUp(self):
        self.range = rows([1, 2], [3, "x"])

    def test_the_mean(self):
        self.assertEqual(call("AVERAGE", self.range), number(2))

    def test_the_mean_of_nothing(self):
        self.assertEqual(call("AVERAGE", rows(["a"])), error(DIVIDED))

    def test_counting(self):
        self.assertEqual(call("COUNT", self.range), number(3))
        self.assertEqual(call("COUNTA", self.range), number(4))
        self.assertEqual(call("COUNTBLANK", rows([1, None])), number(1))

    def test_the_smallest_and_the_largest(self):
        self.assertEqual(call("MIN", self.range), number(1))
        self.assertEqual(call("MAX", self.range), number(3))

    def test_the_middle(self):
        self.assertEqual(call("MEDIAN", number(1), number(2), number(3)), number(2))
        self.assertEqual(call("MEDIAN", number(1), number(2), number(3), number(4)), number(2.5))

    def test_the_spread(self):
        self.assertAlmostEqual(call("VAR", number(1), number(2), number(3)).held, 1.0)
        self.assertAlmostEqual(call("STDEV", number(1), number(2), number(3)).held, 1.0)

    def test_the_spread_of_one_number(self):
        self.assertEqual(call("VAR", number(1)), error(DIVIDED))

    def test_the_nth_largest_and_smallest(self):
        self.assertEqual(call("LARGE", self.range, number(1)), number(3))
        self.assertEqual(call("SMALL", self.range, number(2)), number(2))
        self.assertEqual(call("LARGE", self.range, number(9)), error(NUMBER))

    def test_counting_what_passes_a_test(self):
        self.assertEqual(call("COUNTIF", self.range, text(">1")), number(2))
        self.assertEqual(call("COUNTIF", self.range, text("x")), number(1))
        self.assertEqual(call("COUNTIF", self.range, number(2)), number(1))

    def test_adding_what_passes_a_test(self):
        self.assertEqual(call("SUMIF", self.range, text(">1")), number(5))

    def test_adding_the_cells_beside_the_ones_that_pass(self):
        names = rows(["a"], ["b"])
        amounts = rows([10], [20])
        self.assertEqual(call("SUMIF", names, text("b"), amounts), number(20))

    def test_averaging_what_passes_a_test(self):
        self.assertEqual(call("AVERAGEIF", self.range, text(">1")), number(2.5))
        self.assertEqual(call("AVERAGEIF", self.range, text(">99")), error(DIVIDED))


class TextTest(unittest.TestCase):
    def test_joining(self):
        self.assertEqual(call("CONCAT", text("a"), number(1)), text("a1"))
        self.assertEqual(call("CONCAT", rows(["a", "b"])), text("ab"))

    def test_how_long(self):
        self.assertEqual(call("LEN", text("hello")), number(5))

    def test_the_ends_and_the_middle(self):
        self.assertEqual(call("LEFT", text("hello"), number(2)), text("he"))
        self.assertEqual(call("RIGHT", text("hello"), number(2)), text("lo"))
        self.assertEqual(call("MID", text("hello"), number(2), number(3)), text("ell"))

    def test_the_ends_with_no_count(self):
        self.assertEqual(call("LEFT", text("hello")), text("h"))
        self.assertEqual(call("RIGHT", text("hello")), text("o"))

    def test_a_negative_count(self):
        self.assertEqual(call("LEFT", text("hello"), number(-1)), error(NUMBER))

    def test_the_case(self):
        self.assertEqual(call("UPPER", text("aB")), text("AB"))
        self.assertEqual(call("LOWER", text("aB")), text("ab"))
        self.assertEqual(call("PROPER", text("hello world")), text("Hello World"))

    def test_taking_the_spaces_off(self):
        self.assertEqual(call("TRIM", text("  a   b  ")), text("a b"))

    def test_saying_it_again(self):
        self.assertEqual(call("REPT", text("ab"), number(3)), text("ababab"))

    def test_finding(self):
        self.assertEqual(call("FIND", text("l"), text("hello")), number(3))
        self.assertEqual(call("FIND", text("L"), text("hello")), error(MISSING))
        self.assertEqual(call("SEARCH", text("L"), text("hello")), number(3))

    def test_finding_from_a_position(self):
        self.assertEqual(call("FIND", text("l"), text("hello"), number(4)), number(4))

    def test_replacing(self):
        self.assertEqual(call("SUBSTITUTE", text("aaa"), text("a"), text("b")), text("bbb"))
        self.assertEqual(
            call("REPLACE", text("hello"), number(1), number(1), text("j")), text("jello")
        )

    def test_the_same_letter_for_letter(self):
        self.assertEqual(call("EXACT", text("a"), text("A")), boolean(False))
        self.assertEqual(call("EXACT", text("a"), text("a")), boolean(True))

    def test_reading_and_writing(self):
        self.assertEqual(call("VALUE", text("2.5")), number(2.5))
        self.assertEqual(call("VALUE", text("x")), error(WRONG))
        self.assertEqual(call("TEXT", number(2.5)), text("2.5"))


class LogicTest(unittest.TestCase):
    def test_choosing(self):
        self.assertEqual(call("IF", boolean(True), text("a"), text("b")), text("a"))
        self.assertEqual(call("IF", boolean(False), text("a"), text("b")), text("b"))

    def test_choosing_with_no_second_answer(self):
        self.assertEqual(call("IF", boolean(False), text("a")), boolean(False))

    def test_a_test_that_is_not_a_boolean(self):
        self.assertEqual(call("IF", number(1), text("a"), text("b")), text("a"))
        self.assertEqual(call("IF", text("x"), text("a"), text("b")), error(WRONG))

    def test_and_or_and_not(self):
        self.assertEqual(call("AND", boolean(True), boolean(False)), boolean(False))
        self.assertEqual(call("OR", boolean(True), boolean(False)), boolean(True))
        self.assertEqual(call("NOT", boolean(True)), boolean(False))
        self.assertEqual(call("XOR", boolean(True), boolean(True)), boolean(False))

    def test_blanks_are_passed_over(self):
        self.assertEqual(call("AND", rows([True, None])), boolean(True))

    def test_the_two_booleans_written_out(self):
        self.assertEqual(call("TRUE"), boolean(True))
        self.assertEqual(call("FALSE"), boolean(False))

    def test_catching_an_error(self):
        self.assertEqual(call("IFERROR", error(MISSING), number(0)), number(0))
        self.assertEqual(call("IFERROR", number(1), number(0)), number(1))

    def test_catching_a_blank(self):
        self.assertEqual(call("IFBLANK", blank(), number(0)), number(0))
        self.assertEqual(call("IFBLANK", number(1), number(0)), number(1))

    def test_switching(self):
        held = [number(2), number(1), text("one"), number(2), text("two"), text("other")]
        self.assertEqual(call("SWITCH", *held), text("two"))

    def test_switching_with_nothing_matching(self):
        self.assertEqual(call("SWITCH", number(9), number(1), text("one")), error(MISSING))

    def test_switching_to_the_last_one(self):
        self.assertEqual(
            call("SWITCH", number(9), number(1), text("one"), text("other")), text("other")
        )


class LookupTest(unittest.TestCase):
    def setUp(self):
        self.table = rows(["a", 1], ["b", 2], ["c", 3])

    def test_how_big_a_range_is(self):
        self.assertEqual(call("ROWS", self.table), number(3))
        self.assertEqual(call("COLUMNS", self.table), number(2))

    def test_where_the_cell_asking_is(self):
        self.assertEqual(call("ROW", setting=HERE), number(3))
        self.assertEqual(call("COLUMN", setting=HERE), number(3))

    def test_where_it_is_when_nobody_says(self):
        self.assertEqual(call("ROW"), error(REFERENCE))

    def test_picking_one_of_several(self):
        self.assertEqual(call("CHOOSE", number(2), text("x"), text("y")), text("y"))
        self.assertEqual(call("CHOOSE", number(9), text("x")), error(NUMBER))

    def test_taking_a_cell_out_of_a_range(self):
        self.assertEqual(call("INDEX", self.table, number(2), number(2)), number(2))

    def test_taking_from_a_range_one_column_wide(self):
        self.assertEqual(call("INDEX", rows([1], [2], [3]), number(3)), number(3))

    def test_taking_from_a_range_one_row_deep(self):
        self.assertEqual(call("INDEX", rows([1, 2, 3]), number(2)), number(2))

    def test_taking_from_outside_a_range(self):
        self.assertEqual(call("INDEX", self.table, number(9), number(1)), error(REFERENCE))

    def test_a_rectangle_with_one_number(self):
        self.assertEqual(call("INDEX", self.table, number(1)), error(REFERENCE))

    def test_finding_where_a_value_is(self):
        self.assertEqual(call("MATCH", text("b"), rows(["a"], ["b"], ["c"])), number(2))

    def test_finding_something_that_is_not_there(self):
        self.assertEqual(call("MATCH", text("z"), rows(["a"], ["b"])), error(MISSING))

    def test_finding_in_a_rectangle(self):
        self.assertEqual(call("MATCH", text("b"), self.table), error(REFERENCE))

    def test_finding_the_last_one_at_or_below(self):
        held = rows([1, 2, 5])
        self.assertEqual(call("MATCH", number(3), held, number(1)), number(2))

    def test_looking_down_a_column(self):
        self.assertEqual(call("VLOOKUP", text("b"), self.table, number(2)), number(2))

    def test_looking_down_a_column_for_something_missing(self):
        self.assertEqual(call("VLOOKUP", text("z"), self.table, number(2)), error(MISSING))

    def test_looking_down_a_column_with_a_near_match(self):
        held = rows([1, "low"], [10, "high"])
        self.assertEqual(call("VLOOKUP", number(5), held, number(2), boolean(True)), text("low"))

    def test_looking_at_a_column_that_is_not_there(self):
        self.assertEqual(call("VLOOKUP", text("a"), self.table, number(9)), error(REFERENCE))

    def test_looking_along_a_row(self):
        held = rows(["a", "b"], [1, 2])
        self.assertEqual(call("HLOOKUP", text("b"), held, number(2)), number(2))


class InfoTest(unittest.TestCase):
    def test_asking_what_something_is(self):
        self.assertEqual(call("ISBLANK", blank()), boolean(True))
        self.assertEqual(call("ISNUMBER", number(1)), boolean(True))
        self.assertEqual(call("ISTEXT", text("a")), boolean(True))
        self.assertEqual(call("ISLOGICAL", boolean(True)), boolean(True))

    def test_asking_about_errors(self):
        self.assertEqual(call("ISERROR", error(WRONG)), boolean(True))
        self.assertEqual(call("ISNA", error(MISSING)), boolean(True))
        self.assertEqual(call("ISNA", error(WRONG)), boolean(False))

    def test_the_missing_error_written_out(self):
        self.assertEqual(call("NA"), error(MISSING))

    def test_the_number_of_a_kind(self):
        self.assertEqual(call("TYPE", number(1)), number(1))
        self.assertEqual(call("TYPE", text("a")), number(2))
        self.assertEqual(call("TYPE", error(WRONG)), number(16))

    def test_a_value_as_a_plain_number(self):
        self.assertEqual(call("N", text("a")), number(0))
        self.assertEqual(call("N", number(2)), number(2))
        self.assertEqual(call("N", boolean(True)), number(1))

    def test_asking_about_an_error_does_not_spread_it(self):
        self.assertFalse(call("ISNUMBER", error(WRONG)).is_error)
