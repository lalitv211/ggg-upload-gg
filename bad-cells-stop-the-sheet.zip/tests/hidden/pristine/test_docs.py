"""The documentation, checked against the package rather than read.

A page that nobody runs goes wrong quietly. What can be checked here is checked:
that every function is in the table, that the operators and their levels agree
with the parser, that the errors and the checks and the commands and the exit
codes are all listed, and that every fenced example that looks like a formula
comes to what the page says it comes to.

What cannot be checked is the prose, and there is a lot of it. This at least
makes the facts inside the prose fail loudly when they stop being facts.
"""

import os
import re
import unittest

from trestle import Desk, __version__
from trestle.cli import COMMANDS, describe_exit
from trestle.demo import BOOKS
from trestle.formula import LEVELS
from trestle.functions import FUNCTIONS, GROUPS
from trestle.report import CHECKS
from trestle.values import IN_A_CELL, KINDS, failure_names

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DOCS = os.path.join(ROOT, "docs")

#: Every page, and what it is for.
PAGES = {
    "model.md": "the design note written before any of it",
    "formulas.md": "the language",
    "functions.md": "the seventy nine",
    "format.md": "the book file",
    "guide.md": "the tour",
    "cli.md": "the command line",
    "design.md": "the decisions",
    "performance.md": "what it costs",
    "glossary.md": "the words",
}

_TEXT = {}


def page(name):
    """One page, read once and kept."""
    if name not in _TEXT:
        with open(os.path.join(DOCS, name), encoding="utf-8") as handle:
            _TEXT[name] = handle.read()
    return _TEXT[name]


def everything():
    """Every page run together, for the checks that do not care which."""
    return "\n".join(page(name) for name in sorted(PAGES))


class PagesTest(unittest.TestCase):
    """What the directory holds."""

    def test_every_page_is_there(self):
        for name in sorted(PAGES):
            with self.subTest(page=name):
                self.assertTrue(os.path.isfile(os.path.join(DOCS, name)))

    def test_nothing_is_there_that_is_not_listed(self):
        found = sorted(name for name in os.listdir(DOCS) if name.endswith(".md"))
        self.assertEqual(found, sorted(PAGES))

    def test_every_page_starts_with_a_heading(self):
        for name in sorted(PAGES):
            with self.subTest(page=name):
                self.assertTrue(page(name).startswith("# "))

    def test_every_page_says_something(self):
        for name in sorted(PAGES):
            with self.subTest(page=name):
                self.assertGreater(len(page(name).splitlines()), 30)

    def test_every_page_ends_with_a_newline(self):
        for name in sorted(PAGES):
            with self.subTest(page=name):
                self.assertTrue(page(name).endswith("\n"))

    def test_no_page_has_a_line_of_trailing_space(self):
        for name in sorted(PAGES):
            for number, line in enumerate(page(name).splitlines(), start=1):
                if line != line.rstrip():
                    self.fail("%s line %d ends in a space" % (name, number))


class FunctionsPageTest(unittest.TestCase):
    """The table of functions, against the table in the package."""

    def named(self):
        """Every function name the page mentions in a table."""
        return set(re.findall(r"^\| `([A-Z0-9]+)` \|", page("functions.md"), re.M))

    def test_every_function_is_in_the_table(self):
        self.assertEqual(self.named(), set(FUNCTIONS))

    def test_the_count_is_written_down_correctly(self):
        said = page("functions.md").splitlines()[2]
        self.assertIn(str(len(FUNCTIONS)), said.replace("Seventy nine", "79"))

    def test_every_group_has_a_heading(self):
        for group, about in GROUPS.items():
            with self.subTest(group=group):
                self.assertIn("### %s: %s" % (group, about), page("functions.md"))

    def test_every_row_says_what_the_function_says(self):
        rows = re.findall(r"^\| `([A-Z0-9]+)` \| (.+?) \| (.+?) \|$", page("functions.md"), re.M)
        self.assertEqual(len(rows), len(FUNCTIONS))
        for name, wants, note in rows:
            with self.subTest(function=name):
                held = FUNCTIONS[name]
                self.assertEqual(wants, held.wants())
                self.assertEqual(note, held.note)


class FormulasPageTest(unittest.TestCase):
    """The language page, against the parser."""

    def test_every_operator_is_in_the_table(self):
        said = page("formulas.md")
        for operator in LEVELS:
            if operator == "unary":
                continue
            with self.subTest(operator=operator):
                self.assertIn("`%s`" % operator, said)

    def test_every_level_is_a_row(self):
        rows = re.findall(r"^\| (\d) \| (.+?) \| (\w+) \|", page("formulas.md"), re.M)
        self.assertEqual([row[0] for row in rows], ["7", "6", "5", "4", "3", "2", "1"])

    def test_each_row_holds_the_operators_of_that_level(self):
        """The two rows of ``+`` and ``-`` are the unary ones and the binary ones."""
        rows = re.findall(r"^\| (\d) \| (.+?) \| (\w+) \|", page("formulas.md"), re.M)
        for level, written, _ in rows:
            for operator in re.findall(r"`([^`]+)`", written):
                with self.subTest(operator=operator, level=level):
                    self.assertIn(int(level), (LEVELS[operator], LEVELS["unary"]))

    def test_every_error_is_named(self):
        for failure in failure_names():
            with self.subTest(error=failure):
                self.assertIn(failure, page("formulas.md"))

    def test_the_deepest_a_formula_may_nest_is_written_down(self):
        from trestle.formula import DEEPEST

        self.assertIn("Two hundred", page("formulas.md"))
        self.assertEqual(DEEPEST, 200)


class CommandsPageTest(unittest.TestCase):
    """The command line page, against the command line."""

    def test_every_command_is_named(self):
        said = page("cli.md")
        for name in COMMANDS:
            with self.subTest(command=name):
                self.assertIn("`%s`" % name, said)

    def test_the_count_is_written_down_correctly(self):
        self.assertIn("Eighteen commands", page("cli.md"))
        self.assertEqual(len(COMMANDS), 18)

    def test_every_kind_of_change_is_in_the_table(self):
        from trestle.store import KINDS_OF_CHANGE

        said = page("cli.md")
        for kind in KINDS_OF_CHANGE:
            with self.subTest(kind=kind):
                self.assertIn("| `%s` |" % kind, said)

    def test_every_exit_code_is_in_the_table(self):
        said = page("cli.md")
        for code in (0, 1, 2, 3):
            with self.subTest(code=code):
                self.assertIn("| %d | %s |" % (code, describe_exit(code)), said)

    def test_every_check_is_in_the_table(self):
        said = page("cli.md")
        for name in CHECKS:
            with self.subTest(check=name):
                self.assertTrue("| `%s` |" % name in said, "no row for %s" % name)


class GuidePageTest(unittest.TestCase):
    """The tour, against what it says it is touring."""

    def test_every_way_of_opening_a_desk_is_listed(self):
        said = page("guide.md")
        for name in ("of_text", "of_file", "of_table", "empty", "demo"):
            with self.subTest(way=name):
                self.assertIn("Desk.%s(" % name, said)
                self.assertTrue(hasattr(Desk, name))

    def test_the_layers_are_the_ones_the_package_has(self):
        said = page("guide.md")
        for layer in ("values", "refs", "formula", "functions", "evaluate",
                      "sheet", "graph", "recalc", "book", "store", "report"):
            with self.subTest(layer=layer):
                self.assertIn(layer, said)


class FormatPageTest(unittest.TestCase):
    """The file format page, against the reader."""

    def test_the_header_is_written_as_the_package_writes_it(self):
        from trestle.store import FORMAT, VERSION

        self.assertIn("%s %d" % (FORMAT, VERSION), page("format.md"))

    def test_the_kinds_of_line_are_all_there(self):
        said = page("format.md")
        for held in ("name ", "sheet ", "#"):
            with self.subTest(line=held):
                self.assertIn(held, said)


class GlossaryTest(unittest.TestCase):
    """The words, against the things they are words for."""

    def defined(self):
        """Every word the glossary defines."""
        return set(re.findall(r"^\*\*([a-z ]+)\*\*", page("glossary.md"), re.M))

    def test_the_words_are_in_order(self):
        found = re.findall(r"^\*\*([a-z ]+)\*\*", page("glossary.md"), re.M)
        self.assertEqual(found, sorted(found))

    def test_no_word_is_defined_twice(self):
        found = re.findall(r"^\*\*([a-z ]+)\*\*", page("glossary.md"), re.M)
        self.assertEqual(len(found), len(set(found)))

    def test_every_kind_of_value_is_a_word(self):
        held = self.defined()
        for kind in KINDS:
            with self.subTest(kind=kind):
                self.assertIn(kind if kind in held else "value", held)

    def test_the_words_the_package_is_built_from_are_there(self):
        held = self.defined()
        for word in ("address", "book", "cell", "context", "cycle", "digest",
                     "formula", "graph", "order", "sheet", "span", "trace",
                     "tree", "value"):
            with self.subTest(word=word):
                self.assertIn(word, held)


class WorkedOutTest(unittest.TestCase):
    """Formulas quoted in the pages, worked out.

    Anything written ``=...`` and followed by what it comes to is checked. That
    is the part of the documentation that can go wrong without anybody noticing,
    because it is the part that makes a claim about arithmetic.
    """

    #: What the pages say, and what they say it comes to.
    QUOTED = (
        ("=-2^2", "4"),
        ("=2^3^2", "512"),
        ("=50%", "0.5"),
        ("=INT(-2.5)", "-3"),
        ("=ROUNDDOWN(-2.5)", "-2"),
        ("=MOD(-1,3)", "2"),
        ("=(1+2)*3", "9"),
        ("=1+2*3", "7"),
        ("=ROUND(2/3,4)", "0.6667"),
        ("=0.1+0.2=0.3", "FALSE"),
        ("=1/3", "0.333333333333333"),
        ("=SUM(Z1:Z9)", "0"),
        ("=AVERAGE(Z1:Z9)", "#DIV/0!"),
        ("=COUNT(Z1:Z9)", "0"),
        ("=COUNTBLANK(Z1:Z9)", "9"),
        ("=IF(A1:A9,1,2)", "#VALUE!"),
    )

    def test_every_quoted_formula_comes_to_what_is_written(self):
        desk = Desk.empty()
        for at, (formula, _) in enumerate(self.QUOTED, start=1):
            desk.put("A%d" % at, formula)
        desk.recalculate()
        for at, (formula, said) in enumerate(self.QUOTED, start=1):
            with self.subTest(formula=formula):
                self.assertEqual(desk.value_at("A%d" % at).written(), said)

    def test_every_quoted_formula_is_actually_quoted(self):
        """The pages write them with or without the equals sign, and with spaces."""
        said = everything().replace(" ", "")
        for formula, _ in self.QUOTED:
            with self.subTest(formula=formula):
                written = formula.lstrip("=").replace(" ", "")
                self.assertTrue(written in said, "no page writes %s" % formula)

    def test_the_budget_comes_to_what_the_pages_say(self):
        desk = Desk.demo("budget")
        desk.recalculate()
        for where, said in (("Left!B3", "1090"), ("Left!B4", "64.3")):
            with self.subTest(cell=where):
                self.assertEqual(desk.value_at(where).written(), said)
                self.assertTrue(said in everything(), "no page writes %s" % said)

    def test_raising_the_salary_gives_what_the_guide_says(self):
        desk = Desk.demo("budget")
        desk.put("Income!B2", 2600)
        desk.recalculate()
        self.assertEqual(desk.value_at("Left!B3").written(), "1290")
        self.assertIn("1290", page("guide.md"))

    def test_every_worked_example_is_named_somewhere(self):
        said = everything()
        for name in sorted(BOOKS):
            with self.subTest(book=name):
                self.assertTrue(name in said, "no page names %s" % name)


class ReadmeTest(unittest.TestCase):
    """The readme, and the fifteen things it says the package does not do.

    A list of gaps is only worth having if the gaps are real. Each of these
    asserts the absence the readme claims, so that a gap quietly filled in makes
    the readme wrong loudly rather than quietly.
    """

    def readme(self):
        """The readme, as text."""
        with open(os.path.join(ROOT, "README.md"), encoding="utf-8") as handle:
            return handle.read()

    def test_there_are_fifteen_of_them(self):
        found = re.findall(r"^(\d+)\. \*\*", self.readme(), re.M)
        self.assertEqual(found, [str(one) for one in range(1, 16)])

    def test_every_page_is_linked(self):
        said = self.readme()
        for name in sorted(PAGES):
            with self.subTest(page=name):
                self.assertIn("(docs/%s)" % name, said)

    def test_every_test_module_that_is_described_is_there(self):
        for name in re.findall(r"`(test_\w+\.py)`", self.readme()):
            with self.subTest(module=name):
                self.assertTrue(os.path.isfile(os.path.join(ROOT, "tests", name)))

    def test_the_layers_it_lists_are_the_layers_there_are(self):
        """The first line of the block holds two layers, so words, not line starts."""
        listed = set(re.findall(r"\w+", self.readme()))
        held = {name for name in os.listdir(os.path.join(ROOT, "trestle"))
                if os.path.isdir(os.path.join(ROOT, "trestle", name))
                and name != "__pycache__"}
        self.assertEqual(held - listed, set())

    def test_there_is_no_clock_function(self):
        for name in ("NOW", "TODAY", "DATE", "TIME", "RAND", "RANDBETWEEN"):
            with self.subTest(function=name):
                self.assertNotIn(name, FUNCTIONS)

    def test_a_whole_column_is_not_a_range(self):
        from trestle.errors import TrestleError
        from trestle.refs import read_span

        with self.assertRaises(TrestleError):
            read_span("A:A", None, "Main")

    def test_two_and_two_tenths_is_not_a_third(self):
        desk = Desk.empty()
        desk.put("A1", "=0.1+0.2=0.3")
        desk.recalculate()
        self.assertEqual(desk.value_at("A1").written(), "FALSE")

    def test_a_name_is_not_a_reference(self):
        desk = Desk.empty()
        desk.put("A1", "=Tax_Rate*2")
        desk.recalculate()
        self.assertEqual(desk.value_at("A1").written(), "#NAME?")

    def test_a_range_where_one_value_belongs_is_refused(self):
        desk = Desk.empty()
        desk.put("A1", 1)
        desk.put("A2", 2)
        desk.put("C1", "=A1:A2+1")
        desk.recalculate()
        self.assertEqual(desk.value_at("C1").written(), "#VALUE!")

    def test_a_cycle_is_an_error_and_not_something_to_go_round(self):
        desk = Desk.empty()
        desk.put("A1", "=A1+1")
        desk.recalculate()
        self.assertEqual(desk.value_at("A1").written(), "#CYCLE!")

    def test_two_sheets_whose_names_differ_only_in_case_are_two_sheets(self):
        from trestle.book import Book
        from trestle.sheet import Sheet

        book = Book("Both")
        book.add(Sheet("Costs"))
        book.add(Sheet("costs"))
        self.assertEqual(len(book), 2)

    def test_a_function_name_is_matched_in_any_case(self):
        desk = Desk.empty()
        desk.put("A1", "=sum(1,2)")
        desk.recalculate()
        self.assertEqual(desk.value_at("A1").written(), "3")


class VersionTest(unittest.TestCase):
    """The version, which is written down in more than one place."""

    def written_in_pyproject(self):
        """What the packaging says the version is."""
        with open(os.path.join(ROOT, "pyproject.toml"), encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("version = "):
                    return line.split("=", 1)[1].strip().strip('"')
        return ""

    def test_the_package_and_the_packaging_agree(self):
        self.assertEqual(__version__, self.written_in_pyproject())

    def test_the_version_reads_as_one(self):
        self.assertRegex(__version__, r"^\d+\.\d+\.\d+$")


class CountedTest(unittest.TestCase):
    """Numbers written into the prose, against the numbers there are.

    A count in a sentence is the first thing to go out of date, so every one of
    them that can be checked is checked. The ones written as words are here as
    words, because that is how they are written.
    """

    IN_WORDS = {
        "seventy nine": 79,
        "eighteen commands": 18,
        "nine checks": 9,
        "seven": 7,
        "two hundred": 200,
    }

    def readme(self):
        """The readme, as text."""
        with open(os.path.join(ROOT, "README.md"), encoding="utf-8") as handle:
            return handle.read()

    def test_the_functions_are_counted_the_same_everywhere(self):
        self.assertEqual(len(FUNCTIONS), self.IN_WORDS["seventy nine"])
        for name in ("functions.md", "cli.md"):
            with self.subTest(page=name):
                self.assertIn("eventy nine", page(name))
        self.assertIn("seventy nine", self.readme())

    def test_the_commands_are_counted_the_same_everywhere(self):
        self.assertEqual(len(COMMANDS), self.IN_WORDS["eighteen commands"])
        self.assertIn("Eighteen commands", self.readme().replace("- **A command line.** ", ""))

    def test_the_checks_are_counted_the_same_everywhere(self):
        self.assertEqual(len(CHECKS), self.IN_WORDS["nine checks"])
        self.assertIn("nine checks", page("cli.md"))
        self.assertIn("nine checks", self.readme())

    def test_the_errors_are_counted_the_same_everywhere(self):
        self.assertEqual(len(failure_names()), self.IN_WORDS["seven"])
        self.assertIn("Seven of them", page("formulas.md"))

    def test_the_kinds_of_value_are_all_named(self):
        for kind in KINDS:
            with self.subTest(kind=kind):
                self.assertTrue(kind in everything(), "no page names %s" % kind)

    def test_a_cell_holds_fewer_kinds_than_a_formula_does(self):
        self.assertLess(len(IN_A_CELL), len(KINDS))
