"""Books far bigger than the worked examples, to keep the cost in check.

Nothing here reads a clock, which would make the suite fail on a busy machine
and pass on a quiet one. What it counts is work: how many cells were worked out,
how long the order came to, how many links the graph holds. A change that turns
a recalculation into a square shows up here as a number, not as a suite that
takes a coffee break.
"""

import unittest

from trestle.book import Book
from trestle.graph import links_of, order_of
from trestle.recalc import recalculate, recalculated_after
from trestle.sheet import Sheet
from trestle.store import read_book, write_book
from trestle.values import number


def letter(column):
    """The column letter, for the twenty six this file needs."""
    return chr(ord("A") + column - 1)


def a_chain(length):
    """A sheet where each cell adds one to the cell above it."""
    held = Sheet("Chain", {"A1": 1})
    for row in range(2, length + 1):
        held.put("A%d" % row, "=A%d+1" % (row - 1))
    return held


def a_column(count):
    """A sheet with a column of numbers and one total beside it."""
    held = Sheet("Column")
    for row in range(1, count + 1):
        held.put("A%d" % row, row)
    held.put("B1", "=SUM(A1:A%d)" % count)
    return held


def a_grid(across, down):
    """A sheet of numbers with a total under every column."""
    held = Sheet("Grid")
    for column in range(1, across + 1):
        for row in range(1, down + 1):
            held.put("%s%d" % (letter(column), row), row)
    for column in range(1, across + 1):
        name = letter(column)
        held.put("%s%d" % (name, down + 1), "=SUM(%s1:%s%d)" % (name, name, down))
    return held


class ChainTest(unittest.TestCase):
    """A thousand cells, each reading the one above it."""

    @classmethod
    def setUpClass(cls):
        cls.sheet = a_chain(1000)
        cls.pass_ = recalculate(cls.sheet)

    def test_every_formula_is_worked_out(self):
        self.assertEqual(self.pass_.cells, 999)

    def test_the_last_one_counted_all_the_way_up(self):
        self.assertEqual(self.pass_.value_at("A1000"), number(1000))

    def test_the_order_is_the_chain_itself(self):
        order = order_of(links_of(self.sheet))
        self.assertEqual(len(order), 999)
        self.assertEqual(order.cells[0].written(), "Chain!A2")
        self.assertEqual(order.cells[-1].written(), "Chain!A1000")

    def test_the_graph_holds_one_link_a_cell(self):
        self.assertEqual(len(links_of(self.sheet).edges()), 999)

    def test_nothing_is_stuck(self):
        self.assertFalse(self.pass_.has_cycle)


class ChangeTest(unittest.TestCase):
    """What a change to one cell of a long chain costs."""

    def setUp(self):
        self.sheet = a_chain(400)
        recalculate(self.sheet)

    def test_changing_the_first_cell_works_the_whole_chain_out(self):
        self.sheet.put("A1", 100)
        held = recalculated_after(self.sheet, ["A1"])
        self.assertEqual(held.cells, 399)
        self.assertEqual(held.value_at("A400"), number(499))

    def test_changing_the_last_cell_works_out_one_cell(self):
        self.sheet.put("A400", "=A399+2")
        held = recalculated_after(self.sheet, ["A400"])
        self.assertEqual(held.cells, 1)
        self.assertEqual(held.value_at("A400"), number(401))

    def test_changing_a_cell_in_the_middle_works_out_the_rest(self):
        held = recalculated_after(self.sheet, ["A200"])
        self.assertEqual(held.cells, 201)

    def test_a_change_that_changes_nothing_still_works_the_cells_out(self):
        held = recalculated_after(self.sheet, ["A1"])
        self.assertEqual(held.cells, 399)
        self.assertEqual(len(held.changed()), 0)


class ColumnTest(unittest.TestCase):
    """One formula over five thousand cells."""

    @classmethod
    def setUpClass(cls):
        cls.sheet = a_column(5000)
        cls.pass_ = recalculate(cls.sheet)
        cls.links = links_of(cls.sheet)

    def test_only_the_formula_is_worked_out(self):
        self.assertEqual(self.pass_.cells, 1)

    def test_it_added_them_all_up(self):
        self.assertEqual(self.pass_.value_at("B1"), number(5000 * 5001 / 2))

    def test_the_rectangle_is_kept_as_a_rectangle(self):
        self.assertEqual(len(self.links.spans_of(self.sheet.address_of("B1"))), 1)

    def test_the_formula_waits_for_every_filled_cell_in_it(self):
        self.assertEqual(len(self.links.reads(self.sheet.address_of("B1"))), 5000)

    def test_the_order_is_the_one_formula(self):
        self.assertEqual(len(order_of(self.links)), 1)

    def test_the_sheet_costs_only_what_was_put_in_it(self):
        self.assertEqual(len(self.sheet), 5001)


class GridTest(unittest.TestCase):
    """Twenty columns of a hundred and fifty numbers, each with a total."""

    @classmethod
    def setUpClass(cls):
        cls.sheet = a_grid(20, 150)
        cls.pass_ = recalculate(cls.sheet)
        cls.links = cls.pass_.links

    def test_a_total_under_every_column(self):
        self.assertEqual(self.pass_.cells, 20)

    def test_every_total_came_to_the_same_thing(self):
        held = {
            cell.value.written()
            for where, cell in self.sheet.cells()
            if where.row == 151
        }
        self.assertEqual(held, {"11325"})

    def test_the_sheet_holds_the_numbers_and_the_totals(self):
        self.assertEqual(len(self.sheet), 20 * 150 + 20)

    def test_the_order_is_as_long_as_the_formulas(self):
        self.assertEqual(len(order_of(self.links)), 20)

    def test_it_writes_out_and_reads_back(self):
        book = Book("Big")
        book.add(self.sheet)
        again = read_book(write_book(book))
        self.assertEqual(len(again.sheet_named("Grid")), len(self.sheet))


class BookTest(unittest.TestCase):
    """Twenty sheets, each reading the one before it."""

    @classmethod
    def setUpClass(cls):
        cls.book = Book("Many")
        cls.book.add(Sheet("Sheet1", {"A1": 1}))
        for which in range(2, 21):
            cls.book.add(
                Sheet("Sheet%d" % which, {"A1": "=Sheet%d!A1+1" % (which - 1)})
            )
        cls.trace = cls.book.recalculate()

    def test_every_sheet_is_worked_out(self):
        self.assertEqual(len(self.trace), 19)

    def test_the_last_sheet_counted_all_the_way_up(self):
        self.assertEqual(self.book.value_at("Sheet20!A1"), number(20))

    def test_the_order_runs_through_the_sheets(self):
        order = self.book.order()
        self.assertEqual(order.cells[0].written(), "Sheet2!A1")
        self.assertEqual(order.cells[-1].written(), "Sheet20!A1")

    def test_working_it_out_again_changes_nothing(self):
        self.assertEqual(len(self.book.recalculate().changed()), 0)


class WideFormulaTest(unittest.TestCase):
    """One formula that names two hundred cells one at a time."""

    @classmethod
    def setUpClass(cls):
        cls.sheet = Sheet("Wide")
        for row in range(1, 201):
            cls.sheet.put("A%d" % row, row)
        cls.sheet.put("B1", "=" + "+".join("A%d" % row for row in range(1, 201)))
        cls.pass_ = recalculate(cls.sheet)

    def test_it_adds_them_all_up(self):
        self.assertEqual(self.pass_.value_at("B1"), number(200 * 201 / 2))

    def test_the_graph_holds_every_reference(self):
        held = links_of(self.sheet)
        self.assertEqual(len(held.reads(self.sheet.address_of("B1"))), 200)

    def test_no_rectangle_is_involved(self):
        self.assertEqual(links_of(self.sheet).spans_of(self.sheet.address_of("B1")), ())

    def test_the_written_formula_is_as_long_as_it_was(self):
        self.assertEqual(self.sheet.cell_at(self.sheet.address_of("B1")).text.count("+"), 199)
