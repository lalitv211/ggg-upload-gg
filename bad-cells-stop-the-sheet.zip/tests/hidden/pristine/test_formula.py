"""Formulas: tokens, trees, reading them and writing them back."""

import unittest

from trestle.errors import FormulaError
from trestle.formula import (
    DEEPEST,
    Binary,
    Call,
    Literal,
    OPERATORS,
    Percent,
    Reference,
    Spread,
    Token,
    Unary,
    depth_of,
    filled_tree,
    lex,
    lex_formula,
    moved_to,
    parse,
    references_in,
    rendered,
    rendered_cell,
    renamed_sheet,
    strip_equals,
    token,
    walk,
)
from trestle.refs import read_address, read_span
from trestle.values import boolean, error, number, text


def kinds(formula):
    """The kinds of token a formula comes out as, without the end."""
    return [held.kind for held in lex(formula) if not held.is_end]


def texts(formula):
    """The text of every token in a formula, without the end."""
    return [held.text for held in lex(formula) if not held.is_end]


class TokenTest(unittest.TestCase):
    def test_a_token_knows_its_kind(self):
        held = token("name", "SUM")
        self.assertTrue(held.says("name"))
        self.assertTrue(held.says("name", "sum"))
        self.assertFalse(held.says("number"))

    def test_a_kind_nobody_has(self):
        with self.assertRaises(FormulaError):
            token("shout", "!")

    def test_which_tokens_start_a_value(self):
        self.assertTrue(token("number", "1").is_value)
        self.assertTrue(token("name", "A1").is_value)
        self.assertFalse(token("comma", ",").is_value)

    def test_asking_whether_a_token_is_an_operator(self):
        self.assertTrue(token("operator", "+").is_operator("+", "-"))
        self.assertFalse(token("operator", "*").is_operator("+", "-"))

    def test_every_operator_is_one_or_two_characters(self):
        for held in OPERATORS:
            with self.subTest(operator=held):
                self.assertIn(len(held), (1, 2))


class LexerTest(unittest.TestCase):
    def test_the_equals_sign_is_taken_off(self):
        self.assertEqual(strip_equals("=1+1"), "1+1")
        self.assertEqual(strip_equals("1+1"), "1+1")

    def test_a_number(self):
        self.assertEqual(kinds("=1"), ["number"])
        self.assertEqual(texts("=3.5e2"), ["3.5e2"])
        self.assertEqual(texts("=.5"), [".5"])

    def test_text_in_quotes(self):
        self.assertEqual(texts('="hello"'), ["hello"])

    def test_a_doubled_quote_inside_text(self):
        self.assertEqual(texts('="a""b"'), ['a"b'])

    def test_text_that_is_never_closed(self):
        with self.assertRaises(FormulaError):
            lex('="hello')

    def test_a_reference(self):
        self.assertEqual(kinds("=A1"), ["name"])
        self.assertEqual(texts("=$A$1"), ["$A$1"])
        self.assertEqual(texts("=Costs!A1"), ["Costs!A1"])

    def test_a_sheet_name_in_quotes(self):
        self.assertEqual(texts("='Old Costs'!A1"), ["'Old Costs'!A1"])

    def test_a_span(self):
        self.assertEqual(kinds("=A1:B2"), ["name", "colon", "name"])

    def test_a_call(self):
        self.assertEqual(kinds("=SUM(A1,2)"), ["name", "open", "name", "comma", "number", "close"])

    def test_an_error_value(self):
        self.assertEqual(texts("=#N/A"), ["#N/A"])
        self.assertEqual(kinds("=#DIV/0!"), ["error"])

    def test_something_that_is_not_an_error_value(self):
        with self.assertRaises(FormulaError):
            lex("=#NONSENSE")

    def test_the_two_character_operators(self):
        self.assertEqual(texts("=1<>2"), ["1", "<>", "2"])
        self.assertEqual(texts("=1<=2"), ["1", "<=", "2"])

    def test_spaces_are_left_out(self):
        self.assertEqual(texts("= 1 + 2 "), ["1", "+", "2"])

    def test_something_that_is_not_part_of_a_formula(self):
        with self.assertRaises(FormulaError):
            lex("=1 @ 2")

    def test_every_token_knows_where_it_started(self):
        held = [one for one in lex("=1+22") if not one.is_end]
        self.assertEqual([one.at for one in held], [0, 1, 2])

    def test_a_formula_with_nothing_in_it(self):
        self.assertEqual(len(lex("=")), 1)


class ParseTest(unittest.TestCase):
    def tree(self, formula):
        return parse(formula)

    def test_a_number(self):
        self.assertEqual(self.tree("=1"), Literal(number(1)))

    def test_text(self):
        self.assertEqual(self.tree('="a"'), Literal(text("a")))

    def test_the_booleans(self):
        self.assertEqual(self.tree("=TRUE"), Literal(boolean(True)))
        self.assertEqual(self.tree("=false"), Literal(boolean(False)))

    def test_an_error_value(self):
        self.assertEqual(self.tree("=#N/A"), Literal(error("#N/A")))

    def test_a_reference(self):
        self.assertEqual(self.tree("=A1"), Reference(read_address("A1")))

    def test_a_span(self):
        self.assertEqual(self.tree("=A1:B2"), Spread(read_span("A1:B2")))

    def test_a_call(self):
        held = self.tree("=SUM(A1,2)")
        self.assertIsInstance(held, Call)
        self.assertEqual(held.name, "SUM")
        self.assertEqual(held.count, 2)

    def test_a_call_with_no_arguments(self):
        self.assertEqual(self.tree("=NOW()").count, 0)

    def test_the_name_of_a_call_is_lifted_to_capitals(self):
        self.assertEqual(self.tree("=sum(A1)").name, "SUM")

    def test_multiplying_binds_tighter_than_adding(self):
        self.assertEqual(rendered(self.tree("=1+2*3")), "1+2*3")
        self.assertIsInstance(self.tree("=1+2*3").right, Binary)

    def test_brackets_change_that(self):
        self.assertIsInstance(self.tree("=(1+2)*3").left, Binary)

    def test_power_groups_from_the_right(self):
        held = self.tree("=2^3^2")
        self.assertIsInstance(held.right, Binary)

    def test_a_minus_in_front_binds_tighter_than_a_power(self):
        held = self.tree("=-2^2")
        self.assertIsInstance(held, Binary)
        self.assertIsInstance(held.left, Unary)

    def test_a_percent_after_a_value(self):
        self.assertIsInstance(self.tree("=50%"), Percent)

    def test_joining_text_is_looser_than_adding(self):
        held = self.tree('=1+2&"a"')
        self.assertEqual(held.operator, "&")

    def test_comparing_is_the_loosest(self):
        held = self.tree('=1+2="a"&"b"')
        self.assertEqual(held.operator, "=")

    def test_a_bracket_that_is_never_closed(self):
        with self.assertRaises(FormulaError):
            self.tree("=SUM(A1")

    def test_something_after_the_end(self):
        with self.assertRaises(FormulaError):
            self.tree("=1 2")

    def test_an_operator_with_nothing_after_it(self):
        with self.assertRaises(FormulaError):
            self.tree("=1+")

    def test_a_formula_with_nothing_in_it(self):
        with self.assertRaises(FormulaError):
            self.tree("=")

    def test_a_name_that_is_neither_a_cell_nor_a_function(self):
        with self.assertRaises(FormulaError):
            self.tree("=hello")

    def test_a_formula_in_a_sheet_takes_that_sheet(self):
        held = parse("=A1", sheet="Costs")
        self.assertEqual(held.address.sheet, "Costs")

    def test_a_reference_that_names_its_own_sheet_keeps_it(self):
        held = parse("=Prices!A1", sheet="Costs")
        self.assertEqual(held.address.sheet, "Prices")


class TreeTest(unittest.TestCase):
    def setUp(self):
        self.tree = parse("=1+SUM(A1:B2,C3)")

    def test_walking_it(self):
        self.assertEqual(len(list(walk(self.tree))), 5)

    def test_the_references_in_it(self):
        held = references_in(self.tree)
        self.assertEqual([str(one) for one in held], ["A1:B2", "C3"])

    def test_a_tree_with_no_references(self):
        self.assertEqual(references_in(parse("=1+2")), ())

    def test_a_literal_holds_a_value(self):
        with self.assertRaises(FormulaError):
            Literal(1)

    def test_a_reference_holds_an_address(self):
        with self.assertRaises(FormulaError):
            Reference("A1")

    def test_a_spread_holds_a_span(self):
        with self.assertRaises(FormulaError):
            Spread("A1:B2")

    def test_an_operator_nobody_has(self):
        with self.assertRaises(FormulaError):
            Binary("<=>", Literal(number(1)), Literal(number(2)))
        with self.assertRaises(FormulaError):
            Unary("!", Literal(number(1)))

    def test_a_call_needs_a_name(self):
        with self.assertRaises(FormulaError):
            Call("  ")

    def test_a_comparison_says_it_is_one(self):
        self.assertTrue(parse("=1<2").is_comparison)
        self.assertFalse(parse("=1+2").is_comparison)


class RenderTest(unittest.TestCase):
    """What is written back out reads back into the same tree."""

    formulas = [
        "=1", '="a"', "=TRUE", "=#N/A", "=A1", "=$A$1", "=Costs!A1", "=A1:B2",
        "=1+2", "=1+2*3", "=(1+2)*3", "=1-2-3", "=1-(2-3)", "=2^3^2", "=(2^3)^2",
        "=-2^2", "=-(2^2)", "=50%", "=A1%+1", '="a"&"b"&"c"', "=1<>2", "=1<=2",
        "=SUM(A1:B2)", "=SUM(A1:B2)*2", "=IF(A1>1, \"yes\", \"no\")", "=ROUND(A1/B1, 2)",
        "=(A1+A2)/2", "=NOT(TRUE)", "=SUM()",
    ]

    def test_every_formula_writes_back_the_way_it_was_written(self):
        for held in self.formulas:
            with self.subTest(formula=held):
                self.assertEqual(rendered_cell(parse(held)), held.replace(", ", ", "))

    def test_writing_and_reading_twice_changes_nothing(self):
        for held in self.formulas:
            with self.subTest(formula=held):
                once = rendered_cell(parse(held))
                twice = rendered_cell(parse(once))
                self.assertEqual(once, twice)

    def test_a_tree_the_renderer_does_not_know(self):
        with self.assertRaises(FormulaError):
            rendered("1+1")


class FillTest(unittest.TestCase):
    def test_a_loose_reference_moves(self):
        self.assertEqual(rendered_cell(filled_tree(parse("=A1"), 1, 1)), "=B2")

    def test_a_reference_held_still_does_not(self):
        self.assertEqual(rendered_cell(filled_tree(parse("=$A$1"), 1, 1)), "=$A$1")

    def test_a_span_moves(self):
        self.assertEqual(rendered_cell(filled_tree(parse("=SUM(A1:A5)"), 1, 0)), "=SUM(B1:B5)")

    def test_everything_else_is_left_alone(self):
        self.assertEqual(rendered_cell(filled_tree(parse('=1+"a"'), 1, 1)), '=1+"a"')

    def test_a_reference_that_falls_off_the_sheet(self):
        self.assertEqual(rendered_cell(filled_tree(parse("=A1"), -1, 0)), "=#REF!")

    def test_a_span_that_falls_off_the_sheet(self):
        self.assertEqual(rendered_cell(filled_tree(parse("=SUM(A1:B2)"), 0, -5)), "=SUM(#REF!)")

    def test_filling_from_one_cell_to_another(self):
        held = moved_to(parse("=A1+B1"), read_address("C1"), read_address("C2"))
        self.assertEqual(rendered_cell(held), "=A2+B2")

    def test_filling_between_things_that_are_not_addresses(self):
        with self.assertRaises(FormulaError):
            moved_to(parse("=A1"), "C1", "C2")

    def test_renaming_a_sheet(self):
        held = renamed_sheet(parse("=Costs!A1+B2"), "Costs", "Spend")
        self.assertEqual(rendered_cell(held), "=Spend!A1+B2")

    def test_renaming_leaves_the_sheetless_references_alone(self):
        held = renamed_sheet(parse("=A1"), "Costs", "Spend")
        self.assertEqual(rendered_cell(held), "=A1")

    def test_renaming_inside_a_call(self):
        held = renamed_sheet(parse("=SUM(Costs!A1:A5)"), "Costs", "Spend")
        self.assertEqual(rendered_cell(held), "=SUM(Spend!A1:A5)")


def chained(count):
    """A formula that adds that many cells together."""
    return "=" + "+".join("A%d" % row for row in range(1, count + 1))


class DepthTest(unittest.TestCase):
    """How deep a formula is, and how deep one is allowed to be."""

    def test_one_thing_on_its_own_is_one_deep(self):
        self.assertEqual(depth_of(parse("=1")), 1)
        self.assertEqual(depth_of(parse("=A1")), 1)

    def test_an_operator_adds_a_level(self):
        self.assertEqual(depth_of(parse("=1+2")), 2)
        self.assertEqual(depth_of(parse("=1+2*3")), 3)

    def test_brackets_do_not_add_a_level_of_their_own(self):
        self.assertEqual(depth_of(parse("=(1+2)")), depth_of(parse("=1+2")))

    def test_a_call_counts_as_a_level(self):
        self.assertEqual(depth_of(parse("=SUM(A1:A5)")), 2)
        self.assertEqual(depth_of(parse("=SUM(1+2,3)")), 3)

    def test_the_deepest_arm_is_the_one_that_counts(self):
        self.assertEqual(depth_of(parse("=1+SUM(2*3,4)")), 4)

    def test_a_minus_sign_in_front_adds_a_level(self):
        self.assertEqual(depth_of(parse("=-A1")), 2)

    def test_a_per_cent_sign_adds_a_level(self):
        self.assertEqual(depth_of(parse("=5%")), 2)

    def test_a_long_chain_is_read(self):
        held = parse(chained(DEEPEST))
        self.assertEqual(depth_of(held), DEEPEST)

    def test_a_longer_chain_is_refused(self):
        with self.assertRaises(FormulaError) as caught:
            parse(chained(DEEPEST + 2))
        self.assertIn("nests", str(caught.exception))

    def test_what_is_refused_says_both_numbers(self):
        with self.assertRaises(FormulaError) as caught:
            parse(chained(DEEPEST + 50))
        said = str(caught.exception)
        self.assertIn(str(DEEPEST + 50), said)
        self.assertIn(str(DEEPEST), said)

    def test_the_deepest_formula_allowed_still_works_out(self):
        from trestle.sheet import Sheet
        from trestle.recalc import recalculate

        sheet = Sheet("Deep")
        for row in range(1, DEEPEST + 1):
            sheet.put("A%d" % row, 1)
        sheet.put("B1", chained(DEEPEST))
        held = recalculate(sheet)
        self.assertEqual(held.value_at("B1").held, float(DEEPEST))

    def test_walking_a_deep_tree_costs_no_stack(self):
        from trestle.formula import walk

        self.assertEqual(len(list(walk(parse(chained(DEEPEST))))), 2 * DEEPEST - 1)
