"""The same book gives the same answers, whoever works it out and whenever.

This is the promise the whole package is built around, so it is written down
here as numbers rather than as a paragraph. The digests below were worked out
once and pinned. If a change to the engine moves one of them, that change moved
an answer, and the pinned number has to be changed on purpose with a line in the
changelog saying which answer moved and why.

The pinned digests are checked twice: in this interpreter, and in a fresh one
started under several hash seeds, because a dictionary that gets walked in a
different order is the usual way a result stops being reproducible.
"""

import os
import subprocess
import sys
import unittest

from trestle import Desk
from trestle.demo import BOOKS, demo_book
from trestle.store import (
    digest_of_book,
    digest_of_sheet,
    digest_of_values,
    read_book,
    same_input,
    write_book,
)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

#: What was typed in, and what it came to, for each worked example.
PINNED = {
    "budget": ("be259593af2d7e8a", "4208eab98965ef3b"),
    "invoice": ("b66a01c74a3bf661", "cc52e2b65a0efef9"),
    "loan": ("414e4d8836081839", "02184aa2575710b1"),
    "marks": ("c6cfabec1983ebdd", "a03648473bbf51a9"),
    "trouble": ("44be22e8c571c8b9", "231d9be91c6016b6"),
}

#: The seeds a fresh interpreter is started under.
SEEDS = ("0", "1", "12345")

WORKED_OUT = """
import sys
sys.path.insert(0, %r)
from trestle.demo import demo_book
from trestle.store import digest_of_book, digest_of_values
for name in sorted(%r):
    book = demo_book(name, again=True)
    book.recalculate()
    print("%%s %%s %%s" %% (name, digest_of_book(book), digest_of_values(book)))
"""


def worked_out(name):
    """One worked example, recalculated, as its own copy."""
    book = demo_book(name, again=True)
    book.recalculate()
    return book


class PinnedTest(unittest.TestCase):
    """The digests, in this interpreter."""

    def test_every_example_is_pinned(self):
        self.assertEqual(sorted(PINNED), sorted(BOOKS))

    def test_what_was_typed_in_is_what_it_was(self):
        for name, (typed, _) in sorted(PINNED.items()):
            with self.subTest(book=name):
                self.assertEqual(digest_of_book(worked_out(name)), typed)

    def test_what_it_came_to_is_what_it_came_to(self):
        for name, (_, values) in sorted(PINNED.items()):
            with self.subTest(book=name):
                self.assertEqual(digest_of_values(worked_out(name)), values)

    def test_no_two_examples_hold_the_same_thing(self):
        typed = [held[0] for held in PINNED.values()]
        self.assertEqual(len(set(typed)), len(typed))

    def test_no_two_examples_come_to_the_same_thing(self):
        values = [held[1] for held in PINNED.values()]
        self.assertEqual(len(set(values)), len(values))

    def test_the_two_digests_of_a_book_are_not_the_same(self):
        for name, (typed, values) in sorted(PINNED.items()):
            with self.subTest(book=name):
                self.assertNotEqual(typed, values)


class FreshInterpreterTest(unittest.TestCase):
    """The digests, in an interpreter of its own under several hash seeds."""

    def digests_under(self, seed):
        """What a fresh interpreter makes of the examples."""
        environment = dict(os.environ)
        environment["PYTHONHASHSEED"] = seed
        finished = subprocess.run(
            [sys.executable, "-c", WORKED_OUT % (ROOT, sorted(BOOKS))],
            capture_output=True,
            text=True,
            env=environment,
            cwd=ROOT,
        )
        self.assertEqual(finished.returncode, 0, finished.stderr)
        found = {}
        for line in finished.stdout.splitlines():
            name, typed, values = line.split()
            found[name] = (typed, values)
        return found

    def test_the_seeds_all_agree_with_the_pinned_digests(self):
        for seed in SEEDS:
            with self.subTest(seed=seed):
                self.assertEqual(self.digests_under(seed), PINNED)


class AgainTest(unittest.TestCase):
    """Working the same book out twice, and reading it back."""

    def test_working_it_out_again_moves_nothing(self):
        for name in sorted(BOOKS):
            with self.subTest(book=name):
                book = worked_out(name)
                before = digest_of_values(book)
                book.recalculate()
                self.assertEqual(digest_of_values(book), before)

    def test_a_book_written_out_and_read_back_holds_the_same_thing(self):
        for name in sorted(BOOKS):
            with self.subTest(book=name):
                book = worked_out(name)
                self.assertTrue(same_input(book, read_book(write_book(book))))

    def test_a_book_written_out_and_read_back_comes_to_the_same_thing(self):
        for name in sorted(BOOKS):
            with self.subTest(book=name):
                book = worked_out(name)
                again = read_book(write_book(book))
                again.recalculate()
                self.assertEqual(digest_of_values(again), digest_of_values(book))

    def test_a_book_written_out_twice_is_the_same_text(self):
        for name in sorted(BOOKS):
            with self.subTest(book=name):
                book = worked_out(name)
                self.assertEqual(write_book(book), write_book(read_book(write_book(book))))

    def test_what_was_written_holds_no_values(self):
        """A book file is what was typed. Values are worked out again on the way in."""
        for name in sorted(BOOKS):
            with self.subTest(book=name):
                fresh = read_book(write_book(worked_out(name)))
                self.assertEqual(len(fresh.recalculate().changed()), fresh.counts()["formulas"])


class DeskTest(unittest.TestCase):
    """The same promise through the façade, which is how it is usually reached."""

    def test_the_desk_gives_the_pinned_digests(self):
        for name, (typed, values) in sorted(PINNED.items()):
            with self.subTest(book=name):
                desk = Desk.demo(name)
                desk.recalculate()
                self.assertEqual(desk.digest(), typed)
                self.assertEqual(desk.digest(values=True), values)

    def test_two_desks_on_the_same_example_agree(self):
        for name in sorted(BOOKS):
            with self.subTest(book=name):
                one, other = Desk.demo(name), Desk.demo(name)
                one.recalculate()
                other.recalculate()
                self.assertEqual(one.digest(values=True), other.digest(values=True))

    def test_a_desk_read_back_from_what_it_saved_agrees(self):
        for name in sorted(BOOKS):
            with self.subTest(book=name):
                desk = Desk.demo(name)
                desk.recalculate()
                again = Desk.of_text(write_book(desk.book))
                again.recalculate()
                self.assertEqual(again.digest(values=True), desk.digest(values=True))

    def test_typing_something_in_moves_the_digest(self):
        desk = Desk.demo("budget")
        desk.recalculate()
        before = desk.digest()
        desk.put("Z99", 1)
        self.assertNotEqual(desk.digest(), before)


class SheetTest(unittest.TestCase):
    """A digest over one sheet, which is what a book's digest is built from."""

    def test_every_sheet_of_every_example_has_one(self):
        for name in sorted(BOOKS):
            for sheet in worked_out(name).sheets():
                with self.subTest(book=name, sheet=sheet.name):
                    self.assertEqual(len(digest_of_sheet(sheet)), 16)

    def test_an_empty_sheet_has_the_same_digest_whatever_it_is_called(self):
        from trestle.sheet import Sheet

        self.assertEqual(digest_of_sheet(Sheet("One")), digest_of_sheet(Sheet("Other")))

    def test_two_sheets_holding_the_same_cells_agree(self):
        from trestle.sheet import Sheet

        one = Sheet("One", {"A1": 1, "B1": "=A1*2"})
        other = Sheet("Other", {"B1": "=A1*2", "A1": 1})
        self.assertEqual(digest_of_sheet(one), digest_of_sheet(other))
