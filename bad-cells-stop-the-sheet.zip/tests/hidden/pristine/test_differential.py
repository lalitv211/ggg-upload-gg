"""The package against something else that answers the same question.

Two comparisons. The first is the evaluator against Python itself: an
expression of numbers and operators is worked out here and by ``eval`` over the
same text, and the two are compared. The second is the function library against
the standard library: ``SUM`` against ``sum``, ``AVERAGE`` against a mean
written out, and so on, over ranges built from a seed.

Neither second opinion shares any code with the first. Where they disagree, the
package is wrong.
"""

import math
import random
import unittest

from trestle.evaluate import Plain, evaluated_text
from trestle.refs import read_address
from trestle.sheet import Sheet
from trestle.values import number

OPERATORS = ("+", "-", "*")
NUMBERS = (0, 1, 2, 3, 7, 10, 25, 100, 0.5, 1.5, 2.25)


def an_expression(source, depth=0):
    """A written expression of numbers and operators, the same one every time."""
    if depth >= 3 or source.random() < 0.3:
        return "%g" % source.choice(NUMBERS)
    left = an_expression(source, depth + 1)
    right = an_expression(source, depth + 1)
    operator = source.choice(OPERATORS)
    written = "%s%s%s" % (left, operator, right)
    return "(%s)" % written if source.random() < 0.4 else written


class ArithmeticTest(unittest.TestCase):
    """Expressions of numbers, worked out here and by Python."""

    seeds = range(200)

    def expressions(self):
        for seed in self.seeds:
            yield seed, an_expression(random.Random(seed))

    def test_every_expression_reads(self):
        for seed, written in self.expressions():
            with self.subTest(seed=seed, formula=written):
                self.assertFalse(evaluated_text("=" + written).is_error)

    def test_the_answers_agree(self):
        for seed, written in self.expressions():
            wanted = eval(written)  # noqa: S307 - the second opinion, on our own text
            held = evaluated_text("=" + written)
            with self.subTest(seed=seed, formula=written):
                self.assertAlmostEqual(held.held, float(wanted), places=9)

    def test_dividing_agrees_where_python_can_do_it(self):
        source = random.Random(99)
        for _ in range(100):
            left = source.choice(NUMBERS)
            right = source.choice([one for one in NUMBERS if one])
            written = "%g/%g" % (left, right)
            with self.subTest(formula=written):
                self.assertAlmostEqual(
                    evaluated_text("=" + written).held, left / right, places=9
                )

    def test_raising_to_a_power_agrees(self):
        for left in (0, 1, 2, 3, 10):
            for right in (0, 1, 2, 3):
                written = "%d^%d" % (left, right)
                with self.subTest(formula=written):
                    self.assertAlmostEqual(evaluated_text("=" + written).held, left ** right)

    def test_a_minus_in_front_binds_tighter_than_a_power(self):
        self.assertEqual(evaluated_text("=-2^2").held, 4.0)
        self.assertEqual(eval("(-2)**2"), 4)

    def test_comparing_numbers_agrees_with_python(self):
        source = random.Random(7)
        for _ in range(100):
            left, right = source.choice(NUMBERS), source.choice(NUMBERS)
            for mark, wanted in (
                ("=", left == right),
                ("<", left < right),
                (">", left > right),
                ("<=", left <= right),
                (">=", left >= right),
                ("<>", left != right),
            ):
                written = "%g%s%g" % (left, mark, right)
                with self.subTest(formula=written):
                    self.assertEqual(evaluated_text("=" + written).held, wanted)


def a_column(source, count=12):
    """A column of numbers in a sheet, and the same numbers as a list."""
    held = [round(source.uniform(-50, 50), 3) for _ in range(count)]
    sheet = Sheet("S")
    for row, one in enumerate(held, start=1):
        sheet.put("A%d" % row, one)
    return sheet, held


class FunctionTest(unittest.TestCase):
    """The library against the standard library, over columns of numbers."""

    seeds = range(30)

    def columns(self):
        for seed in self.seeds:
            yield seed, a_column(random.Random(seed))

    def worked(self, sheet, formula):
        """One formula worked out against a sheet."""
        return evaluated_text(formula, sheet)

    def test_adding_up(self):
        for seed, (sheet, held) in self.columns():
            with self.subTest(seed=seed):
                self.assertAlmostEqual(
                    self.worked(sheet, "=SUM(A1:A12)").held, math.fsum(held), places=9
                )

    def test_the_mean(self):
        for seed, (sheet, held) in self.columns():
            with self.subTest(seed=seed):
                self.assertAlmostEqual(
                    self.worked(sheet, "=AVERAGE(A1:A12)").held,
                    math.fsum(held) / len(held),
                    places=9,
                )

    def test_the_smallest_and_the_largest(self):
        for seed, (sheet, held) in self.columns():
            with self.subTest(seed=seed):
                self.assertAlmostEqual(self.worked(sheet, "=MIN(A1:A12)").held, min(held))
                self.assertAlmostEqual(self.worked(sheet, "=MAX(A1:A12)").held, max(held))

    def test_counting(self):
        for seed, (sheet, held) in self.columns():
            with self.subTest(seed=seed):
                self.assertEqual(self.worked(sheet, "=COUNT(A1:A12)").held, len(held))

    def test_the_middle(self):
        import statistics

        for seed, (sheet, held) in self.columns():
            with self.subTest(seed=seed):
                self.assertAlmostEqual(
                    self.worked(sheet, "=MEDIAN(A1:A12)").held, statistics.median(held), places=9
                )

    def test_the_spread(self):
        import statistics

        for seed, (sheet, held) in self.columns():
            with self.subTest(seed=seed):
                self.assertAlmostEqual(
                    self.worked(sheet, "=STDEV(A1:A12)").held, statistics.stdev(held), places=6
                )

    def test_the_nth_largest(self):
        for seed, (sheet, held) in self.columns():
            wanted = sorted(held, reverse=True)
            for position in (1, 3, 12):
                with self.subTest(seed=seed, position=position):
                    self.assertAlmostEqual(
                        self.worked(sheet, "=LARGE(A1:A12,%d)" % position).held,
                        wanted[position - 1],
                    )

    def test_counting_what_is_above_nought(self):
        for seed, (sheet, held) in self.columns():
            with self.subTest(seed=seed):
                self.assertEqual(
                    self.worked(sheet, '=COUNTIF(A1:A12,">0")').held,
                    float(sum(1 for one in held if one > 0)),
                )

    def test_adding_what_is_above_nought(self):
        for seed, (sheet, held) in self.columns():
            with self.subTest(seed=seed):
                self.assertAlmostEqual(
                    self.worked(sheet, '=SUMIF(A1:A12,">0")').held,
                    math.fsum(one for one in held if one > 0),
                    places=9,
                )

    def test_rounding_agrees_with_money(self):
        source = random.Random(5)
        for _ in range(100):
            held = round(source.uniform(-100, 100), 4)
            wanted = math.floor(abs(held) * 100 + 0.5) / 100 * (1 if held >= 0 else -1)
            with self.subTest(number=held):
                self.assertAlmostEqual(
                    evaluated_text("=ROUND(%r,2)" % held).held, wanted, places=9
                )


class TextTest(unittest.TestCase):
    """The text functions against Python's own."""

    words = ("hello", "Trestle", "a b c", "", "  spaced  ", "MiXeD")

    def test_how_long(self):
        for held in self.words:
            with self.subTest(text=held):
                self.assertEqual(evaluated_text('=LEN("%s")' % held).held, float(len(held)))

    def test_the_case(self):
        for held in self.words:
            with self.subTest(text=held):
                self.assertEqual(evaluated_text('=UPPER("%s")' % held).held, held.upper())
                self.assertEqual(evaluated_text('=LOWER("%s")' % held).held, held.lower())

    def test_the_ends(self):
        for held in self.words:
            for count in (0, 1, 3, 20):
                with self.subTest(text=held, count=count):
                    self.assertEqual(
                        evaluated_text('=LEFT("%s",%d)' % (held, count)).held, held[:count]
                    )

    def test_joining(self):
        for held in self.words:
            with self.subTest(text=held):
                self.assertEqual(
                    evaluated_text('=CONCAT("%s","x")' % held).held, held + "x"
                )
