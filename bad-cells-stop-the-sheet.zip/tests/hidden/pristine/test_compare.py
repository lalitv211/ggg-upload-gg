"""Comparing two books: what somebody typed, and what it came to."""

import unittest

from trestle.book import Book
from trestle.errors import StoreError
from trestle.sheet import Sheet
from trestle.store import (
    KINDS_OF_CHANGE,
    Change,
    Difference,
    changed_cells,
    compared_books,
    compared_sheets,
)
from trestle.demo import demo_book
from trestle.values import blank, number


def worked_out(name):
    """One worked example, recalculated, as its own copy."""
    book = demo_book(name, again=True)
    book.recalculate()
    return book


def a_pair():
    """Two sheets that differ in every way a sheet can."""
    before = Sheet("Main", {"A1": 1, "A2": 2, "A3": "=A1+A2", "A4": "gone"})
    after = Sheet("Main", {"A1": 5, "A2": 2, "A3": "=A1+A2", "A5": "new"})
    from trestle.recalc import recalculate

    recalculate(before)
    recalculate(after)
    return before, after


class ChangeTest(unittest.TestCase):
    """One change on its own."""

    def test_a_kind_that_does_not_exist(self):
        sheet = Sheet("Main", {"A1": 1})
        with self.assertRaises(StoreError):
            Change(sheet.address_of("A1"), "moved")

    def test_every_kind_that_does(self):
        sheet = Sheet("Main", {"A1": 1})
        for kind in KINDS_OF_CHANGE:
            with self.subTest(kind=kind):
                self.assertEqual(Change(sheet.address_of("A1"), kind).kind, kind)

    def test_what_it_says_about_itself(self):
        sheet = Sheet("Main", {"A1": 1})
        held = Change(sheet.address_of("A1"), "typed", "1", "2")
        self.assertEqual(str(held), "Main!A1: 1 -> 2")

    def test_an_added_cell_says_what_is_in_it(self):
        sheet = Sheet("Main", {"A1": 1})
        held = Change(sheet.address_of("A1"), "added", "", "=B1")
        self.assertIn("added", str(held))
        self.assertIn("=B1", str(held))

    def test_a_removed_cell_says_what_was_in_it(self):
        sheet = Sheet("Main", {"A1": 1})
        held = Change(sheet.address_of("A1"), "removed", "7", "")
        self.assertIn("was 7", str(held))

    def test_a_cell_that_came_to_something_else_says_so(self):
        sheet = Sheet("Main", {"A1": 1})
        held = Change(
            sheet.address_of("A1"), "worked out", "=B1", "=B1", number(1), number(2)
        )
        self.assertIn("same formula", str(held))
        self.assertFalse(held.is_typed)
        self.assertTrue(held.is_worked_out)


class SheetTest(unittest.TestCase):
    """Two sheets."""

    def setUp(self):
        self.before, self.after = a_pair()
        self.held = compared_sheets(self.before, self.after)

    def test_a_sheet_against_itself_is_no_change(self):
        self.assertTrue(compared_sheets(self.before, self.before).is_empty)

    def test_the_number_that_changed(self):
        self.assertEqual(self.held.at(self.after.address_of("A1")).kind, "typed")

    def test_the_cell_that_went(self):
        self.assertEqual(self.held.at(self.after.address_of("A4")).kind, "removed")

    def test_the_cell_that_arrived(self):
        self.assertEqual(self.held.at(self.after.address_of("A5")).kind, "added")

    def test_the_formula_that_stayed_and_came_to_something_else(self):
        held = self.held.at(self.after.address_of("A3"))
        self.assertEqual(held.kind, "worked out")
        self.assertEqual(held.was_value, number(3))
        self.assertEqual(held.now_value, number(7))

    def test_the_cell_that_did_not_change_is_not_in_it(self):
        self.assertIsNone(self.held.at(self.after.address_of("A2")))

    def test_the_changes_come_out_in_reading_order(self):
        self.assertEqual(
            [one.at.written(False) for one in self.held], ["A1", "A3", "A4", "A5"]
        )

    def test_how_many_of_each(self):
        counts = self.held.counts()
        self.assertEqual(counts["typed"], 1)
        self.assertEqual(counts["added"], 1)
        self.assertEqual(counts["removed"], 1)
        self.assertEqual(counts["worked out"], 1)
        self.assertEqual(counts["cells"], 4)

    def test_what_was_typed_and_what_it_came_to_are_two_questions(self):
        self.assertEqual(len(self.held.typed()), 3)
        self.assertEqual(len(self.held.came_to()), 4)

    def test_asking_for_a_kind_that_does_not_exist(self):
        with self.assertRaises(StoreError):
            self.held.of_kind("moved")

    def test_comparing_something_that_is_not_a_sheet(self):
        with self.assertRaises(StoreError):
            changed_cells(self.before, "after")

    def test_the_rows_it_would_print(self):
        rows = self.held.rows()
        self.assertEqual(len(rows), 4)
        self.assertEqual(len(rows[0]), 6)

    def test_one_line_about_the_whole_thing(self):
        self.assertIn("4 cells", self.held.summary())


class BookTest(unittest.TestCase):
    """Two books."""

    def test_a_book_against_itself_is_no_change(self):
        held = worked_out("budget")
        self.assertTrue(compared_books(held, held).is_empty)
        self.assertEqual(str(compared_books(held, held)), "the two books are the same")

    def test_a_change_at_the_top_reaches_every_sheet(self):
        before, after = worked_out("budget"), worked_out("budget")
        after.put("B2", 2600, "Income")
        after.recalculate()
        held = compared_books(before, after)
        self.assertEqual(held.counts()["typed"], 1)
        self.assertEqual(held.counts()["worked out"], 4)
        self.assertEqual(
            [one.at.written() for one in held.of_kind("worked out")],
            ["Income!B4", "Left!B1", "Left!B3", "Left!B4"],
        )

    def test_the_cell_that_was_typed_into_also_came_to_something_else(self):
        before, after = worked_out("budget"), worked_out("budget")
        after.put("B2", 2600, "Income")
        after.recalculate()
        held = compared_books(before, after)
        self.assertEqual(len(held.typed()), 1)
        self.assertEqual(len(held.came_to()), 5)

    def test_a_sheet_only_one_of_them_holds_is_named(self):
        before, after = worked_out("budget"), worked_out("budget")
        after.add(Sheet("Notes", {"A1": "later"}))
        held = compared_books(before, after)
        self.assertEqual(held.sheets, ("Notes",))
        self.assertEqual(held.counts()["added"], 1)
        self.assertIn("1 sheet", held.summary())

    def test_a_sheet_that_went(self):
        before, after = worked_out("budget"), worked_out("budget")
        after.remove("Left")
        held = compared_books(before, after)
        self.assertEqual(held.sheets, ("Left",))
        self.assertEqual(held.counts()["removed"], 8)

    def test_the_changes_of_every_sheet_are_in_it(self):
        before, after = worked_out("budget"), worked_out("budget")
        after.put("B2", 2600, "Income")
        after.put("B3", 500, "Spending")
        after.recalculate()
        held = compared_books(before, after)
        self.assertEqual({one.at.sheet for one in held}, {"Income", "Spending", "Left"})

    def test_comparing_something_that_is_not_a_book(self):
        with self.assertRaises(StoreError):
            compared_books(worked_out("budget"), "after")

    def test_a_formula_rewritten_to_the_same_answer(self):
        before, after = worked_out("budget"), worked_out("budget")
        after.put("B3", "=B1-B2+0", "Left")
        after.recalculate()
        held = compared_books(before, after)
        self.assertEqual(len(held.typed()), 1)
        self.assertEqual(len(held.came_to()), 0)

    def test_every_worked_example_is_the_same_as_itself(self):
        for name in ("budget", "invoice", "loan", "marks", "trouble"):
            with self.subTest(book=name):
                self.assertTrue(compared_books(worked_out(name), worked_out(name)).is_empty)


class EmptyTest(unittest.TestCase):
    """The edges."""

    def test_two_empty_books(self):
        self.assertTrue(compared_books(Book("One"), Book("Other")).is_empty)

    def test_two_empty_sheets(self):
        self.assertTrue(compared_sheets(Sheet("One"), Sheet("Other")).is_empty)

    def test_a_difference_holding_nothing(self):
        held = Difference()
        self.assertTrue(held.is_empty)
        self.assertEqual(len(held), 0)
        self.assertEqual(held.lines(), ())

    def test_a_book_against_an_empty_one(self):
        held = compared_books(worked_out("budget"), Book("Nothing"))
        self.assertEqual(held.counts()["removed"], 28)
        self.assertEqual(len(held.sheets), 3)
