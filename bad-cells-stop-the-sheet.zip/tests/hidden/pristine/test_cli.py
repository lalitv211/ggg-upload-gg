"""The command line."""

import io
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

from trestle.cli import FAILED, OK, TROUBLE, USAGE, describe_exit, main, parse
from trestle.demo import BUDGET, TROUBLE as TROUBLE_BOOK, demo_text
from trestle.errors import CliError

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run(*argv):
    """The command line, run in this process, with what it printed."""
    stream = io.StringIO()
    code = main(list(argv), stream)
    return code, stream.getvalue()


def written(text, name="book.txt"):
    """A file holding some text, in a directory of its own."""
    path = os.path.join(tempfile.mkdtemp(), name)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return path


class UsageTest(unittest.TestCase):
    def test_no_command_at_all(self):
        code, text = run()
        self.assertEqual(code, USAGE)
        self.assertIn("say what to do", text)

    def test_a_command_nobody_has(self):
        self.assertEqual(run("fly")[0], USAGE)

    def test_an_option_nobody_has(self):
        self.assertEqual(run("show", "--sideways", "book")[0], USAGE)

    def test_a_book_that_is_not_there(self):
        code, text = run("show", "/no/such/book")
        self.assertEqual(code, USAGE)
        self.assertIn("no such book", text)

    def test_the_version(self):
        import trestle

        code, text = run("--version")
        self.assertEqual(code, OK)
        self.assertEqual(text.strip(), "trestle %s" % trestle.__version__)

    def test_what_each_exit_code_means(self):
        self.assertIn("done", describe_exit(OK))
        self.assertIn("would not read", describe_exit(FAILED))
        self.assertIn("wrongly", describe_exit(USAGE))
        self.assertIn("error", describe_exit(TROUBLE))
        self.assertIn("unknown", describe_exit(9))

    def test_the_parser_raises_rather_than_exiting(self):
        with self.assertRaises(CliError):
            parse(["value"])


class ShowTest(unittest.TestCase):
    def setUp(self):
        self.path = written(BUDGET)

    def test_the_grid(self):
        code, text = run("show", self.path, "--sheet", "Left")
        self.assertEqual(code, OK)
        self.assertIn("1090", text)

    def test_the_first_sheet_when_none_is_named(self):
        _, text = run("show", self.path)
        self.assertIn("salary", text)

    def test_the_formulas(self):
        _, text = run("show", self.path, "--sheet", "Left", "--formulas")
        self.assertIn("=B1-B2", text)

    def test_part_of_a_sheet(self):
        _, text = run("show", self.path, "--sheet", "Left", "--over", "A1:B2")
        self.assertNotIn("left", text)

    def test_an_example_by_name(self):
        code, text = run("show", "budget", "--sheet", "Left")
        self.assertEqual(code, OK)
        self.assertIn("1090", text)

    def test_a_sheet_that_is_empty(self):
        code, text = run("show", written("trestle-book 1\nsheet One\n"))
        self.assertEqual(text.strip(), "This sheet is empty.")

    def test_as_a_table(self):
        _, text = run("show", self.path, "--sheet", "Left", "--format", "csv")
        self.assertTrue(text.startswith("Row,A,B"))

    def test_a_book_with_an_error_in_it(self):
        code, _ = run("show", written(TROUBLE_BOOK))
        self.assertEqual(code, TROUBLE)


class ValueTest(unittest.TestCase):
    def setUp(self):
        self.path = written(BUDGET)

    def test_what_a_cell_came_to(self):
        code, text = run("value", self.path, "Left!B3")
        self.assertEqual(code, OK)
        self.assertEqual(text.strip(), "1090")

    def test_what_was_typed(self):
        _, text = run("value", self.path, "Left!B3", "--typed")
        self.assertEqual(text.strip(), "=B1-B2")

    def test_a_cell_in_a_named_sheet(self):
        _, text = run("value", self.path, "B4", "--sheet", "Income")
        self.assertEqual(text.strip(), "3050")

    def test_a_cell_that_came_to_an_error(self):
        code, text = run("value", written(TROUBLE_BOOK), "A3")
        self.assertEqual(code, TROUBLE)
        self.assertEqual(text.strip(), "#DIV/0!")

    def test_a_cell_that_is_not_a_cell(self):
        code, _ = run("value", self.path, "hello")
        self.assertEqual(code, USAGE)

    def test_a_sheet_that_is_not_there(self):
        code, _ = run("value", self.path, "A1", "--sheet", "Nowhere")
        self.assertEqual(code, USAGE)


class SetTest(unittest.TestCase):
    def setUp(self):
        self.path = written(BUDGET)

    def test_typing_into_a_cell(self):
        code, text = run("set", self.path, "B2", "3000", "--sheet", "Income")
        self.assertEqual(code, OK)
        self.assertIn("3000", text)

    def test_it_works_the_book_out_again(self):
        _, text = run("set", self.path, "B2", "3000", "--sheet", "Income")
        self.assertIn("3000", text)

    def test_writing_the_book_out(self):
        out = os.path.join(tempfile.mkdtemp(), "after.book")
        code, text = run("set", self.path, "B2", "3000", "--sheet", "Income", "--out", out)
        self.assertEqual(code, OK)
        self.assertTrue(os.path.isfile(out))
        self.assertIn("Wrote", text)

    def test_typing_a_formula(self):
        out = os.path.join(tempfile.mkdtemp(), "after.book")
        run("set", self.path, "C1", "=B4*2", "--sheet", "Income", "--out", out)
        code, text = run("value", out, "Income!C1")
        self.assertEqual(text.strip(), "6100")


class TableCommandTest(unittest.TestCase):
    def setUp(self):
        self.path = written(BUDGET)

    def test_working_it_out(self):
        code, text = run("calc", self.path)
        self.assertEqual(code, OK)
        self.assertIn("book: 3 sheets", text)

    def test_the_cells(self):
        _, text = run("cells", self.path, "--sheet", "Left")
        self.assertIn("B3", text)

    def test_part_of_the_cells(self):
        _, text = run("cells", self.path, "--sheet", "Left", "--over", "A1:A2")
        self.assertNotIn("B3", text)

    def test_the_formulas(self):
        _, text = run("formulas", self.path, "--sheet", "Left")
        self.assertIn("=B1-B2", text)

    def test_the_sheets(self):
        _, text = run("sheets", self.path)
        self.assertIn("Income", text)
        self.assertIn("Spending", text)

    def test_the_trace(self):
        _, text = run("trace", self.path)
        self.assertIn("Recalculation", text)

    def test_the_order(self):
        _, text = run("order", self.path)
        self.assertIn("Order", text)

    def test_what_reads_what(self):
        _, text = run("links", self.path)
        self.assertIn("Left!B3", text)

    def test_what_kinds_of_value(self):
        _, text = run("values", self.path, "--sheet", "Left")
        self.assertIn("formula", text)

    def test_as_markdown(self):
        _, text = run("sheets", self.path, "--format", "markdown")
        self.assertTrue(text.startswith("## Sheets"))


class ReviewTest(unittest.TestCase):
    def test_a_clean_book(self):
        code, text = run("review", written(BUDGET))
        self.assertEqual(code, OK)
        self.assertIn("Nothing to say", text)

    def test_a_book_with_trouble_in_it(self):
        code, text = run("review", written(TROUBLE_BOOK))
        self.assertEqual(code, FAILED)
        self.assertIn("warning", text)

    def test_one_check_only(self):
        code, text = run("review", written(TROUBLE_BOOK), "--only", "cycles")
        self.assertEqual(code, FAILED)
        self.assertIn("cycles", text)

    def test_a_check_nobody_has(self):
        code, _ = run("review", written(BUDGET), "--only", "nonsense")
        self.assertEqual(code, FAILED)


class TableFileTest(unittest.TestCase):
    def test_a_sheet_as_comma_separated_values(self):
        code, text = run("csv", written(BUDGET), "--sheet", "Left")
        self.assertEqual(code, OK)
        self.assertIn("left,1090", text)

    def test_the_formulas_instead(self):
        _, text = run("csv", written(BUDGET), "--sheet", "Left", "--formulas")
        self.assertIn("=B1-B2", text)

    def test_reading_a_table_in(self):
        path = written("a,1\nb,2\n", "small.csv")
        code, text = run("read", path)
        self.assertEqual(code, OK)
        self.assertIn("trestle-book", text)

    def test_reading_a_table_into_a_file(self):
        path = written("a,1\nb,=A1\n", "small.csv")
        out = os.path.join(tempfile.mkdtemp(), "small.book")
        code, _ = run("read", path, "--out", out, "--name", "Costs")
        self.assertEqual(code, OK)
        code, text = run("value", out, "Costs!B2")
        self.assertEqual(text.strip(), "a")

    def test_a_table_that_is_not_there(self):
        self.assertEqual(run("read", "/no/such/table.csv")[0], USAGE)

    def test_a_book_given_as_a_table(self):
        path = written("a,1\nb,2\n", "small.csv")
        code, text = run("show", path)
        self.assertEqual(code, OK)
        self.assertIn("a", text)


class EvalTest(unittest.TestCase):
    def test_working_out_a_formula(self):
        code, text = run("eval", "=SUM(1,2,3)*2")
        self.assertEqual(code, OK)
        self.assertEqual(text.strip(), "12")

    def test_the_equals_sign_can_be_left_off(self):
        _, text = run("eval", "2+2")
        self.assertEqual(text.strip(), "4")

    def test_against_a_book(self):
        code, text = run("eval", "=Income!B4*2", "--book", written(BUDGET))
        self.assertEqual(code, OK)
        self.assertEqual(text.strip(), "6100")

    def test_a_formula_that_comes_to_an_error(self):
        code, text = run("eval", "=1/0")
        self.assertEqual(code, TROUBLE)
        self.assertEqual(text.strip(), "#DIV/0!")

    def test_a_formula_that_will_not_read(self):
        code, _ = run("eval", "=1+")
        self.assertEqual(code, USAGE)

    def test_a_book_that_is_not_there(self):
        self.assertEqual(run("eval", "=1", "--book", "/no/such/book")[0], USAGE)


class OtherTest(unittest.TestCase):
    def test_every_function(self):
        code, text = run("functions")
        self.assertEqual(code, OK)
        self.assertIn("VLOOKUP", text)

    def test_one_group_of_functions(self):
        _, text = run("functions", "logic")
        self.assertIn("IFERROR", text)
        self.assertNotIn("VLOOKUP", text)

    def test_a_group_nobody_has(self):
        self.assertEqual(run("functions", "dates")[0], USAGE)

    def test_the_worked_examples(self):
        code, text = run("demo")
        self.assertEqual(code, OK)
        self.assertIn("budget", text)

    def test_one_worked_example(self):
        code, text = run("demo", "marks")
        self.assertEqual(code, OK)
        self.assertIn("Grades:", text)

    def test_an_example_nobody_has(self):
        self.assertEqual(run("demo", "chess")[0], USAGE)


class ProcessTest(unittest.TestCase):
    def test_it_runs_as_a_module(self):
        finished = subprocess.run(
            [sys.executable, "-m", "trestle", "show", "budget", "--sheet", "Left"],
            cwd=ROOT, capture_output=True, text=True,
        )
        self.assertEqual(finished.returncode, OK)
        self.assertIn("1090", finished.stdout)

    def test_a_book_with_an_error_answers_three(self):
        path = written(TROUBLE_BOOK)
        finished = subprocess.run(
            [sys.executable, "-m", "trestle", "calc", path],
            cwd=ROOT, capture_output=True, text=True,
        )
        self.assertEqual(finished.returncode, TROUBLE)


class DiffTest(unittest.TestCase):
    """Comparing two books from the command line."""

    def setUp(self):
        self.directory = tempfile.mkdtemp()
        self.first = os.path.join(self.directory, "before.book")
        self.second = os.path.join(self.directory, "after.book")
        with open(self.first, "w", encoding="utf-8") as handle:
            handle.write(demo_text("budget"))
        raised = demo_text("budget").replace("  B2 2400", "  B2 2600")
        with open(self.second, "w", encoding="utf-8") as handle:
            handle.write(raised)

    def tearDown(self):
        shutil.rmtree(self.directory, ignore_errors=True)

    def test_a_book_against_itself_comes_back_clean(self):
        code, said = run("diff", self.first, self.first)
        self.assertEqual(code, 0)
        self.assertIn("the two books are the same", said)

    def test_a_book_against_a_changed_one_comes_back_one(self):
        code, said = run("diff", self.first, self.second)
        self.assertEqual(code, 1)
        self.assertIn("Income!B2", said)

    def test_it_says_what_the_change_did_further_down(self):
        code, said = run("diff", self.first, self.second)
        self.assertIn("Left!B3", said)
        self.assertIn("1290", said)

    def test_one_kind_of_change_at_a_time(self):
        code, said = run("diff", self.first, self.second, "--only", "typed")
        self.assertIn("Income!B2", said)
        self.assertNotIn("Left!B3", said)

    def test_a_kind_of_change_that_does_not_exist(self):
        code, said = run("diff", self.first, self.second, "--only", "moved")
        self.assertEqual(code, 2)

    def test_an_example_can_be_one_side_of_it(self):
        code, said = run("diff", "budget", self.second)
        self.assertEqual(code, 1)

    def test_a_second_book_that_is_not_there(self):
        """The same as a first book that is not there: the command line was wrong."""
        code, said = run("diff", self.first, os.path.join(self.directory, "nope.book"))
        self.assertEqual(code, USAGE)
        self.assertIn("no such book", said)

    def test_it_renders_as_a_table(self):
        code, said = run("diff", self.first, self.second, "--format", "markdown")
        self.assertIn("| Cell | Change |", said)
