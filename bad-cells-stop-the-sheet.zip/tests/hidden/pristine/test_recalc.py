"""Working a sheet out, and working out only what changed."""

import unittest

from trestle.errors import RecalcError
from trestle.graph import links_of
from trestle.recalc import Dirty, Pass, Step, Trace, downstream, recalculate, recalculated_after
from trestle.sheet import Sheet
from trestle.values import CYCLE, blank, error, number, text


def a_sheet():
    """A sheet with a chain of formulas in it."""
    return Sheet("Main", {"A1": 10, "A2": 20, "A3": "=SUM(A1:A2)", "B3": "=A3*2"})


def at(sheet, where):
    """One address of a sheet."""
    return sheet.address_of(where)


class RecalculateTest(unittest.TestCase):
    def setUp(self):
        self.sheet = a_sheet()
        self.pass_ = recalculate(self.sheet)

    def test_every_formula_is_worked_out(self):
        self.assertEqual(self.pass_.cells, 2)

    def test_the_values_are_put_in_the_cells(self):
        self.assertEqual(self.sheet.value_at(at(self.sheet, "A3")), number(30))
        self.assertEqual(self.sheet.value_at(at(self.sheet, "B3")), number(60))

    def test_a_cell_reading_another_is_worked_out_after_it(self):
        held = self.pass_.trace.addresses()
        self.assertEqual([one.written(False) for one in held], ["A3", "B3"])

    def test_the_cells_that_changed(self):
        self.assertEqual(len(self.pass_.changed()), 2)

    def test_working_it_out_again_changes_nothing(self):
        again = recalculate(self.sheet)
        self.assertEqual(len(again.changed()), 0)

    def test_the_answer_of_a_cell(self):
        self.assertEqual(self.pass_.value_at("A3"), number(30))

    def test_a_sheet_with_no_formulas(self):
        held = recalculate(Sheet("Main", {"A1": 1}))
        self.assertTrue(held.trace.is_empty)

    def test_an_empty_sheet(self):
        self.assertEqual(recalculate(Sheet("Empty")).cells, 0)

    def test_working_out_something_that_is_not_a_sheet(self):
        with self.assertRaises(RecalcError):
            recalculate("Main")

    def test_the_counts(self):
        counts = self.pass_.counts()
        self.assertEqual(counts["worked out"], 2)
        self.assertEqual(counts["cycles"], 0)

    def test_a_summary(self):
        self.assertIn("2 cells worked out", self.pass_.summary())


class ErrorTest(unittest.TestCase):
    def test_a_formula_that_gives_an_error(self):
        held = Sheet("Main", {"A1": "=1/0"})
        answer = recalculate(held)
        self.assertEqual(answer.value_at("A1"), error("#DIV/0!"))
        self.assertEqual(len(answer.errors()), 1)

    def test_an_error_spreads_to_what_reads_it(self):
        held = Sheet("Main", {"A1": "=1/0", "A2": "=A1+1"})
        answer = recalculate(held)
        self.assertEqual(answer.value_at("A2"), error("#DIV/0!"))

    def test_a_cell_that_reads_itself(self):
        held = Sheet("Main", {"A1": "=A1+1"})
        answer = recalculate(held)
        self.assertTrue(answer.has_cycle)
        self.assertEqual(answer.value_at("A1"), error(CYCLE))

    def test_two_cells_that_read_each_other(self):
        held = Sheet("Main", {"A1": "=B1", "B1": "=A1"})
        answer = recalculate(held)
        self.assertEqual(len(answer.cycles), 2)
        self.assertEqual(answer.value_at("B1"), error(CYCLE))

    def test_the_cycle_error_reaches_what_reads_it(self):
        held = Sheet("Main", {"A1": "=B1", "B1": "=A1", "C1": "=A1+1"})
        answer = recalculate(held)
        self.assertEqual(answer.value_at("C1"), error(CYCLE))

    def test_the_rest_of_the_sheet_is_still_worked_out(self):
        held = Sheet("Main", {"A1": "=B1", "B1": "=A1", "D1": 2, "E1": "=D1*3"})
        answer = recalculate(held)
        self.assertEqual(answer.value_at("E1"), number(6))

    def test_a_formula_that_will_not_read_is_left_as_it_was(self):
        held = Sheet("Main", {"A1": "=1+"})
        answer = recalculate(held)
        self.assertTrue(answer.trace.is_empty)
        self.assertTrue(held.cell_at("A1").is_broken)


class ChangeTest(unittest.TestCase):
    def setUp(self):
        self.sheet = a_sheet()
        recalculate(self.sheet)

    def test_changing_a_cell_works_out_what_reads_it(self):
        self.sheet.put("A1", 100)
        held = recalculated_after(self.sheet, ["A1"])
        self.assertEqual(held.value_at("A3"), number(120))
        self.assertEqual(held.value_at("B3"), number(240))

    def test_only_what_had_to_be_worked_out_was(self):
        self.sheet.put("A1", 100)
        held = recalculated_after(self.sheet, ["A1"])
        self.assertEqual(held.cells, 2)

    def test_changing_a_cell_nothing_reads(self):
        self.sheet.put("Z9", 1)
        held = recalculated_after(self.sheet, ["Z9"])
        self.assertEqual(held.cells, 0)

    def test_changing_a_formula_works_it_out(self):
        self.sheet.put("A3", "=A1*3")
        held = recalculated_after(self.sheet, ["A3"])
        self.assertEqual(held.value_at("A3"), number(30))
        self.assertEqual(held.value_at("B3"), number(60))

    def test_working_out_some_cells_only(self):
        self.sheet.put("A1", 100)
        held = recalculate(self.sheet, only=[at(self.sheet, "A3")])
        self.assertEqual(held.value_at("A3"), number(120))
        self.assertEqual(held.value_at("B3"), number(60))

    def test_changing_something_that_is_not_a_sheet(self):
        with self.assertRaises(RecalcError):
            recalculated_after("Main", ["A1"])


class DirtyTest(unittest.TestCase):
    def setUp(self):
        self.sheet = a_sheet()
        self.links = links_of(self.sheet)

    def test_marking_a_cell_marks_what_reads_it(self):
        held = Dirty(self.links).mark(at(self.sheet, "A1"))
        self.assertEqual(
            [one.written(False) for one in held], ["A1", "A3", "B3"]
        )

    def test_marking_without_spreading(self):
        held = Dirty(self.links).mark(at(self.sheet, "A1"), spread=False)
        self.assertEqual(len(held), 1)

    def test_the_cells_that_were_changed(self):
        held = Dirty(self.links).mark(at(self.sheet, "A1"))
        self.assertEqual([one.written(False) for one in held.roots()], ["A1"])

    def test_marking_everything(self):
        held = Dirty(self.links).everything()
        self.assertEqual(len(held), 2)

    def test_marking_everything_with_no_graph(self):
        with self.assertRaises(RecalcError):
            Dirty().everything()

    def test_forgetting_one(self):
        held = Dirty(self.links).mark(at(self.sheet, "A1"))
        held.forget(at(self.sheet, "A3"))
        self.assertNotIn(at(self.sheet, "A3"), held)

    def test_clearing_it(self):
        held = Dirty(self.links).mark(at(self.sheet, "A1")).clear()
        self.assertTrue(held.is_empty)

    def test_marking_something_that_is_not_an_address(self):
        with self.assertRaises(RecalcError):
            Dirty(self.links).mark("A1")

    def test_what_follows_from_a_change(self):
        held = downstream(self.links, [at(self.sheet, "A1")])
        self.assertEqual([one.written(False) for one in held], ["A3", "B3"])

    def test_what_follows_in_something_that_is_not_a_graph(self):
        with self.assertRaises(RecalcError):
            downstream("links", [])

    def test_the_counts(self):
        held = Dirty(self.links).mark(at(self.sheet, "A1"))
        self.assertEqual(held.counts(), {"dirty": 3, "changed": 1})


class TraceTest(unittest.TestCase):
    def setUp(self):
        self.sheet = a_sheet()
        self.trace = recalculate(self.sheet).trace

    def test_a_step_for_every_cell(self):
        self.assertEqual(len(self.trace), 2)

    def test_a_step_says_what_changed(self):
        held = self.trace[0]
        self.assertTrue(held.changed)
        self.assertEqual(held.before, blank())
        self.assertEqual(held.after, number(30))

    def test_the_line_a_step_reads_as(self):
        self.assertIn("Main!A3: blank -> 30", self.trace.lines())

    def test_a_step_that_changed_nothing(self):
        again = recalculate(self.sheet).trace
        self.assertFalse(again[0].changed)
        self.assertEqual(again[0].describe(), "Main!A3: 30")

    def test_looking_up_one_cell(self):
        self.assertIsNotNone(self.trace.at(at(self.sheet, "A3")))
        self.assertIsNone(self.trace.at(at(self.sheet, "Z9")))

    def test_the_rows_for_a_table(self):
        rows = self.trace.rows()
        self.assertEqual(rows[0][1], "Main!A3")
        self.assertEqual(rows[0][2], "=SUM(A1:A2)")

    def test_an_empty_trace(self):
        held = Trace()
        self.assertTrue(held.is_empty)
        self.assertEqual(held.counts()["worked out"], 0)


class TraceLookupTest(unittest.TestCase):
    """Finding one cell in a trace, which is a lookup rather than a walk."""

    def setUp(self):
        self.sheet = Sheet("Main", {"A1": 1, "A2": "=A1+1", "A3": "=A2+1"})
        self.pass_ = recalculate(self.sheet)

    def test_a_cell_that_was_worked_out_is_found(self):
        held = self.pass_.trace.at(self.sheet.address_of("A2"))
        self.assertIsNotNone(held)
        self.assertEqual(held.after.written(), "2")

    def test_a_cell_that_was_not_worked_out_is_not_found(self):
        self.assertIsNone(self.pass_.trace.at(self.sheet.address_of("A1")))

    def test_a_cell_that_is_not_in_the_sheet_is_not_found(self):
        self.assertIsNone(self.pass_.trace.at(self.sheet.address_of("Z9")))

    def test_a_step_added_afterwards_is_found(self):
        where = self.sheet.address_of("B1")
        self.pass_.trace.add(Step(where, blank(), number(7), "=7"))
        self.assertEqual(self.pass_.trace.at(where).after, number(7))

    def test_a_cell_in_a_cycle_is_found(self):
        sheet = Sheet("Main", {"A1": "=A1+1"})
        held = recalculate(sheet)
        step = held.trace.at(sheet.address_of("A1"))
        self.assertEqual(step.after.written(), "#CYCLE!")

    def test_the_trace_is_still_in_the_order_it_happened(self):
        self.assertEqual(
            [one.at.written(False) for one in self.pass_.trace], ["A2", "A3"]
        )
