"""The worked examples, read and worked out."""

import unittest

from trestle.book import Book
from trestle.demo import (
    BOOKS,
    NOTES,
    demo_book,
    demo_names,
    demo_review,
    demo_text,
    demo_trace,
    note_of,
)
from trestle.errors import TrestleError
from trestle.store import read_book
from trestle.values import CYCLE, DIVIDED, MISSING, NAME, REFERENCE, WRONG, error, number, text


class ExampleTest(unittest.TestCase):
    def test_there_are_five(self):
        self.assertEqual(len(demo_names()), 5)
        self.assertEqual(len(BOOKS), 5)

    def test_every_one_reads(self):
        for name in demo_names():
            with self.subTest(example=name):
                self.assertIsInstance(demo_book(name), Book)

    def test_every_one_says_what_it_is(self):
        for name in demo_names():
            with self.subTest(example=name):
                self.assertGreater(len(note_of(name)), 20)

    def test_the_notes_and_the_books_are_the_same_set(self):
        self.assertEqual(sorted(NOTES), sorted(BOOKS))

    def test_one_nobody_has(self):
        with self.assertRaises(TrestleError):
            demo_text("chess")
        with self.assertRaises(TrestleError):
            note_of("chess")

    def test_the_name_is_read_however_it_is_written(self):
        self.assertEqual(demo_text("BUDGET"), demo_text("budget"))

    def test_a_book_is_read_once_and_shared(self):
        self.assertIs(demo_book("budget"), demo_book("budget"))

    def test_asking_for_it_again_reads_it_again(self):
        self.assertIsNot(demo_book("budget", again=True), demo_book("budget", again=True))


class BudgetTest(unittest.TestCase):
    def setUp(self):
        self.book = demo_book("budget")

    def test_the_three_sheets(self):
        self.assertEqual(self.book.names(), ("Income", "Spending", "Left"))

    def test_what_comes_in(self):
        self.assertEqual(self.book.value_at("Income!B4"), number(3050))

    def test_what_goes_out(self):
        self.assertEqual(self.book.value_at("Spending!B6"), number(1960))

    def test_what_is_left(self):
        self.assertEqual(self.book.value_at("Left!B3"), number(1090))

    def test_the_share_spent(self):
        self.assertEqual(self.book.value_at("Left!B4"), number(64.3))

    def test_nothing_is_wrong_with_it(self):
        self.assertTrue(demo_review("budget").is_clean)


class InvoiceTest(unittest.TestCase):
    def setUp(self):
        self.book = demo_book("invoice")

    def test_a_line_is_the_price_times_the_count(self):
        self.assertEqual(self.book.value_at("Lines!D2"), number(39))

    def test_the_subtotal(self):
        self.assertEqual(self.book.value_at("Lines!D6"), number(89))

    def test_the_tax_comes_from_the_other_sheet(self):
        self.assertEqual(self.book.value_at("Lines!D7"), number(17.8))

    def test_the_total(self):
        self.assertEqual(self.book.value_at("Lines!D8"), number(106.8))

    def test_changing_the_rate_changes_the_total(self):
        held = demo_book("invoice", again=True)
        held.put("Rates!B2", 0.1)
        held.recalculate()
        self.assertEqual(held.value_at("Lines!D8"), number(97.9))


class LoanTest(unittest.TestCase):
    def setUp(self):
        self.book = demo_book("loan")

    def test_the_payment(self):
        self.assertEqual(self.book.value_at("Terms!B5"), number(430.33))

    def test_each_month_starts_where_the_last_one_ended(self):
        self.assertEqual(
            self.book.value_at("Months!B3"), self.book.value_at("Months!E2")
        )

    def test_the_debt_goes_down(self):
        first = self.book.value_at("Months!E2").held
        last = self.book.value_at("Months!E4").held
        self.assertLess(last, first)

    def test_the_interest_is_worked_out_on_what_is_owed(self):
        self.assertGreater(self.book.value_at("Months!C2").held, 0)


class MarksTest(unittest.TestCase):
    def setUp(self):
        self.book = demo_book("marks")

    def test_a_mark_becomes_a_grade(self):
        self.assertEqual(self.book.value_at("Marks!C2"), text("A"))
        self.assertEqual(self.book.value_at("Marks!C3"), text("F"))
        self.assertEqual(self.book.value_at("Marks!C4"), text("B"))

    def test_who_passed(self):
        self.assertEqual(self.book.value_at("Marks!D2"), text("yes"))
        self.assertEqual(self.book.value_at("Marks!D3"), text("no"))

    def test_the_highest_and_the_mean(self):
        self.assertEqual(self.book.value_at("Marks!B6"), number(82))
        self.assertEqual(self.book.value_at("Marks!B7"), number(64.7))

    def test_how_many_passed(self):
        self.assertEqual(self.book.value_at("Marks!B8"), number(2))


class TroubleTest(unittest.TestCase):
    def setUp(self):
        self.book = demo_book("trouble")

    def test_dividing_by_nought(self):
        self.assertEqual(self.book.value_at("Sheet1!A3"), error(DIVIDED))

    def test_adding_text_to_a_number(self):
        self.assertEqual(self.book.value_at("Sheet1!A4"), error(WRONG))

    def test_a_function_nobody_has(self):
        self.assertEqual(self.book.value_at("Sheet1!A5"), error(NAME))

    def test_two_cells_that_need_each_other(self):
        self.assertEqual(self.book.value_at("Sheet1!A6"), error(CYCLE))
        self.assertEqual(self.book.value_at("Sheet1!B6"), error(CYCLE))

    def test_a_sheet_that_is_not_there(self):
        self.assertEqual(self.book.value_at("Sheet1!A7"), error(REFERENCE))

    def test_a_lookup_that_finds_nothing(self):
        self.assertEqual(self.book.value_at("Sheet1!A8"), error(MISSING))

    def test_a_formula_that_will_not_read(self):
        self.assertTrue(self.book.first().cell_at("A9").is_broken)

    def test_the_review_notices_all_of_it(self):
        held = demo_review("trouble")
        self.assertFalse(held.is_clean)
        self.assertGreater(len(held.of_level("warning")), 5)


class TraceTest(unittest.TestCase):
    def test_working_one_out_from_the_start(self):
        held = demo_trace("budget")
        self.assertGreater(len(held), 3)
        self.assertEqual(len(held.errors()), 0)

    def test_the_same_example_works_out_the_same_way_twice(self):
        first = [one.at.written() for one in demo_trace("budget")]
        again = [one.at.written() for one in demo_trace("budget")]
        self.assertEqual(first, again)

    def test_every_example_reads_back_from_its_own_text(self):
        for name in demo_names():
            with self.subTest(example=name):
                held = read_book(demo_text(name))
                self.assertGreater(len(held), 0)
