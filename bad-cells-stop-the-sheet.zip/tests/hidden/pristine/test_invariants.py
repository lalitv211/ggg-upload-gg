"""Properties that hold of every book, however it was written.

These are not examples. Each one takes every worked example, works it out, and
asserts something the rest of the package leans on: that working it out twice
changes nothing, that every formula reads back into the formula it was, that
inserting a row moves the references with the cells, and that a book saved and
read again comes to the same answers.
"""

import unittest

from trestle.demo import demo_book, demo_names, demo_text
from trestle.formula import parse, references_in, rendered_cell
from trestle.graph import links_of, order_of
from trestle.recalc import recalculate
from trestle.sheet import Sheet, inserted_columns, inserted_rows
from trestle.store import (
    compared_books,
    digest_of_book,
    digest_of_values,
    read_book,
    write_book,
)
from trestle.values import Value


def books():
    """Every worked example, read and worked out from the start."""
    for name in demo_names():
        held = read_book(demo_text(name), name)
        held.recalculate()
        yield name, held


class WorkedOutTest(unittest.TestCase):
    def test_working_one_out_twice_changes_nothing(self):
        for name, held in books():
            trace = held.recalculate()
            with self.subTest(example=name):
                self.assertEqual(len(trace.changed()), 0)

    def test_two_readings_of_one_book_come_to_the_same(self):
        for name in demo_names():
            first = read_book(demo_text(name))
            first.recalculate()
            second = read_book(demo_text(name))
            second.recalculate()
            with self.subTest(example=name):
                self.assertEqual(digest_of_values(first), digest_of_values(second))

    def test_every_formula_has_been_given_a_value(self):
        for name, held in books():
            for sheet in held.sheets():
                for where, cell in sheet.formulas():
                    with self.subTest(example=name, cell=where.written()):
                        self.assertIsInstance(cell.value, Value)
                        self.assertFalse(cell.value.is_span)

    def test_no_cell_holds_a_span(self):
        for name, held in books():
            for sheet in held.sheets():
                for where, cell in sheet.cells():
                    with self.subTest(example=name, cell=where.written()):
                        self.assertTrue(cell.value.fits_in_a_cell)

    def test_nothing_is_worked_out_before_what_it_reads(self):
        for name, held in books():
            links = held.links()
            order = order_of(links)
            for one in order:
                for other in links.reads(one):
                    if other in order:
                        with self.subTest(example=name, cell=one.written()):
                            self.assertTrue(order.before(other, one))

    def test_every_cell_in_the_order_holds_a_formula(self):
        for name, held in books():
            for one in held.order():
                sheet = held.sheet_named(one.sheet)
                with self.subTest(example=name, cell=one.written()):
                    self.assertTrue(sheet.cell_at(one.without_sheet()).is_formula)


class FormulaTest(unittest.TestCase):
    def test_every_formula_reads_back_into_the_same_tree(self):
        """What the renderer writes reads back into the formula it was.

        Not into the same text: the renderer puts a space after each comma and
        somebody typing does not, so the text is normalised while the meaning is
        not.
        """
        for name, held in books():
            for sheet in held.sheets():
                for where, cell in sheet.formulas():
                    with self.subTest(example=name, cell=where.written()):
                        self.assertEqual(parse(rendered_cell(cell.tree)), cell.tree)

    def test_writing_a_formula_out_twice_gives_the_same_text(self):
        for name, held in books():
            for sheet in held.sheets():
                for where, cell in sheet.formulas():
                    once = rendered_cell(cell.tree)
                    with self.subTest(example=name, cell=where.written()):
                        self.assertEqual(rendered_cell(parse(once)), once)

    def test_every_reference_a_formula_makes_is_read_from_it(self):
        for name, held in books():
            links = held.links()
            for sheet in held.sheets():
                for where, cell in sheet.formulas():
                    wanted = references_in(cell.tree)
                    with self.subTest(example=name, cell=where.written()):
                        self.assertEqual(
                            len(links.spans_of(where.in_sheet(sheet.name))),
                            len([one for one in wanted if hasattr(one, "first")]),
                        )


class FileTest(unittest.TestCase):
    def test_every_book_round_trips_through_a_file(self):
        for name, held in books():
            again = read_book(write_book(held))
            with self.subTest(example=name):
                self.assertEqual(digest_of_book(again), digest_of_book(held))

    def test_a_book_read_back_comes_to_the_same_answers(self):
        for name, held in books():
            again = read_book(write_book(held))
            again.recalculate()
            with self.subTest(example=name):
                self.assertEqual(digest_of_values(again), digest_of_values(held))

    def test_writing_a_book_twice_gives_the_same_text(self):
        for name, held in books():
            with self.subTest(example=name):
                self.assertEqual(write_book(held), write_book(held))

    def test_no_value_is_written_to_the_file(self):
        for name, held in books():
            text = write_book(held)
            with self.subTest(example=name):
                self.assertEqual(text.count("\n"), len(text.splitlines()))


class EditTest(unittest.TestCase):
    """Moving cells about does not change what the book comes to."""

    def sheets(self):
        """Every sheet of every worked example that holds a formula."""
        for name, held in books():
            for sheet in held.sheets():
                if sheet.formulas():
                    yield "%s.%s" % (name, sheet.name), sheet

    def test_inserting_a_row_above_everything_keeps_the_answers(self):
        for name, sheet in self.sheets():
            before = {
                where.written(False): cell.value
                for where, cell in sheet.cells()
                if not cell.is_formula
            }
            after = inserted_rows(sheet.copy(), 1)
            recalculate(after)
            moved = {
                where.offset(0, -1).written(False): cell.value
                for where, cell in after.cells()
                if not cell.is_formula
            }
            with self.subTest(sheet=name):
                self.assertEqual(moved, before)

    def test_inserting_a_row_keeps_the_formulas_pointing_at_the_same_cells(self):
        for name, sheet in self.sheets():
            first = recalculate(sheet.copy())
            after = inserted_rows(sheet.copy(), 1)
            second = recalculate(after)
            before = sorted(one.after.written() for one in first.trace)
            following = sorted(one.after.written() for one in second.trace)
            with self.subTest(sheet=name):
                self.assertEqual(following, before)

    def test_inserting_a_column_keeps_the_answers(self):
        for name, sheet in self.sheets():
            first = recalculate(sheet.copy())
            after = inserted_columns(sheet.copy(), 1)
            second = recalculate(after)
            before = sorted(one.after.written() for one in first.trace)
            following = sorted(one.after.written() for one in second.trace)
            with self.subTest(sheet=name):
                self.assertEqual(following, before)


class CountTest(unittest.TestCase):
    def test_the_order_holds_every_formula_that_is_not_in_a_cycle(self):
        for name, held in books():
            order = held.order()
            formulas = sum(len(one.formulas()) for one in held.sheets())
            broken = sum(len(one.broken()) for one in held.sheets())
            with self.subTest(example=name):
                self.assertEqual(len(order) + len(order.stuck), formulas - 0)
                self.assertGreaterEqual(formulas, len(order))
                self.assertEqual(broken, sum(len(one.broken()) for one in held.sheets()))

    def test_every_link_names_a_cell_that_holds_something(self):
        for name, held in books():
            links = held.links()
            for one in links.cells:
                for other in links.reads(one):
                    with self.subTest(example=name, cell=one.written()):
                        self.assertIn(other, links.filled)


class ComparisonTest(unittest.TestCase):
    """Comparing a book with one that came from it.

    A comparison and the two digests answer the same question two ways, so they
    have to agree, on every book, whichever way it was got hold of.
    """

    def test_a_book_is_the_same_as_itself(self):
        for name, held in books():
            with self.subTest(example=name):
                self.assertTrue(compared_books(held, held).is_empty)

    def test_a_book_is_the_same_as_the_one_read_back_from_its_file(self):
        for name, held in books():
            again = read_book(write_book(held))
            again.recalculate()
            with self.subTest(example=name):
                self.assertTrue(compared_books(held, again).is_empty)

    def test_a_comparison_that_is_empty_means_the_digests_agree(self):
        for name, held in books():
            again = read_book(write_book(held))
            again.recalculate()
            with self.subTest(example=name):
                self.assertEqual(digest_of_book(held), digest_of_book(again))
                self.assertEqual(digest_of_values(held), digest_of_values(again))

    def test_typing_into_one_cell_makes_a_comparison_that_is_not_empty(self):
        for name, held in books():
            other = demo_book(name, again=True)
            other.recalculate()
            sheet = other.first()
            other.put("Z99", 1, sheet.name)
            with self.subTest(example=name):
                found = compared_books(held, other)
                self.assertEqual(len(found), 1)
                self.assertEqual(found.counts()["added"], 1)

    def test_every_change_names_a_cell_one_of_the_books_holds(self):
        for name, held in books():
            other = demo_book(name, again=True)
            other.recalculate()
            for change in compared_books(held, other):
                with self.subTest(example=name, cell=change.at.written()):
                    self.fail("two copies of the same example differ")

    def test_what_changed_is_what_was_typed_or_what_it_came_to(self):
        """Nothing is in a comparison for no reason at all."""
        for name, held in books():
            other = demo_book(name, again=True)
            other.put("A1", "=1+1", other.first().name)
            other.recalculate()
            for change in compared_books(held, other):
                with self.subTest(example=name, cell=change.at.written()):
                    self.assertTrue(change.is_typed or change.is_worked_out)
