"""Which cell reads which, and the order that follows from it."""

import unittest

from trestle.errors import GraphError
from trestle.graph import Links, Order, cycles_in, in_a_cycle, links_of, order_of, reaches
from trestle.refs import read_address
from trestle.sheet import Sheet


def a_sheet():
    """A sheet where each cell reads the one before it."""
    return Sheet("Main", {"A1": 1, "A2": "=A1+1", "A3": "=SUM(A1:A2)", "B1": "=A3*2"})


def at(sheet, where):
    """One address of a sheet."""
    return sheet.address_of(where)


class LinkTest(unittest.TestCase):
    def setUp(self):
        self.sheet = a_sheet()
        self.links = links_of(self.sheet)

    def test_only_the_formulas_read_anything(self):
        self.assertEqual(len(self.links), 3)

    def test_every_filled_cell_is_noted(self):
        self.assertEqual(len(self.links.filled), 4)

    def test_what_one_cell_reads(self):
        held = self.links.reads(at(self.sheet, "A3"))
        self.assertEqual([one.written(False) for one in held], ["A1", "A2"])

    def test_what_reads_one_cell(self):
        held = self.links.read_by(at(self.sheet, "A1"))
        self.assertEqual([one.written(False) for one in held], ["A2", "A3"])

    def test_a_cell_that_reads_nothing_filled(self):
        held = Sheet("Main", {"A1": "=SUM(Z1:Z9)"})
        self.assertEqual(links_of(held).reads(at(held, "A1")), ())

    def test_the_rectangles_a_cell_reads(self):
        held = self.links.spans_of(at(self.sheet, "A3"))
        self.assertEqual([one.written(False) for one in held], ["A1:A2"])

    def test_a_rectangle_is_not_opened_out(self):
        held = Sheet("Main", {"A1": 1, "B1": "=SUM(A1:A1000)"})
        links = links_of(held)
        self.assertEqual(len(links.reads(at(held, "B1"))), 1)

    def test_the_edges(self):
        self.assertEqual(len(self.links.edges()), 4)

    def test_the_cells_that_read_nothing(self):
        held = [one.written(False) for one in self.links.leaves()]
        self.assertEqual(held, [])

    def test_the_counts(self):
        counts = self.links.counts()
        self.assertEqual(counts["cells"], 3)
        self.assertEqual(counts["filled"], 4)
        self.assertEqual(counts["spans"], 1)

    def test_a_graph_of_something_that_is_not_a_sheet(self):
        with self.assertRaises(GraphError):
            links_of("Main")

    def test_noting_against_something_that_is_not_an_address(self):
        with self.assertRaises(GraphError):
            Links().note("A1", None)

    def test_asking_about_a_cell_that_is_not_there(self):
        self.assertEqual(self.links.reads(read_address("Z9")), ())
        self.assertEqual(self.links.spans_of(read_address("Z9")), ())

    def test_what_it_says_about_itself(self):
        self.assertIn("3 cells reading", str(self.links))


class CycleTest(unittest.TestCase):
    def test_a_sheet_with_no_cycle(self):
        self.assertEqual(cycles_in(links_of(a_sheet())), ())
        self.assertEqual(in_a_cycle(links_of(a_sheet())), ())

    def test_two_cells_that_read_each_other(self):
        held = Sheet("Main", {"A1": "=B1", "B1": "=A1"})
        groups = cycles_in(links_of(held))
        self.assertEqual(len(groups), 1)
        self.assertEqual([one.written(False) for one in groups[0]], ["A1", "B1"])

    def test_a_cell_that_reads_itself(self):
        held = Sheet("Main", {"A1": "=A1+1"})
        self.assertEqual(len(cycles_in(links_of(held))), 1)

    def test_a_longer_ring(self):
        held = Sheet("Main", {"A1": "=A2", "A2": "=A3", "A3": "=A1"})
        groups = cycles_in(links_of(held))
        self.assertEqual(len(groups[0]), 3)

    def test_two_rings_at_once(self):
        held = Sheet("Main", {"A1": "=A2", "A2": "=A1", "B1": "=B2", "B2": "=B1"})
        self.assertEqual(len(cycles_in(links_of(held))), 2)

    def test_a_cell_reading_a_ring_is_not_in_it(self):
        held = Sheet("Main", {"A1": "=A2", "A2": "=A1", "C1": "=A1"})
        self.assertNotIn(at(held, "C1"), in_a_cycle(links_of(held)))

    def test_a_cycle_through_a_range(self):
        held = Sheet("Main", {"A1": "=SUM(A2:A3)", "A2": 1, "A3": "=A1"})
        self.assertEqual(len(cycles_in(links_of(held))), 1)

    def test_whether_one_cell_reaches_another(self):
        held = a_sheet()
        links = links_of(held)
        self.assertTrue(reaches(links, at(held, "B1"), at(held, "A1")))
        self.assertFalse(reaches(links, at(held, "A1"), at(held, "B1")))

    def test_looking_for_cycles_in_something_else(self):
        with self.assertRaises(GraphError):
            cycles_in("links")


class OrderTest(unittest.TestCase):
    def setUp(self):
        self.sheet = a_sheet()
        self.order = order_of(links_of(self.sheet))

    def test_every_formula_is_in_the_order(self):
        self.assertEqual([one.written(False) for one in self.order], ["A2", "A3", "B1"])

    def test_nothing_comes_before_what_it_reads(self):
        for held in self.order:
            for other in links_of(self.sheet).reads(held):
                if other in self.order:
                    with self.subTest(cell=held.written(False)):
                        self.assertTrue(self.order.before(other, held))

    def test_a_cell_holding_a_number_is_not_in_the_order(self):
        self.assertIsNone(self.order.position(at(self.sheet, "A1")))

    def test_where_a_cell_falls(self):
        self.assertEqual(self.order.position(at(self.sheet, "A2")), 0)

    def test_the_order_of_an_empty_sheet(self):
        held = order_of(links_of(Sheet("Empty")))
        self.assertTrue(held.is_empty)

    def test_the_same_sheet_orders_the_same_way_twice(self):
        again = order_of(links_of(a_sheet()))
        self.assertEqual(list(again), list(self.order))

    def test_cells_in_a_cycle_are_left_out(self):
        held = Sheet("Main", {"A1": "=B1", "B1": "=A1", "C1": 1})
        order = order_of(links_of(held))
        self.assertTrue(order.has_cycle)
        self.assertEqual([one.written(False) for one in order.stuck], ["A1", "B1"])

    def test_a_cell_reading_a_cycle_is_still_worked_out(self):
        held = Sheet("Main", {"A1": "=B1", "B1": "=A1", "C1": "=A1"})
        order = order_of(links_of(held))
        self.assertEqual([one.written(False) for one in order], ["C1"])

    def test_the_counts(self):
        self.assertEqual(self.order.counts(), {"ordered": 3, "stuck": 0})

    def test_what_it_says_about_itself(self):
        self.assertEqual(str(self.order), "3 cells")
        held = order_of(links_of(Sheet("Main", {"A1": "=A1"})))
        self.assertIn("in a cycle", str(held))

    def test_an_order_of_something_that_is_not_a_graph(self):
        with self.assertRaises(GraphError):
            order_of("links")

    def test_comparing_two_cells_that_are_not_both_in_it(self):
        self.assertFalse(self.order.before(at(self.sheet, "A1"), at(self.sheet, "A2")))


class KeptAnswerTest(unittest.TestCase):
    """A graph keeps what it worked out, so what it keeps has to stay true.

    Three questions are answered once and kept: what settling an address came
    to, which cells name each address, and what one cell reads. The first can
    never go stale, because an address never changes. The other two go stale
    the moment something is noted against the graph or filled in, and these are
    the tests that say so.
    """

    def test_what_a_cell_reads_is_the_same_answer_twice(self):
        held = links_of(a_sheet())
        where = at(a_sheet(), "A3").in_sheet("Main")
        self.assertEqual(held.reads(where), held.reads(where))

    def test_filling_a_cell_inside_a_rectangle_changes_what_is_read(self):
        sheet = Sheet("Main", {"A1": 1, "B1": "=SUM(A1:A3)"})
        held = links_of(sheet)
        before = held.reads(at(sheet, "B1"))
        held.fill(at(sheet, "A2"))
        after = held.reads(at(sheet, "B1"))
        self.assertEqual(len(before), 1)
        self.assertEqual(len(after), 2)

    def test_noting_a_new_formula_changes_what_reads_a_cell(self):
        sheet = Sheet("Main", {"A1": 1, "B1": "=A1"})
        held = links_of(sheet)
        self.assertEqual(len(held.read_by(at(sheet, "A1"))), 1)
        sheet.put("C1", "=A1*2")
        held.note(at(sheet, "C1"), sheet.cell_at(at(sheet, "C1")).tree)
        self.assertEqual(len(held.read_by(at(sheet, "A1"))), 2)

    def test_noting_a_formula_changes_what_a_cell_reads(self):
        sheet = Sheet("Main", {"A1": 1, "A2": 2, "B1": "=A1"})
        held = links_of(sheet)
        self.assertEqual(len(held.reads(at(sheet, "B1"))), 1)
        sheet.put("B1", "=A1+A2")
        held.note(at(sheet, "B1"), sheet.cell_at(at(sheet, "B1")).tree)
        self.assertEqual(len(held.reads(at(sheet, "B1"))), 2)

    def test_a_cell_that_holds_nothing_is_still_read_by_something(self):
        sheet = Sheet("Main", {"B1": "=A1+1"})
        held = links_of(sheet)
        self.assertEqual(held.reads(at(sheet, "B1")), ())
        self.assertEqual(len(held.read_by(at(sheet, "A1"))), 1)

    def test_a_cell_inside_a_rectangle_is_read_by_the_formula_over_it(self):
        sheet = Sheet("Main", {"A1": 1, "B1": "=SUM(A1:A9)"})
        held = links_of(sheet)
        self.assertEqual(len(held.read_by(at(sheet, "A7"))), 1)

    def test_the_same_cell_named_twice_is_only_read_by_one_thing(self):
        sheet = Sheet("Main", {"A1": 1, "B1": "=A1+SUM(A1:A9)"})
        held = links_of(sheet)
        self.assertEqual(len(held.read_by(at(sheet, "A1"))), 1)

    def test_an_address_written_with_dollars_settles_to_the_same_cell(self):
        sheet = Sheet("Main", {"A1": 1, "B1": "=$A$1"})
        held = links_of(sheet)
        self.assertEqual(len(held.read_by(read_address("$A$1", None, "Main"))), 1)
        self.assertEqual(len(held.read_by(read_address("A1", None, "Main"))), 1)


class InTheOrderTest(unittest.TestCase):
    """Asking an order about one cell, which is a lookup rather than a walk."""

    def setUp(self):
        self.sheet = a_sheet()
        self.order = order_of(links_of(self.sheet))

    def test_a_formula_cell_is_in_it(self):
        self.assertIn(at(self.sheet, "A2").in_sheet("Main"), self.order)

    def test_a_cell_holding_a_number_is_not(self):
        self.assertNotIn(at(self.sheet, "A1").in_sheet("Main"), self.order)

    def test_a_cell_that_is_not_in_the_sheet_is_not(self):
        self.assertNotIn(at(self.sheet, "Z9").in_sheet("Main"), self.order)

    def test_something_that_is_not_a_cell_is_not(self):
        self.assertNotIn("A2", self.order)

    def test_where_a_cell_falls_is_the_same_answer_twice(self):
        where = at(self.sheet, "A3").in_sheet("Main")
        self.assertEqual(self.order.position(where), self.order.position(where))

    def test_a_cell_in_a_cycle_is_not_in_the_order(self):
        sheet = Sheet("Main", {"A1": "=A1+1"})
        order = order_of(links_of(sheet))
        self.assertNotIn(at(sheet, "A1").in_sheet("Main"), order)
        self.assertIn(at(sheet, "A1").in_sheet("Main"), order.stuck)
