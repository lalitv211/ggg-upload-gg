"""Reports: rows, renderings, the grid and the review."""

import unittest

from trestle.book import Book
from trestle.errors import TrestleError
from trestle.graph import links_of, order_of
from trestle.recalc import Trace, recalculate
from trestle.report import (
    CHECKS,
    Finding,
    RENDERINGS,
    Report,
    Review,
    cells_report,
    check_names,
    formulas_report,
    functions_report,
    grid_lines,
    grid_report,
    links_report,
    order_report,
    review,
    review_report,
    sheets_report,
    summary_lines,
    summary_report,
    trace_report,
    values_report,
    widths_of,
)
from trestle.sheet import Sheet


def a_sheet():
    """A small sheet with a heading, some numbers and a total."""
    return Sheet(
        "Costs",
        {"A1": "item", "B1": "cost", "A2": "nails", "B2": 1.5, "A3": "glue", "B3": 4,
         "A4": "total", "B4": "=SUM(B2:B3)"},
    )


def a_book():
    """A book with one worked out sheet in it."""
    held = Book("Budget")
    held.add(a_sheet())
    held.recalculate()
    return held


class ReportTest(unittest.TestCase):
    def setUp(self):
        self.report = Report("Cells", ("Cell", "Value"), [("A1", "1"), ("A2", "2")], ("two",))

    def test_what_it_holds(self):
        self.assertEqual(len(self.report), 2)
        self.assertFalse(self.report.is_empty)

    def test_a_column(self):
        self.assertEqual(self.report.column(0), ("A1", "A2"))

    def test_a_column_that_is_not_there(self):
        with self.assertRaises(TrestleError):
            self.report.column(5)

    def test_a_row_that_is_too_wide(self):
        with self.assertRaises(TrestleError):
            Report("x", ("a",), [("1", "2")])

    def test_adding_a_note(self):
        self.assertEqual(len(self.report.with_notes("more").notes), 2)

    def test_the_three_renderings(self):
        self.assertTrue(self.report.as_text().startswith("Cells"))
        self.assertTrue(self.report.as_markdown().startswith("## Cells"))
        self.assertTrue(self.report.as_csv().startswith("Cell,Value"))

    def test_rendering_by_name(self):
        for how in RENDERINGS:
            with self.subTest(how=how):
                self.assertTrue(self.report.render(how))

    def test_a_rendering_nobody_has(self):
        with self.assertRaises(TrestleError):
            self.report.render("html")


class GridTest(unittest.TestCase):
    def setUp(self):
        self.sheet = a_sheet()
        recalculate(self.sheet)

    def test_the_letters_are_along_the_top(self):
        lines = grid_lines(self.sheet)
        self.assertIn("A", lines[0])
        self.assertIn("B", lines[0])

    def test_the_numbers_are_down_the_side(self):
        lines = grid_lines(self.sheet)
        self.assertTrue(lines[2].strip().startswith("1"))

    def test_a_row_for_every_row_of_the_sheet(self):
        self.assertEqual(len(grid_lines(self.sheet)), 6)

    def test_the_values_are_shown(self):
        self.assertIn("5.5", "\n".join(grid_lines(self.sheet)))

    def test_the_formulas_can_be_shown_instead(self):
        self.assertIn("=SUM(B2:B3)", "\n".join(grid_lines(self.sheet, formulas=True)))

    def test_part_of_a_sheet(self):
        self.assertEqual(len(grid_lines(self.sheet, over="A1:B2")), 4)

    def test_an_empty_sheet(self):
        self.assertEqual(grid_lines(Sheet("Empty")), ())

    def test_the_rule_is_as_wide_as_the_widest_line(self):
        lines = grid_lines(self.sheet)
        self.assertEqual(len(lines[1]), max(len(one) for one in lines))

    def test_the_numbers_can_be_left_off(self):
        lines = grid_lines(self.sheet, numbers=False)
        self.assertFalse(lines[2].startswith(" "))

    def test_what_is_too_wide_is_cut(self):
        held = Sheet("S", {"A1": "a very long piece of text indeed, far too long"})
        lines = grid_lines(held, widest=10)
        self.assertIn("...", lines[2])

    def test_a_column_narrower_than_nothing(self):
        with self.assertRaises(TrestleError):
            widths_of(self.sheet, self.sheet.used(), widest=1)

    def test_drawing_something_that_is_not_a_sheet(self):
        with self.assertRaises(TrestleError):
            grid_lines("Costs")

    def test_the_grid_as_a_report(self):
        held = grid_report(self.sheet)
        self.assertEqual(held.headers, ("Row", "A", "B"))
        self.assertEqual(len(held.rows), 4)

    def test_the_grid_of_an_empty_sheet_as_a_report(self):
        self.assertIn("This sheet is empty.", grid_report(Sheet("Empty")).notes)


class TableTest(unittest.TestCase):
    def setUp(self):
        self.book = a_book()
        self.sheet = self.book.first()

    def test_the_cells(self):
        held = cells_report(self.sheet)
        self.assertEqual(len(held.rows), 8)
        self.assertEqual(held.rows[0][0], "A1")

    def test_part_of_the_cells(self):
        self.assertEqual(len(cells_report(self.sheet, over="A1:B1").rows), 2)

    def test_a_cell_table_of_something_else(self):
        with self.assertRaises(TrestleError):
            cells_report("Costs")

    def test_the_formulas(self):
        held = formulas_report(self.sheet)
        self.assertEqual(len(held.rows), 1)
        self.assertIn("B2:B3", held.rows[0][2])

    def test_the_broken_formulas_are_counted(self):
        self.sheet.put("C1", "=1+")
        self.assertIn("1 cell would not read", formulas_report(self.sheet).notes)

    def test_what_kinds_of_value_are_in_it(self):
        held = values_report(self.sheet)
        kinds = dict((row[0], row[1]) for row in held.rows)
        self.assertEqual(kinds["number"], "2")
        self.assertEqual(kinds["formula"], "1")

    def test_the_sheets_of_a_book(self):
        held = sheets_report(self.book)
        self.assertEqual(held.rows[0][0], "Costs")
        self.assertEqual(held.rows[0][1], "A1:B4")

    def test_a_sheet_table_of_something_else(self):
        with self.assertRaises(TrestleError):
            sheets_report("Budget")

    def test_a_book_naming_a_sheet_that_is_not_there(self):
        self.book.put("Costs!C1", "=Nowhere!A1")
        self.assertTrue(any("not there" in one for one in sheets_report(self.book).notes))

    def test_the_trace(self):
        held = trace_report(recalculate(self.sheet).trace)
        self.assertIsInstance(held, Report)

    def test_the_trace_cut_short(self):
        trace = recalculate(self.sheet).trace
        held = trace_report(trace, most=0)
        self.assertEqual(len(held.rows), 0)

    def test_what_reads_what(self):
        held = links_report(links_of(self.sheet))
        self.assertEqual(held.rows[0][1], "2")

    def test_the_order(self):
        held = order_report(order_of(links_of(self.sheet)))
        self.assertEqual(len(held.rows), 1)

    def test_the_order_when_there_is_a_cycle(self):
        held = Sheet("S", {"A1": "=A1"})
        report = order_report(order_of(links_of(held)))
        self.assertTrue(any("in a cycle" in one for one in report.notes))

    def test_the_functions(self):
        self.assertGreater(len(functions_report().rows), 70)

    def test_the_functions_of_one_group(self):
        held = functions_report("logic")
        self.assertGreater(len(held.rows), 5)
        self.assertLess(len(held.rows), 20)


class ReviewTest(unittest.TestCase):
    def test_a_clean_book(self):
        held = review(a_book())
        self.assertTrue(held.is_clean)
        self.assertEqual(held.summary(), "0 warnings, 0 notices")

    def test_a_cell_holding_an_error(self):
        book = Book("B")
        book.add(Sheet("S", {"A1": "=1/0"}))
        book.recalculate()
        held = review(book)
        self.assertEqual(len(held.of_check("errors")), 1)

    def test_a_formula_that_will_not_read(self):
        book = Book("B")
        book.add(Sheet("S", {"A1": "=1+"}))
        self.assertEqual(len(review(book).of_check("unreadable")), 1)

    def test_a_cell_that_needs_itself(self):
        book = Book("B")
        book.add(Sheet("S", {"A1": "=A1"}))
        self.assertEqual(len(review(book).of_check("cycles")), 1)

    def test_a_formula_naming_a_sheet_that_is_not_there(self):
        book = Book("B")
        book.add(Sheet("S", {"A1": "=Nowhere!A1"}))
        self.assertEqual(len(review(book).of_check("missing-sheet")), 1)

    def test_a_formula_that_reads_nothing(self):
        book = Book("B")
        book.add(Sheet("S", {"A1": "=2+2"}))
        self.assertEqual(len(review(book).of_check("constant-formula")), 1)

    def test_a_formula_nobody_will_read_twice(self):
        book = Book("B")
        book.add(Sheet("S", {"A1": "=" + "+".join(["B%d" % one for one in range(1, 30)])}))
        self.assertEqual(len(review(book).of_check("long-formula")), 1)

    def test_a_cell_on_its_own(self):
        book = Book("B")
        book.add(Sheet("S", {"A1": 1, "A2": 2, "Z9": 3}))
        self.assertEqual(len(review(book).of_check("lonely-cell")), 1)

    def test_a_number_written_into_a_formula(self):
        book = Book("B")
        book.add(Sheet("S", {"A1": 1, "A2": "=A1*1.075"}))
        self.assertEqual(len(review(book).of_check("written-in-number")), 1)

    def test_the_ordinary_numbers_are_left_alone(self):
        book = Book("B")
        book.add(Sheet("S", {"A1": 1, "A2": "=A1*2", "A3": "=A1+1"}))
        self.assertEqual(review(book).of_check("written-in-number"), ())

    def test_running_one_check_only(self):
        book = Book("B")
        book.add(Sheet("S", {"A1": "=1/0", "A2": "=2+2"}))
        book.recalculate()
        held = review(book, only=["errors"])
        self.assertEqual(len(held), 1)

    def test_a_check_nobody_has(self):
        with self.assertRaises(TrestleError):
            review(a_book(), only=["nonsense"])

    def test_reviewing_something_that_is_not_a_book(self):
        with self.assertRaises(TrestleError):
            review("Budget")

    def test_every_check_is_named(self):
        self.assertEqual(sorted(check_names()), sorted(CHECKS))

    def test_a_level_nobody_has(self):
        with self.assertRaises(TrestleError):
            Finding("errors", "disaster", "A1", "x")

    def test_the_findings_come_back_worst_first(self):
        book = Book("B")
        book.add(Sheet("S", {"A1": "=1/0", "A2": "=2+2"}))
        book.recalculate()
        held = list(review(book))
        self.assertEqual(tuple(held)[0].level, "warning")

    def test_as_a_report(self):
        book = Book("B")
        book.add(Sheet("S", {"A1": "=1/0"}))
        book.recalculate()
        self.assertEqual(len(review_report(review(book)).rows), 2)

    def test_a_clean_report_says_so(self):
        self.assertIn("Nothing to say about this book.", review_report(review(a_book())).notes)


class SummaryTest(unittest.TestCase):
    def setUp(self):
        self.book = a_book()

    def test_the_lines(self):
        lines = summary_lines(self.book)
        self.assertTrue(lines[0].startswith("book:"))
        self.assertTrue(any(one.startswith("sheet Costs:") for one in lines))
        self.assertTrue(any(one.startswith("review:") for one in lines))

    def test_with_a_trace(self):
        trace = self.book.recalculate()
        self.assertTrue(any(one.startswith("worked out:") for one in summary_lines(self.book, trace)))

    def test_the_errors_are_named(self):
        self.book.put("Costs!C1", "=1/0")
        self.book.recalculate()
        self.assertTrue(any("#DIV/0!" in one for one in summary_lines(self.book)))

    def test_a_summary_of_something_that_is_not_a_book(self):
        with self.assertRaises(TrestleError):
            summary_lines("Budget")

    def test_as_a_report(self):
        self.assertEqual(summary_report(self.book).rows[0][0], "book")


class OddOneOutTest(unittest.TestCase):
    """One cell in a filled run that is not the fill of the rest.

    This is the check that finds the mistake nobody sees: a column of formulas
    filled down, one of them overtyped, and the whole thing still working out.
    """

    def looked_over(self, text, name="Q"):
        """What the check says about a sheet written out as a book."""
        from trestle import Desk

        desk = Desk.of_text(text)
        desk.recalculate()
        return desk.review(["odd-one-out"])

    def a_column(self, third):
        """Four cells down a column, the third of them whatever is given."""
        return (
            "trestle-book 1\nname Sales\nsheet Q\n"
            "  A1 10\n  A2 20\n  A3 30\n  A4 40\n"
            "  B1 =A1*2\n  B2 =A2*2\n  B3 %s\n  B4 =A4*2\n" % third
        )

    def test_a_column_that_was_filled_all_the_way_down(self):
        self.assertEqual(len(self.looked_over(self.a_column("=A3*2"))), 0)

    def test_one_cell_in_the_middle_that_was_not(self):
        held = self.looked_over(self.a_column("=A3*3"))
        self.assertEqual(len(held), 1)
        self.assertEqual(tuple(held)[0].where, "Q!B3")
        self.assertEqual(tuple(held)[0].level, "warning")

    def test_it_says_which_way_the_run_goes(self):
        self.assertIn("down this column", tuple(self.looked_over(self.a_column("=A3*3")))[0].message)

    def test_a_cell_reading_the_wrong_row(self):
        self.assertEqual(len(self.looked_over(self.a_column("=A2*2"))), 1)

    def test_a_cell_held_still_when_the_rest_are_not(self):
        self.assertEqual(len(self.looked_over(self.a_column("=$A$3*2"))), 1)

    def test_a_total_at_the_bottom_is_not_the_odd_one(self):
        held = self.looked_over(self.a_column("=A3*2").replace("  B4 =A4*2", "  B4 =SUM(B1:B3)"))
        self.assertEqual(len(held), 0)

    def test_an_opening_figure_at_the_top_is_not_the_odd_one(self):
        held = self.looked_over(self.a_column("=A3*2").replace("  B1 =A1*2", "  B1 =A1+100"))
        self.assertEqual(len(held), 0)

    def test_a_run_of_two_is_not_a_pattern(self):
        held = self.looked_over(
            "trestle-book 1\nname Sales\nsheet Q\n  A1 1\n  A2 2\n  B1 =A1*2\n  B2 =A2*3\n"
        )
        self.assertEqual(len(held), 0)

    def test_a_run_nobody_filled_says_nothing(self):
        held = self.looked_over(
            "trestle-book 1\nname Sales\nsheet Q\n"
            "  A1 1\n  A2 2\n  A3 3\n  A4 4\n"
            "  B1 =A1*2\n  B2 =A2*3\n  B3 =A3*4\n  B4 =A4*5\n"
        )
        self.assertEqual(len(held), 0)

    def test_two_runs_with_a_gap_between_them(self):
        held = self.looked_over(
            "trestle-book 1\nname Sales\nsheet Q\n"
            "  A1 1\n  A2 2\n  A3 3\n  A5 5\n  A6 6\n  A7 7\n  A8 8\n"
            "  B1 =A1*2\n  B2 =A2*2\n  B3 =A3*2\n"
            "  B5 =A5*2\n  B6 =A6*9\n  B7 =A7*2\n  B8 =A8*2\n"
        )
        self.assertEqual(len(held), 1)
        self.assertEqual(tuple(held)[0].where, "Q!B6")

    def test_a_run_along_a_row(self):
        held = self.looked_over(
            "trestle-book 1\nname Sales\nsheet Q\n"
            "  A1 1\n  B1 2\n  C1 3\n  D1 4\n"
            "  A2 =A1*2\n  B2 =B1*2\n  C2 =C1*7\n  D2 =D1*2\n"
        )
        self.assertEqual(len(held), 1)
        self.assertIn("along this row", tuple(held)[0].message)

    def test_a_sheet_with_no_formulas_in_it(self):
        held = self.looked_over("trestle-book 1\nname Sales\nsheet Q\n  A1 1\n  A2 2\n")
        self.assertEqual(len(held), 0)

    def test_none_of_the_worked_examples_trips_it(self):
        from trestle import Desk
        from trestle.demo import BOOKS

        for name in sorted(BOOKS):
            with self.subTest(book=name):
                desk = Desk.demo(name)
                desk.recalculate()
                self.assertEqual(desk.review(["odd-one-out"]).of_level("warning"), ())
