"""Plain English and plain columns."""

import unittest

from trestle.plain import (
    columns,
    counted,
    indented,
    listed,
    plural,
    ruled,
    shortened,
    table,
    wrapped,
)


class WordTest(unittest.TestCase):
    def test_one_of_a_thing(self):
        self.assertEqual(plural("cell", 1), "cell")

    def test_none_or_several(self):
        self.assertEqual(plural("cell", 0), "cells")
        self.assertEqual(plural("cell", 3), "cells")

    def test_a_word_that_hisses_takes_es(self):
        self.assertEqual(plural("address", 2), "addresses")
        self.assertEqual(plural("box", 2), "boxes")
        self.assertEqual(plural("address", 1), "address")

    def test_counting(self):
        self.assertEqual(counted(1, "sheet"), "1 sheet")
        self.assertEqual(counted(0, "sheet"), "0 sheets")

    def test_listing_nothing_one_two_and_three(self):
        self.assertEqual(listed([]), "")
        self.assertEqual(listed(["a"]), "a")
        self.assertEqual(listed(["a", "b"]), "a and b")
        self.assertEqual(listed(["a", "b", "c"]), "a, b and c")

    def test_another_joiner(self):
        self.assertEqual(listed(["a", "b"], "or"), "a or b")


class CuttingTest(unittest.TestCase):
    def test_text_that_fits(self):
        self.assertEqual(shortened("=SUM(A1:A9)", 20), "=SUM(A1:A9)")

    def test_text_that_does_not(self):
        self.assertEqual(shortened("abcdefghij", 8), "abcde...")

    def test_never_wider_than_asked_for(self):
        for width in range(1, 12):
            with self.subTest(width=width):
                self.assertLessEqual(len(shortened("abcdefghij", width)), width)

    def test_a_width_of_nothing(self):
        with self.assertRaises(ValueError):
            shortened("abc", 0)

    def test_wrapping_on_spaces(self):
        self.assertEqual(wrapped("one two three four", 8), ("one two", "three", "four"))

    def test_a_word_longer_than_the_width(self):
        self.assertEqual(wrapped("a supercalifragilistic b", 6), ("a", "supercalifragilistic", "b"))

    def test_wrapping_nothing(self):
        self.assertEqual(wrapped("", 10), ())


class LayoutTest(unittest.TestCase):
    def test_indenting(self):
        self.assertEqual(indented(["a", "", "b"]), ("  a", "", "  b"))

    def test_a_negative_indent(self):
        with self.assertRaises(ValueError):
            indented(["a"], -1)

    def test_columns_run_across_the_row(self):
        self.assertEqual(columns(["a", "b", "c", "d"], 2), ("a  b", "c  d"))

    def test_a_short_last_row(self):
        self.assertEqual(columns(["a", "b", "c"], 2), ("a  b", "c"))

    def test_no_columns_at_all(self):
        with self.assertRaises(ValueError):
            columns(["a"], 0)

    def test_a_rule_is_as_wide_as_the_line(self):
        self.assertEqual(ruled("abcd"), "----")

    def test_a_rule_needs_something_to_draw_with(self):
        with self.assertRaises(ValueError):
            ruled("abcd", "")


class TableTest(unittest.TestCase):
    rows = [("A1", "=SUM(B1:B9)", "45"), ("A2", "12", "12")]

    def test_a_heading_a_rule_and_a_row_each(self):
        lines = table(("Cell", "Input", "Value"), self.rows)
        self.assertEqual(len(lines), 4)
        self.assertTrue(set(lines[1]) <= {"-"})

    def test_the_columns_line_up(self):
        lines = table(("Cell", "Input", "Value"), self.rows)
        self.assertEqual(lines[2].index("=SUM"), lines[3].index("12"))

    def test_numbers_can_sit_against_the_right(self):
        lines = table(("A", "B"), [("1", "22222"), ("2", "3")], right=(1,))
        self.assertTrue(lines[3].endswith("3"))

    def test_a_short_row_is_padded(self):
        lines = table(("A", "B", "C"), [("1",)])
        self.assertEqual(lines[2].strip(), "1")

    def test_a_wider_gap(self):
        narrow = table(("A", "B"), [("1", "2")], gap=1)
        wide = table(("A", "B"), [("1", "2")], gap=4)
        self.assertLess(len(narrow[0]), len(wide[0]))

    def test_no_gap_at_all(self):
        with self.assertRaises(ValueError):
            table(("A", "B"), [("1", "2")], gap=0)

    def test_a_table_of_nothing(self):
        self.assertEqual(len(table(("A", "B"), [])), 2)
