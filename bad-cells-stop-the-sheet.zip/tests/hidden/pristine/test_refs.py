"""References: addresses, spans, reading them and moving them."""

import unittest

from trestle.errors import ReferenceError_
from trestle.refs import (
    COLUMNS,
    ROWS,
    Address,
    Span,
    bounding,
    column_letters,
    column_number,
    filled,
    is_address,
    is_column_letters,
    is_reference,
    is_span,
    moved,
    read_address,
    read_reference,
    read_span,
    removed_lines,
    shifted,
    span_of,
    split_sheet,
)


class ColumnTest(unittest.TestCase):
    def test_the_first_twenty_six(self):
        self.assertEqual(column_letters(1), "A")
        self.assertEqual(column_letters(26), "Z")

    def test_the_ones_after_that(self):
        self.assertEqual(column_letters(27), "AA")
        self.assertEqual(column_letters(52), "AZ")
        self.assertEqual(column_letters(53), "BA")

    def test_the_last_one(self):
        self.assertEqual(column_letters(COLUMNS), "XFD")

    def test_letters_back_to_numbers(self):
        for number in (1, 26, 27, 703, COLUMNS):
            with self.subTest(number=number):
                self.assertEqual(column_number(column_letters(number)), number)

    def test_the_case_does_not_matter(self):
        self.assertEqual(column_number("ab"), column_number("AB"))

    def test_a_column_outside_the_sheet(self):
        with self.assertRaises(ReferenceError_):
            column_letters(0)
        with self.assertRaises(ReferenceError_):
            column_letters(COLUMNS + 1)
        with self.assertRaises(ReferenceError_):
            column_number("XFE")

    def test_something_that_is_not_letters(self):
        with self.assertRaises(ReferenceError_):
            column_number("A1")
        self.assertFalse(is_column_letters("1"))
        self.assertTrue(is_column_letters("AA"))


class AddressTest(unittest.TestCase):
    def test_where_it_is(self):
        held = Address(1, 1)
        self.assertEqual((held.column, held.row), (1, 1))
        self.assertEqual(held.letters, "A")
        self.assertEqual(held.written(), "A1")

    def test_holding_parts_still(self):
        self.assertEqual(Address(1, 1, True, True).written(), "$A$1")
        self.assertEqual(Address(1, 1, True, False).written(), "$A1")
        self.assertEqual(Address(1, 1, False, True).written(), "A$1")

    def test_whether_it_is_held_still(self):
        self.assertTrue(Address(1, 1, True, True).is_fixed)
        self.assertTrue(Address(1, 1).is_loose)
        self.assertFalse(Address(1, 1, True).is_fixed)

    def test_a_sheet_of_its_own(self):
        held = Address(1, 1, sheet="Costs")
        self.assertTrue(held.has_sheet)
        self.assertEqual(held.written(), "Costs!A1")
        self.assertEqual(held.written(with_sheet=False), "A1")

    def test_taking_the_sheet_off(self):
        self.assertFalse(Address(1, 1, sheet="Costs").without_sheet().has_sheet)

    def test_moving_it(self):
        self.assertEqual(Address(1, 1).offset(1, 2), Address(2, 3))

    def test_the_plain_version_of_it(self):
        held = Address(1, 1, True, True, "Costs").plain()
        self.assertEqual(held, Address(1, 1))

    def test_outside_the_sheet(self):
        for column, row in ((0, 1), (1, 0), (COLUMNS + 1, 1), (1, ROWS + 1)):
            with self.subTest(column=column, row=row):
                with self.assertRaises(ReferenceError_):
                    Address(column, row)

    def test_two_addresses_compare_and_hash(self):
        self.assertEqual(Address(1, 1), Address(1, 1))
        self.assertLess(Address(1, 1), Address(1, 2))
        self.assertEqual(len({Address(1, 1), Address(1, 1)}), 1)

    def test_the_key_a_sheet_reads_them_by(self):
        self.assertEqual(Address(3, 2).key(), (2, 3))


class SpanTest(unittest.TestCase):
    def setUp(self):
        self.span = Span(Address(1, 1), Address(2, 10))

    def test_how_big_it_is(self):
        self.assertEqual((self.span.width, self.span.height, self.span.size), (2, 10, 20))
        self.assertEqual(len(self.span), 20)

    def test_the_corners_come_out_in_order(self):
        held = Span(Address(2, 10), Address(1, 1))
        self.assertEqual(held.first, Address(1, 1))
        self.assertEqual(held.last, Address(2, 10))

    def test_what_it_holds(self):
        self.assertTrue(self.span.holds(Address(2, 5)))
        self.assertFalse(self.span.holds(Address(3, 5)))
        self.assertIn(Address(1, 1), self.span)

    def test_the_cells_come_row_by_row(self):
        held = Span(Address(1, 1), Address(2, 2)).addresses()
        self.assertEqual([one.written() for one in held], ["A1", "B1", "A2", "B2"])

    def test_rows_and_columns(self):
        self.assertEqual(len(self.span.rows()), 10)
        self.assertEqual(len(self.span.columns()), 2)
        self.assertEqual(self.span.row_at(0)[0], Address(1, 1))
        self.assertEqual(self.span.column_at(1)[0], Address(2, 1))

    def test_a_row_that_is_not_there(self):
        with self.assertRaises(ReferenceError_):
            self.span.row_at(99)
        with self.assertRaises(ReferenceError_):
            self.span.column_at(99)

    def test_one_cell_on_its_own(self):
        held = span_of(Address(1, 1))
        self.assertTrue(held.is_one_cell)
        self.assertEqual(held.written(), "A1:A1")

    def test_a_row_and_a_column(self):
        self.assertTrue(Span(Address(1, 1), Address(5, 1)).is_row)
        self.assertTrue(Span(Address(1, 1), Address(1, 5)).is_column)

    def test_two_that_overlap(self):
        other = Span(Address(2, 5), Address(4, 8))
        self.assertTrue(self.span.overlaps(other))
        self.assertEqual(self.span.meeting(other).written(), "B5:B8")

    def test_two_that_do_not(self):
        other = Span(Address(5, 5), Address(6, 6))
        self.assertFalse(self.span.overlaps(other))
        self.assertIsNone(self.span.meeting(other))

    def test_a_span_cannot_cross_sheets(self):
        with self.assertRaises(ReferenceError_):
            Span(Address(1, 1, sheet="A"), Address(2, 2, sheet="B"))

    def test_a_span_of_something_that_is_not_an_address(self):
        with self.assertRaises(ReferenceError_):
            Span("A1", "B2")

    def test_moving_it_to_another_sheet(self):
        self.assertEqual(self.span.in_sheet("Costs").sheet, "Costs")

    def test_the_smallest_span_around_some_cells(self):
        held = bounding([Address(3, 4), Address(1, 9)])
        self.assertEqual(held.written(), "A4:C9")

    def test_the_smallest_span_around_nothing(self):
        self.assertIsNone(bounding([]))

    def test_cells_in_two_sheets_have_no_span(self):
        with self.assertRaises(ReferenceError_):
            bounding([Address(1, 1, sheet="A"), Address(2, 2, sheet="B")])


class ReadTest(unittest.TestCase):
    def test_a_plain_cell(self):
        self.assertEqual(read_address("B7"), Address(2, 7))

    def test_a_cell_held_still(self):
        held = read_address("$B$7")
        self.assertTrue(held.is_fixed)

    def test_a_cell_in_a_sheet(self):
        self.assertEqual(read_address("Costs!B7").sheet, "Costs")

    def test_a_sheet_whose_name_has_a_space(self):
        self.assertEqual(read_address("'Old Costs'!B7").sheet, "Old Costs")

    def test_the_case_of_the_column_does_not_matter(self):
        self.assertEqual(read_address("b7"), read_address("B7"))

    def test_something_that_is_not_a_cell(self):
        for text in ("", "7B", "A", "1", "A0", "hello"):
            with self.subTest(text=text):
                with self.assertRaises(ReferenceError_):
                    read_address(text)

    def test_a_span(self):
        self.assertEqual(read_span("A1:B10").written(), "A1:B10")

    def test_a_span_written_the_other_way_round(self):
        self.assertEqual(read_span("B10:A1").written(), "A1:B10")

    def test_a_span_in_a_sheet(self):
        self.assertEqual(read_span("Costs!A1:B2").sheet, "Costs")

    def test_a_single_cell_read_as_a_span(self):
        self.assertTrue(read_span("A1").is_one_cell)

    def test_a_span_missing_a_side(self):
        for text in ("A1:", ":B2"):
            with self.subTest(text=text):
                with self.assertRaises(ReferenceError_):
                    read_span(text)

    def test_a_span_that_crosses_sheets(self):
        with self.assertRaises(ReferenceError_):
            read_span("Costs!A1:Prices!B2")

    def test_either_kind(self):
        self.assertIsInstance(read_reference("A1"), Address)
        self.assertIsInstance(read_reference("A1:B2"), Span)

    def test_asking_what_something_is(self):
        self.assertTrue(is_address("A1"))
        self.assertFalse(is_address("A1:B2"))
        self.assertTrue(is_span("A1:B2"))
        self.assertFalse(is_span("A1"))
        self.assertTrue(is_reference("Costs!A1"))
        self.assertFalse(is_reference("hello"))

    def test_taking_the_sheet_off_some_text(self):
        self.assertEqual(split_sheet("Costs!A1"), ("Costs", "A1"))
        self.assertEqual(split_sheet("A1"), ("", "A1"))
        self.assertEqual(split_sheet("'Old Costs'!A1"), ("Old Costs", "A1"))


class FillTest(unittest.TestCase):
    def test_a_loose_reference_moves(self):
        self.assertEqual(moved(read_address("A1"), 2, 3), read_address("C4"))

    def test_a_column_held_still_does_not(self):
        self.assertEqual(moved(read_address("$A1"), 2, 3).written(), "$A4")

    def test_a_row_held_still_does_not(self):
        self.assertEqual(moved(read_address("A$1"), 2, 3).written(), "C$1")

    def test_a_reference_held_still_altogether(self):
        self.assertEqual(moved(read_address("$A$1"), 5, 5).written(), "$A$1")

    def test_filling_off_the_sheet(self):
        with self.assertRaises(ReferenceError_):
            moved(read_address("A1"), -1, 0)

    def test_filling_a_span(self):
        self.assertEqual(filled(read_span("A1:B2"), 1, 1).written(), "B2:C3")

    def test_filling_something_that_is_not_a_reference(self):
        with self.assertRaises(ReferenceError_):
            moved("A1", 1, 1)


class ShiftTest(unittest.TestCase):
    def test_a_row_below_an_insertion_moves_down(self):
        self.assertEqual(shifted(read_address("A5"), 3, 2).written(), "A7")

    def test_a_row_above_it_stays(self):
        self.assertEqual(shifted(read_address("A2"), 3, 2).written(), "A2")

    def test_a_column_insertion(self):
        self.assertEqual(shifted(read_address("C1"), 2, 1, columns=True).written(), "D1")

    def test_a_row_that_is_removed_has_nowhere_to_point(self):
        self.assertIsNone(shifted(read_address("A3"), 3, -1))

    def test_a_row_below_a_removal_moves_up(self):
        self.assertEqual(shifted(read_address("A5"), 3, -2).written(), "A3")

    def test_a_reference_held_still_moves_anyway(self):
        self.assertEqual(shifted(read_address("A$5"), 3, 1).written(), "A$6")

    def test_a_line_counted_from_nought(self):
        with self.assertRaises(ReferenceError_):
            shifted(read_address("A1"), 0)

    def test_a_span_that_grows(self):
        self.assertEqual(removed_lines(read_span("A1:A10"), 5, 2).written(), "A1:A12")

    def test_a_span_that_shrinks(self):
        self.assertEqual(removed_lines(read_span("A1:A10"), 5, -2).written(), "A1:A8")

    def test_a_span_that_is_removed_altogether(self):
        self.assertIsNone(removed_lines(read_span("A5:A6"), 5, -2))

    def test_shifting_something_that_is_not_a_span(self):
        with self.assertRaises(ReferenceError_):
            removed_lines(read_address("A1"), 1)
