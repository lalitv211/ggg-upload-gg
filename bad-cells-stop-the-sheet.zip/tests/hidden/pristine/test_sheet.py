"""Sheets: cells, the grid, editing it and finding the blocks in it."""

import unittest

from trestle.errors import SheetError
from trestle.evaluate import evaluate
from trestle.refs import read_address, read_span
from trestle.sheet import (
    Cell,
    Sheet,
    around,
    blocks,
    cell_of,
    column_headers,
    filled_across,
    inserted_columns,
    inserted_rows,
    is_formula_text,
    moved_block,
    removed_columns,
    removed_rows,
    row_headers,
)
from trestle.values import NAME, blank, error, number, text


def a_sheet():
    """A small sheet with numbers, a formula and a note."""
    return Sheet("Main", {"A1": 10, "A2": 20, "A3": "=SUM(A1:A2)", "B1": "note"})


class CellTest(unittest.TestCase):
    def test_a_plain_number(self):
        held = cell_of("12")
        self.assertFalse(held.is_formula)
        self.assertEqual(held.value, number(12))
        self.assertEqual(held.text, "12")

    def test_a_piece_of_text(self):
        self.assertEqual(cell_of("hello").value, text("hello"))

    def test_a_formula(self):
        held = cell_of("=1+1")
        self.assertTrue(held.is_formula)
        self.assertEqual(held.value, blank())
        self.assertEqual(held.text, "=1+1")

    def test_a_formula_that_will_not_read(self):
        held = cell_of("=1+")
        self.assertFalse(held.is_formula)
        self.assertTrue(held.is_broken)
        self.assertEqual(held.value, error(NAME))
        self.assertEqual(held.text, "=1+")

    def test_a_cell_nobody_typed_in(self):
        self.assertTrue(cell_of("").is_blank)
        self.assertTrue(cell_of(None).is_blank)

    def test_asking_whether_text_is_a_formula(self):
        self.assertTrue(is_formula_text(" =1+1"))
        self.assertFalse(is_formula_text("1+1"))

    def test_what_a_cell_shows(self):
        self.assertEqual(cell_of("12").shown(), "12")
        self.assertEqual(cell_of("=1+1").shown(), "")

    def test_giving_a_cell_a_value(self):
        held = cell_of("=1+1").with_value(2)
        self.assertEqual(held.value, number(2))
        self.assertEqual(held.text, "=1+1")

    def test_throwing_the_value_away(self):
        self.assertTrue(cell_of("=1+1").with_value(2).cleared().value.is_blank)

    def test_a_formula_keeps_no_sheet_of_its_own(self):
        held = cell_of("=A1", sheet="Main")
        self.assertEqual(held.tree.address.sheet, "")


class GridTest(unittest.TestCase):
    def setUp(self):
        self.sheet = a_sheet()

    def test_what_it_holds(self):
        self.assertEqual(len(self.sheet), 4)
        self.assertEqual(self.sheet.counts()["formulas"], 1)

    def test_reading_a_cell(self):
        self.assertEqual(self.sheet.value_at(read_address("A1")), number(10))
        self.assertEqual(self.sheet.text_at("A3"), "=SUM(A1:A2)")

    def test_a_cell_nobody_typed_in(self):
        self.assertTrue(self.sheet.cell_at("Z9").is_blank)
        self.assertEqual(self.sheet.value_at(read_address("Z9")), blank())

    def test_typing_in_a_cell(self):
        self.sheet.put("C1", 5)
        self.assertEqual(self.sheet.value_at(read_address("C1")), number(5))

    def test_typing_nothing_takes_the_cell_away(self):
        self.sheet.put("A1", "")
        self.assertEqual(len(self.sheet), 3)

    def test_clearing_a_cell(self):
        self.sheet.clear("A1")
        self.assertNotIn("A1", self.sheet)

    def test_clearing_a_span(self):
        self.sheet.clear("A1:A3")
        self.assertEqual(len(self.sheet), 1)

    def test_the_cells_come_back_in_reading_order(self):
        held = [where.written(False) for where in self.sheet.addresses()]
        self.assertEqual(held, ["A1", "B1", "A2", "A3"])

    def test_the_rectangle_it_covers(self):
        self.assertEqual(self.sheet.used().written(False), "A1:B3")

    def test_the_rectangle_of_an_empty_sheet(self):
        self.assertIsNone(Sheet("Empty").used())

    def test_the_rows_and_columns_in_use(self):
        self.assertEqual(self.sheet.rows(), (1, 2, 3))
        self.assertEqual(self.sheet.columns(), (1, 2))

    def test_one_row_and_one_column(self):
        self.assertEqual(len(self.sheet.row_cells(1)), 2)
        self.assertEqual(len(self.sheet.column_cells(1)), 3)

    def test_the_values_of_a_span(self):
        held = self.sheet.values_in(read_span("A1:A2"))
        self.assertEqual([one.written() for row in held for one in row], ["10", "20"])

    def test_the_texts_of_a_span(self):
        held = self.sheet.texts_in("A1:A3")
        self.assertEqual(held[2][0], "=SUM(A1:A2)")

    def test_a_formula_can_be_worked_out_against_it(self):
        self.assertEqual(evaluate(self.sheet.cell_at("A3").tree, self.sheet), number(30))

    def test_a_copy_is_the_same_and_separate(self):
        held = self.sheet.copy()
        held.put("A1", 99)
        self.assertEqual(self.sheet.value_at(read_address("A1")), number(10))

    def test_renaming_it(self):
        held = self.sheet.renamed("Other")
        self.assertEqual(held.name, "Other")
        self.assertEqual(len(held), len(self.sheet))

    def test_the_broken_formulas(self):
        self.sheet.put("C1", "=1+")
        self.assertEqual(len(self.sheet.broken()), 1)

    def test_a_summary(self):
        self.assertIn("4 cells over A1:B3", self.sheet.summary())


class FillTest(unittest.TestCase):
    def test_filling_a_formula_across(self):
        held = Sheet("Main", {"A1": 1, "B1": 2, "A2": 10, "B2": 20, "A3": "=A1+A2"})
        filled_across(held, "A3", "A3:B3")
        self.assertEqual(held.text_at("B3"), "=B1+B2")

    def test_filling_a_plain_value(self):
        held = Sheet("Main", {"A1": "x"})
        filled_across(held, "A1", "A1:A3")
        self.assertEqual(held.text_at("A3"), "x")

    def test_the_first_cell_is_left_as_it_was(self):
        held = Sheet("Main", {"A1": 1, "A2": "=A1"})
        filled_across(held, "A2", "A2:A4")
        self.assertEqual(held.text_at("A2"), "=A1")

    def test_a_reference_held_still_does_not_move(self):
        held = Sheet("Main", {"A1": 1, "B1": "=$A$1"})
        filled_across(held, "B1", "B1:D1")
        self.assertEqual(held.text_at("D1"), "=$A$1")

    def test_filling_from_an_empty_cell(self):
        with self.assertRaises(SheetError):
            filled_across(Sheet("Main"), "A1", "A1:A3")


class InsertTest(unittest.TestCase):
    def setUp(self):
        self.sheet = a_sheet()

    def test_inserting_a_row_moves_the_cells_below(self):
        held = inserted_rows(self.sheet, 2)
        self.assertEqual(held.value_at(read_address("A3")), number(20))

    def test_inserting_a_row_rewrites_the_formulas(self):
        held = inserted_rows(self.sheet, 2)
        self.assertEqual(held.text_at("A4"), "=SUM(A1:A3)")

    def test_inserting_a_row_below_a_formula_leaves_it_alone(self):
        held = inserted_rows(self.sheet, 9)
        self.assertEqual(held.text_at("A3"), "=SUM(A1:A2)")

    def test_inserting_a_column(self):
        held = inserted_columns(self.sheet, 1)
        self.assertEqual(held.value_at(read_address("B1")), number(10))
        self.assertEqual(held.text_at("B3"), "=SUM(B1:B2)")

    def test_removing_a_row_moves_the_cells_up(self):
        held = removed_rows(self.sheet, 1)
        self.assertEqual(held.value_at(read_address("A1")), number(20))

    def test_removing_a_row_shrinks_a_span(self):
        held = removed_rows(self.sheet, 1)
        self.assertEqual(held.text_at("A2"), "=SUM(A1:A1)")

    def test_removing_the_row_a_formula_points_at(self):
        held = Sheet("Main", {"A1": 1, "B1": "=A1"})
        after = removed_rows(held, 1)
        self.assertEqual(after.text_at("A1") or after.text_at("B1"), "")

    def test_removing_a_column(self):
        held = removed_columns(self.sheet, 2)
        self.assertNotIn("B1", held)

    def test_inserting_none_at_all(self):
        for held in (inserted_rows, inserted_columns, removed_rows, removed_columns):
            with self.subTest(what=held.__name__):
                with self.assertRaises(SheetError):
                    held(self.sheet, 1, 0)


class MoveTest(unittest.TestCase):
    def test_moving_a_block(self):
        held = Sheet("Main", {"A1": 1, "A2": 2, "A3": "=A1+A2"})
        moved_block(held, "A1:A3", "C1")
        self.assertEqual(held.value_at(read_address("C1")), number(1))
        self.assertEqual(held.text_at("C3"), "=C1+C2")
        self.assertNotIn("A1", held)

    def test_moving_leaves_the_formulas_outside_alone(self):
        held = Sheet("Main", {"A1": 1, "B1": "=A1"})
        moved_block(held, "A1:A1", "C1")
        self.assertEqual(held.text_at("B1"), "=A1")


class RegionTest(unittest.TestCase):
    def setUp(self):
        self.sheet = Sheet("Main", {"A1": 1, "A2": 2, "B1": 3, "D5": "far", "E5": "away"})

    def test_the_blocks(self):
        held = blocks(self.sheet)
        self.assertEqual([one.written(False) for one in held], ["A1:B2", "D5:E5"])

    def test_the_block_around_a_cell(self):
        self.assertEqual(around(self.sheet, "A2").written(False), "A1:B2")

    def test_the_block_around_an_empty_cell(self):
        self.assertIsNone(around(self.sheet, "Z9"))

    def test_cells_that_touch_at_a_corner_are_one_block(self):
        held = Sheet("Main", {"A1": 1, "B2": 2})
        self.assertEqual(len(blocks(held)), 1)

    def test_an_empty_sheet_has_no_blocks(self):
        self.assertEqual(blocks(Sheet("Empty")), ())

    def test_the_headers_of_a_block(self):
        held = Sheet("Main", {"A1": "name", "B1": "cost", "A2": "x", "B2": 1})
        self.assertEqual(column_headers(held, "A1:B2"), ("name", "cost"))
        self.assertEqual(row_headers(held, "A1:B2"), ("name", "x"))
