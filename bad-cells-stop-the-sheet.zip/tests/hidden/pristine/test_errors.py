"""Failures: their codes, their places and the advice about them."""

import unittest

from trestle.errors import (
    ADVICE,
    BookError,
    CliError,
    FormulaError,
    FunctionError,
    GraphError,
    Place,
    RecalcError,
    ReferenceError_,
    SheetError,
    StoreError,
    TrestleError,
    ValueError_,
    advice_for,
    code_of,
    describe,
    known_codes,
    missing_advice,
    with_advice,
)


class PlaceTest(unittest.TestCase):
    def test_nowhere_at_all(self):
        self.assertTrue(Place().is_nowhere)
        self.assertEqual(str(Place()), "")

    def test_a_cell(self):
        self.assertEqual(str(Place(cell="B4")), "B4")

    def test_a_sheet_and_a_cell(self):
        self.assertEqual(str(Place("Costs", "B4")), "Costs!B4")

    def test_a_sheet_on_its_own(self):
        self.assertEqual(str(Place("Costs")), "sheet Costs")

    def test_a_file_and_a_line(self):
        self.assertEqual(str(Place(source="book.txt", line=12)), "book.txt line 12")

    def test_a_line_with_no_file(self):
        self.assertEqual(str(Place(line=12)), "line 12")

    def test_everything_at_once(self):
        held = Place("Costs", "B4", "book.txt", 12)
        self.assertEqual(str(held), "Costs!B4, book.txt line 12")

    def test_moving_to_another_cell(self):
        self.assertEqual(Place("Costs", "A1").at_cell("B2").cell, "B2")

    def test_moving_to_another_sheet(self):
        self.assertEqual(Place("Costs", "A1").in_sheet("Prices").sheet, "Prices")

    def test_moving_to_another_line(self):
        self.assertEqual(Place(source="book.txt").at_line(9).line, 9)

    def test_two_places_compare(self):
        self.assertLess(Place("A"), Place("B"))

    def test_a_line_below_zero(self):
        with self.assertRaises(ValueError):
            Place(line=-1)


class FailureTest(unittest.TestCase):
    def test_a_failure_carries_its_message(self):
        self.assertEqual(str(ValueError_("that is not a number")), "that is not a number")

    def test_a_failure_carries_its_place(self):
        held = FormulaError("no closing bracket", Place("Costs", "B4"))
        self.assertIn("Costs!B4", str(held))

    def test_a_place_can_be_attached_later(self):
        held = FormulaError("no closing bracket").at(Place(cell="B4"))
        self.assertEqual(held.place.cell, "B4")
        self.assertEqual(held.message, "no closing bracket")

    def test_every_failure_is_a_trestle_failure(self):
        for held in (ValueError_("x"), SheetError("x"), BookError("x"), CliError("x")):
            with self.subTest(kind=type(held).__name__):
                self.assertIsInstance(held, TrestleError)

    def test_every_kind_has_a_code_of_its_own(self):
        codes = [
            kind.code
            for kind in (
                ValueError_, ReferenceError_, FormulaError, FunctionError, SheetError,
                GraphError, RecalcError, BookError, StoreError, CliError,
            )
        ]
        self.assertEqual(len(codes), len(set(codes)))

    def test_the_code_of_a_failure(self):
        self.assertEqual(code_of(SheetError("x")), "sheet")

    def test_the_code_of_something_else(self):
        self.assertEqual(code_of(KeyError("x")), "unknown")

    def test_every_code_is_known(self):
        self.assertIn("sheet", known_codes())
        self.assertIn("trestle", known_codes())

    def test_a_failure_written_out(self):
        self.assertEqual(describe(BookError("no such sheet")), "book: no such sheet")


class AdviceTest(unittest.TestCase):
    def test_every_code_has_advice(self):
        self.assertEqual(missing_advice(), ())

    def test_advice_for_a_code(self):
        self.assertIn("column letter", advice_for("reference"))

    def test_advice_for_a_stranger(self):
        self.assertEqual(advice_for("weather"), "")

    def test_no_two_codes_share_a_line(self):
        self.assertEqual(len(set(ADVICE.values())), len(ADVICE))

    def test_the_message_comes_first_and_the_advice_under_it(self):
        said = with_advice(StoreError("this is not a sheet file"))
        self.assertTrue(said.startswith("store: this is not a sheet file"))
        self.assertEqual(len(said.splitlines()), 2)

    def test_another_joiner(self):
        self.assertIn(" -- ", with_advice(CliError("no such command"), " -- "))

    def test_a_failure_from_somewhere_else(self):
        self.assertTrue(with_advice(KeyError("x")).startswith("unknown:"))
