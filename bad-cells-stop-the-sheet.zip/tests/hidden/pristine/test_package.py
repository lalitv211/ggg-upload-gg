"""Rules about the source itself, checked by reading it.

Everything here reads the files rather than calling them: that a module does not
import from above it, that every public name says what it is for, that no line
runs off the side of a screen, and that nothing reaches for the clock, the
network or a random number. A sheet that worked out differently on a Tuesday
would be no use at all, and the way to keep that true is to make it impossible
rather than to remember it.
"""

import ast
import os
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PACKAGE = os.path.join(ROOT, "trestle")

#: What may import what. A module may import from a lower layer and no other.
LAYERS = {
    "plain": 0,
    "errors": 0,
    "values": 1,
    "refs": 2,
    "formula": 3,
    "functions": 4,
    "evaluate": 5,
    "sheet": 6,
    "graph": 7,
    "recalc": 8,
    "book": 9,
    "store": 10,
    "report": 11,
    "demo": 12,
    "__root__": 13,
    "cli": 14,
    "__main__": 15,
}

#: Things no module in this package may do.
FORBIDDEN = (
    "time.time(",
    "time.monotonic(",
    "datetime.now(",
    "random.",
    "os.environ",
    "urllib",
    "socket",
)

#: How wide a line may be.
WIDTH = 100


def source_files():
    """Every Python file in the package, sorted."""
    found = []
    for here, _, names in os.walk(PACKAGE):
        for name in sorted(names):
            if name.endswith(".py"):
                found.append(os.path.join(here, name))
    return sorted(found)


FILES = source_files()


def module_name(path):
    """The dotted name of a file in the package."""
    relative = os.path.relpath(path, ROOT)
    return relative[:-3].replace(os.sep, ".")


def top_package(name):
    """Which layer a module belongs to.

    A name of two parts is either a module sitting at the root of the package,
    such as ``trestle.session``, or one of the packages named in the table, such
    as ``trestle.errors``. The table settles which.
    """
    parts = name.split(".")
    if len(parts) < 2:
        return "__root__"
    if parts[1] == "__main__":
        return "__main__"
    if parts[1] in LAYERS:
        return parts[1]
    return "__root__"


#: Every file read once, because a dozen tests read all of them.
_TEXT = {}
_TREES = {}


def read(path):
    """One file as text, read once and kept."""
    if path not in _TEXT:
        with open(path, encoding="utf-8") as handle:
            _TEXT[path] = handle.read()
    return _TEXT[path]


def tree_of(path):
    """One file as a syntax tree, parsed once and kept.

    A dozen tests here walk every file in the package. Parsing each of them
    once rather than a dozen times takes the suite from seconds to less than
    one, which is worth a dictionary.
    """
    if path not in _TREES:
        _TREES[path] = ast.parse(read(path), filename=path)
    return _TREES[path]


def public_names(tree):
    """Every function and class in a file that is not private."""
    found = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if not node.name.startswith("_"):
                found.append(node)
    return found


class ShapeTest(unittest.TestCase):
    """Every file looks like every other file."""

    def test_there_are_plenty_of_files(self):
        self.assertGreater(len(FILES), 50)

    def test_every_file_has_a_docstring(self):
        for path in FILES:
            with self.subTest(path=os.path.relpath(path, ROOT)):
                self.assertTrue(ast.get_docstring(tree_of(path)))

    def test_every_public_name_has_a_docstring(self):
        for path in FILES:
            for node in public_names(tree_of(path)):
                with self.subTest(path=os.path.relpath(path, ROOT), name=node.name):
                    self.assertTrue(ast.get_docstring(node), "%s says nothing" % node.name)

    def test_every_public_method_has_a_docstring(self):
        for path in FILES:
            for node in public_names(tree_of(path)):
                if not isinstance(node, ast.ClassDef):
                    continue
                for held in node.body:
                    if not isinstance(held, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        continue
                    if held.name.startswith("_"):
                        continue
                    with self.subTest(path=os.path.relpath(path, ROOT), name=held.name):
                        self.assertTrue(ast.get_docstring(held), "%s says nothing" % held.name)

    def test_every_module_says_what_it_exports(self):
        for path in FILES:
            if os.path.basename(path) == "__main__.py":
                continue
            with self.subTest(path=os.path.relpath(path, ROOT)):
                self.assertIn("__all__", read(path))

    def test_every_export_list_is_sorted(self):
        for path in FILES:
            for node in ast.walk(tree_of(path)):
                if not isinstance(node, ast.Assign):
                    continue
                if not any(getattr(target, "id", "") == "__all__" for target in node.targets):
                    continue
                names = [held.value for held in node.value.elts]
                with self.subTest(path=os.path.relpath(path, ROOT)):
                    self.assertEqual(names, sorted(names), "exports out of order")

    def test_no_export_list_repeats_itself(self):
        for path in FILES:
            for node in ast.walk(tree_of(path)):
                if not isinstance(node, ast.Assign):
                    continue
                if not any(getattr(target, "id", "") == "__all__" for target in node.targets):
                    continue
                names = [held.value for held in node.value.elts]
                with self.subTest(path=os.path.relpath(path, ROOT)):
                    self.assertEqual(len(names), len(set(names)))

    def test_everything_exported_is_there(self):
        import importlib

        for path in FILES:
            name = module_name(path)
            if name.endswith("__main__"):
                continue
            module = importlib.import_module(name)
            for exported in getattr(module, "__all__", ()):
                with self.subTest(module=name, exported=exported):
                    self.assertTrue(hasattr(module, exported))

    def test_no_line_runs_off_the_screen(self):
        for path in FILES:
            for number, line in enumerate(read(path).splitlines(), start=1):
                if len(line) > WIDTH:
                    self.fail(
                        "%s:%d is %d characters" % (os.path.relpath(path, ROOT), number, len(line))
                    )

    def test_no_file_ends_without_a_newline(self):
        for path in FILES:
            with self.subTest(path=os.path.relpath(path, ROOT)):
                self.assertTrue(read(path).endswith("\n"))

    def test_no_tabs(self):
        for path in FILES:
            with self.subTest(path=os.path.relpath(path, ROOT)):
                self.assertNotIn("\t", read(path))


class DisciplineTest(unittest.TestCase):
    """Things no module may do."""

    def test_nothing_reaches_for_the_clock_or_the_world(self):
        for path in FILES:
            text = read(path)
            for forbidden in FORBIDDEN:
                with self.subTest(path=os.path.relpath(path, ROOT), forbidden=forbidden):
                    self.assertNotIn(forbidden, text)

    def test_nothing_prints(self):
        """Only the command line prints, and only in one file.

        A docstring may show a caller printing something, so this looks at the
        calls the code makes rather than at the text.
        """
        for path in FILES:
            if path.endswith(os.path.join("cli", "main.py")):
                continue
            for node in ast.walk(tree_of(path)):
                if isinstance(node, ast.Call) and getattr(node.func, "id", "") == "print":
                    self.fail("%s prints" % os.path.relpath(path, ROOT))

    def test_nothing_asks_the_person_at_the_keyboard(self):
        """Nothing waits for somebody to type.

        A library that stops to ask a question cannot be used from anything but
        a terminal. The name is looked for as a call rather than as text, so
        that a function called something_input keeps its name.
        """
        for path in FILES:
            for node in ast.walk(tree_of(path)):
                if isinstance(node, ast.Call) and getattr(node.func, "id", "") == "input":
                    self.fail("%s asks for input" % os.path.relpath(path, ROOT))

    def test_nothing_is_left_to_do(self):
        for path in FILES:
            text = read(path).lower()
            for mark in ("todo", "fixme", "xxx"):
                with self.subTest(path=os.path.relpath(path, ROOT), mark=mark):
                    self.assertNotIn(mark, text)


class LayerTest(unittest.TestCase):
    """The table at the top of this file, enforced."""

    def imports_of(self, path):
        """Which layers a file imports from."""
        found = set()
        for node in ast.walk(tree_of(path)):
            if isinstance(node, ast.ImportFrom) and node.module:
                if node.module.startswith("trestle"):
                    found.add(top_package(node.module))
            elif isinstance(node, ast.Import):
                for held in node.names:
                    if held.name.startswith("trestle"):
                        found.add(top_package(held.name))
        return found

    def test_every_module_belongs_to_a_layer(self):
        for path in FILES:
            with self.subTest(path=os.path.relpath(path, ROOT)):
                self.assertIn(top_package(module_name(path)), LAYERS)

    def test_nothing_imports_from_its_own_layer_or_above(self):
        for path in FILES:
            owner = top_package(module_name(path))
            for imported in self.imports_of(path):
                if imported == owner:
                    continue
                with self.subTest(path=os.path.relpath(path, ROOT), imported=imported):
                    self.assertLess(
                        LAYERS[imported],
                        LAYERS[owner],
                        "%s imports %s, which is not below it" % (owner, imported),
                    )

    def test_the_bottom_layer_leans_on_nothing(self):
        for path in FILES:
            owner = top_package(module_name(path))
            if LAYERS[owner] != 0:
                continue
            with self.subTest(path=os.path.relpath(path, ROOT)):
                self.assertEqual(self.imports_of(path) - {owner}, set())

    def test_the_layers_are_numbered_without_a_gap(self):
        numbers = sorted(set(LAYERS.values()))
        self.assertEqual(numbers, list(range(len(numbers))))


class SuiteTest(unittest.TestCase):
    """Rules about the suite itself."""

    def test_every_test_file_is_named_the_same_way(self):
        directory = os.path.join(ROOT, "tests")
        for name in sorted(os.listdir(directory)):
            if not name.endswith(".py") or name == "__init__.py":
                continue
            with self.subTest(name=name):
                self.assertTrue(name.startswith("test_"))

    def test_there_is_a_test_file_for_every_layer(self):
        names = set(os.listdir(os.path.join(ROOT, "tests")))
        for layer in ("values", "refs", "formula", "functions", "evaluate", "sheet", "graph"):
            with self.subTest(layer=layer):
                self.assertIn("test_%s.py" % layer, names)


class VersionTest(unittest.TestCase):
    """The version string, which is written down in two places."""

    def written_in_pyproject(self):
        """What ``pyproject.toml`` says the version is."""
        with open(os.path.join(ROOT, "pyproject.toml"), encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("version = "):
                    return line.split("=", 1)[1].strip().strip('"')
        return ""

    def test_the_package_says_which_version_it_is(self):
        import trestle

        self.assertTrue(trestle.__version__)

    def test_the_two_places_agree(self):
        import trestle

        self.assertEqual(trestle.__version__, self.written_in_pyproject())

    def test_the_marker_that_says_the_package_is_typed_is_there(self):
        self.assertTrue(os.path.isfile(os.path.join(ROOT, "trestle", "py.typed")))
