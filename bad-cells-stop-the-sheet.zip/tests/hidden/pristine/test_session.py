"""The desk: the short way in."""

import os
import tempfile
import unittest

from trestle import Desk
from trestle.book import Book
from trestle.errors import TrestleError
from trestle.sheet import Sheet
from trestle.store import read_book
from trestle.values import number, text

TEXT = """trestle-book 1
name Small
sheet One
  A1 10
  A2 20
  A3 =SUM(A1:A2)
"""


class BuildTest(unittest.TestCase):
    def test_from_text(self):
        held = Desk.of_text(TEXT)
        self.assertEqual(held.name, "Small")
        self.assertEqual(held.counts()["cells"], 3)

    def test_from_a_file(self):
        path = os.path.join(tempfile.mkdtemp(), "small.book")
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(TEXT)
        self.assertEqual(Desk.of_file(path).value_at("A3"), number(30))

    def test_from_a_file_that_is_not_there(self):
        with self.assertRaises(TrestleError):
            Desk.of_file("/no/such/book")

    def test_from_a_table(self):
        held = Desk.of_table("a,1\nb,2\n", "Costs")
        self.assertEqual(held.value_at("B2"), number(2))

    def test_an_empty_one(self):
        held = Desk.empty("New", "First")
        self.assertEqual(held.sheet().name, "First")
        self.assertEqual(held.counts()["cells"], 0)

    def test_from_a_worked_example(self):
        self.assertEqual(Desk.demo("budget").name, "Budget")

    def test_from_something_that_is_not_a_book(self):
        with self.assertRaises(TrestleError):
            Desk("Budget")


class WorkTest(unittest.TestCase):
    def setUp(self):
        self.desk = Desk.of_text(TEXT)

    def test_a_value(self):
        self.assertEqual(self.desk.value_at("A3"), number(30))

    def test_what_was_typed(self):
        self.assertEqual(self.desk.text_at("A3"), "=SUM(A1:A2)")

    def test_typing_something_in(self):
        self.desk.put("A1", 100)
        self.assertEqual(self.desk.value_at("A3"), number(120))

    def test_the_trace_is_kept(self):
        self.assertIs(self.desk.recalculate(), self.desk.recalculate())

    def test_working_it_out_again(self):
        first = self.desk.recalculate()
        self.assertIsNot(self.desk.recalculate(again=True), first)

    def test_typing_forgets_what_was_worked_out(self):
        self.desk.recalculate()
        self.desk.put("A1", 5)
        self.assertEqual(self.desk.value_at("A3"), number(25))

    def test_one_sheet_by_name(self):
        self.assertEqual(self.desk.sheet("One").name, "One")

    def test_a_sheet_nobody_has(self):
        with self.assertRaises(TrestleError):
            self.desk.sheet("Nowhere")

    def test_the_graph_and_the_order(self):
        self.assertEqual(len(self.desk.links()), 1)
        self.assertEqual(len(self.desk.order()), 1)

    def test_the_digests(self):
        self.assertEqual(len(self.desk.digest()), 16)
        self.assertNotEqual(self.desk.digest(), self.desk.digest(values=True))

    def test_the_same_book_gives_the_same_digest(self):
        self.assertEqual(Desk.of_text(TEXT).digest(), self.desk.digest())


class LookTest(unittest.TestCase):
    def setUp(self):
        self.desk = Desk.demo("invoice")

    def test_the_grid(self):
        held = self.desk.grid("Lines")
        self.assertIn("A", held[0])
        self.assertTrue(any("106.8" in one for one in held))

    def test_the_grid_of_formulas(self):
        held = self.desk.grid("Lines", formulas=True)
        self.assertTrue(any("=SUM(D2:D4)" in one for one in held))

    def test_part_of_the_grid(self):
        self.assertEqual(len(self.desk.grid("Lines", over="A1:B2")), 4)

    def test_the_summary(self):
        self.assertIn("book: 2 sheets", self.desk.summary())

    def test_the_review(self):
        self.assertTrue(self.desk.review().is_clean)

    def test_one_check_of_the_review(self):
        self.assertEqual(len(self.desk.review(only=["cycles"])), 0)

    def test_as_a_table(self):
        held = self.desk.as_table("Rates")
        self.assertEqual(held.splitlines()[0], "what,rate")

    def test_as_a_table_of_formulas(self):
        self.assertIn("=SUM(D2:D4)", self.desk.as_table("Lines", formulas=True))


class ReportTest(unittest.TestCase):
    def setUp(self):
        self.desk = Desk.demo("marks")

    def test_every_report_it_offers_builds(self):
        for name in self.desk.reports():
            with self.subTest(report=name):
                self.assertTrue(self.desk.report(name).as_text())

    def test_a_report_of_one_sheet(self):
        held = self.desk.report("cells", sheet="Grades")
        self.assertGreater(len(held.rows), 5)

    def test_a_report_nobody_has(self):
        with self.assertRaises(TrestleError):
            self.desk.report("weather")

    def test_the_summary_report(self):
        self.assertEqual(self.desk.report("summary").rows[0][0], "book")


class SaveTest(unittest.TestCase):
    def test_saving_and_reading_back(self):
        path = os.path.join(tempfile.mkdtemp(), "small.book")
        first = Desk.of_text(TEXT)
        first.save(path)
        again = Desk.of_file(path)
        self.assertEqual(again.digest(), first.digest())
        self.assertEqual(again.value_at("A3"), number(30))

    def test_what_is_saved_holds_no_values(self):
        path = os.path.join(tempfile.mkdtemp(), "small.book")
        held = Desk.of_text(TEXT)
        held.recalculate()
        held.save(path)
        with open(path, encoding="utf-8") as handle:
            self.assertNotIn("A3 30", handle.read())


class CompareTest(unittest.TestCase):
    """Comparing two desks, which is the way in for comparing two books."""

    def test_a_book_against_itself(self):
        self.assertTrue(Desk.demo("budget").compare(Desk.demo("budget")).is_empty)

    def test_it_works_both_of_them_out_first(self):
        """Neither has been recalculated, and half the answer is about values."""
        one, other = Desk.demo("budget"), Desk.demo("budget")
        other.put("Income!B2", 2600)
        held = one.compare(other)
        self.assertEqual(len(held.came_to()), 5)

    def test_what_changed_further_down(self):
        one, other = Desk.demo("budget"), Desk.demo("budget")
        other.put("Income!B2", 2600)
        held = one.compare(other)
        self.assertEqual(held.at(other.sheet("Left").address_of("B3")).kind, "worked out")

    def test_comparing_with_something_that_is_not_a_desk(self):
        with self.assertRaises(TrestleError):
            Desk.demo("budget").compare("other")

    def test_two_different_examples(self):
        held = Desk.demo("budget").compare(Desk.demo("marks"))
        self.assertFalse(held.is_empty)
        self.assertTrue(held.sheets)
