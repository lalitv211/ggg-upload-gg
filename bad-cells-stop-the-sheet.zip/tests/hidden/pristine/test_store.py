"""Reading and writing books, tables and digests."""

import unittest

from trestle.book import Book
from trestle.errors import StoreError
from trestle.sheet import Sheet
from trestle.store import (
    FORMAT,
    digest_of_book,
    digest_of_sheet,
    digest_of_values,
    read_book,
    read_sheet,
    read_table,
    rows_of_sheet,
    same_input,
    write_book,
    write_sheet,
    write_table,
)
from trestle.values import number


def a_book():
    """A book with two sheets in it."""
    held = Book("Budget")
    held.add(Sheet("Costs", {"A1": 10, "A2": 20, "A3": "=SUM(A1:A2)"}))
    held.add(Sheet("Report", {"A1": "=Costs!A3*2"}))
    return held


class WriteTest(unittest.TestCase):
    def setUp(self):
        self.book = a_book()

    def test_it_starts_with_the_format(self):
        self.assertTrue(write_book(self.book).startswith(FORMAT))

    def test_it_holds_the_name(self):
        self.assertIn("name Budget", write_book(self.book))

    def test_it_holds_a_line_for_each_sheet(self):
        held = write_book(self.book)
        self.assertIn("sheet Costs", held)
        self.assertIn("sheet Report", held)

    def test_it_holds_what_was_typed(self):
        self.assertIn("A3 =SUM(A1:A2)", write_book(self.book))

    def test_it_holds_no_values(self):
        self.book.recalculate()
        self.assertNotIn("A3 30", write_book(self.book))

    def test_writing_twice_gives_the_same_text(self):
        self.assertEqual(write_book(self.book), write_book(self.book))

    def test_one_sheet_on_its_own(self):
        held = write_sheet(self.book.sheet_named("Costs"))
        self.assertTrue(held.startswith("sheet Costs"))

    def test_writing_something_that_is_not_a_book(self):
        with self.assertRaises(StoreError):
            write_book("Budget")
        with self.assertRaises(StoreError):
            write_sheet("Costs")


class ReadTest(unittest.TestCase):
    def setUp(self):
        self.book = a_book()
        self.text = write_book(self.book)

    def test_it_reads_back_the_same(self):
        again = read_book(self.text)
        self.assertTrue(same_input(self.book, again))
        self.assertEqual(again.name, "Budget")

    def test_the_sheets_come_back_in_order(self):
        self.assertEqual(read_book(self.text).names(), ("Costs", "Report"))

    def test_the_formulas_come_back(self):
        again = read_book(self.text)
        self.assertEqual(again.sheet_named("Costs").text_at("A3"), "=SUM(A1:A2)")

    def test_it_works_out_the_same(self):
        again = read_book(self.text)
        again.recalculate()
        self.assertEqual(again.value_at("Report!A1"), number(60))

    def test_comments_and_blank_lines_are_ignored(self):
        held = self.text.replace("name Budget", "# a note\n\nname Budget")
        self.assertEqual(read_book(held).name, "Budget")

    def test_a_file_that_is_not_one(self):
        for text in ("", "nonsense\n", "trestle-book\n"):
            with self.subTest(text=text):
                with self.assertRaises(StoreError):
                    read_book(text)

    def test_a_version_from_the_future(self):
        with self.assertRaises(StoreError):
            read_book("trestle-book 9\n")

    def test_a_cell_before_any_sheet(self):
        with self.assertRaises(StoreError):
            read_book("trestle-book 1\n  A1 1\n")

    def test_a_sheet_with_no_name(self):
        with self.assertRaises(StoreError):
            read_book("trestle-book 1\nsheet\n")

    def test_a_line_that_means_nothing(self):
        with self.assertRaises(StoreError):
            read_book("trestle-book 1\nwibble 1\n")

    def test_a_cell_that_is_not_one(self):
        with self.assertRaises(StoreError):
            read_book("trestle-book 1\nsheet A\n  hello 1\n")

    def test_reading_something_that_is_not_text(self):
        with self.assertRaises(StoreError):
            read_book(["trestle-book 1"])


class SheetFileTest(unittest.TestCase):
    def test_a_file_of_cells_with_no_header(self):
        held = read_sheet("A1 10\nA2 =A1*2\n")
        self.assertEqual(held.text_at("A2"), "=A1*2")
        self.assertEqual(held.name, "Sheet1")

    def test_a_name_for_it(self):
        self.assertEqual(read_sheet("A1 1\n", name="Costs").name, "Costs")

    def test_a_whole_book_read_as_one_sheet(self):
        held = read_sheet(write_book(a_book()))
        self.assertEqual(held.name, "Costs")

    def test_a_book_with_no_sheets(self):
        with self.assertRaises(StoreError):
            read_sheet("trestle-book 1\n")

    def test_a_line_that_is_not_a_cell(self):
        with self.assertRaises(StoreError):
            read_sheet("hello 1\n")


class TableTest(unittest.TestCase):
    def setUp(self):
        self.book = a_book()
        self.book.recalculate()
        self.sheet = self.book.sheet_named("Costs")

    def test_writing_the_values(self):
        self.assertEqual(write_table(self.sheet), "10\n20\n30\n")

    def test_writing_what_was_typed(self):
        self.assertEqual(write_table(self.sheet, formulas=True), "10\n20\n=SUM(A1:A2)\n")

    def test_writing_part_of_a_sheet(self):
        self.assertEqual(write_table(self.sheet, over="A1:A2"), "10\n20\n")

    def test_writing_an_empty_sheet(self):
        self.assertEqual(write_table(Sheet("Empty")), "")

    def test_another_separator(self):
        held = Sheet("S", {"A1": 1, "B1": 2})
        self.assertEqual(write_table(held, separator=";"), "1;2\n")

    def test_a_separator_that_is_not_one_character(self):
        with self.assertRaises(StoreError):
            write_table(self.sheet, separator=", ")

    def test_the_rows_of_a_sheet(self):
        self.assertEqual(rows_of_sheet(self.sheet), (("10",), ("20",), ("30",)))

    def test_the_rows_of_something_that_is_not_a_sheet(self):
        with self.assertRaises(StoreError):
            rows_of_sheet("Costs")

    def test_reading_a_table(self):
        held = read_table("a,1\nb,2\n")
        self.assertEqual(held.text_at("A1"), "a")
        self.assertEqual(held.value_at(held.address_of("B2")), number(2))

    def test_reading_a_table_that_holds_a_formula(self):
        held = read_table('a,=1+1\n')
        self.assertTrue(held.cell_at("B1").is_formula)

    def test_reading_a_table_somewhere_else(self):
        held = read_table("1\n", at="C5")
        self.assertEqual(held.value_at(held.address_of("C5")), number(1))

    def test_an_empty_field_is_left_empty(self):
        held = read_table("1,,2\n")
        self.assertNotIn("B1", held)

    def test_reading_something_that_is_not_text(self):
        with self.assertRaises(StoreError):
            read_table(["a,1"])

    def test_a_table_round_trips_through_the_values(self):
        held = read_table(write_table(self.sheet), name="Costs")
        self.assertEqual(rows_of_sheet(held), rows_of_sheet(self.sheet))


class DigestTest(unittest.TestCase):
    def test_the_same_book_gives_the_same_digest(self):
        self.assertEqual(digest_of_book(a_book()), digest_of_book(a_book()))

    def test_the_name_of_the_book_does_not_change_it(self):
        held = a_book()
        held.name = "Other"
        self.assertEqual(digest_of_book(held), digest_of_book(a_book()))

    def test_one_cell_does(self):
        held = a_book()
        held.put("Costs!A1", 99)
        self.assertNotEqual(digest_of_book(held), digest_of_book(a_book()))

    def test_a_digest_over_one_sheet(self):
        self.assertEqual(
            digest_of_sheet(a_book().sheet_named("Costs")),
            digest_of_sheet(a_book().sheet_named("Costs")),
        )

    def test_the_values_have_a_digest_of_their_own(self):
        held = a_book()
        before = digest_of_values(held)
        held.recalculate()
        self.assertNotEqual(digest_of_values(held), before)

    def test_a_change_that_does_not_change_the_answer(self):
        first = a_book()
        first.recalculate()
        second = a_book()
        second.put("Costs!A3", "=A1+A2")
        second.recalculate()
        self.assertEqual(digest_of_values(first), digest_of_values(second))
        self.assertNotEqual(digest_of_book(first), digest_of_book(second))

    def test_a_digest_of_something_that_is_not_a_book(self):
        with self.assertRaises(StoreError):
            digest_of_book("Budget")
        with self.assertRaises(StoreError):
            digest_of_values("Budget")
        with self.assertRaises(StoreError):
            digest_of_sheet("Costs")
