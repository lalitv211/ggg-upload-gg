"""Workbooks: several sheets, and formulas that read across them."""

import unittest

from trestle.book import Across, Book, links_across, unknown_sheets
from trestle.errors import BookError
from trestle.refs import read_address, read_span
from trestle.sheet import Sheet
from trestle.values import CYCLE, REFERENCE, error, number, text


def a_book():
    """A book with two sheets, one reading the other."""
    held = Book("Budget")
    held.add(Sheet("Costs", {"A1": 10, "A2": 20, "A3": "=SUM(A1:A2)"}))
    held.add(Sheet("Report", {"A1": "=Costs!A3*2", "B1": "total"}))
    return held


class BookTest(unittest.TestCase):
    def setUp(self):
        self.book = a_book()

    def test_what_it_holds(self):
        self.assertEqual(self.book.names(), ("Costs", "Report"))
        self.assertEqual(len(self.book), 2)
        self.assertIn("Costs", self.book)

    def test_the_counts(self):
        counts = self.book.counts()
        self.assertEqual(counts["sheets"], 2)
        self.assertEqual(counts["cells"], 5)
        self.assertEqual(counts["formulas"], 2)

    def test_adding_a_sheet_by_name(self):
        held = self.book.add("Notes")
        self.assertIsInstance(held, Sheet)
        self.assertIn("Notes", self.book)

    def test_adding_a_sheet_twice(self):
        with self.assertRaises(BookError):
            self.book.add("Costs")

    def test_adding_a_sheet_with_no_name(self):
        with self.assertRaises(BookError):
            self.book.add(Sheet(""))

    def test_the_first_sheet(self):
        self.assertEqual(self.book.first().name, "Costs")

    def test_the_first_sheet_of_an_empty_book(self):
        with self.assertRaises(BookError):
            Book("Empty").first()

    def test_one_sheet_by_name(self):
        self.assertEqual(self.book.sheet_named("Report").name, "Report")

    def test_a_sheet_nobody_has(self):
        with self.assertRaises(BookError):
            self.book.sheet_named("Nowhere")

    def test_removing_a_sheet(self):
        self.book.remove("Report")
        self.assertNotIn("Report", self.book)

    def test_removing_a_sheet_nobody_has(self):
        with self.assertRaises(BookError):
            self.book.remove("Nowhere")

    def test_a_summary(self):
        self.assertIn("2 sheets, 5 cells", self.book.summary())


class ReadAcrossTest(unittest.TestCase):
    def setUp(self):
        self.book = a_book()
        self.book.recalculate()

    def test_a_formula_reads_another_sheet(self):
        self.assertEqual(self.book.value_at("Report!A1"), number(60))

    def test_a_cell_by_name_and_sheet(self):
        self.assertEqual(self.book.value_at("A3", sheet="Costs"), number(30))

    def test_a_cell_with_no_sheet_means_the_first(self):
        self.assertEqual(self.book.value_at("A1"), number(10))

    def test_typing_into_a_sheet(self):
        self.book.put("Costs!A1", 100)
        self.book.recalculate()
        self.assertEqual(self.book.value_at("Report!A1"), number(240))

    def test_a_reference_to_a_sheet_that_is_not_there(self):
        self.book.put("Report!A2", "=Nowhere!A1")
        self.book.recalculate()
        self.assertEqual(self.book.value_at("Report!A2"), error(REFERENCE))

    def test_saying_which_formulas_name_a_missing_sheet(self):
        self.book.put("Report!A2", "=Nowhere!A1")
        self.assertEqual(self.book.missing_sheets(), (("Report", "A2"),))

    def test_a_book_where_nothing_is_missing(self):
        self.assertEqual(self.book.missing_sheets(), ())

    def test_a_span_across_a_sheet(self):
        self.book.put("Report!A3", "=SUM(Costs!A1:A2)")
        self.book.recalculate()
        self.assertEqual(self.book.value_at("Report!A3"), number(30))


class RenameTest(unittest.TestCase):
    def setUp(self):
        self.book = a_book()

    def test_renaming_a_sheet(self):
        self.book.rename("Costs", "Spend")
        self.assertIn("Spend", self.book)
        self.assertNotIn("Costs", self.book)

    def test_the_formulas_that_named_it_are_rewritten(self):
        self.book.rename("Costs", "Spend")
        self.assertEqual(self.book.sheet_named("Report").text_at("A1"), "=Spend!A3*2")

    def test_it_still_works_out(self):
        self.book.rename("Costs", "Spend")
        self.book.recalculate()
        self.assertEqual(self.book.value_at("Report!A1"), number(60))

    def test_renaming_to_a_name_that_is_taken(self):
        with self.assertRaises(BookError):
            self.book.rename("Costs", "Report")

    def test_renaming_a_sheet_nobody_has(self):
        with self.assertRaises(BookError):
            self.book.rename("Nowhere", "Somewhere")

    def test_removing_a_sheet_leaves_the_formulas_pointing_nowhere(self):
        self.book.remove("Costs")
        self.book.recalculate()
        self.assertEqual(self.book.value_at("Report!A1"), error(REFERENCE))


class OrderTest(unittest.TestCase):
    def setUp(self):
        self.book = a_book()

    def test_the_graph_covers_every_sheet(self):
        held = self.book.links()
        self.assertEqual(len(held), 2)

    def test_a_cell_is_worked_out_after_the_one_it_reads(self):
        held = self.book.order()
        names = [one.written() for one in held]
        self.assertEqual(names, ["Costs!A3", "Report!A1"])

    def test_a_cycle_across_sheets(self):
        held = Book("B")
        held.add(Sheet("One", {"A1": "=Two!A1"}))
        held.add(Sheet("Two", {"A1": "=One!A1"}))
        held.recalculate()
        self.assertEqual(held.value_at("One!A1"), error(CYCLE))

    def test_working_it_out_twice_changes_nothing(self):
        self.book.recalculate()
        again = self.book.recalculate()
        self.assertEqual(len(again.changed()), 0)

    def test_the_trace_names_the_sheet_of_every_cell(self):
        held = self.book.recalculate()
        self.assertTrue(all("!" in one.at.written() for one in held))


class ContextTest(unittest.TestCase):
    def setUp(self):
        self.book = a_book()
        self.book.recalculate()

    def test_a_context_over_the_whole_book(self):
        held = self.book.context("Report")
        self.assertEqual(held.value_at(read_address("Costs!A3")), number(30))

    def test_a_reference_with_no_sheet_means_the_one_it_is_in(self):
        held = self.book.context("Costs")
        self.assertEqual(held.value_at(read_address("A1")), number(10))

    def test_a_sheet_that_is_not_there(self):
        held = self.book.context("Report")
        self.assertEqual(held.value_at(read_address("Nowhere!A1")), error(REFERENCE))

    def test_a_span_in_a_sheet_that_is_not_there(self):
        held = self.book.context("Report")
        rows = held.values_in(read_span("Nowhere!A1:A2"))
        self.assertEqual(rows[0][0], error(REFERENCE))

    def test_which_sheets_it_knows(self):
        held = self.book.context("Report")
        self.assertTrue(held.knows_sheet("Costs"))
        self.assertFalse(held.knows_sheet("Nowhere"))

    def test_moving_it_to_another_cell(self):
        held = self.book.context("Costs").at(read_address("Report!B2"))
        self.assertEqual(held.sheet, "Report")

    def test_moving_it_to_another_sheet(self):
        self.assertEqual(self.book.context("Costs").in_sheet("Report").sheet, "Report")

    def test_how_many_sheets_it_covers(self):
        self.assertEqual(len(self.book.context()), 2)
        self.assertEqual(str(self.book.context()), "2 sheets")


class AcrossTest(unittest.TestCase):
    def test_a_graph_across_sheets_names_every_cell_by_its_sheet(self):
        held = links_across({"A": Sheet("A", {"A1": "=B!A1"}), "B": Sheet("B", {"A1": 1})})
        self.assertTrue(all(one.sheet for one in held.cells))

    def test_what_names_a_sheet_that_is_not_there(self):
        held = {"A": Sheet("A", {"A1": "=Nowhere!A1"})}
        self.assertEqual(unknown_sheets(held), (("A", "A1"),))
