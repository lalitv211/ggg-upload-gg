"""The example books, worked out and checked against what they should come to.

An example that nobody runs rots. Every file in ``examples/`` is read here, made
to work itself out, and checked cell by cell against numbers written down in
this file. The documentation quotes these same books, so a change that moves an
answer moves a number here first.
"""

import os
import subprocess
import sys
import unittest

from trestle import Desk
from trestle.store import read_book, write_book

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXAMPLES = os.path.join(ROOT, "examples")

#: Every book in the examples directory, and what a few of its cells come to.
ANSWERS = {
    "budget.book": {
        "Income!B4": "3050",
        "Spending!B6": "1960",
        "Left!B3": "1090",
        "Left!B4": "64.3",
    },
    "quote.book": {
        "Labour!D2": "532",
        "Labour!D5": "1318",
        "Parts!D5": "323.4",
        "Quote!B3": "1641.4",
        "Quote!B8": "2324.22",
    },
    "stock.book": {
        "Levels!F2": "hold",
        "Levels!F3": "order",
        "Levels!E4": "66",
        "Summary!B2": "2",
        "Summary!B5": "washer",
    },
    "hours.book": {
        "Week!G2": "40",
        "Week!H3": "8.5",
        "Week!G5": "116",
        "Week!G6": "38.67",
        "Week!G7": "10",
    },
    "broken.book": {
        "Wrong!B1": "#DIV/0!",
        "Wrong!B2": "#VALUE!",
        "Wrong!B3": "#NAME?",
        "Wrong!B4": "#NUM!",
        "Wrong!B5": "#N/A",
        "Wrong!B6": "#REF!",
        "Wrong!B7": "#CYCLE!",
        "Wrong!B8": "#DIV/0!",
        "Wrong!B9": "4",
    },
}

#: The one example that is a table rather than a book.
TABLE = "readings.csv"


def path_of(name):
    """Where one example lives."""
    return os.path.join(EXAMPLES, name)


def worked_out(name):
    """One example book, read and recalculated."""
    desk = Desk.of_file(path_of(name))
    desk.recalculate()
    return desk


def run(*arguments):
    """The command line, run on the examples, as a code and its output."""
    finished = subprocess.run(
        [sys.executable, "-m", "trestle"] + list(arguments),
        capture_output=True,
        text=True,
        cwd=ROOT,
    )
    return finished.returncode, finished.stdout


class DirectoryTest(unittest.TestCase):
    """What the directory holds."""

    def test_every_book_in_the_directory_is_answered_for(self):
        found = sorted(
            name for name in os.listdir(EXAMPLES) if name.endswith(".book")
        )
        self.assertEqual(found, sorted(ANSWERS))

    def test_the_table_is_there(self):
        self.assertTrue(os.path.isfile(path_of(TABLE)))

    def test_the_directory_has_a_note_of_its_own(self):
        self.assertTrue(os.path.isfile(os.path.join(EXAMPLES, "README.md")))

    def test_the_note_names_every_file(self):
        with open(os.path.join(EXAMPLES, "README.md"), encoding="utf-8") as handle:
            said = handle.read()
        for name in sorted(ANSWERS) + [TABLE]:
            with self.subTest(name=name):
                self.assertIn(name, said)


class AnswerTest(unittest.TestCase):
    """What each example comes to."""

    def test_every_answer_is_what_it_should_be(self):
        for name, wanted in sorted(ANSWERS.items()):
            desk = worked_out(name)
            for where, said in sorted(wanted.items()):
                with self.subTest(book=name, cell=where):
                    self.assertEqual(desk.value_at(where).written(), said)

    def test_only_the_broken_one_has_errors_in_it(self):
        for name in sorted(ANSWERS):
            with self.subTest(book=name):
                errors = worked_out(name).trace().errors()
                self.assertEqual(bool(errors), name == "broken.book")

    def test_working_them_out_again_moves_nothing(self):
        for name in sorted(ANSWERS):
            with self.subTest(book=name):
                desk = worked_out(name)
                self.assertEqual(len(desk.recalculate(again=True).changed()), 0)

    def test_each_one_writes_out_and_reads_back(self):
        for name in sorted(ANSWERS):
            with self.subTest(book=name):
                desk = worked_out(name)
                again = read_book(write_book(desk.book))
                again.recalculate()
                self.assertEqual(write_book(again), write_book(desk.book))

    def test_only_the_broken_one_is_warned_about(self):
        for name in ("budget.book", "stock.book"):
            with self.subTest(book=name):
                self.assertEqual(worked_out(name).review().of_level("warning"), ())
        self.assertTrue(worked_out("broken.book").review().of_level("warning"))


class TableTest(unittest.TestCase):
    """The comma separated table, which is read rather than worked out."""

    def desk(self):
        """The table read into a book of one sheet."""
        with open(path_of(TABLE), encoding="utf-8") as handle:
            return Desk.of_table(handle.read(), "Readings")

    def test_it_reads_as_a_sheet(self):
        desk = self.desk()
        self.assertEqual(desk.value_at("A1").written(), "day")
        self.assertEqual(len(desk.sheet()), 6 * 11)

    def test_the_numbers_came_in_as_numbers(self):
        self.assertEqual(self.desk().value_at("D2").kind, "number")

    def test_something_can_be_worked_out_over_it(self):
        desk = self.desk()
        desk.put("H1", "=AVERAGE(D2:D11)")
        desk.recalculate()
        self.assertEqual(desk.value_at("H1").written(), "1113")


class CommandLineTest(unittest.TestCase):
    """The examples through the command line, which is how the readme shows them."""

    def test_the_budget_works_out_and_says_so(self):
        code, said = run("calc", "examples/budget.book")
        self.assertEqual(code, 0)
        self.assertIn("6 formulas", said)

    def test_one_cell_comes_back_on_its_own(self):
        code, said = run("value", "examples/budget.book", "Left!B3")
        self.assertEqual(code, 0)
        self.assertEqual(said.strip(), "1090")

    def test_the_broken_book_stops_with_trouble(self):
        code, said = run("calc", "examples/broken.book")
        self.assertEqual(code, 3)
        self.assertIn("#DIV/0!", said)

    def test_a_review_of_the_broken_book_warns(self):
        code, said = run("review", "examples/broken.book")
        self.assertEqual(code, 1)
        self.assertIn("this cell needs itself", said)

    def test_a_review_of_a_sound_book_says_nothing(self):
        code, said = run("review", "examples/budget.book")
        self.assertEqual(code, 0)
        self.assertIn("Nothing to say", said)

    def test_a_sheet_comes_out_as_a_table(self):
        code, said = run("csv", "examples/budget.book", "--sheet", "Left")
        self.assertEqual(code, 0)
        self.assertIn("left,1090", said)

    def test_the_table_reads_into_a_book(self):
        code, said = run("read", "examples/readings.csv", "--name", "Readings")
        self.assertEqual(code, 0)
        self.assertIn("sheet Readings", said)
