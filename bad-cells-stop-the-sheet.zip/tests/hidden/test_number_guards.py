"""Hidden guards: what already holds at the base commit and has to keep holding.

Ordinary numbers stay numbers, typed or read, in every spelling the formulas page gives; text
that reads as an ordinary number still works in arithmetic; the results that already gave
#NUM!, #DIV/0! and #VALUE! still do; rounding to an ordinary number of places is unchanged; a
chain of operators two hundred deep still works and one level deeper is still refused; a
formula still refuses an underscore in a number; the performance page's chain of four thousand
cells, a column of five hundred cells each reading the one below and a ring of five hundred all
still come out as they did.

Standard library only: one test method per case, so that every case keeps an id.
"""

import re
import unittest

from trestle.recalc import recalculate
from trestle.sheet import Sheet
from trestle.store import read_table

TYPED_NUMBERS = [
    ("12", "12"),
    ("1e308", "1e+308"),
    ("-3.5", "-3.5"),
    ("1e5", "100000"),
    (".5", "0.5"),
    ("1E+05", "100000"),
    ("+5", "5"),
    ("1e-5", "1e-05"),
]

STILL_WORKS = [
    ('="12"+1', "13"),
    ('="1e5"*2', "200000"),
    ('=VALUE(" 3 ")', "3"),
    ('="x"+1', "#VALUE!"),
    ('=VALUE("x")', "#VALUE!"),
    ("=2^2000", "#NUM!"),
    ("=EXP(1000)", "#NUM!"),
    ("=POWER(10,400)", "#NUM!"),
    ("=SQRT(-1)", "#NUM!"),
    ("=MOD(1,0)", "#DIV/0!"),
    ("=1/0", "#DIV/0!"),
    ("=1E308", "1e+308"),
    ("=1E308*1", "1e+308"),
    ("=SUM(1E308,-1E308,1E308)", "1e+308"),
    ("=SUM(1,2,3)", "6"),
    ('=REPT("ab",3)', "ababab"),
    ('=REPT("x",0)', ""),
    ("=ROUND(1.25,1)", "1.3"),
    ("=ROUND(2.5)", "3"),
    ("=ROUNDDOWN(-2.5)", "-2"),
    ("=ROUNDUP(5,-2)", "100"),
    ("=ROUND(1234.5678,-2)", "1200"),
    ("=INT(-2.5)", "-3"),
    ("=TRUNC(7.9)", "7"),
    ('=LEFT("abc",2)', "ab"),
    ("=INDEX(B1:B3,2)", "2"),
]


def each(cls, prefix, cases, body):
    """One test method per case, named after it, so that every case keeps an id."""
    for index, case in enumerate(cases, start=1):
        label = case[0] if isinstance(case, tuple) else case
        slug = re.sub(r"[^0-9a-zA-Z]+", "_", str(label)).strip("_").lower()[:50]
        name = "test_%s_%02d_%s" % (prefix, index, slug)

        def method(self, case=case):
            body(self, case)

        method.__name__ = name
        setattr(cls, name, method)


def worked_out(cells):
    sheet = Sheet("S", cells)
    recalculate(sheet)
    return sheet


def value(sheet, where):
    return sheet.value_at(sheet.address_of(where)).written()


class NumbersStayNumbersTest(unittest.TestCase):
    """Ordinary numbers, typed or read, stay numbers."""

    def test_comma_separated_numbers_stay_numbers(self):
        kinds = [cell.value.kind for _, cell in read_table("12,x,1e308\n", "S").cells()]

        self.assertEqual(kinds, ["number", "text", "number"])

    def test_a_formula_still_reads_the_spellings_the_page_gives(self):
        sheet = worked_out({"A1": "=12", "A2": "=-4.5", "A3": "=1e3", "A4": "=.5", "A5": "=1E+05"})

        self.assertEqual(
            [value(sheet, "A%d" % row) for row in (1, 2, 3, 4, 5)], ["12", "-4.5", "1000", "0.5", "100000"]
        )

    def test_a_formula_still_refuses_an_underscore_in_a_number(self):
        sheet = Sheet("S", {"A1": "=1_000"})
        held = sheet.cell_at(sheet.address_of("A1"))

        self.assertTrue(held.trouble)
        self.assertFalse(held.is_formula)


def _typed_number(self, case):
    typed, shown = case
    sheet = Sheet("S", {"A1": typed})
    held = sheet.cell_at(sheet.address_of("A1")).value
    self.assertTrue(held.is_number, "%r is %s" % (typed, held.kind))
    self.assertEqual(held.written(), shown)


each(NumbersStayNumbersTest, "typed_number_stays_a_number", TYPED_NUMBERS, _typed_number)


class StillWorksTest(unittest.TestCase):
    """What already worked still works."""


def _still_works(self, case):
    formula, wanted = case
    sheet = worked_out({"B1": 1, "B2": 2, "B3": 3, "A1": formula})
    self.assertEqual(value(sheet, "A1"), wanted)


each(StillWorksTest, "still_works", STILL_WORKS, _still_works)


class ChainsTest(unittest.TestCase):
    """A chain of operators two hundred deep still works, one more is still refused."""

    def test_a_chain_of_operators_two_hundred_deep_still_works(self):
        sheet = worked_out({"A1": "=" + "-" * 199 + "1", "A2": "=" + "^".join(["1"] * 200)})

        self.assertEqual(value(sheet, "A1"), "-1")
        self.assertEqual(value(sheet, "A2"), "1")

    def test_a_chain_one_level_deeper_is_still_refused(self):
        sheet = Sheet("S", {"A1": "=" + "-" * 200 + "1"})
        held = sheet.cell_at(sheet.address_of("A1"))

        self.assertTrue(held.trouble)
        self.assertFalse(held.is_formula)


class LongSheetGuardTest(unittest.TestCase):
    """The performance page's chain, and chains and rings short enough, already work."""

    def test_the_performance_pages_chain_still_works(self):
        cells = {"A1": 1}
        for row in range(2, 4001):
            cells["A%d" % row] = "=A%d+1" % (row - 1)
        sheet = worked_out(cells)

        self.assertEqual(value(sheet, "A4000"), "4000")

    def test_a_short_column_reading_the_row_below_still_works(self):
        cells = {"A500": 1}
        for row in range(1, 500):
            cells["A%d" % row] = "=A%d+1" % (row + 1)
        sheet = worked_out(cells)

        self.assertEqual(value(sheet, "A1"), "500")

    def test_a_short_ring_is_still_a_cycle(self):
        cells = {"A1": "=A500"}
        for row in range(2, 501):
            cells["A%d" % row] = "=A%d" % (row - 1)
        sheet = worked_out(cells)

        self.assertEqual(value(sheet, "A1"), "#CYCLE!")
        self.assertEqual(value(sheet, "A250"), "#CYCLE!")


if __name__ == "__main__":
    unittest.main()
