One bad cell stops the whole book. =ROUND(1.5,400) raises OverflowError, so =1+1 on another sheet is never worked out; REPT, SUM, AVERAGE, the IF kind and LCM do the same with silly input. Every formula comes out as a value or an error value, the rest worked out as always.

Not-numbers get in: nan, inf or 1e999 typed or read from csv give NaN or Infinity, and float takes 1_000 and foreign digits. A number in a cell is what a formula calls one, digits, a point, an exponent, signed or not; the rest stays text, and text used as a number is #VALUE! by the same rule or when too big.

Too big for a float is #NUM!; 1E308*10, =1E400, PRODUCT and dividing by a sliver give Infinity. No cell holds NaN or Infinity. But only what's truly too big is #NUM!: a function whose answer a float holds gives it, however far the working strayed on the way. Operators stay plain floats: =1E308+1E308-1E308 is #NUM!, SUM of the same 1E308.

Rounding to more places than a number has gives it back, ROUND, ROUNDUP and ROUNDDOWN alike; to more tens than it has, ROUND and ROUNDDOWN give nought.

Docs promise two hundred deep; nested calls crash with RecursionError near a hundred. Two hundred should work wherever a formula goes, deeper refused as now, without leaning on the stack: at Python's limit of three hundred, two hundred deep still reads, works out, writes back, fills and saves, the limit untouched.

Long sheets crash too: two thousand rows each adding one to the row below, a ring of two thousand cells that should be #CYCLE! all round, a chain across two sheets at nine hundred. Finding cycles mustn't lean on the stack either.

Please add tests for all of it.
