One bad cell stops the whole book. Put =ROUND(1.5,400) in a cell and recalculation raises OverflowError, so =1+1 on another sheet is not worked out either. REPT with a silly count and SUM of two huge numbers do the same. Docs say a function never raises and one bad cell does not stop a sheet. Every formula should come out as a value or an error value, and the rest is worked out as always.

Numbers that are not numbers get in too. Typing nan, inf or 1e999 into a cell gives NaN or Infinity, same when csv is read. These should stay text like any other word. Text used as a number, in arithmetic or VALUE, is #VALUE! by the same rule or when too big for a float.

Result too big for a float is #NUM!, the way 2^2000 and EXP(1000) already are. Now 1E308*10, =1E400, PRODUCT of two big numbers and dividing by a tiny number show Infinity. A number in a cell is never NaN or Infinity.

Rounding to more places than a number has gives the number back, for ROUND, ROUNDUP and ROUNDDOWN. ROUND and ROUNDDOWN to more tens than it has give nought.

Docs also say a formula may nest two hundred deep. Nested function calls crash with RecursionError at about a hundred, brackets at about a hundred and fifty. Up to two hundred should work everywhere a formula goes, worked out, written back, filled and saved. Deeper is refused like it is now, never a crash. Please don't change Python's recursion limit for this.

Please add tests for all of it, typed numbers in the spellings the formulas page gives too.
