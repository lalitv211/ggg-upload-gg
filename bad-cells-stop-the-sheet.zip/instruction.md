One bad cell stops the whole book. Put =ROUND(1.5,400) in a cell and recalculation raises OverflowError, so =1+1 on another sheet is not worked out either. REPT with a silly count and SUM of two huge numbers do the same, AVERAGE, the IF kind and LCM too. Docs say a function never raises and one bad cell does not stop a sheet. Every formula should come out as a value or an error value, and the rest is worked out as always.

Numbers that are not numbers get in too. Typing nan, inf or 1e999 into a cell gives NaN or Infinity, same when csv is read. Python's float reads those and more, like 1_000 or digits from other scripts. A number in a cell is what a formula calls a number, digits, a point, an exponent, sign in front or not. Everything else stays text like any other word. Text used as a number, in arithmetic or VALUE, is #VALUE! by the same rule or when too big for a float.

Result too big for a float is #NUM!, the way 2^2000 and EXP(1000) already are. Now 1E308*10, =1E400, PRODUCT and dividing by a tiny number show Infinity. A number in a cell is never NaN or Infinity.

Rounding to more places than a number has gives the number back, for ROUND, ROUNDUP and ROUNDDOWN. ROUND and ROUNDDOWN to more tens than it has give nought.

Docs also say a formula may nest two hundred deep. Nested calls crash with RecursionError at about a hundred, brackets at hundred and fifty. Up to two hundred should work everywhere a formula goes, worked out, written back, filled, saved. Deeper is refused as now, never a crash. Please don't touch Python's recursion limit.

Please add tests for all of it.
