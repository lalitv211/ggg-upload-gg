One bad cell stops the whole book. =ROUND(1.5,400) raises OverflowError, so =1+1 on another sheet is never worked out; REPT with a silly count, SUM of huge numbers, AVERAGE, the IF kind and LCM do the same. Every formula comes out as a value or an error value and the rest is worked out as always.

Not-numbers get in too: typing nan, inf or 1e999, or reading csv, gives NaN or Infinity, and Python's float takes 1_000 and digits from other scripts. A number in a cell is what a formula calls one, digits, a point, an exponent, signed or not; everything else stays text, and text used as a number is #VALUE! by the same rule or when too big.

Too big for a float is #NUM!; 1E308*10, =1E400, PRODUCT and dividing by a tiny number give Infinity. No cell holds NaN or Infinity.

Rounding to more places than a number has gives it back, ROUND, ROUNDUP and ROUNDDOWN alike; to more tens than it has, ROUND and ROUNDDOWN give nought.

Docs say a formula may nest two hundred deep; nested calls crash with RecursionError near a hundred. Two hundred should work everywhere a formula goes, deeper refused as now, never a crash. Deep formulas shouldn't lean on the stack: at Python's limit of three hundred, two hundred deep still reads, works out, writes back, fills and saves. Don't touch the limit.

Long sheets crash the same way. A column where each cell adds one to the row below crashes with RecursionError at two thousand rows, so does a ring of two thousand cells that should be #CYCLE! all round, and a chain crossing two sheets at nine hundred. Such a book is ordinary; finding cycles mustn't lean on the stack either.

Please add tests for all of it.
