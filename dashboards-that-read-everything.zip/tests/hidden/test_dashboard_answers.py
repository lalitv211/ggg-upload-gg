"""The dashboard answers do not move.

Each public analytics function is compared with the answer the code gave
before the change, recomputed here the slow way, on many random streams: one
episode or many, downloads, repeated reports, empty input, ties.
"""

from src.domain.analytics import report, retention, rollup
from src.domain.analytics.event import PlayEvent, furthest_position, sessions
from src.domain.timeline.calendar import days_between, parse_date
from tests.hidden_dashboard_streams import DURATION, episode, episodes, stream
from tests.support import DomainTestCase

SEEDS = (1, 2, 3, 5, 8, 13, 21, 34)


def plain(listeners, references, seed):
    return stream(listeners, references, seed=seed, factory=PlayEvent)


def slow_curve(events, length, count=10):
    listeners = sessions(events)
    if not listeners:
        return tuple(0.0 for _ in range(count + 1))
    furthest = [furthest_position(events, session) for session in listeners]
    return tuple(
        round(
            sum(1 for position in furthest if position >= length * index // count)
            * 100.0
            / len(listeners),
            2,
        )
        for index in range(count + 1)
    )


def slow_completion(events, length, threshold=90):
    listeners = sessions(events)
    if not listeners:
        return 0.0
    boundary = length * threshold // 100
    reached = sum(1 for session in listeners if furthest_position(events, session) >= boundary)
    return round(reached * 100.0 / len(listeners), 2)


def slow_average(events):
    listeners = sessions(events)
    if not listeners:
        return 0
    return sum(furthest_position(events, session) for session in listeners) // len(listeners)


def slow_episode_report(events, item, start, end, buckets=10):
    scoped = tuple(event for event in events if event.episode_reference == item.reference)
    rows = rollup.fill_gaps(rollup.daily(scoped), start, end)
    totals = rollup.combine(rows)
    duration = item.duration_millis or 1
    return {
        "episode": item.reference,
        "title": item.title,
        "days": [row.to_dict() for row in rows],
        "totals": totals.to_dict() if totals else None,
        "listeners": len(sessions(scoped)),
        "retention": list(slow_curve(scoped, duration, buckets)),
        "completion_rate": slow_completion(scoped, duration),
    }


def slow_show_report(events, items, start, end):
    rows = []
    for item in items:
        scoped = tuple(event for event in events if event.episode_reference == item.reference)
        totals = rollup.combine(rollup.daily(scoped))
        rows.append(
            {
                "episode": item.reference,
                "title": item.title,
                "listeners": len(sessions(scoped)),
                "starts": totals.starts if totals else 0,
                "downloads": totals.downloads if totals else 0,
            }
        )
    rows.sort(key=lambda row: (-row["listeners"], row["title"]))
    return {
        "start": parse_date(start, "start").isoformat(),
        "end": parse_date(end, "end").isoformat(),
        "days": days_between(start, end),
        "episodes": rows,
        "listeners": sum(row["listeners"] for row in rows),
        "starts": sum(row["starts"] for row in rows),
    }


class RetentionAnswerTests(DomainTestCase):
    def setUp(self):
        self.reference = episode("Episode 12").reference

    def test_the_curve_is_the_same(self):
        for seed in SEEDS:
            events = plain(120, [self.reference], seed)
            for count in (1, 4, 10, 100):
                self.assertEqual(
                    slow_curve(events, DURATION, count),
                    retention.curve(events, DURATION, count),
                    (seed, count),
                )

    def test_the_curve_of_a_short_episode_is_the_same(self):
        events = plain(80, [self.reference], 4)
        self.assertEqual(slow_curve(events, 1000, 10), retention.curve(events, 1000))

    def test_the_completion_rate_is_the_same(self):
        for seed in SEEDS:
            events = plain(120, [self.reference], seed)
            for threshold in (1, 50, 90, 100):
                self.assertEqual(
                    slow_completion(events, DURATION, threshold),
                    retention.completion_rate(events, DURATION, threshold),
                    (seed, threshold),
                )

    def test_the_average_position_is_the_same(self):
        for seed in SEEDS:
            events = plain(120, [self.reference], seed)
            self.assertEqual(slow_average(events), retention.average_position(events), seed)

    def test_downloads_still_count_as_listeners_at_zero(self):
        events = [
            PlayEvent(self.reference, "s-1", "start", "2021-05-01T10:00:00Z", 0),
            PlayEvent(self.reference, "s-1", "progress", "2021-05-01T10:00:00Z", DURATION),
            PlayEvent(self.reference, "s-2", "download", "2021-05-01T10:00:00Z", 0, "rss"),
        ]
        self.assertEqual(50.0, retention.completion_rate(events, DURATION))
        self.assertEqual(DURATION // 2, retention.average_position(events))
        self.assertEqual((100.0, 50.0), retention.curve(events, DURATION, 1))

    def test_nothing_in_gives_the_empty_answers(self):
        self.assertEqual(tuple(0.0 for _ in range(11)), retention.curve([], DURATION))
        self.assertEqual(0.0, retention.completion_rate([], DURATION))
        self.assertEqual(0, retention.average_position([]))

    def test_the_guards_still_reject_bad_arguments(self):
        self.assertField("duration_millis", retention.curve, [], 0)
        self.assertField("buckets", retention.curve, [], DURATION, 101)
        self.assertField("threshold_percent", retention.completion_rate, [], DURATION, 0)


class ReportAnswerTests(DomainTestCase):
    def test_the_episode_report_is_the_same(self):
        show = episodes(4)
        for seed in SEEDS:
            events = plain(160, [item.reference for item in show], seed)
            for item in show:
                self.assertEqual(
                    slow_episode_report(events, item, "2021-05-01", "2021-05-08"),
                    report.episode_report(events, item, "2021-05-01", "2021-05-08"),
                    (seed, item.title),
                )

    def test_the_episode_report_with_other_buckets_is_the_same(self):
        item = episode("Episode 12")
        events = plain(90, [item.reference], 6)
        self.assertEqual(
            slow_episode_report(events, item, "2021-05-02", "2021-05-05", 4),
            report.episode_report(events, item, "2021-05-02", "2021-05-05", buckets=4),
        )

    def test_the_episode_report_still_takes_a_one_shot_stream(self):
        show = episodes(3)
        events = plain(90, [item.reference for item in show], 11)
        self.assertEqual(
            slow_episode_report(events, show[0], "2021-05-01", "2021-05-08"),
            report.episode_report((e for e in events), show[0], "2021-05-01", "2021-05-08"),
        )

    def test_the_episode_report_of_an_episode_nobody_played(self):
        item = episode("Quiet")
        events = plain(50, [episode("Loud").reference], 3)
        self.assertEqual(
            slow_episode_report(events, item, "2021-05-01", "2021-05-03"),
            report.episode_report(events, item, "2021-05-01", "2021-05-03"),
        )

    def test_the_show_report_is_the_same(self):
        show = episodes(12)
        for seed in SEEDS:
            events = plain(300, [item.reference for item in show[:9]], seed)
            self.assertEqual(
                slow_show_report(events, show, "2021-05-01", "2021-05-08"),
                report.show_report(events, show, "2021-05-01", "2021-05-08"),
                seed,
            )

    def test_ties_still_break_by_title(self):
        show = [episode("Beta"), episode("Alpha")]
        events = [
            PlayEvent(show[0].reference, "s-1", "start", "2021-05-01T10:00:00Z"),
            PlayEvent(show[1].reference, "s-2", "start", "2021-05-01T10:00:00Z"),
        ]
        built = report.show_report(events, show, "2021-05-01", "2021-05-03")
        self.assertEqual(["Alpha", "Beta"], [row["title"] for row in built["episodes"]])

    def test_top_episodes_still_reads_the_show_report(self):
        show = episodes(6)
        events = plain(200, [item.reference for item in show], 2)
        built = report.show_report(events, show, "2021-05-01", "2021-05-08")
        expected = slow_show_report(events, show, "2021-05-01", "2021-05-08")
        self.assertEqual(
            tuple(row["episode"] for row in expected["episodes"][:3]),
            report.top_episodes(built, 3),
        )


class HelperAnswerTests(DomainTestCase):
    def test_sessions_and_furthest_position_are_unchanged(self):
        reference = episode("Episode 12").reference
        events = plain(60, [reference], 5)
        found = sessions(events)
        self.assertEqual(tuple(sorted({event.session_id for event in events})), found)
        for session in found:
            positions = [
                event.position_millis
                for event in events
                if event.session_id == session and event.is_listen
            ]
            self.assertEqual(max(positions) if positions else 0, furthest_position(events, session))

    def test_daily_and_the_source_breakdown_are_unchanged(self):
        reference = episode("Episode 12").reference
        events = plain(80, [reference], 6)
        rows = rollup.daily(events)
        self.assertEqual(sum(row.starts for row in rows), sum(1 for e in events if e.kind == "start"))
        by_source = report.source_breakdown(events)
        self.assertEqual(
            {e.source for e in events if e.kind in ("start", "download")}, set(by_source)
        )
