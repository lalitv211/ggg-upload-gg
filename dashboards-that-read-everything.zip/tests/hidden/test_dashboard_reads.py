"""The dashboard read budget.

Rule from the request: curve, completion rate and average position read at
most four event fields per event, and the episode report and the show report
at most twenty per event, whatever the number of listeners or episodes. Reads
are counted on the events themselves, through every path.
"""

from src.domain.analytics import report, retention
from src.domain.analytics.event import PlayEvent
from tests.hidden_dashboard_streams import (
    DURATION,
    episode,
    episodes,
    reads_per_event,
    stream,
)
from tests.support import DomainTestCase

RETENTION_BUDGET = 4
REPORT_BUDGET = 20


class RetentionBudgetTests(DomainTestCase):
    def setUp(self):
        self.reference = episode("Episode 12").reference

    def assertWithin(self, call, listeners, budget=RETENTION_BUDGET):
        events = stream(listeners, [self.reference])
        used = reads_per_event(call, events)
        self.assertLessEqual(used, budget, "{} listeners: {:.1f} reads per event".format(listeners, used))

    def test_the_curve_for_fifty_listeners(self):
        self.assertWithin(lambda events: retention.curve(events, DURATION), 50)

    def test_the_curve_for_four_hundred_listeners(self):
        self.assertWithin(lambda events: retention.curve(events, DURATION), 400)

    def test_the_curve_for_two_thousand_listeners(self):
        self.assertWithin(lambda events: retention.curve(events, DURATION), 2000)

    def test_a_fine_curve_of_a_hundred_buckets(self):
        self.assertWithin(lambda events: retention.curve(events, DURATION, 100), 400)

    def test_the_completion_rate_for_fifty_listeners(self):
        self.assertWithin(lambda events: retention.completion_rate(events, DURATION), 50)

    def test_the_completion_rate_for_two_thousand_listeners(self):
        self.assertWithin(lambda events: retention.completion_rate(events, DURATION), 2000)

    def test_the_completion_rate_at_another_threshold(self):
        self.assertWithin(lambda events: retention.completion_rate(events, DURATION, 50), 400)

    def test_the_average_position_for_fifty_listeners(self):
        self.assertWithin(retention.average_position, 50)

    def test_the_average_position_for_two_thousand_listeners(self):
        self.assertWithin(retention.average_position, 2000)


class EpisodeReportBudgetTests(DomainTestCase):
    def setUp(self):
        self.episode = episode("Episode 12")

    def report_on(self, events):
        return report.episode_report(events, self.episode, "2021-05-01", "2021-05-08")

    def assertWithin(self, events, label):
        used = reads_per_event(self.report_on, events)
        self.assertLessEqual(used, REPORT_BUDGET, "{}: {:.1f} reads per event".format(label, used))

    def test_fifty_listeners(self):
        self.assertWithin(stream(50, [self.episode.reference]), "fifty")

    def test_four_hundred_listeners(self):
        self.assertWithin(stream(400, [self.episode.reference]), "four hundred")

    def test_two_thousand_listeners(self):
        self.assertWithin(stream(2000, [self.episode.reference]), "two thousand")

    def test_an_episode_among_many_in_the_stream(self):
        others = [item.reference for item in episodes(3)]
        events = stream(2000, [self.episode.reference] + others)
        self.assertWithin(events, "one episode of four")

    def test_a_fine_retention_curve(self):
        events = stream(400, [self.episode.reference])
        used = reads_per_event(
            lambda items: report.episode_report(
                items, self.episode, "2021-05-01", "2021-05-08", buckets=100
            ),
            events,
        )
        self.assertLessEqual(used, REPORT_BUDGET)


class ShowReportBudgetTests(DomainTestCase):
    def assertWithin(self, listeners, episode_count):
        show = episodes(episode_count)
        events = stream(listeners, [item.reference for item in show])
        used = reads_per_event(
            lambda items: report.show_report(items, show, "2021-05-01", "2021-05-08"), events
        )
        self.assertLessEqual(
            used,
            REPORT_BUDGET,
            "{} episodes: {:.1f} reads per event".format(episode_count, used),
        )

    def test_a_show_of_ten_episodes(self):
        self.assertWithin(400, 10)

    def test_a_show_of_forty_episodes(self):
        self.assertWithin(1600, 40)

    def test_a_show_of_two_hundred_episodes(self):
        self.assertWithin(2000, 200)

    def test_a_show_listing_episodes_nobody_played(self):
        show = episodes(60)
        events = stream(600, [item.reference for item in show[:5]])
        used = reads_per_event(
            lambda items: report.show_report(items, show, "2021-05-01", "2021-05-08"), events
        )
        self.assertLessEqual(used, REPORT_BUDGET)


class GrowthTests(DomainTestCase):
    """Four times the listeners costs about four times the reads, not sixteen."""

    def total(self, call, listeners, references):
        events = stream(listeners, references)
        return reads_per_event(call, events) * len(events), len(events)

    def assertLinear(self, call, references):
        small, small_events = self.total(call, 300, references)
        large, large_events = self.total(call, 1200, references)
        self.assertLessEqual(large / small, 1.25 * large_events / small_events)

    def test_the_episode_report_grows_with_the_events(self):
        item = episode("Episode 12")
        self.assertLinear(
            lambda events: report.episode_report(events, item, "2021-05-01", "2021-05-08"),
            [item.reference],
        )

    def test_the_curve_grows_with_the_events(self):
        self.assertLinear(
            lambda events: retention.curve(events, DURATION), [episode("Episode 12").reference]
        )


class StreamWalkedOnceTests(DomainTestCase):
    """Rule from the request: the events may come as a stream that can only be walked once.

    Each answer for a one-shot stream is compared with the answer for the same
    events in a list.
    """

    def setUp(self):
        self.show = episodes(3)
        self.events = stream(
            90, [item.reference for item in self.show], seed=11, factory=PlayEvent
        )

    def once(self):
        return (event for event in self.events)

    def test_the_curve_of_a_one_shot_stream(self):
        self.assertEqual(
            retention.curve(self.events, DURATION), retention.curve(self.once(), DURATION)
        )

    def test_the_completion_rate_of_a_one_shot_stream(self):
        self.assertEqual(
            retention.completion_rate(self.events, DURATION),
            retention.completion_rate(self.once(), DURATION),
        )

    def test_the_average_position_of_a_one_shot_stream(self):
        self.assertEqual(
            retention.average_position(self.events), retention.average_position(self.once())
        )

    def test_the_show_report_of_a_one_shot_stream(self):
        self.assertEqual(
            report.show_report(self.events, self.show, "2021-05-01", "2021-05-08"),
            report.show_report(self.once(), self.show, "2021-05-01", "2021-05-08"),
        )
