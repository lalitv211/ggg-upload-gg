"""Event streams for the dashboard tests, and an event that counts its own reads.

``CountedEvent`` is a real ``PlayEvent``; it only adds a counter that goes up
every time one of the six recorded fields is read, through any path.
"""

import random

from src.domain.analytics.event import PlayEvent
from src.domain.episodes.episode import Episode
from src.domain.media.asset import Asset

FIELDS = frozenset(PlayEvent.__slots__)
ASSET = Asset("u-1", "episode-12.mp3", 5_000_000, duration="30:00")
DURATION = 1_800_000


class CountedEvent(PlayEvent):
    __slots__ = ()
    reads = 0

    def __getattribute__(self, name):
        if name in FIELDS:
            CountedEvent.reads += 1
        return object.__getattribute__(self, name)


def episode(title, number=1):
    return Episode("u-1", "vokal-weekly", title, ASSET, "Notes.", number=number)


def episodes(count):
    return [episode("Episode {}".format(index), index + 1) for index in range(count)]


def stream(listeners, references, per_listener=5, seed=7, factory=CountedEvent):
    """``listeners`` sessions spread over ``references``, a mix of every kind."""
    rnd = random.Random(seed)
    events = []
    for index in range(listeners):
        reference = references[index % len(references)]
        session = "s-{}".format(index)
        day = 1 + rnd.randrange(7)
        at = "2021-05-{:02d}T{:02d}:{:02d}:00Z".format(day, rnd.randrange(24), rnd.randrange(60))
        source = rnd.choice(("web", "ios", "android", "rss", "embed"))
        if rnd.random() < 0.15:
            events.append(factory(reference, session, "download", at, 0, "rss"))
            continue
        events.append(factory(reference, session, "start", at, 0, source))
        position = 0
        for _ in range(per_listener - 2):
            position += rnd.randrange(1, DURATION // 3)
            events.append(factory(reference, session, "progress", at, position, source))
        if rnd.random() < 0.4:
            events.append(factory(reference, session, "complete", at, DURATION, source))
        else:
            events.append(factory(reference, session, "progress", at, position + 1, source))
        if rnd.random() < 0.1:
            events.append(factory(reference, session, "progress", at, position, source))
    rnd.shuffle(events)
    return events


def reads_per_event(call, events):
    """How many recorded fields ``call(events)`` reads, per event it was given."""
    CountedEvent.reads = 0
    call(events)
    return CountedEvent.reads / len(events)
