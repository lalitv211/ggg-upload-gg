Dashboard is slow for popular shows. Episode screen with two thousand listeners takes seconds to load. Retention curve, completion rate and average position look at every event once per listener, so the work grows with listeners times events. Episode report pays that twice. Show report walks all the events again for every episode, so forty episodes means forty walks.

The cost should be per event. Curve, completion rate and average position should read at most four event fields per event. Episode report and show report at most twenty per event. It has to hold for any number of listeners, buckets or episodes. Events can come straight from a database cursor, so the stream may only be walked once.

The numbers on the dashboard stay exactly the same. Download-only sessions still count as listeners at position zero. Show report keeps its order and ties still go by title. Repeated reports of the same moment give the same answers as today. Nothing else in the analytics changes how it behaves.

Please prove the budgets in the tests. Count how many times the six recorded fields of an event are read, through every path. Don't use timing since it fails on CI.
