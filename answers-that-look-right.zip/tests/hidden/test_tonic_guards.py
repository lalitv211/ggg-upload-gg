"""What already held about frequencies, and has to go on holding.

A tonic of C was right before and must stay right, octaves must still
double, a refusal must still be a refusal, and the scale table on C
still counts its cents from the tonic. These pass at the base commit;
they are here so a change that mends the other tonics cannot quietly
break the one that worked.
"""

from __future__ import annotations

from fractions import Fraction

import pytest

from wolf.cli.main import run
from wolf.errors import NotInTheTemperament
from wolf.io import identify
from wolf.pitch import frequency, note
from wolf.temper import table


@pytest.mark.parametrize("name", table.known())
def test_a_tonic_of_c_still_puts_a_on_the_standard(name):
    """Every tuning, at three standards."""

    made = table.named(name, "C")
    for standard, want in (("a440", 440), ("a415", 415),
                           ("a466", 466)):
        found = frequency.frequency(made, note.note("A4"), standard)
        assert round(float(found), 9) == want, (name, standard)


def test_middle_c_on_a_tonic_of_c_is_unchanged():
    """The two documented figures."""

    equal = frequency.frequency(table.named("equal"), note.note("C4"))
    meantone = frequency.frequency(table.named("quarter_comma"),
                                   note.note("C4"))
    assert round(float(equal), 4) == 261.6256
    assert round(float(meantone), 4) == 263.1814
    assert round(float(frequency.tonic_frequency(
        table.named("equal"), "a440", 4)), 4) == 261.6256


def test_a_scale_on_c_runs_from_c_to_b_in_pitch_order():
    """Twelve pitches, the fourth octave, sorted."""

    for name in table.known():
        found = frequency.scale(table.named(name), 4, "a440")
        assert len(found) == 12, name
        assert str(found[0].note) == "C4", name
        assert found[-1].note.letter == "B", name
        hertz = [one.hertz for one in found]
        assert hertz == sorted(hertz), name
        assert all(one.note.octave == 4 for one in found), name


def test_the_table_on_c_counts_cents_from_the_tonic():
    """Which is the figure the temperament itself gives."""

    for name in ("equal", "quarter_comma", "werckmeister_iii", "just"):
        made = table.named(name)
        for row in frequency.table(made, 4, "a440"):
            assert row["cents"] == made.cents(row["note"][:-1]), (
                name, row)


def test_octaves_still_double_on_every_tonic():
    """An octave is exactly two, whatever the tonic."""

    for tonic in ("C", "G", "Bb", "B"):
        made = table.named("quarter_comma", tonic)
        for name in ("C", "F#", "A", "Eb", "B"):
            low = frequency.frequency(made, note.note(name + "3"))
            high = frequency.frequency(made, note.note(name + "4"))
            assert high == 2 * low, (tonic, name)
        one = frequency.pitch(made, "G4")
        assert one.octave_up().hertz == 2 * one.hertz
        assert one.octave_up(-2).hertz * 4 == one.hertz


def test_a_note_the_tuning_has_not_got_is_refused_on_every_tonic():
    """Twelve keys hold twelve notes, wherever the ratios start."""

    for tonic in ("C", "G", "B"):
        with pytest.raises(NotInTheTemperament):
            frequency.frequency(table.named("equal", tonic),
                                note.note("Eb4"))
        with pytest.raises(NotInTheTemperament):
            frequency.frequency(table.named("quarter_comma", tonic),
                                note.note("Ab4"))


def test_beats_on_c_are_unchanged():
    """The documented 0.4429, and a just third that does not beat."""

    found = frequency.beats_against_just(table.named("equal"), "C", "G",
                                         Fraction(3, 2), "a440", 4)
    assert round(float(found["beats"]), 4) == 0.4429
    third = frequency.beats_against_just(table.named("quarter_comma"),
                                         "C", "E", Fraction(5, 4),
                                         "a440", 4)
    assert abs(float(third["beats"])) < 1e-9


def test_the_audible_range_on_c_is_unchanged():
    """Eleven octaves of C, from the bottom of hearing to the top."""

    found = frequency.audible_range(table.named("equal"), "C", "a440")
    assert found["lowest_octave"] == 0
    assert found["highest_octave"] == 10
    assert found["octaves"] == 11


def test_the_matcher_is_untouched_by_the_tonic():
    """Twelve frequencies for a tuning written down from G are still
    recognised as that tuning, because the matcher tries every
    rotation."""

    found = identify.frequencies_of("quarter_comma", 261, "G")
    assert len(found) == 12
    assert found[0] == 261
    assert list(found) == sorted(found)
    named = identify.identify(found)
    assert named["best"] == "quarter_comma"
    assert named["worst_note"] < Fraction(1, 10 ** 6)
    assert named["decided"]


def test_the_documented_commands_on_c_print_what_they_printed():
    """The three frequency commands with no --tonic."""

    code, text = run(["hertz", "C4"])
    assert code == 0 and "261.6256" in text
    code, text = run(["hertz", "C4", "--temperament", "quarter_comma"])
    assert code == 0 and "263.1814" in text
    code, text = run(["scale", "--temperament", "quarter_comma"])
    assert code == 0 and "263.1814" in text and "491.9350" in text
    code, text = run(["beats", "C", "G"])
    assert code == 0 and "0.4429" in text


def test_a_tonic_the_chain_has_not_got_is_still_refused():
    """H is not a note and D sharp is not on the usual chain."""

    assert run(["tuning", "quarter_comma", "--tonic", "H"])[0] == 3
    assert run(["hertz", "C4", "--temperament", "quarter_comma",
                "--tonic", "D#"])[0] == 3
    assert run(["hertz", "C4", "--temperament", "equal",
                "--tonic", "Eb"])[0] == 3
