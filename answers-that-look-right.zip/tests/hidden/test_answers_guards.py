"""What already answered right, and has to go on answering right.

A fifth is still judged against 3:2 and a major third against 5:4, a
ratio named with ``--just`` is still the one used, ``keys`` and
``chord`` still say what they said, a tuning measured from C still
reports the character it did, meantone built from a real fraction is
unchanged and nought parts of a comma is still refused where a comma
is divided, the first fourteen harmonics keep their names, and a rank
with its eight foot drawn needs the pipes it always needed. These
pass at the base commit; they are here so a change that mends the
five wrong answers cannot quietly break the right ones.
"""

from __future__ import annotations

import re
from fractions import Fraction

import pytest

from wolf.cli.main import run
from wolf.errors import Degenerate, Inconsistent, OutOfRange, Unsupported
from wolf.format import chart
from wolf.io import identify
from wolf.format.report import parts_of
from wolf.interval import harmonic
from wolf.interval.comma import part_of
from wolf.pipe import stop
from wolf.temper import optimal
from wolf.pipe import rank
from wolf.temper import table, tuning
from wolf.temper import wolf as wolves


def figure(text):
    """The figure part of a report, as its lines."""

    return parts_of(text)["figure"]


def value_of(text, name):
    """The value printed beside a name in a report's figure part."""

    for line in text.splitlines():
        words = line.split()
        if words and words[0] == name:
            return words[-1]
    raise AssertionError("no line for {0!r} in:\n{1}".format(name, text))


@pytest.mark.parametrize("command", ["intervals", "spread"])
@pytest.mark.parametrize("steps,just", [("7", "3:2"), ("4", "5:4")])
@pytest.mark.parametrize("name", table.known())
def test_fifths_and_thirds_are_judged_as_before(name, command, steps,
                                                just):
    """The two defaults that were right stay right."""

    code, plain = run([command, name, "--steps", steps])
    assert code == 0, plain
    code, chosen = run([command, name, "--steps", steps, "--just",
                        just])
    assert code == 0, chosen
    assert figure(plain) == figure(chosen)


def test_the_documented_interval_figures_are_unchanged():
    """Quarter-comma's thirds and equal's spread, to the figure."""

    text = run(["intervals", "quarter_comma", "--steps", "4"])[1]
    assert "41.0589" in text
    assert "386.3137" in text
    text = run(["spread", "equal", "--steps", "4"])[1]
    assert value_of(text, "best") == "13.6863"
    assert value_of(text, "spread") == "0.0000"


def test_a_ratio_named_by_hand_is_the_one_used():
    """As it always was."""

    made = table.named("quarter_comma")
    found = tuning.spread(made, 3, Fraction(5, 4))
    text = run(["spread", "quarter_comma", "--steps", "3", "--just",
                "5:4"])[1]
    assert value_of(text, "spread") == "{0:.4f}".format(
        float(found["spread"]))


def test_a_just_ratio_of_nothing_is_still_refused():
    """Whichever way the default is found."""

    code, text = run(["intervals", "equal", "--steps", "3", "--just",
                      "0:1"])
    assert code in (2, 3), text


def test_keys_and_chord_still_say_what_they_said():
    """The key table and the chord table read the same ratios."""

    text = run(["keys", "quarter_comma"])[1]
    assert "41.0589" in text
    text = run(["chord", "major", "--temperament", "quarter_comma"])[1]
    assert "386.3137" in text
    text = run(["keys", "werckmeister_iii"])[1]
    assert "21.5063" in text


def test_character_from_c_is_what_it_was():
    """The documented tables, with their levels."""

    text = run(["character", "--temperament", "werckmeister_iii"])[1]
    assert value_of(text, "C") == "0"
    assert value_of(text, "C#") == "17.5950"
    assert "4 distinct levels" in " ".join(text.split())
    text = run(["character", "--temperament", "quarter_comma"])[1]
    assert "41.0589" in text
    assert "2 distinct levels" in " ".join(text.split())
    text = run(["character", "--temperament", "equal"])[1]
    assert "1 distinct level" in " ".join(text.split())


@pytest.mark.parametrize("tonic", ["D", "G", "A#"])
def test_equal_temperament_has_no_character_from_anywhere(tonic):
    """Every key is the same scale moved, whichever is the tonic."""

    code, text = run(["character", "--temperament", "equal", "--tonic",
                      tonic])
    assert code == 0, text
    for line in figure(text):
        words = line.split()
        if len(words) == 2 and re.fullmatch(r"-?[\d.]+", words[1]):
            assert abs(float(words[1])) < 0.001, line


def test_a_regular_tuning_reads_alike_from_any_good_key():
    """Quarter-comma from G and from C are the same table."""

    first = run(["character", "--temperament", "quarter_comma"])[1]
    second = run(["character", "--temperament", "quarter_comma",
                  "--tonic", "G"])[1]
    assert sorted(figure(first)) == sorted(figure(second))


def test_meantone_from_a_quarter_of_a_comma_is_unchanged():
    """The documented tuning, to the figure."""

    code, text = run(["meantone", "--part", "1/4"])
    assert code == 0, text
    assert value_of(text, "each_fifth_narrowed") == "5.3766"
    assert value_of(text, "wolf_cents") == "737.6373"
    assert value_of(text, "wolf_wide_by") == "35.6823"
    code, text = run(["meantone", "--part", "1/6"])
    assert code == 0, text
    assert value_of(text, "each_fifth_narrowed") == "3.5844"


def test_a_part_no_temperament_takes_is_still_refused():
    """More than a whole comma, a negative share, a share that is not
    a fraction, and a comma nobody has heard of."""

    assert run(["meantone", "--part", "2"])[0] == 3
    assert run(["meantone", "--part", "-1/4"])[0] in (2, 3)
    assert run(["meantone", "--part", "quarter"])[0] == 2
    assert run(["meantone", "--part", "1/4", "--comma",
                "ptolemaic"])[0] in (2, 3)


def test_more_than_a_whole_comma_is_still_refused():
    """The comma module's own refusal of a share past one."""

    with pytest.raises(OutOfRange):
        part_of("syntonic", 2)
    with pytest.raises(OutOfRange):
        part_of("pythagorean", Fraction(3, 2))


def test_equal_and_just_still_have_no_chain_to_move():
    """And the tunings that do still move it."""

    for name in ("equal", "just"):
        with pytest.raises(Unsupported):
            table.flatward(name)
    one = table.named("quarter_comma")
    other = table.flatward("quarter_comma")
    assert wolves.the_wolf(one)["from"] != wolves.the_wolf(other)["from"]


def test_pythagorean_tuning_by_name_is_unchanged():
    """Eleven pure fifths and a wolf a comma narrow."""

    text = run(["tuning", "pythagorean"])[1]
    assert value_of(text, "F#") == "611.7300"
    text = run(["temperaments"])[1]
    assert "-23.4600" in text
    assert run(["optimum", "--weights", "fifth=1"])[1].count(
        "Pythagorean") == 1


@pytest.mark.parametrize("number,name", [
    (1, "the fundamental"), (2, "the octave"), (3, "the twelfth"),
    (4, "the fifteenth"), (5, "the seventeenth"),
    (6, "the nineteenth"), (7, "the flat twenty-first"),
    (8, "the twenty-second"), (9, "the twenty-third"),
    (10, "the twenty-fourth"), (11, "the sharp twenty-fifth"),
    (12, "the twenty-sixth"), (13, "the flat twenty-seventh"),
    (14, "the flat twenty-eighth"),
])
def test_the_first_fourteen_harmonics_keep_their_names(number, name):
    """Only two were wrong."""

    assert harmonic.name_of(number) == name


def test_the_harmonics_table_is_still_sixteen_rows():
    """And still refuses the seventeenth."""

    text = run(["harmonics"])[1]
    assert value_of(text, "7") == "twenty-first"
    assert run(["harmonics", "--places", "2"])[0] == 0
    with pytest.raises(OutOfRange):
        harmonic.name_of(17)


@pytest.mark.parametrize("stops,pipes", [
    (("8",), 61), (("8", "4"), 73), (("16", "8"), 73),
    (("16", "8", "4"), 85), (("16", "8", "4", "2"), 97),
    (("16", "4"), 85), (("8", "2"), 85),
])
def test_a_rank_with_its_eight_foot_drawn_needs_what_it_needed(
        stops, pipes):
    """The documented counts, library and command."""

    assert rank.pipes_needed(61, stops) == pipes
    text = run(["unit", "--stops", ",".join(stops)])[1]
    assert value_of(text, "pipes") == str(pipes)


def test_the_documented_unit_rank_is_unchanged():
    """Eighty-five pipes, twenty-four extra, ninety-eight saved."""

    text = run(["unit"])[1]
    assert value_of(text, "pipes") == "85"
    assert value_of(text, "extra") == "24"
    assert value_of(text, "as_separate_ranks") == "183"
    assert value_of(text, "saved") == "98"


def test_thinning_and_mutations_are_untouched():
    """A unit rank still loses a note to sharing, and a mutation is
    still refused a place on a unison rank."""

    text = run(["thinning", "24", "36"])[1]
    assert value_of(text, "lost") == "1"
    assert run(["unit", "--stops", "8,2 2/3"])[0] == 3
    assert run(["unit", "--stops", "8", "--compass", "0"])[0] == 3


def test_the_fifth_is_still_the_interval_asked_about_by_default():
    """intervals and spread without --steps are about fifths."""

    code, text = run(["intervals", "quarter_comma"])
    assert code == 0, text
    assert "35.6823" in text
    assert "3:2" in text
    code, text = run(["spread", "quarter_comma"])
    assert code == 0, text
    assert value_of(text, "steps") == "7"
    assert value_of(text, "spread") == "41.0589"


def test_thinning_counts_another_chord_as_before():
    """A semitone apart, nothing is shared and nothing is lost."""

    code, text = run(["thinning", "24", "25"])
    assert code == 0, text
    assert value_of(text, "lost") == "0"
    assert value_of(text, "sounding") == "4"


def test_readings_in_one_octave_match_as_before():
    """The files page's example and the package's own readings."""

    doc = ["263.18", "275", "294.25", "314.84", "328.98", "352.4",
           "368.18", "393.55", "411.22", "439.99", "470.78", "492.14"]
    code, text = run(["which"] + doc)
    assert code == 0, text
    assert "quarter_comma" in figure(text)[2]
    assert "1.9753" in text
    assert "it is decided" in " ".join(text.split())
    found = identify.identify(identify.frequencies_of("sixth_comma"))
    assert found["best"] == "sixth_comma"
    assert found["decided"]


def test_which_still_wants_twelve_readings_above_nought():
    """Thirteen, eleven and a nought are refused as before."""

    assert run(["which"] + ["261.6"] * 13)[0] in (2, 3)
    assert run(["which"] + ["261.6"] * 11)[0] in (2, 3)
    with pytest.raises(Inconsistent):
        identify.as_cents([261.6] * 13)
    with pytest.raises(Degenerate):
        identify.as_cents([0] + [261.6] * 11)


@pytest.mark.parametrize("name", ["werckmeister_iii", "pythagorean"])
def test_a_chart_drawn_to_another_scale_is_as_before(name):
    """Equal temperament against a tuning whose scale leaves its
    thirds clear of a half mark: twelve bars of one length, the
    nearest mark for the figure, as it already was."""

    code, text = run(["picture", "--temperament", name, "--against",
                      "equal"])
    assert code == 0, text
    found = [line.split(None, 1)[1].count("#")
             for line in text.splitlines()
             if "|" in line and line.rstrip().endswith("+13.6863")]
    assert len(found) == 12, text
    assert set(found) == {15}, text


def test_the_documented_chart_is_drawn_as_before():
    """Quarter-comma's ruined thirds fill the width and the rest are
    nought; the worked claims about bars still hold."""

    text = run(["picture", "--temperament", "quarter_comma"])[1]
    lengths = {line.split(None, 1)[1].count("#")
               for line in text.splitlines() if "|" in line}
    assert lengths == {0, 24}, text
    assert chart.bar(2, 1, 3) == "   |## "
    assert chart.bar(-2, 1, 3) == " ##|   "
    assert chart.bar(99, 1, 3) == "   |###"
    assert chart.bar(0, 1, 3) == "   |   "


def test_twelve_fifths_are_still_seven_octaves_and_a_comma():
    """The documented circle."""

    code, text = run(["circle", "12"])
    assert code == 0, text
    assert value_of(text, "octaves") == "7"
    assert value_of(text, "cents") == "23.4600"
    assert value_of(text, "closes") == "no"
    assert run(["circle"])[1] == text


def test_beats_inside_one_octave_are_as_before():
    """C to G is G4 at 0.4429 and E to B is B4."""

    text = run(["beats", "C", "G"])[1]
    assert value_of(text, "upper") == "G4"
    assert value_of(text, "beats") == "0.4429"
    text = run(["beats", "E", "B", "--temperament", "quarter_comma"])[1]
    assert value_of(text, "upper") == "B4"
    assert value_of(text, "lower") == "E4"


def test_the_documented_optima_keep_their_names():
    """A quarter on the total, a fifth and a sixth on the worst, and
    nought for the fifths alone."""

    assert optimal.best({"fifth": 1, "major_third": 1},
                        how="total")["as_a_fraction"] == "1/4"
    assert optimal.best({"fifth": 1, "major_third": 1},
                        how="worst")["as_a_fraction"] == "1/5"
    assert optimal.best({"fifth": 2, "major_third": 1},
                        how="worst")["as_a_fraction"] == "1/6"
    assert "Pythagorean" in optimal.best({"fifth": 1})["as_a_fraction"]
    text = run(["optimum", "--weights", "fifth=1,major_third=1",
                "--how", "total"])[1]
    assert value_of(text, "as_a_fraction") == "1/4"


def test_the_documented_rounding_costs_are_unchanged():
    """A415 cost 1.2706 cents and A392 0.0202, to four places."""

    text = run(["rounding", "-1"])[1]
    assert value_of(text, "exact") == "415.3047"
    assert value_of(text, "cents") == "-1.2706" or value_of(
        text, "cents") == "1.2706", text
    text = run(["rounding", "-2"])[1]
    assert value_of(text, "exact") == "391.9954"


def test_the_other_stops_still_sound_what_they_sounded():
    """A fifth above, an octave below, a twelfth above."""

    assert stop.sounds("5 1/3") == "a fifth above"
    assert stop.sounds("16") == "an octave below"
    assert stop.sounds("2 2/3") == "a twelfth above"
    text = run(["stops"])[1]
    assert "a fifth above" in text and "a twelfth above" in text
