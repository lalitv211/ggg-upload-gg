"""A temperament on another tonic, through the file checker and the
command line.

The library's frequencies reach a person two ways: a ``.stops`` file's
claims, which the package recomputes, and the three commands that
print a frequency. Both routes carry the file's or the option's tonic,
so both are tried here on tonics other than C.
"""

from __future__ import annotations

import pytest

from wolf.cli.main import run
from wolf.io import bundle
from wolf.io import check as checking
from wolf.io.write import from_mapping
from wolf.pitch import frequency, note
from wolf.temper import table


def figure(text, name):
    """The value printed beside a name in a report's figure part."""

    for line in text.splitlines():
        words = line.split()
        if words and words[0] == name:
            return words[-1]
    raise AssertionError("no line for {0!r} in:\n{1}".format(name, text))


def table_rows(text):
    """The rows of a report's table, as lists of words."""

    lines = text.splitlines()
    rules = [index for index, line in enumerate(lines)
             if line.strip() and set(line.replace(" ", "")) == {"-"}
             and "  " in line]
    assert rules, text
    out = []
    for line in lines[rules[0] + 1:]:
        if not line.strip():
            break
        out.append(line.split())
    return out


def test_hertz_on_another_tonic_prints_middle_c():
    """The documented 263.1814, from a tonic of G."""

    code, text = run(["hertz", "C4", "--temperament", "quarter_comma",
                      "--tonic", "G"])
    assert code == 0, text
    assert figure(text, "hertz") == "263.1814", text
    assert figure(text, "sounding") == "C4"
    assert figure(text, "tonic") == "G"


def test_hertz_on_a_tonic_above_a_keeps_the_standard():
    """A4 is 440 on B, at a440."""

    code, text = run(["hertz", "A4", "--temperament", "equal",
                      "--tonic", "B"])
    assert code == 0, text
    assert figure(text, "hertz") == "440", text
    code, text = run(["hertz", "A4", "--temperament", "quarter_comma",
                      "--tonic", "Bb", "--standard", "a415"])
    assert code == 0, text
    assert figure(text, "hertz") == "415", text


@pytest.mark.parametrize("tonic", ("D", "G", "A", "Bb", "B"))
def test_hertz_on_every_tonic_agrees_with_c(tonic):
    """Whatever the command prints for C4 on C, it prints on G."""

    want = run(["hertz", "C4", "--temperament", "sixth_comma"])[1]
    code, text = run(["hertz", "C4", "--temperament", "sixth_comma",
                      "--tonic", tonic])
    assert code == 0, text
    assert figure(text, "hertz") == figure(want, "hertz"), (tonic, text)
    assert figure(text, "key") == figure(want, "key")


def scale_rows(args, octave):
    """Note and hertz of every row scale prints, in one octave on C."""

    code, text = run(["scale", "--octave", str(octave)] + list(args))
    assert code == 0, text
    return [tuple(row[:2]) for row in table_rows(text)]


def check_scale(args, octave, tonic):
    """The scale on a tonic lists twelve rising notes, each at the
    hertz its own name has on C, numbered in the octave asked for or
    the one above it; the text is returned for more checks."""

    want = dict(scale_rows(args, octave) + scale_rows(args, octave + 1))
    code, text = run(["scale", "--octave", str(octave),
                      "--tonic", tonic] + list(args))
    assert code == 0, text
    found = [tuple(row[:2]) for row in table_rows(text)]
    assert len(found) == 12, found
    assert len({name.rstrip("0123456789")
                for name, _ in found}) == 12, found
    for name, hertz in found:
        assert name in want, (name, sorted(want))
        assert hertz == want[name], (name, hertz, want[name])
    hertz = [float(one) for _, one in found]
    assert hertz == sorted(hertz), found
    return text


def test_scale_on_another_tonic_lists_one_octave():
    """Twelve notes, each at the hertz its name has on C, whether the
    list starts at C4 or at G4 and runs on into the fifth octave."""

    text = check_scale(["--temperament", "equal"], 4, "G")
    assert "391.9954" in text
    assert "493.8833" in text


def test_scale_on_b_keeps_the_standard():
    """And prints the same twelve frequencies as on C, with the A it
    lists on the standard: A4 at 440 or, when the list runs on from B4
    into the fifth octave, A5 at 880."""

    text = check_scale(["--temperament", "equal"], 4, "B")
    found = table_rows(text)
    named = [row[:2] for row in found if row[0] in ("A4", "A5")]
    assert named in ([["A4", "440"]], [["A5", "880"]]), found


def test_scale_on_another_tonic_and_standard_and_octave():
    """Every knob at once: meantone on E flat at a415 in the third
    octave matches the same tuning on C."""

    check_scale(["--temperament", "quarter_comma", "--standard", "a415"],
                3, "Eb")


def test_beats_on_another_tonic():
    """The fifth a tuner counts does not depend on where the ratios
    start."""

    code, text = run(["beats", "C", "G", "--temperament", "equal",
                      "--tonic", "G"])
    assert code == 0, text
    assert figure(text, "beats") == "0.4429", text
    assert figure(text, "tempered") == "391.9954", text
    want = run(["beats", "C", "E", "--temperament", "quarter_comma"])[1]
    code, text = run(["beats", "C", "E", "--temperament", "quarter_comma",
                      "--tonic", "D"])
    assert code == 0, text
    assert figure(text, "beats") == figure(want, "beats")
    assert figure(text, "just") == figure(want, "just")


def test_a_claims_file_on_another_tonic_agrees(tmp_path):
    """A chapel organ in meantone on G writes down its A and its middle
    C, and both hold."""

    path = tmp_path / "chapel-on-g.stops"
    path.write_text("\n".join([
        "# a chapel organ in meantone, measured from G",
        "[instrument]", "place = Chapel", "[tuning]",
        "temperament = quarter_comma", "tonic = G", "standard = a440",
        "[claims]", "a4 = 440", "middle_c = 263.1814", "",
    ]), encoding="utf-8")
    code, text = run(["claims", str(path)])
    assert code == 0, text
    rows = table_rows(text)
    assert sorted(row[0] for row in rows) == ["a4", "middle_c"], rows
    assert [row[-1] for row in rows] == ["agrees", "agrees"], rows
    code, text = run(["verdict", str(path)])
    assert code == 0, text
    assert figure(text, "agreed") == "yes", text
    assert figure(text, "disagrees") == "0", text


def test_a_claims_file_on_b_keeps_a_on_the_standard(tmp_path):
    """Equal temperament written down from B still has A4 at 440."""

    path = tmp_path / "on-b.stops"
    path.write_text("\n".join([
        "# written down from B", "[tuning]", "temperament = equal",
        "tonic = B", "standard = a440", "[claims]", "a4 = 440",
        "middle_c = 261.6256", "",
    ]), encoding="utf-8")
    code, text = run(["claims", str(path)])
    assert code == 0, text
    rows = table_rows(text)
    assert len(rows) == 2, rows
    assert [row[-1] for row in rows] == ["agrees", "agrees"], rows


def test_the_checker_recomputes_on_the_files_tonic():
    """The claims checker uses the tonic the file names, and gets the
    same figures as on C."""

    found = from_mapping({
        "tuning": {"temperament": "quarter_comma", "tonic": "G",
                   "standard": "a440"},
        "claims": {"a4": "440", "middle_c": "263.1814"},
    }, "on-g.stops")
    assert checking.agreed(found)
    assert checking.verdicts(found) == {"agrees": 2, "disagrees": 0,
                                        "unknown": 0,
                                        "uncheckable": 0}
    on_c = frequency.frequency(table.named("kirnberger_iii", "C"),
                               note.note("C4"), "a415")
    high = from_mapping({
        "tuning": {"temperament": "kirnberger_iii", "tonic": "Bb",
                   "standard": "a415"},
        "claims": {"a4": "415", "middle_c": "{0:.3f}".format(
            float(on_c))},
    }, "on-bb.stops")
    assert checking.agreed(high), checking.check(high)
    computed = checking.computed(high)
    assert abs(computed["middle_c"] - on_c) < 1e-6
    assert computed["a4"] == 415


def test_a_survey_with_a_default_tonic_checks_every_instrument():
    """A diocese that writes its instruments down from G."""

    text = "\n".join([
        "[defaults]", "tuning.tonic = G", "tuning.standard = a440",
        "---",
        "[instrument]", "place = Chapel", "[tuning]",
        "temperament = quarter_comma", "[claims]",
        "middle_c = 263.1814", "a4 = 440",
        "---",
        "[instrument]", "place = Hall", "[tuning]",
        "temperament = equal", "[claims]", "middle_c = 261.6256",
        "---",
        "[instrument]", "place = Loft", "[tuning]",
        "temperament = werckmeister_iii", "tonic = B", "[claims]",
        "a4 = 440",
    ])
    found = bundle.with_defaults(bundle.split(text, "survey.stops"))
    rows = bundle.check_all(found)
    assert [row["agreed"] for row in rows] == [True, True, True], rows
    assert bundle.failing(found) == ()
    assert bundle.summary(found)["agreeing"] == 3
