"""Five answers that came back with exit nought and a wrong figure.

``intervals`` and ``spread`` judged every interval but the fifth
against a major third; ``character`` compared every key against C
whatever ``--tonic`` said; ``meantone --part 0`` refused the
Pythagorean tuning the package builds by name and ``flatward`` fell
over on it; the fifteenth and sixteenth harmonics shared one name; a
unit rank was counted as if an eight foot were always drawn; ``which``
took a reading in another octave for a different note; a chart cut
every bar down to the mark below; ``circle`` took seven octaves off
whatever the count; ``beats`` named the upper note an octave low;
``optimum`` called an eightieth a twelfth; ``rounding`` padded six
places with noughts; and the ten and two thirds foot stop was said to
sound a fifth below when its own harmonic is a fourth below.

Only outcomes are tested, through the command line and the public
functions the commands call: a figure, a verdict, a name. Where the
right answer can be got from the package itself (the just interval
of so many steps, the character of two keys, the wolf of a tuning)
it is, so no design of the fix is assumed.
"""

from __future__ import annotations

import re
from fractions import Fraction

import pytest

from wolf.cli.main import run
from wolf.constants import JUST
from wolf.format import chart
from wolf.format.report import parts_of
from wolf.constants import EQUAL_SEMITONE, cents_of
from wolf.interval import harmonic
from wolf.io import identify
from wolf.pipe import stop
from wolf.temper import optimal
from wolf.pipe import rank
from wolf.pitch import scale as scale_module
from wolf.temper import table
from wolf.temper import wolf as wolves

#: The just ratio of each number of semitone steps, nought to twelve:
#: the thirteen ratios ``wolf just`` lists, in order of size.
BY_STEPS = tuple(sorted(JUST.values()))

#: Every step count whose default was wrong: everything but the
#: fourth and the fifth.
STEPS = (1, 2, 3, 5, 6, 8, 9, 10, 11)


def written(ratio):
    """A ratio the way it is typed."""

    return "{0}:{1}".format(ratio.numerator, ratio.denominator)


def figure(text):
    """The figure part of a report, as its lines."""

    return parts_of(text)["figure"]


def value_of(text, name):
    """The value printed beside a name in a report's figure part."""

    for line in text.splitlines():
        words = line.split()
        if words and words[0] == name:
            return words[-1]
    raise AssertionError("no line for {0!r} in:\n{1}".format(name, text))


def rows_of(text):
    """A two-column table as {first word: last word}."""

    out = {}
    for line in figure(text):
        words = line.split()
        if len(words) == 2 and re.fullmatch(r"-?\d+(\.\d+)?", words[1]):
            out[words[0]] = words[1]
    return out


# --- intervals and spread --------------------------------------------


@pytest.mark.parametrize("steps", STEPS)
@pytest.mark.parametrize("name", table.known())
def test_intervals_are_judged_against_the_just_interval_of_their_steps(
        name, steps):
    """The figures are the ones ``--just`` gives when it names the
    just ratio of that many steps, and the report says which."""

    just = BY_STEPS[steps]
    code, plain = run(["intervals", name, "--steps", str(steps)])
    assert code == 0, plain
    code, chosen = run(["intervals", name, "--steps", str(steps),
                        "--just", written(just)])
    assert code == 0, chosen
    assert figure(plain) == figure(chosen)
    assert written(just) in plain


@pytest.mark.parametrize("steps", STEPS)
@pytest.mark.parametrize("name", table.known())
def test_spread_is_judged_against_the_just_interval_of_its_steps(
        name, steps):
    """Same figures as naming the ratio, and the ratio is named."""

    just = BY_STEPS[steps]
    code, plain = run(["spread", name, "--steps", str(steps)])
    assert code == 0, plain
    code, chosen = run(["spread", name, "--steps", str(steps),
                        "--just", written(just)])
    assert code == 0, chosen
    assert figure(plain) == figure(chosen)
    assert written(just) in plain


def test_a_ratio_named_by_hand_still_wins():
    """``--just`` was never the problem and is not taken away."""

    code, text = run(["spread", "quarter_comma", "--steps", "3",
                      "--just", "7:6"])
    assert code == 0, text
    assert "7:6" in text
    assert "6:5" not in text
    code, text = run(["intervals", "equal", "--steps", "10", "--just",
                      "7:4"])
    assert code == 0, text
    assert "7:4" in text
    assert "16:9" not in text


# --- character --------------------------------------------------------

#: Every tuning and tonic whose table changes once the keys are
#: measured from the tonic: the circulating temperaments from any
#: tonic, and the regular ones from a tonic whose scale crosses the
#: wolf. Equal temperament reads the same from anywhere.
TONICS = [
    ("werckmeister_iii", "A"), ("werckmeister_iii", "B"),
    ("werckmeister_iii", "Bb"), ("werckmeister_iii", "C#"),
    ("werckmeister_iii", "D"), ("werckmeister_iii", "E"),
    ("werckmeister_iii", "Eb"), ("werckmeister_iii", "F"),
    ("werckmeister_iii", "F#"), ("werckmeister_iii", "G"),
    ("werckmeister_iii", "G#"),
    ("kirnberger_iii", "A"), ("kirnberger_iii", "B"),
    ("kirnberger_iii", "Bb"), ("kirnberger_iii", "C#"),
    ("kirnberger_iii", "D"), ("kirnberger_iii", "E"),
    ("kirnberger_iii", "Eb"), ("kirnberger_iii", "F"),
    ("kirnberger_iii", "F#"), ("kirnberger_iii", "G"),
    ("kirnberger_iii", "G#"),
] + [(name, tonic)
     for name in ("pythagorean", "quarter_comma", "sixth_comma",
                  "fifth_comma", "third_comma")
     for tonic in ("B", "C#", "E", "Eb", "F#", "G#")]


@pytest.mark.parametrize("name,tonic", TONICS,
                         ids=["-".join(one) for one in TONICS])
def test_character_measures_every_key_from_the_tonic(name, tonic):
    """The tonic's own row is nought and every other row is how far
    that key's scale is from the tonic's, which the scale module
    already works out for any two keys."""

    made = table.named(name, tonic)
    code, text = run(["character", "--temperament", name,
                      "--tonic", tonic])
    assert code == 0, text
    rows = rows_of(text)
    assert set(rows) == set(made.notes()), text
    assert float(rows[tonic]) == 0, text
    for key, shown in rows.items():
        want = scale_module.character(made, tonic, key)["worst"]
        assert abs(float(shown) - float(want)) < 0.00006, (key, text)


@pytest.mark.parametrize("name,tonic", [
    ("werckmeister_iii", "D"), ("kirnberger_iii", "D"),
    ("kirnberger_iii", "E"), ("kirnberger_iii", "G"),
], ids=lambda one: one)
def test_the_levels_are_counted_from_the_tonic_too(name, tonic):
    """The count in the working part is the number of distinct
    amounts in the table it sits under."""

    made = table.named(name, tonic)
    code, text = run(["character", "--temperament", name,
                      "--tonic", tonic])
    assert code == 0, text
    found = re.search(r"(\d+) distinct level", " ".join(text.split()))
    assert found, text
    distinct = {round(float(scale_module.character(
        made, tonic, key)["worst"]), 4) for key in made.notes()}
    assert int(found.group(1)) == len(distinct), text
    assert len({round(float(one), 4)
                for one in rows_of(text).values()}) == len(distinct)


# --- nought parts of a comma -----------------------------------------


@pytest.mark.parametrize("part", ["0", "0/4", "0.0"])
def test_meantone_with_no_part_of_a_comma_is_pythagorean(part):
    """Eleven fifths narrowed by nothing, and a wolf that is the
    twelfth fifth of ``chain pythagorean``."""

    code, text = run(["meantone", "--part", part])
    assert code == 0, (part, text)
    assert float(value_of(text, "each_fifth_narrowed")) == 0
    code, chain = run(["chain", "pythagorean"])
    assert code == 0, chain
    the_wolf = [line.split() for line in figure(chain)
                if line.split() and line.split()[-1] == "yes"]
    assert len(the_wolf) == 1, chain
    assert value_of(text, "wolf_cents") == the_wolf[0][2], text
    assert round(float(value_of(text, "wolf_wide_by")), 4) == -23.46


def test_meantone_with_no_part_still_wants_a_comma_it_knows():
    """The comma has to exist even when none of it is taken."""

    code, text = run(["meantone", "--part", "0", "--comma",
                      "pythagorean"])
    assert code == 0, text
    assert float(value_of(text, "each_fifth_narrowed")) == 0
    code, text = run(["meantone", "--part", "0", "--comma",
                      "ptolemaic"])
    assert code in (2, 3), text
    assert len(text.splitlines()) == 1


def test_pythagorean_tuning_lays_out_flatward():
    """Eleven pure fifths and the wolf somewhere else."""

    usual = table.named("pythagorean")
    other = table.flatward("pythagorean")
    assert len(other.notes()) == 12
    assert wolves.the_wolf(usual)["from"] != wolves.the_wolf(other)["from"]
    assert round(float(wolves.the_wolf(other)["error"]), 4) == -23.46
    pure = [row for row in wolves.fifths(other) if row["error"] == 0]
    assert len(pure) == 11


# --- the harmonic series ---------------------------------------------


def test_the_sixteenth_harmonic_is_the_twenty_ninth():
    """Four octaves, which a mixture's 29 already sounds as the
    sixteenth harmonic."""

    assert harmonic.name_of(16) == "the twenty-ninth"


def test_the_fifteenth_harmonic_is_the_twenty_eighth():
    """A major seventh above the twenty-second."""

    assert harmonic.name_of(15) == "the twenty-eighth"


def test_harmonics_shows_the_two_names():
    """The table carries them, and no harmonic is named after
    another's octave."""

    code, text = run(["harmonics"])
    assert code == 0, text
    assert value_of(text, "15") == "twenty-eighth"
    assert value_of(text, "16") == "twenty-ninth"
    assert "'s octave" not in text


# --- a unit rank ------------------------------------------------------

#: Stops drawn, the compass, and the pipes the rank needs: from the
#: lowest pipe a drawn stop reaches to the highest.
RANKS = [
    (("4",), 61, 61),
    (("2",), 61, 61),
    (("1",), 61, 61),
    (("16",), 61, 61),
    (("32",), 61, 61),
    (("4", "2"), 61, 73),
    (("4", "1"), 61, 85),
    (("2", "1"), 61, 73),
    (("4", "2", "1"), 61, 85),
    (("32", "16"), 61, 73),
    (("4",), 56, 56),
    (("4", "2"), 56, 68),
    (("16",), 32, 32),
    (("32", "16"), 32, 44),
]


@pytest.mark.parametrize("stops,compass,pipes", RANKS,
                         ids=lambda one: str(one).replace(" ", ""))
def test_a_unit_rank_counts_the_stops_that_are_drawn(stops, compass,
                                                     pipes):
    """Through the command: the pipes, what is extra beyond the
    compass, and what is saved against separate ranks, which is
    never below nought."""

    code, text = run(["unit", "--stops", ",".join(stops),
                      "--compass", str(compass)])
    assert code == 0, text
    assert value_of(text, "pipes") == str(pipes), text
    assert value_of(text, "extra") == str(pipes - compass), text
    assert value_of(text, "saved") == str(compass * len(stops) - pipes)


@pytest.mark.parametrize("stops,compass,pipes", RANKS,
                         ids=lambda one: str(one).replace(" ", ""))
def test_pipes_needed_counts_the_stops_that_are_drawn(stops, compass,
                                                      pipes):
    """And the library agrees with the command."""

    assert rank.pipes_needed(compass, stops) == pipes
    found = rank.extended(compass, stops)
    assert found["pipes"] == pipes
    assert found["saved"] >= 0


# --- which: readings in more than one octave --------------------------


def readings(name):
    """Twelve readings this package would make of a tuning, as typed."""

    return ["{0:.4f}".format(float(one))
            for one in identify.frequencies_of(name)]


def moved(words, factors):
    """The same readings with some of them in another octave: each
    is multiplied by its factor, a power of two, which keeps the
    four written places exact."""

    return ["{0:.4f}".format(float(Fraction(one) * factors.get(where, 1)))
            for where, one in enumerate(words)]


#: Which readings are moved, and by how many octaves: one reading
#: up, one two octaves up, everything but one up (so one reading is
#: an octave below the rest), and three moved at once.
OCTAVES = {
    "one_up": {11: 2},
    "two_up": {3: 4},
    "one_below_the_rest": {where: 2 for where in range(12) if where != 5},
    "three_moved": {0: 2, 7: 4, 9: 8},
}


def matches_of(text):
    """Each tuning's worst note from a which table, and whether the
    match was decided; which reading counted as the lowest, and so
    the rotation, is not part of it."""

    rows = {}
    for line in figure(text):
        words = line.split()
        if len(words) == 3 and re.fullmatch(r"[\d.]+", words[1]):
            rows[words[0]] = words[1]
    return rows, "not decided" not in " ".join(text.split())


@pytest.mark.parametrize("pattern", sorted(OCTAVES))
@pytest.mark.parametrize("name", table.known())
def test_which_brings_every_reading_into_one_octave(name, pattern):
    """A pipe read an octave out is the same reading: every tuning
    is as far from the readings as it was when they sat in one
    octave, and the match is still decided."""

    plain = readings(name)
    code, before = run(["which"] + plain)
    assert code == 0, before
    code, after = run(["which"] + moved(plain, OCTAVES[pattern]))
    assert code == 0, after
    assert matches_of(after) == matches_of(before)
    assert len(matches_of(after)[0]) == 9
    assert matches_of(after)[1]


def test_the_documented_readings_match_with_one_an_octave_up():
    """The files page's own example, with its top reading doubled."""

    doc = ["263.18", "275", "294.25", "314.84", "328.98", "352.4",
           "368.18", "393.55", "411.22", "439.99", "470.78", "492.14"]
    up = doc[:-1] + ["984.28"]
    code, text = run(["which"] + up)
    assert code == 0, text
    assert matches_of(text) == matches_of(run(["which"] + doc)[1])
    assert "quarter_comma" in figure(text)[2]


# --- a chart's bars ----------------------------------------------------


def lengths_of(text, figure_text=None):
    """How many marks each bar line has, its label left out (a sharp
    in a note name is not a mark), for the bars with a figure."""

    out = []
    for line in text.splitlines():
        if "|" not in line:
            continue
        label, rest = line.split(None, 1)
        if figure_text is None or rest.rstrip().endswith(figure_text):
            out.append(rest.count("#"))
    return out


def test_a_bar_is_the_nearest_number_of_marks():
    """Not the mark below: nine tenths of a third mark is three."""

    assert chart.bar(Fraction(29, 10), 1, 3).count("#") == 3
    assert chart.bar(Fraction(-29, 10), 1, 3).count("#") == 3
    assert chart.bar(Fraction(21, 10), 1, 3).count("#") == 2
    assert chart.bar(Fraction(4, 10), 1, 3).count("#") == 0
    assert chart.bar(Fraction(239999, 10000), 1, 24).count("#") == 24


def test_figures_that_print_alike_are_drawn_alike():
    """Through the chart itself, on two values a hair apart."""

    made = chart.bars({"a": 10, "b": Fraction(99999, 10000)})
    assert made[0].count("#") == 24
    assert made[1].count("#") == 24


def test_equal_temperaments_thirds_are_drawn_at_one_length():
    """Twelve identical figures, twelve identical bars, all full."""

    code, text = run(["picture", "--temperament", "equal"])
    assert code == 0, text
    assert set(lengths_of(text)) == {24}, text


def test_equal_temperament_is_drawn_alike_against_quarter_comma():
    """Drawn to meantone's scale its thirds are a hair under eight
    marks each, so they are eight, and all twelve are one length."""

    code, text = run(["picture", "--temperament", "quarter_comma",
                      "--against", "equal"])
    assert code == 0, text
    found = lengths_of(text, "+13.6863")
    assert len(found) == 12, text
    assert len(set(found)) == 1, text
    worth = re.search(r"one # is \+([\d.]+)", text)
    assert worth, text
    assert found[0] == round(13.6863 / float(worth.group(1))), text


# --- the circle of fifths ----------------------------------------------


@pytest.mark.parametrize("fifths,octaves,cents", [
    (5, 3, "-90.2250"), (7, 4, "113.6850"), (19, 11, "137.1450"),
    (24, 14, "46.9200"), (31, 18, "160.6050"), (41, 24, "-19.8450"),
    (53, 31, "3.6150"),
])
def test_a_run_of_fifths_is_measured_against_the_nearest_octaves(
        fifths, octaves, cents):
    """Fifty-three fifths are 3.615 cents from thirty-one octaves."""

    code, text = run(["circle", str(fifths)])
    assert code == 0, text
    assert value_of(text, "octaves") == str(octaves), text
    assert value_of(text, "cents") == cents, text
    assert value_of(text, "closes") == "no", text


# --- the upper note of a beat rate --------------------------------------


@pytest.mark.parametrize("lower,upper,octave,want", [
    ("G", "D", "4", "D5"), ("B", "F#", "3", "F#4"), ("A", "E", "4", "E5"),
    ("F", "C", "4", "C5"), ("G#", "D#", "5", "D#6"),
])
def test_the_upper_note_of_a_beat_rate_is_named_where_it_sounds(
        lower, upper, octave, want):
    """The name beside the tempered frequency is the note in the
    octave the frequency was brought to, which hertz confirms."""

    code, text = run(["beats", lower, upper, "--temperament", "equal",
                      "--octave", octave])
    assert code == 0, text
    assert value_of(text, "upper") == want, text
    code, hertz = run(["hertz", want, "--temperament", "equal"])
    assert code == 0, hertz
    assert value_of(hertz, "hertz") == value_of(text, "tempered"), text


# --- the fraction optimum names ----------------------------------------


def test_optimum_names_the_fraction_the_part_is_when_none_is_near():
    """An eightieth is an eightieth, not the twelfth that was the
    nearest thing with a small denominator."""

    code, text = run(["optimum", "--weights", "fifth=3,major_third=1",
                      "--how", "total"])
    assert code == 0, text
    assert value_of(text, "part") == "0.0125", text
    assert value_of(text, "as_a_fraction") == "1/80", text


@pytest.mark.parametrize("weights", [
    {"fifth": 4, "major_third": 1}, {"fifth": 6, "major_third": 1},
])
def test_the_fraction_named_is_never_far_from_the_part(weights):
    """Through the library: the name is a fraction within a sweep
    step of the part, which for these is the part itself."""

    found = optimal.best(weights, how="total")
    top, bottom = found["as_a_fraction"].split("/")
    assert abs(Fraction(int(top), int(bottom)) - found["part"]) <= Fraction(
        1, 240), found


# --- rounding a standard, to the places asked --------------------------


@pytest.mark.parametrize("steps,whole", [("-1", 415), ("1", 466),
                                         ("-2", 392)])
def test_a_standard_moved_by_semitones_is_carried_whole(steps, whole):
    """Twelve places asked for are twelve places, not six and
    noughts; the cost in cents follows the whole figure."""

    exact = 440 * EQUAL_SEMITONE ** int(steps)
    code, text = run(["rounding", steps, "--places", "12"])
    assert code == 0, text
    shown = value_of(text, "exact")
    assert not shown.endswith("000000"), text
    assert abs(float(shown) - float(exact)) < 1e-8, text
    cost = cents_of(Fraction(whole) / exact)
    assert abs(float(value_of(text, "cents")) - float(cost)) < 1e-8, text


# --- what a stop sounds ------------------------------------------------


def test_the_ten_and_two_thirds_foot_sounds_a_fourth_below():
    """Its harmonic is three quarters, which is 498 cents down."""

    code, text = run(["stops"])
    assert code == 0, text
    row = [line for line in text.splitlines() if line.startswith("10 2/3")]
    assert row and "fourth below" in row[0], text
    assert "fifth below" not in text
    assert "fourth" in stop.sounds("10 2/3")
