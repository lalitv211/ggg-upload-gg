"""A temperament on another tonic: the frequencies it comes out at.

The ratios are measured upward from the tonic, but a note sounds in
the octave its number names whatever the tonic. Every test here holds
the package to the two facts that follow: A4 is the standard's A
whatever the tonic, and the same tuning measured from another of its
notes puts every note where it put it measured from C. Whether a
scale is listed from C or from the tonic is left to the package.

Only outcomes are tested -- frequencies, pitches, scales, beats and
ranges -- never how the join between the standard and the tonic is
worked out.
"""

from __future__ import annotations

from fractions import Fraction

import pytest

from wolf.errors import NotInTheTemperament
from wolf.pitch import frequency, note
from wolf.temper import circle, table

#: Equal temperament's semitone is a twelve-place root, so two routes
#: round the circle differ in the tenth decimal of a hertz. Anything
#: closer than this is the same frequency.
CLOSE = Fraction(1, 10 ** 6)

#: Every tonic the usual chain allows, except the one that always
#: worked.
TONICS = tuple(one for one in circle.USUAL if one != "C")

#: The tunings built from a chain of fifths, which can be measured from
#: any note on it.
CHAINED = tuple(one for one in table.known() if one not in table.APART)


def tonics_of(name):
    """Every tonic a named temperament can be measured from."""

    if name == "just":
        return ("C",)
    if name == "equal":
        return table.named(name).notes()
    return circle.chain_for(table.named(name))


def in_octave(one, octave=4, standard="a440"):
    """Every note of a tuning in one numbered octave, by name."""

    out = {}
    for name in one.notes():
        made = note.Note(name[0], name.count("#") - name.count("b"),
                         octave)
        out[name] = frequency.frequency(one, made, standard)
    return out


def same(first, second, close=CLOSE):
    """Whether two frequencies are the same to the places that mean
    anything."""

    return abs(Fraction(first) - Fraction(second)) < close


@pytest.mark.parametrize("tonic", TONICS)
def test_middle_c_is_middle_c_whatever_the_tonic(tonic):
    """Quarter-comma meantone measured from any note of its chain has
    the same eleven fifths, so its middle C is still 263.1814."""

    made = table.named("quarter_comma", tonic)
    found = frequency.frequency(made, note.note("C4"), "a440")
    assert round(float(found), 4) == 263.1814, (tonic, float(found))
    assert same(frequency.pitch(made, "C3", "a440").hertz, found / 2)
    assert same(frequency.pitch(made, "C5", "a440").hertz, found * 2)


@pytest.mark.parametrize("name,tonic", [
    ("equal", "A#"), ("equal", "B"), ("quarter_comma", "Bb"),
    ("quarter_comma", "B"), ("werckmeister_iii", "Bb"),
    ("kirnberger_iii", "B"), ("pythagorean", "B"),
])
def test_the_standard_is_the_standard_on_a_tonic_above_a(name, tonic):
    """B flat and B have the A of their octave below them, and A4 is
    still the standard's A."""

    made = table.named(name, tonic)
    for standard, want in (("a440", 440), ("a415", 415),
                           ("a392", 392)):
        found = frequency.frequency(made, note.note("A4"), standard)
        assert same(found, want), (name, tonic, standard, float(found))
    assert same(frequency.frequency(made, note.note("A3"), "a440"),
                220), (name, tonic)
    assert same(frequency.frequency(made, note.note("A5"), "a440"),
                880), (name, tonic)


@pytest.mark.parametrize("name", CHAINED + ("equal",))
def test_a_tonic_is_a_reference_and_not_a_pitch(name):
    """The same tuning measured from another of its notes is the same
    set of pitches, note for note."""

    on_c = in_octave(table.named(name, "C"))
    tried = 0
    for tonic in tonics_of(name):
        if tonic == "C":
            continue
        tried += 1
        found = in_octave(table.named(name, tonic))
        assert set(found) == set(on_c), (name, tonic)
        for each in sorted(on_c):
            assert same(found[each], on_c[each]), (
                name, tonic, each, float(found[each]),
                float(on_c[each]))
    assert tried >= 11, name


@pytest.mark.parametrize("name,tonic", [
    ("equal", "G"), ("equal", "B"), ("quarter_comma", "D"),
    ("quarter_comma", "Bb"), ("pythagorean", "A"),
    ("werckmeister_iii", "F#"), ("sixth_comma", "G#"),
])
def test_a_scale_sounds_each_note_in_the_octave_it_names(name, tonic):
    """Twelve rising notes, each at the hertz its own name has on C.
    The list may start at C4 and stay in the fourth octave or start at
    the tonic and run on into the fifth; either way a note numbered 4
    sounds in the fourth octave and one numbered 5 an octave up."""

    made = table.named(name, tonic)
    on_c = table.named(name, "C")
    found = frequency.scale(made, 4, "a440")
    bottom = frequency.frequency(on_c, note.note("C4"), "a440")
    assert len(found) == 12
    assert len({(one.note.letter, one.note.accidental)
                for one in found}) == 12, (name, tonic)
    for one in found:
        assert one.note.octave in (4, 5), (name, tonic, str(one.note))
        want = frequency.frequency(on_c, one.note, "a440")
        assert same(one.hertz, want), (
            name, tonic, str(one.note), float(one.hertz), float(want))
        assert bottom - CLOSE <= one.hertz < 4 * bottom, (
            name, tonic, str(one.note), float(one.hertz))
    hertz = [one.hertz for one in found]
    assert hertz == sorted(hertz), (name, tonic)


def test_the_table_carries_the_same_frequencies():
    """The frequency table is the scale laid out, and on another tonic
    its hertz are the notes' own, whichever octave its C is listed
    in."""

    made = table.named("equal", "G")
    rows = {row["note"]: row
            for row in frequency.table(made, 4, "a440")}
    assert set(rows) == {str(one.note) for one in frequency.scale(
        made, 4, "a440")}
    assert round(float(rows["G4"]["hertz"]), 4) == 391.9954
    assert round(float(rows["B4"]["hertz"]), 4) == 493.8833
    listed = [one for one in ("C4", "C5") if one in rows]
    assert len(listed) == 1, sorted(rows)
    want = {"C4": 261.6256, "C5": 523.2511}[listed[0]]
    assert round(float(rows[listed[0]]["hertz"]), 4) == want


@pytest.mark.parametrize("name,tonic", [
    ("equal", "G"), ("equal", "D"), ("equal", "B"),
    ("quarter_comma", "G"), ("quarter_comma", "Bb"),
])
def test_beats_are_the_same_fifth_on_another_tonic(name, tonic):
    """A tuner setting C to G hears the same fifth whichever note the
    tuning was written down from."""

    want = frequency.beats_against_just(
        table.named(name, "C"), "C", "G", Fraction(3, 2), "a440", 4)
    found = frequency.beats_against_just(
        table.named(name, tonic), "C", "G", Fraction(3, 2), "a440", 4)
    assert same(found["beats"], want["beats"]), (
        name, tonic, float(found["beats"]), float(want["beats"]))
    assert same(found["tempered"], want["tempered"]), (name, tonic)
    assert same(found["just"], want["just"]), (name, tonic)
    if name == "equal":
        assert round(float(found["beats"]), 4) == 0.4429, (name, tonic)


@pytest.mark.parametrize("tonic", ("G", "A#", "B"))
def test_the_audible_range_is_a_fact_about_the_pitch(tonic):
    """The octaves a C can be heard in do not depend on where the
    ratios start."""

    on_c = frequency.audible_range(table.named("equal", "C"), "C",
                                   "a440")
    found = frequency.audible_range(table.named("equal", tonic), "C",
                                    "a440")
    assert found == on_c, (tonic, found, on_c)
    on_c = frequency.audible_range(table.named("equal", "C"), "A",
                                   "a440")
    found = frequency.audible_range(table.named("equal", tonic), "A",
                                    "a440")
    assert found == on_c, (tonic, found, on_c)


@pytest.mark.parametrize("standard", ("a415", "a392", "a466", "a442"))
def test_other_standards_move_everything_together(standard):
    """At any standard, a tonic of G gives the same middle C as a tonic
    of C, and A4 is the standard."""

    on_c = table.named("quarter_comma", "C")
    for tonic in ("G", "Eb", "Bb", "B"):
        made = table.named("quarter_comma", tonic)
        for text in ("C4", "E4", "A4", "G#4", "Eb3", "F5"):
            found = frequency.frequency(made, note.note(text), standard)
            want = frequency.frequency(on_c, note.note(text), standard)
            assert same(found, want), (standard, tonic, text,
                                       float(found), float(want))
        assert same(frequency.frequency(made, note.note("A4"),
                                        standard),
                    table.named("equal").ratios["C"]
                    * frequency.frequency(table.named("equal"),
                                          note.note("A4"), standard))


def test_other_octaves_follow_the_same_numbering():
    """A3 on a tonic of B is 220 and C5 on a tonic of G is twice middle
    C, because octave numbers change at C whatever the tonic is."""

    on_b = table.named("equal", "B")
    assert same(frequency.frequency(on_b, note.note("A3"), "a440"),
                220)
    assert same(frequency.frequency(on_b, note.note("A2"), "a440"),
                110)
    on_g = table.named("quarter_comma", "G")
    c4 = frequency.frequency(table.named("quarter_comma", "C"),
                             note.note("C4"), "a440")
    assert same(frequency.frequency(on_g, note.note("C5"), "a440"),
                2 * c4)
    assert same(frequency.frequency(on_g, note.note("C2"), "a440"),
                c4 / 4)
    low = frequency.pitch(on_g, "F#2", "a440")
    assert same(low.octave_up(2).hertz,
                frequency.pitch(on_g, "F#4", "a440").hertz)


def test_the_flat_chain_agrees_with_itself():
    """A tuning laid out flatward, measured from any of its own
    spellings, is still one set of pitches."""

    on_c = in_octave(table.flatward("quarter_comma", "C"))
    tried = 0
    for tonic in circle.FLATWARD:
        if tonic == "C":
            continue
        tried += 1
        found = in_octave(table.flatward("quarter_comma", tonic))
        for each in sorted(on_c):
            assert same(found[each], on_c[each]), (tonic, each)
    assert tried == 11
    on_db = table.flatward("sixth_comma", "Db")
    assert same(frequency.frequency(on_db, note.note("A4"), "a440"),
                440)


def test_a_note_the_tuning_has_not_got_is_still_refused_elsewhere():
    """Moving the tonic adds no spelling, and the refusal still names
    the tuning. Checked here because the fix has to keep it."""

    with pytest.raises(NotInTheTemperament) as bad:
        frequency.frequency(table.named("equal", "G"), note.note("Eb4"),
                            "a440")
    assert "equal" in str(bad.value)
    on_g = table.named("quarter_comma", "G")
    with pytest.raises(NotInTheTemperament):
        frequency.frequency(on_g, note.note("D#4"), "a440")
    assert same(frequency.frequency(on_g, note.note("Eb4"), "a440"),
                frequency.frequency(table.named("quarter_comma", "C"),
                                    note.note("Eb4"), "a440"))
