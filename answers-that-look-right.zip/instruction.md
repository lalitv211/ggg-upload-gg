Some commands answer with exit zero and wrong figure.

wolf spread quarter_comma --steps 3 compares minor thirds against 5:4, intervals too. Default should be just interval for that many steps, three is 6:5. keys and chord already have this table, reuse one table. Report says which ratio was used, spread too. --just by hand still wins.

wolf character --temperament werckmeister_iii --tonic D shows C with nought. Working line promises each key against tonic's own scale, so D should be nought, others compared with D major. Levels count comes from the same table.

wolf meantone --part 0 refuses, but optimum answers 0 as Pythagorean. Part zero should answer like any part, each fifth narrowed by nothing, wolf a Pythagorean comma narrow as wolf chain pythagorean shows. flatward for pythagorean crashes too, fix both. Comma name is still checked.

wolf harmonics calls harmonic 15 "the twenty-ninth" and 16 "the twenty-ninth's octave". 16 is four octaves up, the twenty-ninth, 15 is twenty-eighth.

wolf unit --stops 4 says 73 pipes and saved -12. Four foot alone needs 61 pipes, nothing saved. Count goes from lowest pipe a drawn stop reaches to highest, eight foot counts only when drawn.

wolf which with one pipe read an octave up answers nonsense. Bring each reading into the octave above the lowest first, same pipe an octave up is same reading.

wolf picture --temperament equal draws same third with 23 marks in some rows, 24 in others. Bar should be nearest number of marks for its figure.

wolf hertz C4 --tonic G gives 1046.5023, two octaves up, and --tonic B makes A4 880. Tonic is only where ratios start, A4 stays on the standard and C4 is middle C whatever the tonic, same frequencies as from C.

Please add tests for each and changelog entries as usual.
