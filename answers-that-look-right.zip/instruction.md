Many commands answer with exit zero and wrong figure. I checked every command's output against what the library itself knows and counted fourteen wrong lines. Five kinds, please find all fourteen and fix each one.

Wrong reference. spread and intervals measure an interval against 5:4 unless it is a fifth, default must be just interval for that many steps, report says which ratio was used, --just by hand wins. Closing a run of fifths takes seven octaves off whatever the count, nearest octaves is right, 53 fifths come 3.6150 cents short of closing.

Tonic and octave. Tonic is only where ratios start, A4 stays on standard and C4 is middle C whatever the tonic, in names as in figures. A reading an octave up is same note. Several commands break one of these, one of them ignores --tonic though its working line promises tonic's own scale.

Names beside figures. A name must agree with the figure beside it. Four names do not, one of them a fraction standing for a part, name the part itself when nothing simple is near.

Counts and marks. Count only what is drawn. Same figure draws same bar, bar is nearest number of marks. A value rounded inside is carried to places asked, not padded with noughts. Each of these is wrong somewhere.

Refusals. meantone --part 0 refuses but optimum answers 0 as Pythagorean. Part zero answers like any part, wolf a comma narrow as chain pythagorean shows. flatward for pythagorean crashes too, comma name still checked.

Please add tests and changelog entries as usual.
