"""A watch measures a price change against the price the traveller last heard.

Not against the previous check: that comparison moved on every run, so a fare sliding a few
euros a day never cleared any one day's threshold, and below_budget resent a price that was
lower than yesterday's check but higher than the one already sent. Before any email, the
reference is the first price a check found. The reference moves only with an email that went.

Driven through SavedSearchService with the tool registry replaced by one that finds a single
trip at whatever price the test sets. Nothing here imports app.main.
"""

from datetime import datetime, timedelta
from uuid import uuid4

import pytest
from sqlalchemy.orm import sessionmaker

from app.alerts import service as alerts_service
from app.alerts.email import EmailProviderError
from app.alerts.schemas import UpdateSavedSearchRequest
from app.alerts.service import SavedSearchService
from app.alerts.token_utils import hash_token
from app.auth.security import hash_password
from app.db.models import AlertRunDB, SavedSearchDB, UserDB
from app.models import Flight, TripOption
from app.tools.schemas import SearchTripsOutput


# --- Controlled search results ------------------------------------------------

def trip_at(price: float) -> TripOption:
    out = Flight(id=f"o-{price}", origin="VIE", destination="BCN", airline="Mock", price=price / 2,
                 departureDateTime=datetime(2026, 10, 6, 9), arrivalDateTime=datetime(2026, 10, 6, 11))
    back = Flight(id=f"r-{price}", origin="BCN", destination="VIE", airline="Mock", price=price / 2,
                  departureDateTime=datetime(2026, 10, 10, 18), arrivalDateTime=datetime(2026, 10, 10, 20))
    return TripOption(id=f"t-{price}", tripType="same_city", outboundFlight=out, returnFlight=back,
                      groundTransfer=None, totalPrice=price, tripLengthDays=4, nights=4, score=50,
                      dealScore=50, explanation="", warnings=[], tags=[])


class PricedSearch:
    """Every search finds exactly one trip, at whatever price the test set (none: no trips).

    `during` is run once, inside the next search, before it answers: that is how another
    runner gets to act while this one is still waiting for its provider.
    """

    def __init__(self):
        self.price: float | None = None
        self.during = None

    def run_tool(self, name, payload, context):
        if self.during is not None:
            hook, self.during = self.during, None
            hook()
        trips = [trip_at(self.price)] if self.price is not None else []
        return SearchTripsOutput(trips=trips, providerUsed="mock")


def make_watch(db_session, **overrides) -> SavedSearchDB:
    values = dict(
        id=str(uuid4()), email="traveller@example.com", origin_airports=["VIE"],
        start_date=datetime(2026, 10, 1).date(), end_date=datetime(2026, 11, 30).date(),
        min_trip_length_days=4, max_trip_length_days=8, max_budget=400.0,
        max_ground_transfer_hours=4.0, trip_style="one city", frequency="daily", is_active=True,
        manage_token_hash="h", unsubscribe_token_hash="h", email_verified_at=datetime.utcnow(),
    )
    values.update(overrides)
    row = SavedSearchDB(**values)
    db_session.add(row)
    db_session.commit()
    return row


def make_user(db_session, email="owner@example.com") -> UserDB:
    user = UserDB(id=str(uuid4()), email=email, password_hash=hash_password("Strong-pass-123!"),
                  is_active=True)
    db_session.add(user)
    db_session.commit()
    return user


def past_cooldown(db_session, row) -> None:
    """Step the watch past the send cooldown so only the trigger decision is under test."""
    db_session.refresh(row)
    if row.last_notified_at is not None:
        row.last_notified_at = datetime.utcnow() - timedelta(hours=25)
        db_session.commit()


def runner(db, monkeypatch):
    """A service whose searches are the controlled one, built the way the app builds it."""
    search = PricedSearch()
    monkeypatch.setattr(alerts_service, "build_default_tool_registry", lambda: search)
    return SavedSearchService(db), search


@pytest.fixture()
def checker(db_session, monkeypatch):
    service, search = runner(db_session, monkeypatch)

    def check(row, price: float | None) -> bool:
        past_cooldown(db_session, row)
        search.price = price
        return service.run_saved_search_alert(row).notificationSent

    return check


# --- The slow slide ----------------------------------------------------------

def test_an_any_watch_notices_a_price_that_slides_down_slowly(checker, db_session):
    row = make_watch(db_session, trigger_mode="any")

    assert checker(row, 200.0) is True
    assert checker(row, 196.0) is False
    assert checker(row, 192.0) is False
    assert checker(row, 190.0) is True, "ten below the price last sent, however gradually it got there"


def test_an_any_watch_stays_quiet_until_the_slide_adds_up(checker, db_session):
    row = make_watch(db_session, trigger_mode="any")
    checker(row, 300.0)

    assert [checker(row, price) for price in (297.0, 294.0, 291.0)] == [False, False, False]
    assert checker(row, 290.0) is True


def test_a_price_equal_to_the_one_sent_is_not_a_drop(checker, db_session):
    row = make_watch(db_session, trigger_mode="any")

    assert checker(row, 200.0) is True
    assert checker(row, 200.0) is False
    assert checker(row, 191.0) is False
    assert checker(row, 190.0) is True


def test_price_drop_is_measured_from_the_first_price_a_check_found(checker, db_session):
    """A watch set on a two hundred euro route that slides to the one-eighties has to say so."""
    row = make_watch(db_session, trigger_mode="price_drop")

    assert checker(row, 200.0) is False
    assert checker(row, 194.0) is False
    assert checker(row, 188.0) is True


def test_a_sent_price_becomes_the_new_reference(checker, db_session):
    row = make_watch(db_session, trigger_mode="price_drop")
    for price in (200.0, 194.0, 188.0):
        checker(row, price)

    assert checker(row, 182.0) is False, "six below what was just sent is not another drop"
    assert checker(row, 176.0) is True


def test_price_drop_percentage_threshold_applies_to_the_reference(checker, db_session):
    """Above two hundred the threshold is five percent of the reference, not a flat ten."""
    row = make_watch(db_session, trigger_mode="price_drop")
    checker(row, 1000.0)
    checker(row, 980.0)

    assert checker(row, 960.0) is False
    assert checker(row, 950.0) is True


def test_below_budget_does_not_resend_a_price_above_the_one_it_sent(checker, db_session):
    row = make_watch(db_session, trigger_mode="below_budget", max_budget=300.0)

    assert checker(row, 250.0) is True
    assert checker(row, 260.0) is False
    assert checker(row, 255.0) is False, "cheaper than the last check, dearer than the 250 already sent"
    assert checker(row, 240.0) is True


def test_below_budget_measures_from_the_sent_price_after_a_rise(checker, db_session):
    row = make_watch(db_session, trigger_mode="below_budget", max_budget=400.0)
    checker(row, 300.0)
    for price in (320.0, 340.0, 330.0, 310.0):
        assert checker(row, price) is False, price
    assert checker(row, 299.0) is True


def test_a_rise_and_a_fall_back_count_only_from_the_sent_price(checker, db_session):
    row = make_watch(db_session, trigger_mode="any")
    assert checker(row, 200.0) is True
    for price in (230.0, 220.0, 210.0, 191.0):
        assert checker(row, price) is False, price
    assert checker(row, 190.0) is True


def test_a_weekly_watch_measures_the_same_way(checker, db_session):
    row = make_watch(db_session, trigger_mode="any", frequency="weekly")
    assert [checker(row, price) for price in (200.0, 196.0, 192.0, 190.0)] == [True, False, False, True]


def test_two_watches_keep_their_own_reference(checker, db_session):
    first = make_watch(db_session, trigger_mode="any")
    second = make_watch(db_session, trigger_mode="any", email="other@example.com")
    checker(first, 200.0)
    checker(second, 300.0)
    assert checker(first, 196.0) is False
    assert checker(second, 296.0) is False

    assert checker(first, 190.0) is True
    assert checker(second, 290.0) is True


# --- The cooldown and the claim ------------------------------------------------

def test_a_drop_that_arrives_during_the_cooldown_still_counts_after_it(db_session, monkeypatch):
    row = make_watch(db_session, trigger_mode="any")
    service, search = runner(db_session, monkeypatch)

    search.price = 200.0
    assert service.run_saved_search_alert(row).notificationSent is True
    search.price = 185.0
    assert service.run_saved_search_alert(row).notificationSent is False, "the cooldown"
    past_cooldown(db_session, row)
    assert service.run_saved_search_alert(row).notificationSent is True, "still a drop from 200"


def _other_runner(db_session, monkeypatch, row):
    """A second runner on its own session, the way the tick and a manual run coexist."""
    other = sessionmaker(bind=db_session.get_bind(), autoflush=False, autocommit=False)()
    service, search = runner(other, monkeypatch)
    return service, search, other.get(SavedSearchDB, row.id), other


def test_a_runner_that_loses_the_claim_does_not_move_the_reference(db_session, monkeypatch):
    row = make_watch(db_session, trigger_mode="any")
    service, search = runner(db_session, monkeypatch)
    other_service, other_search, other_row, other = _other_runner(db_session, monkeypatch, row)

    def the_other_runner_sends_first():
        other_search.price = 200.0
        assert other_service.run_saved_search_alert(other_row).notificationSent is True

    search.during = the_other_runner_sends_first
    search.price = 150.0
    assert service.run_saved_search_alert(row).notificationSent is False, "the slot was taken"

    past_cooldown(db_session, row)
    search.price = 195.0
    assert service.run_saved_search_alert(row).notificationSent is False, "they heard 200, not 150"
    past_cooldown(db_session, row)
    search.price = 190.0
    assert service.run_saved_search_alert(row).notificationSent is True
    other.close()


def test_a_losing_runner_leaves_the_below_budget_reference_alone(db_session, monkeypatch):
    row = make_watch(db_session, trigger_mode="below_budget", max_budget=300.0)
    service, search = runner(db_session, monkeypatch)
    other_service, other_search, other_row, other = _other_runner(db_session, monkeypatch, row)

    def the_other_runner_sends_first():
        other_search.price = 250.0
        assert other_service.run_saved_search_alert(other_row).notificationSent is True

    search.during = the_other_runner_sends_first
    search.price = 200.0
    assert service.run_saved_search_alert(row).notificationSent is False

    for price in (255.0, 252.0):
        past_cooldown(db_session, row)
        search.price = price
        assert service.run_saved_search_alert(row).notificationSent is False, "not under the 250 they heard"
    past_cooldown(db_session, row)
    search.price = 245.0
    assert service.run_saved_search_alert(row).notificationSent is True, "lower than the 250 they heard"
    other.close()


class RefusingProvider:
    """An email provider whose every send fails, the way a down SMTP relay does."""

    provider_name = "refusing"

    def send_email(self, to, subject, html_body, text_body):
        raise EmailProviderError("relay down")


def refuse_emails(monkeypatch):
    monkeypatch.setattr(alerts_service, "build_email_provider", lambda: RefusingProvider())


def test_an_email_that_failed_to_send_leaves_the_reference_alone(db_session, monkeypatch):
    """They never heard 185, so 184 is still a drop from the 200 they did hear."""
    row = make_watch(db_session, trigger_mode="any")
    service, search = runner(db_session, monkeypatch)
    search.price = 200.0
    assert service.run_saved_search_alert(row).notificationSent is True

    past_cooldown(db_session, row)
    with pytest.MonkeyPatch.context() as refusing:
        refuse_emails(refusing)
        search.price = 185.0
        service.run_saved_search_alert(row)

    past_cooldown(db_session, row)
    search.price = 184.0
    assert service.run_saved_search_alert(row).notificationSent is True


def test_a_failed_send_does_not_become_the_below_budget_reference(db_session, monkeypatch):
    row = make_watch(db_session, trigger_mode="below_budget", max_budget=300.0)
    service, search = runner(db_session, monkeypatch)
    search.price = 250.0
    assert service.run_saved_search_alert(row).notificationSent is True

    past_cooldown(db_session, row)
    with pytest.MonkeyPatch.context() as refusing:
        refuse_emails(refusing)
        search.price = 240.0
        service.run_saved_search_alert(row)

    past_cooldown(db_session, row)
    search.price = 245.0
    assert service.run_saved_search_alert(row).notificationSent is True, "lower than the 250 they heard"


# --- A price belongs to the search that found it -------------------------------------

def test_a_watch_pointed_at_another_place_starts_afresh(db_session, monkeypatch):
    """They heard 140 for Barcelona; nobody has told them a Lisbon price yet."""
    user = make_user(db_session)
    row = make_watch(db_session, trigger_mode="price_drop", user_id=user.id, email=user.email,
                     destination_airports=["BCN"])
    service, search = runner(db_session, monkeypatch)

    def check(price):
        past_cooldown(db_session, row)
        search.price = price
        return service.run_saved_search_alert(row).notificationSent

    assert check(150.0) is False
    assert check(140.0) is True
    service.update_user_saved_search(user, row.id, UpdateSavedSearchRequest(destinationAirports=["LIS"]))

    assert check(300.0) is False, "the first Lisbon price a check found"
    assert check(290.0) is False, "within five percent of the first Lisbon price"
    assert check(285.0) is True, "five percent below the first Lisbon price"


def test_an_any_watch_pointed_at_another_place_speaks_up_on_its_first_check_there(db_session, monkeypatch):
    user = make_user(db_session)
    row = make_watch(db_session, trigger_mode="any", user_id=user.id, email=user.email,
                     destination_airports=["BCN"])
    service, search = runner(db_session, monkeypatch)
    search.price = 150.0
    assert service.run_saved_search_alert(row).notificationSent is True
    service.update_user_saved_search(user, row.id, UpdateSavedSearchRequest(destinationAirports=["LIS"]))

    past_cooldown(db_session, row)
    search.price = 300.0
    assert service.run_saved_search_alert(row).notificationSent is True, "they never heard a Lisbon price"


def test_a_renamed_watch_is_still_the_same_watch(db_session, monkeypatch):
    user = make_user(db_session)
    row = make_watch(db_session, trigger_mode="any", user_id=user.id, email=user.email,
                     destination_airports=["BCN"])
    service, search = runner(db_session, monkeypatch)
    search.price = 200.0
    assert service.run_saved_search_alert(row).notificationSent is True
    service.update_user_saved_search(
        user, row.id, UpdateSavedSearchRequest(name="Barcelona in autumn", frequency="weekly"))

    for price in (195.0, 191.0):
        past_cooldown(db_session, row)
        search.price = price
        assert service.run_saved_search_alert(row).notificationSent is False, price
    past_cooldown(db_session, row)
    search.price = 190.0
    assert service.run_saved_search_alert(row).notificationSent is True


# --- Watches from before the change --------------------------------------------

def test_an_existing_watch_that_never_sent_speaks_up_once_the_slide_adds_up(checker, db_session):
    """A row with only today's columns, one recorded check at 200 and no email yet."""
    row = make_watch(db_session, trigger_mode="price_drop", last_best_price=200.0,
                     last_checked_at=datetime.utcnow() - timedelta(days=1))
    db_session.add(AlertRunDB(id=str(uuid4()), saved_search_id=row.id, status="success",
                              result_count=1, best_price=200.0,
                              started_at=datetime.utcnow() - timedelta(days=1),
                              finished_at=datetime.utcnow() - timedelta(days=1)))
    db_session.commit()

    sent = [checker(row, price) for price in (196.0, 192.0, 188.0, 184.0)]
    assert sent[:2] == [False, False]
    assert True in sent[2:], "four euros a day from 200 must not stay quiet forever"


def test_an_existing_any_watch_with_an_email_behind_it_measures_from_that_email(checker, db_session):
    """Told 250 two days ago, then two quiet checks; a row from before the change."""
    row = make_watch(db_session, trigger_mode="any", last_best_price=244.0,
                     last_notified_at=datetime.utcnow() - timedelta(days=2),
                     last_checked_at=datetime.utcnow() - timedelta(days=1))
    for days, price in ((2, 250.0), (1, 247.0), (1, 244.0)):
        db_session.add(AlertRunDB(id=str(uuid4()), saved_search_id=row.id, status="success",
                                  result_count=1, best_price=price,
                                  started_at=datetime.utcnow() - timedelta(days=days),
                                  finished_at=datetime.utcnow() - timedelta(days=days)))
    db_session.commit()

    sent = [checker(row, price) for price in (241.0, 238.0, 235.0, 232.0, 229.0)]
    assert sent[0] is False
    assert True in sent[1:], "three euros a day below the 250 they heard must not stay quiet forever"


# --- Every entry point is the same runner ------------------------------------------

def test_the_signed_in_run_measures_from_the_last_email(db_session, monkeypatch):
    user = make_user(db_session)
    row = make_watch(db_session, user_id=user.id, email=user.email, trigger_mode="any")
    service, search = runner(db_session, monkeypatch)

    sent = []
    for price in (200.0, 196.0, 192.0, 190.0):
        past_cooldown(db_session, row)
        search.price = price
        sent.append(service.run_user_alert(user, row.id).notificationSent)

    assert sent == [True, False, False, True]


def test_the_token_link_run_measures_from_the_last_email(db_session, monkeypatch):
    token = "manage-token"
    row = make_watch(db_session, trigger_mode="price_drop", manage_token_hash=hash_token(token))
    service, search = runner(db_session, monkeypatch)

    sent = []
    for price in (200.0, 194.0, 188.0):
        past_cooldown(db_session, row)
        search.price = price
        sent.append(service.run_one_alert(row.id, token).notificationSent)

    assert sent == [False, False, True]


def test_the_tick_measures_from_the_last_email(db_session, monkeypatch):
    row = make_watch(db_session, trigger_mode="any")
    service, search = runner(db_session, monkeypatch)

    sent = []
    for price in (200.0, 196.0, 192.0, 190.0):
        past_cooldown(db_session, row)
        row.last_checked_at = datetime.utcnow() - timedelta(days=2)
        db_session.commit()
        search.price = price
        results = [one for one in service.run_due_alerts() if one.savedSearchId == row.id]
        assert len(results) == 1
        sent.append(results[0].notificationSent)

    assert sent == [True, False, False, True]


def test_the_run_response_still_reports_the_price_of_this_check(checker, db_session, monkeypatch):
    row = make_watch(db_session, trigger_mode="any")
    service, search = runner(db_session, monkeypatch)
    search.price = 200.0
    service.run_saved_search_alert(row)
    past_cooldown(db_session, row)
    search.price = 196.0
    result = service.run_saved_search_alert(row)

    assert result.bestPrice == 196.0
    assert result.notificationSent is False
    past_cooldown(db_session, row)
    search.price = 190.0
    result = service.run_saved_search_alert(row)
    assert (result.bestPrice, result.notificationSent) == (190.0, True)
