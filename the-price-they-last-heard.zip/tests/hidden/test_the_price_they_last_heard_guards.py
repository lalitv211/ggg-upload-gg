"""What already holds at the base and must go on holding once the reference is fixed.

The send cooldown wins over any drop, route_deal still measures against the route average
of the recorded checks, the dashboard's latest best price follows the latest check whether
or not an email went, a preview or a check with no results or an error moves nothing, two
runners cannot both send, and any column added to saved_searches is created by a migration.

Driven through SavedSearchService with the tool registry replaced. Nothing imports app.main.
"""

import re
from datetime import datetime, timedelta
from pathlib import Path
from uuid import uuid4

import pytest
from sqlalchemy.orm import sessionmaker

from app.alerts import service as alerts_service
from app.alerts.service import SavedSearchService, saved_search_to_response
from app.auth.security import hash_password
from app.db.models import AlertRunDB, SavedSearchDB, UserDB
from app.models import Flight, TripOption
from app.tools.schemas import SearchTripsOutput

API_DIR = Path(alerts_service.__file__).resolve().parents[2]

# The columns saved_searches had before this change; anything beyond needs a migration.
COLUMNS_AT_THE_BASE = {
    "id", "email", "name", "origin_airports", "destination_airports", "start_date", "end_date",
    "min_trip_length_days", "max_trip_length_days", "max_budget", "max_ground_transfer_hours",
    "trip_style", "direct_only", "include_baggage", "frequency", "trigger_mode", "is_active",
    "created_at", "updated_at", "last_checked_at", "last_notified_at", "last_best_price",
    "last_best_trip_id", "manage_token_hash", "unsubscribe_token_hash", "user_id",
    "email_verified_at", "verification_token_hash", "verification_sent_at",
    "verification_expires_at",
}


def trip_at(price: float) -> TripOption:
    out = Flight(id=f"o-{price}", origin="VIE", destination="BCN", airline="Mock", price=price / 2,
                 departureDateTime=datetime(2026, 10, 6, 9), arrivalDateTime=datetime(2026, 10, 6, 11))
    back = Flight(id=f"r-{price}", origin="BCN", destination="VIE", airline="Mock", price=price / 2,
                  departureDateTime=datetime(2026, 10, 10, 18), arrivalDateTime=datetime(2026, 10, 10, 20))
    return TripOption(id=f"t-{price}", tripType="same_city", outboundFlight=out, returnFlight=back,
                      groundTransfer=None, totalPrice=price, tripLengthDays=4, nights=4, score=50,
                      dealScore=50, explanation="", warnings=[], tags=[])


class PricedSearch:
    """Every search finds exactly one trip at the price set; none means no trips; `fail` raises."""

    def __init__(self):
        self.price: float | None = None
        self.fail = False
        self.during = None

    def run_tool(self, name, payload, context):
        if self.during is not None:
            hook, self.during = self.during, None
            hook()
        if self.fail:
            raise RuntimeError("provider down")
        trips = [trip_at(self.price)] if self.price is not None else []
        return SearchTripsOutput(trips=trips, providerUsed="mock")


def make_watch(db_session, **overrides) -> SavedSearchDB:
    values = dict(
        id=str(uuid4()), email="traveller@example.com", origin_airports=["VIE"],
        start_date=datetime(2026, 10, 1).date(), end_date=datetime(2026, 11, 30).date(),
        min_trip_length_days=4, max_trip_length_days=8, max_budget=400.0,
        max_ground_transfer_hours=4.0, trip_style="one city", frequency="daily", is_active=True,
        manage_token_hash="h", unsubscribe_token_hash="h", email_verified_at=datetime.utcnow(),
    )
    values.update(overrides)
    row = SavedSearchDB(**values)
    db_session.add(row)
    db_session.commit()
    return row


def make_user(db_session, email="owner@example.com") -> UserDB:
    user = UserDB(id=str(uuid4()), email=email, password_hash=hash_password("Strong-pass-123!"),
                  is_active=True)
    db_session.add(user)
    db_session.commit()
    return user


def past_cooldown(db_session, row) -> None:
    db_session.refresh(row)
    if row.last_notified_at is not None:
        row.last_notified_at = datetime.utcnow() - timedelta(hours=25)
        db_session.commit()


def runner(db, monkeypatch):
    search = PricedSearch()
    monkeypatch.setattr(alerts_service, "build_default_tool_registry", lambda: search)
    return SavedSearchService(db), search


@pytest.fixture()
def checker(db_session, monkeypatch):
    service, search = runner(db_session, monkeypatch)

    def check(row, price: float | None) -> bool:
        past_cooldown(db_session, row)
        search.price = price
        return service.run_saved_search_alert(row).notificationSent

    return check


def recorded_check(db_session, row, price: float, days_ago: int) -> None:
    when = datetime.utcnow() - timedelta(days=days_ago)
    db_session.add(AlertRunDB(id=str(uuid4()), saved_search_id=row.id, status="success",
                              result_count=1, best_price=price, started_at=when, finished_at=when))
    db_session.commit()


# --- The cooldown ---------------------------------------------------------------

def test_the_cooldown_still_wins_over_a_real_drop(db_session, monkeypatch):
    row = make_watch(db_session, trigger_mode="any")
    service, search = runner(db_session, monkeypatch)

    search.price = 200.0
    assert service.run_saved_search_alert(row).notificationSent is True
    search.price = 100.0
    assert service.run_saved_search_alert(row).notificationSent is False


def test_the_cooldown_applies_whatever_the_trigger(db_session, monkeypatch):
    service, search = runner(db_session, monkeypatch)
    for mode in ("any", "price_drop", "route_deal", "below_budget"):
        row = make_watch(db_session, trigger_mode=mode, max_budget=400.0,
                         last_notified_at=datetime.utcnow() - timedelta(minutes=5),
                         last_best_price=300.0)
        search.price = 10.0
        assert service.run_saved_search_alert(row).notificationSent is False, mode


def test_two_runners_cannot_both_send(db_session, monkeypatch):
    row = make_watch(db_session, trigger_mode="any")
    service, search = runner(db_session, monkeypatch)
    other = sessionmaker(bind=db_session.get_bind(), autoflush=False, autocommit=False)()
    other_service, other_search = runner(other, monkeypatch)
    other_row = other.get(SavedSearchDB, row.id)
    outcomes = []

    def the_other_runner_goes_first():
        other_search.price = 200.0
        outcomes.append(other_service.run_saved_search_alert(other_row).notificationSent)

    search.during = the_other_runner_goes_first
    search.price = 200.0
    outcomes.append(service.run_saved_search_alert(row).notificationSent)
    other.close()

    assert sorted(outcomes) == [False, True]


# --- route_deal and the first checks -------------------------------------------------

def test_route_deal_still_measures_against_the_route_average(checker, db_session):
    row = make_watch(db_session, trigger_mode="route_deal", max_budget=400.0)
    for days_ago, price in ((3, 300.0), (2, 320.0), (1, 310.0)):
        recorded_check(db_session, row, price, days_ago)

    assert checker(row, 300.0) is False
    assert checker(row, 240.0) is True


def test_route_deal_still_falls_back_to_the_budget_before_it_has_history(checker, db_session):
    row = make_watch(db_session, trigger_mode="route_deal", max_budget=400.0)

    assert checker(row, 350.0) is False
    assert checker(row, 300.0) is True


def test_an_any_watch_still_sends_on_its_first_check(checker, db_session):
    row = make_watch(db_session, trigger_mode="any")
    assert checker(row, 500.0) is True


def test_price_drop_still_says_nothing_until_it_has_something_to_compare(checker, db_session):
    row = make_watch(db_session, trigger_mode="price_drop")
    assert checker(row, 100.0) is False


def test_below_budget_still_stays_silent_above_the_ceiling(checker, db_session):
    row = make_watch(db_session, trigger_mode="below_budget", max_budget=300.0)
    assert checker(row, 500.0) is False
    assert checker(row, 350.0) is False
    assert checker(row, 301.0) is False


def test_below_budget_measures_an_over_budget_start_from_that_start(checker, db_session):
    row = make_watch(db_session, trigger_mode="below_budget", max_budget=300.0)

    assert checker(row, 350.0) is False
    assert checker(row, 310.0) is False
    assert checker(row, 290.0) is True
    assert checker(row, 295.0) is False


def test_a_watch_from_before_the_change_decides_as_it_did_where_nothing_differs(checker, db_session):
    """Told 200 two days ago; the figures every reading of the fix agrees on."""
    row = make_watch(db_session, trigger_mode="any", last_best_price=200.0,
                     last_notified_at=datetime.utcnow() - timedelta(days=2),
                     last_checked_at=datetime.utcnow() - timedelta(days=2))
    recorded_check(db_session, row, 200.0, 2)

    assert checker(row, 191.0) is False
    assert checker(row, 181.0) is True
    assert checker(row, 175.0) is False
    assert checker(row, 165.0) is True


# --- What the dashboard shows -------------------------------------------------------

def test_last_best_price_keeps_following_the_latest_check(checker, db_session):
    row = make_watch(db_session, trigger_mode="any")
    checker(row, 200.0)
    checker(row, 196.0)

    db_session.refresh(row)
    assert row.last_best_price == 196.0
    assert row.last_best_trip_id == "t-196.0"


def test_the_saved_search_response_still_reports_the_latest_best_price(checker, db_session):
    row = make_watch(db_session, trigger_mode="any")
    checker(row, 200.0)
    checker(row, 196.0)
    db_session.refresh(row)

    assert saved_search_to_response(row).lastBestPrice == 196.0


def test_the_insights_still_follow_the_recorded_checks(checker, db_session):
    user = make_user(db_session)
    row = make_watch(db_session, user_id=user.id, email=user.email, trigger_mode="any")
    checker(row, 200.0)
    checker(row, 196.0)

    insights = SavedSearchService(db_session).get_user_saved_search_insights(user, row.id)
    assert insights.totalChecks == 2
    assert insights.notificationCount == 1
    assert sorted(point.bestPrice for point in insights.history) == [196.0, 200.0]
    assert insights.lowestObservedPrice == 196.0
    assert insights.averageObservedPrice == 198.0


# --- What is not a check ------------------------------------------------------------

def test_a_preview_moves_nothing(db_session, monkeypatch):
    user = make_user(db_session)
    row = make_watch(db_session, trigger_mode="price_drop", user_id=user.id, email=user.email)
    service, search = runner(db_session, monkeypatch)

    search.price = 150.0
    preview = service.preview_user_saved_search(user, row.id)
    assert [trip.totalPrice for trip in preview.matchingTrips] == [150.0]
    db_session.refresh(row)
    assert row.last_best_price is None
    assert row.last_checked_at is None

    search.price = 200.0
    assert service.run_saved_search_alert(row).notificationSent is False
    past_cooldown(db_session, row)
    search.price = 190.0
    assert service.run_saved_search_alert(row).notificationSent is True


def test_a_check_with_no_results_moves_nothing(checker, db_session):
    row = make_watch(db_session, trigger_mode="any")
    assert checker(row, 200.0) is True
    assert checker(row, None) is False
    db_session.refresh(row)
    assert row.last_best_price == 200.0

    assert checker(row, 190.0) is True


def test_a_check_that_errors_moves_nothing(db_session, monkeypatch):
    row = make_watch(db_session, trigger_mode="any")
    service, search = runner(db_session, monkeypatch)
    search.price = 200.0
    assert service.run_saved_search_alert(row).notificationSent is True

    past_cooldown(db_session, row)
    search.fail = True
    result = service.run_saved_search_alert(row)
    assert result.status == "error"
    assert result.notificationSent is False
    db_session.refresh(row)
    assert row.last_best_price == 200.0

    search.fail = False
    past_cooldown(db_session, row)
    search.price = 190.0
    assert service.run_saved_search_alert(row).notificationSent is True


def test_an_unverified_watch_still_sends_nothing(db_session, monkeypatch):
    row = make_watch(db_session, trigger_mode="any", email_verified_at=None)
    service, search = runner(db_session, monkeypatch)
    search.price = 200.0
    result = service.run_saved_search_alert(row)
    assert result.notificationSent is False
    assert result.status == "error"


# --- Schema and migrations agree ------------------------------------------------------

def test_every_column_added_to_saved_searches_is_created_by_a_migration():
    """If the fix added a column to the table, some migration file has to add it."""
    from app.database import Base
    from app.db import models  # noqa: F401

    versions = list((API_DIR / "alembic" / "versions").glob("*.py"))
    assert versions, "no migrations found"
    texts = [path.read_text(encoding="utf-8") for path in versions]
    columns = {column.name for column in Base.metadata.tables["saved_searches"].columns}
    for name in sorted(columns - COLUMNS_AT_THE_BASE):
        pattern = re.compile(r"saved_searches[\s\S]*?[\"']" + re.escape(name) + r"[\"']")
        assert any(pattern.search(text) for text in texts), (
            f"{name} exists in the ORM but no migration under alembic/versions adds it"
        )
