"""What already answered right about beats, and has to go on doing so.

A pure interval beats nought whichever partials are counted; a
tuning's frequencies, the cents a tempered interval is off by, the
plans' closing and doubling, the refusals and the shape of the report
are all untouched by counting on the partials. These pass at the base
commit; they are here so a change that mends the rate cannot quietly
break the rest.
"""

from __future__ import annotations

import re

import pytest

from wolf.cli.main import run
from wolf.errors import Unsupported
from wolf.format.report import parts_of
from wolf.pitch import bearings
from wolf.pitch import frequency
from wolf.temper import table

#: Intervals that are pure in their tuning, and beat nought either
#: way: tuning, lower, upper, octave, beats.
PURE = (
    ('werckmeister_iii', 'A', 'E', 4, '0.0000'),
    ('werckmeister_iii', 'E', 'B', 4, '0.0000'),
    ('kirnberger_iii', 'E', 'B', 4, '0.0000'),
    ('pythagorean', 'C', 'G', 4, '0.0000'),
    ('pythagorean', 'G', 'D', 4, '0.0000'),
    ('pythagorean', 'D', 'A', 4, '0.0000'),
    ('pythagorean', 'A', 'E', 4, '0.0000'),
    ('pythagorean', 'E', 'B', 4, '0.0000'),
    ('just', 'C', 'G', 4, '0.0000'),
    ('just', 'G', 'D', 4, '0.0000'),
    ('just', 'A', 'E', 4, '0.0000'),
    ('just', 'E', 'B', 4, '0.0000'),
)


def figure(text):
    """The figure part of a report, as its lines."""

    return parts_of(text)["figure"]


def value_of(text, name):
    """The value printed beside a name in a report's figure part."""

    for line in figure(text):
        words = line.split()
        if words and words[0] == name:
            return words[-1]
    raise AssertionError("no line for {0!r} in:\n{1}".format(name,
                                                             text))


def rate_in(text):
    """The beat rate a report prints, from the row that names it."""

    for line in figure(text):
        words = line.split()
        if len(words) == 2 and ("beat" in words[0].lower()
                                or "rate" in words[0].lower()):
            return words[1].lstrip("-")
    raise AssertionError("no row for the beat rate in:\n" + text)


@pytest.mark.parametrize("name,lower,upper,octave,want", PURE)
def test_a_pure_interval_still_beats_nought(name, lower, upper, octave,
                                            want):
    """Which is how a tuner knows it is pure."""

    code, text = run(["beats", lower, upper, "--temperament", name,
                      "--octave", str(octave)])
    assert code == 0, text
    assert abs(float(rate_in(text))) < 1e-9, text


@pytest.mark.parametrize("ratio", ("0:1", "-3:2", "nonsense"))
def test_a_ratio_of_nothing_is_still_refused(ratio):
    """Nought and nonsense are not intervals, by hand or otherwise."""

    code, text = run(["beats", "C", "G", "--just", ratio])
    assert code in (2, 3), text


def test_a_note_the_tuning_has_not_got_is_still_refused():
    """Equal temperament spells its notes with sharps."""

    code, text = run(["beats", "C", "Eb", "--temperament", "equal"])
    assert code == 3, text


@pytest.mark.parametrize("name,want", (
    ("equal", "-1.9550"), ("quarter_comma", "-5.3766"),
    ("pythagorean", "0"), ("sixth_comma", "-3.5844")))
def test_the_cents_row_still_says_how_far_the_fifth_is_off(name, want):
    """Cents are about the fundamentals and do not change."""

    code, text = run(["beats", "C", "G", "--temperament", name])
    assert code == 0, text
    assert value_of(text, "cents") == want, text


def test_the_report_still_has_its_three_parts():
    """Figure, working and limits, as every report has."""

    code, text = run(["beats", "C", "G"])
    assert code == 0, text
    found = parts_of(text)
    assert set(found) >= {"figure", "working", "limits"}, text


def test_places_are_still_honoured():
    """``--places 2`` prints two places."""

    code, text = run(["beats", "C", "G", "--places", "2"])
    assert code == 0, text
    assert re.fullmatch(r"\d+\.\d{2}", rate_in(text)), text


@pytest.mark.parametrize("plan", sorted(bearings.PLANS))
def test_every_plan_still_closes(plan):
    """Eleven steps, twelve notes, each reached once."""

    assert bearings.closes(bearings.plan(plan))
    assert len(bearings.reached(bearings.plan(plan))) == 12


@pytest.mark.parametrize("plan", sorted(bearings.PLANS))
def test_an_octave_up_still_doubles_every_rate(plan):
    """A beat rate is a difference of frequencies."""

    assert bearings.an_octave_up(plan)["all_exactly_double"], plan


def test_an_unknown_plan_is_still_refused():
    """A plan is written for a particular tuning."""

    code, text = run(["bearings", "pythagorean"])
    assert code == 3, text


def test_an_unknown_check_is_still_refused():
    """Four kinds, named."""

    with pytest.raises(Unsupported):
        bearings.beats(table.named("equal"), "C", "G", "seventh")


def test_two_equal_pitches_do_not_beat():
    """A unison, by any arithmetic."""

    made = table.named("equal")
    one = frequency.pitch(made, "C4")
    assert abs(float(frequency.beats(one, one))) < 1e-9


@pytest.mark.parametrize("name,written,want", (
    ("equal", "C4", "261.6256"), ("quarter_comma", "C4", "263.1814"),
    ("equal", "A4", "440"), ("pythagorean", "G4", "391.1111")))
def test_frequencies_are_untouched(name, written, want):
    """Counting partials changes no note's frequency."""

    code, text = run(["hertz", written, "--temperament", name])
    assert code == 0, text
    assert value_of(text, "hertz") == want, text


@pytest.mark.parametrize("name", table.known())
def test_a_pure_fifth_by_the_library_still_beats_nought(name):
    """Against 3:2, in whatever tuning has a pure one at C to G."""

    made = table.named(name)
    found = frequency.beats_against_just(made, "C", "G", "3/2",
                                         "a440", 4)
    cents = [value for name, value in found.items()
             if "cent" in name.lower()]
    rates = [value for name, value in found.items()
             if ("beat" in name.lower() or "rate" in name.lower())
             and not isinstance(value, str)]
    assert cents and rates, found
    pure = abs(float(cents[0])) < 1e-9
    assert (abs(float(rates[0])) < 1e-9) == pure, found
