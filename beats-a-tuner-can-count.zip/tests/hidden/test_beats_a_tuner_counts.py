"""Beats counted the way a tuner counts them.

At the base ``beats`` and the bearing plans give the difference of two
fundamentals, which nobody hears: real beating is between the partials
that coincide when the interval is pure, the third partial of the
lower note against the second of the upper for a fifth. ``beats`` is a
fifth whatever two notes it is given, an octave check or a twelfth is
folded into the wrong octave, and the two-pitch function is a plain
difference.

Every figure here is arithmetic on the package's own frequencies at
tonic C, done once with fractions and written down: for a check of
p:q, the q-th partial of the upper note against the p-th of the lower,
the upper note taken in the octave nearest the pure interval. Only
outcomes are checked, through the command line and the two public
functions the commands call. Row names, wording and the order of rows
are not assumed; a rate is read from whichever row calls itself a beat
or a rate.
"""

from __future__ import annotations

import pathlib
import re

import pytest

from wolf.cli.main import run
from wolf.format.report import parts_of
from wolf.pitch import bearings
from wolf.pitch import frequency
from wolf.temper import table

ROOT = pathlib.Path(__file__).resolve().parents[1]

#: How far a figure printed to four places may sit from the one
#: written here: half a unit in the last place, and a little.
SLACK = 0.00006

#: The ``beats`` command on two notes, with the rate a tuner counts:
#: tuning, lower, upper, octave, beats a second at A440.
CASES = (
    ('equal', 'C', 'G', 3, '0.4429'),
    ('equal', 'C', 'G', 4, '0.8858'),
    ('equal', 'G', 'D', 3, '0.6636'),
    ('equal', 'G', 'D', 4, '1.3272'),
    ('equal', 'D', 'A', 3, '0.4972'),
    ('equal', 'D', 'A', 4, '0.9943'),
    ('equal', 'A', 'E', 3, '0.7449'),
    ('equal', 'A', 'E', 4, '1.4898'),
    ('equal', 'E', 'B', 3, '0.5580'),
    ('equal', 'E', 'B', 4, '1.1161'),
    ('equal', 'C', 'F', 3, '0.5912'),
    ('equal', 'C', 'F', 4, '1.1824'),
    ('equal', 'G', 'C', 3, '0.8858'),
    ('equal', 'G', 'C', 4, '1.7716'),
    ('equal', 'C', 'E', 3, '5.1912'),
    ('equal', 'C', 'E', 4, '10.3824'),
    ('equal', 'F', 'A', 3, '6.9294'),
    ('equal', 'F', 'A', 4, '13.8588'),
    ('equal', 'G', 'B', 3, '7.7780'),
    ('equal', 'G', 'B', 4, '15.5560'),
    ('equal', 'C', 'A', 3, '5.9361'),
    ('equal', 'C', 'A', 4, '11.8722'),
    ('equal', 'D', 'F', 3, '7.9237'),
    ('equal', 'D', 'F', 4, '15.8475'),
    ('equal', 'E', 'C', 3, '10.3824'),
    ('equal', 'E', 'C', 4, '20.7648'),
    ('equal', 'C', 'D', 3, '2.6560'),
    ('equal', 'C', 'D', 4, '5.3119'),
    ('quarter_comma', 'C', 'G', 3, '1.2241'),
    ('quarter_comma', 'C', 'G', 4, '2.4482'),
    ('quarter_comma', 'G', 'D', 3, '1.8305'),
    ('quarter_comma', 'G', 'D', 4, '3.6610'),
    ('quarter_comma', 'D', 'A', 3, '1.3686'),
    ('quarter_comma', 'D', 'A', 4, '2.7372'),
    ('quarter_comma', 'A', 'E', 3, '2.0465'),
    ('quarter_comma', 'A', 'E', 4, '4.0931'),
    ('quarter_comma', 'E', 'B', 3, '1.5301'),
    ('quarter_comma', 'E', 'B', 4, '3.0603'),
    ('quarter_comma', 'C', 'F', 3, '1.6372'),
    ('quarter_comma', 'C', 'F', 4, '3.2745'),
    ('quarter_comma', 'G', 'C', 3, '2.4482'),
    ('quarter_comma', 'G', 'C', 4, '4.8965'),
    ('quarter_comma', 'C', 'E', 3, '0.0000'),
    ('quarter_comma', 'C', 'E', 4, '0.0000'),
    ('quarter_comma', 'F', 'A', 3, '0.0000'),
    ('quarter_comma', 'F', 'A', 4, '0.0000'),
    ('quarter_comma', 'G', 'B', 3, '0.0000'),
    ('quarter_comma', 'G', 'B', 4, '0.0000'),
    ('quarter_comma', 'C', 'A', 3, '2.0465'),
    ('quarter_comma', 'C', 'A', 4, '4.0931'),
    ('quarter_comma', 'D', 'F', 3, '2.7372'),
    ('quarter_comma', 'D', 'F', 4, '5.4744'),
    ('quarter_comma', 'E', 'C', 3, '0.0000'),
    ('quarter_comma', 'E', 'C', 4, '0.0000'),
    ('quarter_comma', 'C', 'D', 3, '7.3333'),
    ('quarter_comma', 'C', 'D', 4, '14.6666'),
    ('werckmeister_iii', 'C', 'G', 4, '2.6725'),
    ('werckmeister_iii', 'G', 'D', 4, '3.9952'),
    ('werckmeister_iii', 'D', 'A', 4, '2.9863'),
    ('werckmeister_iii', 'C', 'F', 4, '0.0000'),
    ('werckmeister_iii', 'G', 'C', 4, '5.3450'),
    ('werckmeister_iii', 'C', 'E', 4, '2.9788'),
    ('werckmeister_iii', 'F', 'A', 4, '3.9718'),
    ('werckmeister_iii', 'G', 'B', 4, '11.1496'),
    ('werckmeister_iii', 'C', 'A', 4, '2.9788'),
    ('werckmeister_iii', 'D', 'F', 4, '9.9443'),
    ('werckmeister_iii', 'E', 'C', 4, '5.9577'),
    ('werckmeister_iii', 'C', 'D', 4, '16.0080'),
    ('kirnberger_iii', 'C', 'G', 4, '2.4482'),
    ('kirnberger_iii', 'G', 'D', 4, '3.6610'),
    ('kirnberger_iii', 'D', 'A', 4, '2.7372'),
    ('kirnberger_iii', 'A', 'E', 4, '4.0931'),
    ('kirnberger_iii', 'C', 'F', 4, '0.0000'),
    ('kirnberger_iii', 'G', 'C', 4, '4.8965'),
    ('kirnberger_iii', 'C', 'E', 4, '0.0000'),
    ('kirnberger_iii', 'F', 'A', 4, '5.4574'),
    ('kirnberger_iii', 'G', 'B', 4, '6.1206'),
    ('kirnberger_iii', 'C', 'A', 4, '4.0931'),
    ('kirnberger_iii', 'D', 'F', 4, '10.9318'),
    ('kirnberger_iii', 'E', 'C', 4, '0.0000'),
    ('kirnberger_iii', 'C', 'D', 4, '14.6666'),
    ('sixth_comma', 'C', 'G', 4, '1.6279'),
    ('sixth_comma', 'G', 'D', 4, '2.4368'),
    ('sixth_comma', 'D', 'A', 4, '1.8239'),
    ('sixth_comma', 'A', 'E', 4, '2.7301'),
    ('sixth_comma', 'E', 'B', 4, '2.0434'),
    ('sixth_comma', 'C', 'F', 4, '2.1751'),
    ('sixth_comma', 'G', 'C', 4, '3.2559'),
    ('sixth_comma', 'C', 'E', 4, '5.4433'),
    ('sixth_comma', 'F', 'A', 4, '7.2728'),
    ('sixth_comma', 'G', 'B', 4, '8.1481'),
    ('sixth_comma', 'C', 'A', 4, '8.1735'),
    ('sixth_comma', 'D', 'F', 4, '10.9205'),
    ('sixth_comma', 'E', 'C', 4, '10.8867'),
    ('sixth_comma', 'C', 'D', 4, '9.7575'),
    ('third_comma', 'C', 'G', 4, '3.2728'),
    ('third_comma', 'G', 'D', 4, '4.8889'),
    ('third_comma', 'D', 'A', 4, '3.6515'),
    ('third_comma', 'A', 'E', 4, '5.4546'),
    ('third_comma', 'E', 'B', 4, '4.0741'),
    ('third_comma', 'C', 'F', 4, '4.3818'),
    ('third_comma', 'G', 'C', 4, '6.5455'),
    ('third_comma', 'C', 'E', 4, '5.4546'),
    ('third_comma', 'F', 'A', 4, '7.3030'),
    ('third_comma', 'G', 'B', 4, '8.1481'),
    ('third_comma', 'C', 'A', 4, '0.0000'),
    ('third_comma', 'D', 'F', 4, '0.0000'),
    ('third_comma', 'E', 'C', 4, '10.9092'),
    ('third_comma', 'C', 'D', 4, '19.5960'),
    ('fifth_comma', 'C', 'G', 4, '1.9555'),
    ('fifth_comma', 'G', 'D', 4, '2.9260'),
    ('fifth_comma', 'D', 'A', 4, '2.1891'),
    ('fifth_comma', 'A', 'E', 4, '3.2755'),
    ('fifth_comma', 'E', 'B', 4, '2.4505'),
    ('fifth_comma', 'C', 'F', 4, '2.6139'),
    ('fifth_comma', 'G', 'C', 4, '3.9111'),
    ('fifth_comma', 'C', 'E', 4, '3.2673'),
    ('fifth_comma', 'F', 'A', 4, '4.3673'),
    ('fifth_comma', 'G', 'B', 4, '4.8889'),
    ('fifth_comma', 'C', 'A', 4, '6.5428'),
    ('fifth_comma', 'D', 'F', 4, '8.7455'),
    ('fifth_comma', 'E', 'C', 4, '6.5347'),
    ('fifth_comma', 'C', 'D', 4, '11.7187'),
    ('pythagorean', 'C', 'F', 4, '0.0000'),
    ('pythagorean', 'G', 'C', 4, '0.0000'),
    ('pythagorean', 'C', 'E', 4, '16.2963'),
    ('pythagorean', 'F', 'A', 4, '21.7284'),
    ('pythagorean', 'G', 'B', 4, '24.4444'),
    ('pythagorean', 'C', 'A', 4, '16.2963'),
    ('pythagorean', 'D', 'F', 4, '21.7284'),
    ('pythagorean', 'E', 'C', 4, '32.5926'),
    ('pythagorean', 'C', 'D', 4, '0.0000'),
    ('just', 'D', 'A', 4, '11.0000'),
    ('just', 'C', 'F', 4, '0.0000'),
    ('just', 'G', 'C', 4, '0.0000'),
    ('just', 'C', 'E', 4, '0.0000'),
    ('just', 'F', 'A', 4, '0.0000'),
    ('just', 'G', 'B', 4, '0.0000'),
    ('just', 'C', 'A', 4, '0.0000'),
    ('just', 'D', 'F', 4, '22.0000'),
    ('just', 'E', 'C', 4, '0.0000'),
    ('just', 'C', 'D', 4, '0.0000'),
)

#: The same, at another standard: the rate scales with it.
STANDARDS = (
    ('equal', 'C', 'G', 4, 'a415', '0.8355'),
    ('quarter_comma', 'C', 'G', 4, 'a415', '2.3091'),
    ('equal', 'C', 'E', 4, 'a442', '10.4296'),
    ('werckmeister_iii', 'C', 'F', 3, 'a392', '0.0000'),
)

#: The same in other octaves: the rate doubles with each.
OCTAVES = (
    ('equal', 'C', 'G', 2, '0.2215'),
    ('equal', 'C', 'G', 5, '1.7716'),
    ('werckmeister_iii', 'C', 'G', 5, '5.3450'),
    ('sixth_comma', 'C', 'E', 2, '1.3608'),
    ('quarter_comma', 'G', 'C', 5, '9.7929'),
)

#: A ratio given by hand: tuning, lower, upper, octave, ratio, beats.
#: 2:1 is the note an octave up and beats nought in every tuning
#: here; 3:1 is a twelfth, checked a twelfth up; 5:2 a tenth.
BY_HAND = (
    ('equal', 'C', 'G', 4, '3:2', '0.8858'),
    ('equal', 'C', 'E', 4, '5:4', '10.3824'),
    ('quarter_comma', 'C', 'Bb', 4, '7:4', '40.9030'),
    ('equal', 'C', 'G', 3, '3:1', '0.4429'),
    ('quarter_comma', 'C', 'G', 3, '3:1', '1.2241'),
    ('equal', 'C', 'C', 4, '2:1', '0.0000'),
    ('quarter_comma', 'C', 'C', 3, '2:1', '0.0000'),
    ('werckmeister_iii', 'C', 'C', 4, '2:1', '0.0000'),
    ('equal', 'C', 'E', 3, '5:2', '5.1912'),
    ('pythagorean', 'C', 'G', 4, '3:1', '0.0000'),
    ('equal', 'C', 'A', 4, '5:3', '11.8722'),
    ('equal', 'D', 'F', 4, '7:6', '39.7160'),
    ('equal', 'C', 'C', 4, '1:1', '0.0000'),
)

#: Every step of both bearing plans: plan, octave, from, to, check,
#: beats a second.
PLAN_ROWS = (
    ('equal', 3, 'C', 'G', 'fifth', '0.4429'),
    ('equal', 3, 'G', 'D', 'fifth', '0.6636'),
    ('equal', 3, 'D', 'A', 'fifth', '0.4972'),
    ('equal', 3, 'A', 'E', 'fifth', '0.7449'),
    ('equal', 3, 'E', 'B', 'fifth', '0.5580'),
    ('equal', 3, 'B', 'F#', 'fifth', '0.8361'),
    ('equal', 3, 'F#', 'C#', 'fifth', '0.6264'),
    ('equal', 3, 'C', 'F', 'fourth', '0.5912'),
    ('equal', 3, 'F', 'A#', 'fourth', '0.7892'),
    ('equal', 3, 'A#', 'D#', 'fourth', '1.0534'),
    ('equal', 3, 'D#', 'G#', 'fourth', '0.7031'),
    ('equal', 4, 'C', 'G', 'fifth', '0.8858'),
    ('equal', 4, 'G', 'D', 'fifth', '1.3272'),
    ('equal', 4, 'D', 'A', 'fifth', '0.9943'),
    ('equal', 4, 'A', 'E', 'fifth', '1.4898'),
    ('equal', 4, 'E', 'B', 'fifth', '1.1161'),
    ('equal', 4, 'B', 'F#', 'fifth', '1.6722'),
    ('equal', 4, 'F#', 'C#', 'fifth', '1.2527'),
    ('equal', 4, 'C', 'F', 'fourth', '1.1824'),
    ('equal', 4, 'F', 'A#', 'fourth', '1.5784'),
    ('equal', 4, 'A#', 'D#', 'fourth', '2.1069'),
    ('equal', 4, 'D#', 'G#', 'fourth', '1.4062'),
    ('quarter_comma', 3, 'C', 'G', 'fifth', '1.2241'),
    ('quarter_comma', 3, 'G', 'D', 'fifth', '1.8305'),
    ('quarter_comma', 3, 'D', 'A', 'fifth', '1.3686'),
    ('quarter_comma', 3, 'A', 'E', 'fifth', '2.0465'),
    ('quarter_comma', 3, 'C', 'F', 'fourth', '1.6372'),
    ('quarter_comma', 3, 'F', 'Bb', 'fourth', '2.1898'),
    ('quarter_comma', 3, 'Bb', 'Eb', 'fourth', '2.9288'),
    ('quarter_comma', 3, 'E', 'B', 'fifth', '1.5301'),
    ('quarter_comma', 3, 'B', 'F#', 'fifth', '2.2881'),
    ('quarter_comma', 3, 'F#', 'C#', 'fifth', '1.7108'),
    ('quarter_comma', 3, 'C#', 'G#', 'fifth', '1.2791'),
    ('quarter_comma', 4, 'C', 'G', 'fifth', '2.4482'),
    ('quarter_comma', 4, 'G', 'D', 'fifth', '3.6610'),
    ('quarter_comma', 4, 'D', 'A', 'fifth', '2.7372'),
    ('quarter_comma', 4, 'A', 'E', 'fifth', '4.0931'),
    ('quarter_comma', 4, 'C', 'F', 'fourth', '3.2745'),
    ('quarter_comma', 4, 'F', 'Bb', 'fourth', '4.3795'),
    ('quarter_comma', 4, 'Bb', 'Eb', 'fourth', '5.8575'),
    ('quarter_comma', 4, 'E', 'B', 'fifth', '3.0603'),
    ('quarter_comma', 4, 'B', 'F#', 'fifth', '4.5762'),
    ('quarter_comma', 4, 'F#', 'C#', 'fifth', '3.4215'),
    ('quarter_comma', 4, 'C#', 'G#', 'fifth', '2.5582'),
)

#: Two pitches, as the library counts them: tuning, first, second,
#: beats a second.
TWO_PITCHES = (
    ('equal', 'C4', 'G4', '0.8858'),
    ('equal', 'G4', 'C4', '0.8858'),
    ('equal', 'C4', 'E4', '10.3824'),
    ('equal', 'C4', 'F4', '1.1824'),
    ('equal', 'C4', 'C5', '0.0000'),
    ('equal', 'C3', 'C4', '0.0000'),
    ('quarter_comma', 'C4', 'E4', '0.0000'),
    ('equal', 'E4', 'B4', '1.1161'),
    ('equal', 'C4', 'A4', '11.8722'),
    ('equal', 'D4', 'F4', '15.8475'),
    ('just', 'D4', 'A4', '11.0000'),
    ('quarter_comma', 'C4', 'G4', '2.4482'),
    ('werckmeister_iii', 'F3', 'C4', '0.0000'),
    ('equal', 'G3', 'C4', '0.8858'),
)


def figure(text):
    """The figure part of a report, as its lines."""

    return parts_of(text)["figure"]


def rows_of(text):
    """A two-column figure as {first word: last word}."""

    out = {}
    for line in figure(text):
        words = line.split()
        if len(words) == 2 and re.fullmatch(r"-?\d+(\.\d+)?", words[1]):
            out[words[0]] = words[1]
    return out


def rate_in(text):
    """The beat rate a report prints, from the row that names it."""

    found = [value for name, value in rows_of(text).items()
             if "beat" in name.lower() or "rate" in name.lower()]
    assert found, "no row for the beat rate in:\n" + text
    return abs(float(found[0]))


def rate_of(found):
    """The beat rate in a result mapping, whatever the key is called."""

    for name, value in found.items():
        if "beat" in name.lower() or "rate" in name.lower():
            if not isinstance(value, str):
                return abs(value)
    raise AssertionError("no beat rate in {0!r}".format(found))


def near(shown, want):
    """Whether a printed figure is the one written here."""

    return abs(float(shown) - float(want)) <= SLACK


def beats(*words):
    """Run ``wolf beats`` and give back its report."""

    code, text = run(["beats"] + list(words))
    assert code == 0, text
    return text


# --- the beats command ------------------------------------------------


@pytest.mark.parametrize("name,lower,upper,octave,want", CASES)
def test_beats_counts_the_partials_that_coincide(name, lower, upper,
                                                 octave, want):
    """The q-th partial of the upper note against the p-th of the
    lower, for the just interval of the steps from the lower note up
    to the upper one."""

    text = beats(lower, upper, "--temperament", name,
                 "--octave", str(octave))
    assert near(rate_in(text), want), text


@pytest.mark.parametrize("name,lower,upper,octave,standard,want",
                         STANDARDS)
def test_the_standard_scales_the_rate(name, lower, upper, octave,
                                      standard, want):
    """A beat rate is a difference of frequencies, so it moves with
    the standard."""

    text = beats(lower, upper, "--temperament", name,
                 "--octave", str(octave), "--standard", standard)
    assert near(rate_in(text), want), text


@pytest.mark.parametrize("name,lower,upper,octave,want", OCTAVES)
def test_the_octave_moves_the_rate(name, lower, upper, octave, want):
    """Twice as fast an octave up, half as fast an octave down."""

    text = beats(lower, upper, "--temperament", name,
                 "--octave", str(octave))
    assert near(rate_in(text), want), text


@pytest.mark.parametrize("name,lower,upper,octave,ratio,want", BY_HAND)
def test_a_ratio_given_by_hand_is_the_check(name, lower, upper, octave,
                                            ratio, want):
    """``--just`` wins, any ratio, wider than an octave included, and
    the report says which ratio it counted against."""

    text = beats(lower, upper, "--temperament", name,
                 "--octave", str(octave), "--just", ratio)
    assert near(rate_in(text), want), text
    assert ratio in text or ratio.replace(":", "/") in text, text


@pytest.mark.parametrize("lower,upper,ratio,want", (
    ("C", "G", "3:2", "0.8858"),
    ("C", "E", "5:4", "10.3824"),
    ("G", "C", "4:3", "1.7716"),
    ("D", "F", "6:5", "15.8475"),
    ("E", "C", "8:5", "20.7648"),
    ("C", "D", "9:8", "5.3119"),
))
def test_the_report_names_the_check_it_counted(lower, upper, ratio,
                                               want):
    """The just ratio of the steps from the lower note up to the
    upper one, written out beside the figure it explains."""

    text = beats(lower, upper)
    assert ratio in text or ratio.replace(":", "/") in text, text
    assert near(rate_in(text), want), text


def test_the_report_says_which_partials_were_counted():
    """A tuner wants to know what to listen for."""

    text = beats("C", "G")
    assert "partial" in text.lower() or "harmonic" in text.lower(), \
        text
    assert near(rate_in(text), "0.8858"), text


def test_the_help_lists_the_ratio_option():
    """``wolf help beats`` says the ratio can be given by hand."""

    code, text = run(["help", "beats"])
    assert code == 0, text
    assert "--just" in text, text


def test_the_command_is_no_longer_a_fifth_only():
    """The limits line that said so is gone, because it is not so."""

    text = beats("C", "G")
    assert "this is a fifth" not in text, text


# --- the bearing plans ------------------------------------------------


@pytest.mark.parametrize("plan,octave,lower,upper,check,want",
                         PLAN_ROWS)
def test_every_step_of_a_plan_beats_on_its_partials(plan, octave, lower,
                                                    upper, check, want):
    """Fifths on the third partial against the second, fourths on the
    fourth against the third, in both plans and in two octaves."""

    rows = [row for row in bearings.rates(plan, "a440", octave)
            if row["from"] == lower and row["to"] == upper]
    assert len(rows) == 1, rows
    assert rows[0]["check"] == check
    assert near(rate_of(rows[0]), want), rows[0]


@pytest.mark.parametrize("plan,octave", (
    ("equal", 3), ("equal", 4), ("quarter_comma", 3),
    ("quarter_comma", 4)))
def test_the_bearings_command_prints_the_rates(plan, octave):
    """What the tuner reads off is what the library counts."""

    code, text = run(["bearings", plan, "--octave", str(octave)])
    assert code == 0, text
    wanted = [row[5] for row in PLAN_ROWS
              if row[0] == plan and row[1] == octave]
    for want in wanted:
        assert want in text, (want, text)


@pytest.mark.parametrize("plan,octave", (
    ("equal", 3), ("equal", 4), ("quarter_comma", 3),
    ("quarter_comma", 4)))
def test_the_fastest_and_slowest_steps_follow(plan, octave):
    """The hardest step to count and the hardest to hear."""

    wanted = [float(row[5]) for row in PLAN_ROWS
              if row[0] == plan and row[1] == octave]
    assert near(rate_of(bearings.fastest(plan, "a440", octave)),
                max(wanted))
    assert near(rate_of(bearings.slowest(plan, "a440", octave)),
                min(wanted))


# --- the library ------------------------------------------------------


@pytest.mark.parametrize("name,first,second,want", TWO_PITCHES)
def test_two_pitches_beat_on_their_partials(name, first, second, want):
    """The just interval of the steps between the two notes decides
    which partials, and the lower note is the lower whichever was
    named first."""

    made = table.named(name)
    found = frequency.beats(frequency.pitch(made, first),
                            frequency.pitch(made, second))
    assert near(found, want), found


@pytest.mark.parametrize("name", table.known())
def test_an_octave_between_two_pitches_beats_nought(name):
    """Octaves are exact in every tuning here."""

    made = table.named(name)
    found = frequency.beats(frequency.pitch(made, "C4"),
                            frequency.pitch(made, "C5"))
    assert abs(float(found)) < 1e-9, found


@pytest.mark.parametrize("name", table.known())
def test_an_octave_check_beats_nought(name):
    """Through the function the plans use, against 2:1."""

    made = table.named(name)
    found = frequency.beats_against_just(made, "C", "C", 2, "a440", 3)
    assert abs(float(rate_of(found))) < 1e-9, found


# --- the pages and the changelog --------------------------------------


def test_the_pitch_page_shows_the_rate_a_tuner_counts():
    """The documented ``beats C G`` block is regenerated."""

    text = (ROOT / "docs" / "pitch.md").read_text(encoding="utf-8")
    assert "0.8858" in text


def test_the_bearings_page_shows_the_new_rates():
    """The documented plan is regenerated, fastest step included."""

    text = (ROOT / "docs" / "more.md").read_text(encoding="utf-8")
    assert "1.0534" in text


def test_the_gap_is_off_the_not_covered_page():
    """The section that said beat rates were for a pure sine goes,
    because they are not any more."""

    text = (ROOT / "docs" / "not-covered.md").read_text(
        encoding="utf-8")
    assert "beat rates are for a pure sine" not in text.lower()


def test_the_gap_is_off_the_readme_list():
    """And the short version in the README goes with it."""

    text = (ROOT / "README.md").read_text(encoding="utf-8")
    assert "beat rates for a pure sine" not in text.lower()


BASE_ENTRIES = 56
BASE_LINES = 223


def test_the_changelog_gains_an_entry():
    """A corrected figure is recorded, as every one before it was."""

    text = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
    lines = [line for line in text.splitlines() if line.strip()]
    entries = [line for line in lines if line.startswith(("- ", "* "))]
    assert len(entries) > BASE_ENTRIES or len(lines) > BASE_LINES, (
        len(entries), len(lines))
