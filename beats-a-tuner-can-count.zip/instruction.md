Beats command gives the difference of two fundamentals. A tuner never hears those. Real beating is between the partials that coincide when the interval is pure. For a fifth it is third partial of lower note against second partial of upper one, so the rate is twice what we print. Fourth is fourth partial against third, major third is fifth against fourth. Not-covered page admits this since the start. Please count beats the way the tuner counts them.

Every beat rate this package gives should be counted on partials, bearing plans too, each step. Ratio to count against is the just ratio for the steps between the two notes, we have the list, just command prints it. Cents stay what they are, cents are about fundamentals.

Beats command is a fifth only today, its limits line says so, beats C E compares E with a pure G and prints sixty-two beats a second. It should check the interval from the lower note up to the upper one, as a tuner plays it. Ratio given by hand with --just wins, any ratio, an octave or wider as well. Report should say which ratio and which partials were counted. Ratio of nothing is refused as usual.

Figures in docs and in claims change, please regenerate them and fix the sentences beside. Please take the gap off not-covered page and from README's short list. Please add tests and changelog entry as usual.
