import { describe, it, expect, vi, afterEach } from 'vitest';
import React from 'react';
import { renderToString } from 'react-dom/server';

let currentUser: any = null;
vi.mock('@/hooks/useAuth', () => ({ useAuth: () => ({ user: currentUser }) }));
vi.mock('react-router-dom', () => ({ useNavigate: () => vi.fn() }));

const FLAG_KEYS = [
  'canView', 'canEdit', 'canDelete', 'canManageAppointments', 'canManageReminders', 'canAddWeights',
  'canManageLabs', 'canPrescribeMedications', 'canManageVaccinations', 'canManageFiles', 'canCreateTasks',
  'canAssignOwners', 'isFullAdmin',
];

async function ask(user: any) {
  currentUser = user;
  const { usePermissions } = await import('@/hooks/usePermissions');
  let got: any;
  const Probe = () => {
    const p: any = usePermissions();
    got = p;
    return null;
  };
  renderToString(React.createElement(Probe));
  return got;
}

afterEach(() => {
  currentUser = null;
});

describe('what already worked keeps working', () => {
  it('the hook returns every flag of the permission set', async () => {
    const p = await ask({ id: 'u1', role: 'org_admin', role_isDefault: true });
    for (const k of FLAG_KEYS) expect(typeof p[k]).toBe('boolean');
    expect(typeof p.hasPermission).toBe('function');
    expect(typeof p.getPermissionTooltip).toBe('function');
  });

  it('a receptionist manages appointments and reminders but not labs', async () => {
    const p = await ask({ id: 'u1', role: 'receptionist', role_isDefault: true });
    expect(p.canManageAppointments).toBe(true);
    expect(p.canManageReminders).toBe(true);
    expect(p.canAssignOwners).toBe(true);
    expect(p.canManageLabs).toBe(false);
    expect(p.canPrescribeMedications).toBe(false);
  });

  it('a televet prescribes and manages vaccinations but does not delete', async () => {
    const p = await ask({ id: 'u1', role: 'televet', role_isDefault: true });
    expect(p.canPrescribeMedications).toBe(true);
    expect(p.canManageVaccinations).toBe(true);
    expect(p.canDelete).toBe(false);
    expect(p.isFullAdmin).toBe(false);
  });

  it('an org admin has the organization ids and views patients', async () => {
    const p = await ask({ id: 'u1', role: 'org_admin', role_isDefault: true });
    expect(p.hasPermission('view_all_clinics')).toBe(true);
    expect(p.hasPermission('manage_organization_settings')).toBe(true);
    expect(p.canView).toBe(true);
    expect(p.canEdit).toBe(false);
  });

  it('a clinic admin deletes patients and is a full admin', async () => {
    const p = await ask({ id: 'u1', role: 'clinic_admin', role_isDefault: true });
    expect(p.canDelete).toBe(true);
    expect(p.isFullAdmin).toBe(true);
  });

  it('a super admin deletes patients and is a full admin', async () => {
    const p = await ask({ id: 'u1', role: 'super_admin', role_isDefault: true });
    expect(p.canDelete).toBe(true);
    expect(p.isFullAdmin).toBe(true);
  });

  it('tooltip texts are unchanged', async () => {
    const p = await ask({ id: 'u1', role: 'receptionist', role_isDefault: true });
    expect(p.getPermissionTooltip('manage_labs')).toBe('Insufficient permissions to manage lab results');
    expect(p.getPermissionTooltip('full_admin')).toBe('Administrator privileges required');
    expect(p.getPermissionTooltip('manage_appointments')).toBe('');
  });

  it('an org admin sees the clinics page buttons enabled', async () => {
    currentUser = { id: 'o1', role: 'org_admin', role_isDefault: true };
    const { default: Page } = await import('@/pages/org-admin/ClinicsManagementPage');
    const html = renderToString(React.createElement(Page));
    const buttons = html.match(/<button[^>]*>/g) || [];
    expect(buttons.length).toBeGreaterThan(3);
    expect(buttons.filter((b) => /\bdisabled\b/.test(b)).length).toBe(0);
  });

  it('a clinic admin sees the users page buttons disabled', async () => {
    currentUser = { id: 'c1', role: 'clinic_admin', role_isDefault: true };
    const { default: Page } = await import('@/pages/org-admin/UsersManagementPage');
    const html = renderToString(React.createElement(Page));
    const buttons = html.match(/<button[^>]*>/g) || [];
    expect(buttons.filter((b) => /\bdisabled\b/.test(b)).length).toBeGreaterThan(0);
  });

  it('a clinic admin keeps the admin row but has no organization permission', async () => {
    const p = await ask({ id: 'u1', role: 'clinic_admin', role_isDefault: true });
    for (const k of FLAG_KEYS) expect(p[k]).toBe(true);
    expect(['view_all_clinics', 'edit_organization', 'view_all_users'].filter((id) => p.hasPermission(id))).toEqual([]);
  });

  it('a super admin has every clinic flag on', async () => {
    const p = await ask({ id: 'u1', role: 'super_admin', role_isDefault: true });
    for (const k of FLAG_KEYS) expect(p[k]).toBe(true);
  });

  it('a missing organization permission has a tooltip', async () => {
    const p = await ask({ id: 'u1', role: 'clinic_admin', role_isDefault: true });
    expect(p.getPermissionTooltip('edit_clinics').length).toBeGreaterThan(0);
  });
});
