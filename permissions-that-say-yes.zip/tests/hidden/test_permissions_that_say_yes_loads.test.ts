import { describe, it, expect, vi } from 'vitest';

vi.mock('@/hooks/useAuth', () => ({ useAuth: () => ({ user: null }) }));
vi.mock('react-router-dom', () => ({ useNavigate: () => vi.fn() }));

describe('the modules the change touches still load', () => {
  it('the permissions hook module loads with its names', async () => {
    const mod: any = await import('@/hooks/usePermissions');
    expect(typeof mod.usePermissions).toBe('function');
  });

  it('the clinics management page loads', async () => {
    const mod: any = await import('@/pages/org-admin/ClinicsManagementPage');
    expect(typeof mod.default).toBe('function');
  });

  it('the users management page loads', async () => {
    const mod: any = await import('@/pages/org-admin/UsersManagementPage');
    expect(typeof mod.default).toBe('function');
  });

  it('the organization settings page loads', async () => {
    const mod: any = await import('@/pages/org-admin/OrganizationSettingsPage');
    expect(typeof mod.default).toBe('function');
  });
});
