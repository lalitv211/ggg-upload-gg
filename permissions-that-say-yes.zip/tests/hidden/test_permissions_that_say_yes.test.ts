import { describe, it, expect, vi, afterEach } from 'vitest';
import React from 'react';
import { renderToString } from 'react-dom/server';

let currentUser: any = null;
vi.mock('@/hooks/useAuth', () => ({ useAuth: () => ({ user: currentUser }) }));
vi.mock('react-router-dom', () => ({ useNavigate: () => vi.fn() }));

type Flags = Record<string, boolean>;
const FLAG_KEYS = [
  'canView', 'canEdit', 'canDelete', 'canManageAppointments', 'canManageReminders', 'canAddWeights',
  'canManageLabs', 'canPrescribeMedications', 'canManageVaccinations', 'canManageFiles', 'canCreateTasks',
  'canAssignOwners', 'isFullAdmin',
];
const CLINIC_IDS = [
  'view_patients', 'edit_patients', 'delete_patients', 'manage_appointments', 'manage_reminders', 'add_weights',
  'manage_labs', 'prescribe_medications', 'manage_vaccinations', 'manage_files', 'create_tasks', 'assign_owners',
  'full_admin',
];
const ORG_IDS = [
  'view_organization', 'edit_organization', 'manage_organization_settings', 'view_all_clinics', 'create_clinics',
  'edit_clinics', 'delete_clinics', 'manage_clinic_settings', 'view_all_users', 'create_clinic_users',
  'edit_clinic_users', 'delete_clinic_users', 'assign_user_roles', 'transfer_users', 'view_org_reports',
  'export_org_data', 'view_financial_reports', 'manage_subscription', 'view_billing_history',
  'manage_payment_methods', 'view_org_patients', 'view_org_appointments',
];

async function ask(user: any) {
  currentUser = user;
  const { usePermissions } = await import('@/hooks/usePermissions');
  let got: { flags: Flags; has: (id: string) => boolean; tip: (id: string) => string } | undefined;
  const Probe = () => {
    const p: any = usePermissions();
    const flags: Flags = {};
    for (const k of FLAG_KEYS) flags[k] = !!p[k];
    got = { flags, has: (id: string) => !!p.hasPermission(id), tip: (id: string) => p.getPermissionTooltip(id) };
    return null;
  };
  renderToString(React.createElement(Probe));
  if (!got) throw new Error('the hook did not run');
  return got;
}

const allFalse = () => Object.fromEntries(FLAG_KEYS.map((k) => [k, false]));
const flagsOf = (on: string[]) => ({ ...allFalse(), ...Object.fromEntries(on.map((k) => [k, true])) });
const VET_FLAGS = flagsOf([
  'canView', 'canEdit', 'canManageAppointments', 'canManageReminders', 'canAddWeights', 'canManageLabs',
  'canPrescribeMedications', 'canManageVaccinations', 'canManageFiles', 'canCreateTasks', 'canAssignOwners',
]);
const TECH_FLAGS = flagsOf([
  'canView', 'canEdit', 'canManageAppointments', 'canManageReminders', 'canAddWeights', 'canManageLabs',
  'canManageFiles', 'canCreateTasks', 'canAssignOwners',
]);
const ADMIN_FLAGS = flagsOf(FLAG_KEYS);

afterEach(() => {
  currentUser = null;
  vi.restoreAllMocks();
});

describe('nobody the hook does not know gets anything', () => {
  it('no signed-in user gets no permission', async () => {
    const p = await ask(null);
    expect(p.flags).toEqual(allFalse());
    expect(CLINIC_IDS.concat(ORG_IDS).filter((id) => p.has(id))).toEqual([]);
  });

  it('a user without a role gets no permission', async () => {
    const p = await ask({ id: 'u1', email: 'x@y.z' });
    expect(p.flags).toEqual(allFalse());
    expect(p.has('view_patients')).toBe(false);
  });

  it('a role the table does not know gets no permission', async () => {
    const p = await ask({ id: 'u1', role: 'intern', role_isDefault: true });
    expect(p.flags).toEqual(allFalse());
    expect(p.has('full_admin')).toBe(false);
  });

  it('a stale key of the old table is not a role', async () => {
    const p = await ask({ id: 'u1', role: 'admin' });
    expect(p.flags).toEqual(allFalse());
  });
});

describe('the backend roles answer from the table', () => {
  it('a veterinarian gets the vet row, without delete or full admin', async () => {
    const p = await ask({ id: 'u1', role: 'veterinarian', role_isDefault: true });
    expect(p.flags).toEqual(VET_FLAGS);
  });

  it('a veterinarian whose profile carries the id list of the auth hook answers from the table', async () => {
    const p = await ask({ id: 'u1', role: 'veterinarian', role_isDefault: true, role_permissions: ['view_patients', 'messages'] });
    expect(p.flags).toEqual(VET_FLAGS);
  });

  it('a veterinarian can prescribe but cannot delete patients', async () => {
    const p = await ask({ id: 'u1', role: 'veterinarian', role_isDefault: true });
    expect(p.has('prescribe_medications')).toBe(true);
    expect(p.has('delete_patients')).toBe(false);
    expect(p.has('full_admin')).toBe(false);
  });

  it('staff gets the tech row', async () => {
    const p = await ask({ id: 'u1', role: 'staff', role_isDefault: true });
    expect(p.flags).toEqual(TECH_FLAGS);
  });

  it('staff cannot prescribe or manage vaccinations', async () => {
    const p = await ask({ id: 'u1', role: 'staff', role_isDefault: true });
    expect(p.has('prescribe_medications')).toBe(false);
    expect(p.has('manage_vaccinations')).toBe(false);
    expect(p.has('manage_labs')).toBe(true);
  });

  it('a client can only view patients', async () => {
    const p = await ask({ id: 'u1', role: 'client', role_isDefault: true });
    expect(p.flags).toEqual(flagsOf(['canView']));
    expect(ORG_IDS.filter((id) => p.has(id))).toEqual([]);
  });

  it('a client cannot edit, delete or administer', async () => {
    const p = await ask({ id: 'u1', role: 'client', role_isDefault: true });
    expect(p.has('edit_patients')).toBe(false);
    expect(p.has('delete_patients')).toBe(false);
    expect(p.has('full_admin')).toBe(false);
  });

});

describe('a super admin has every permission the hook knows', () => {

  it('every organization id is granted', async () => {
    const p = await ask({ id: 'u1', role: 'super_admin', role_isDefault: true });
    expect(ORG_IDS.filter((id) => !p.has(id))).toEqual([]);
  });

  it('the clinics page ids are granted', async () => {
    const p = await ask({ id: 'u1', role: 'super_admin' });
    expect(['view_all_clinics', 'edit_clinics', 'create_clinics'].map((id) => p.has(id))).toEqual([true, true, true]);
  });

  it('the users page ids are granted', async () => {
    const p = await ask({ id: 'u1', role: 'super_admin' });
    expect(
      ['view_all_users', 'edit_clinic_users', 'transfer_users', 'delete_clinic_users', 'create_clinic_users'].map((id) => p.has(id))
    ).toEqual([true, true, true, true, true]);
  });

  it('the organization settings ids are granted', async () => {
    const p = await ask({ id: 'u1', role: 'super_admin' });
    expect(['manage_organization_settings', 'edit_organization'].map((id) => p.has(id))).toEqual([true, true]);
  });

  it('a super admin built the way the auth hook builds it still has everything', async () => {
    const p = await ask({ id: 'u1', role: 'super_admin', role_isDefault: false, role_permissions: undefined });
    expect(p.flags).toEqual(ADMIN_FLAGS);
    expect(ORG_IDS.filter((id) => !p.has(id))).toEqual([]);
  });

  it('a super admin whose profile carries lists is still a super admin', async () => {
    const p = await ask({
      id: 'u1', role: 'super_admin', role_isDefault: false,
      role_permissions: { id: 'r9', admin_controls: [], view_access: ['view_patients'], create_access: [], edit_access: [], cancel_access: [], delete_access: [] },
    });
    expect(p.has('delete_clinics')).toBe(true);
    expect(p.has('full_admin')).toBe(true);
  });
});

describe('a custom role answers from its own lists', () => {
  const lists = (over: Partial<Record<string, string[]>>) => ({
    id: 'r1',
    admin_controls: [],
    view_access: [],
    create_access: [],
    edit_access: [],
    cancel_access: [],
    delete_access: [],
    ...over,
  });

  it('an id in one of the lists is granted', async () => {
    const p = await ask({
      id: 'u1', role: 'Care Team', role_isDefault: false,
      role_permissions: lists({ view_access: ['view_patients'], edit_access: ['edit_patients'] }),
    });
    expect(p.flags).toEqual(flagsOf(['canView', 'canEdit']));
  });

  it('nothing outside the lists is granted', async () => {
    const p = await ask({
      id: 'u1', role: 'Care Team', role_isDefault: false,
      role_permissions: lists({ edit_access: ['edit_patients'] }),
    });
    expect(p.has('delete_patients')).toBe(false);
    expect(p.has('full_admin')).toBe(false);
    expect(ORG_IDS.filter((id) => p.has(id))).toEqual([]);
  });

  it('an id in the admin controls list counts', async () => {
    const p = await ask({
      id: 'u1', role: 'Office', role_isDefault: false,
      role_permissions: lists({ admin_controls: ['full_admin'], delete_access: ['delete_patients'] }),
    });
    expect(p.flags).toEqual(flagsOf(['canDelete', 'isFullAdmin']));
  });

  it('a custom role without lists gets nothing', async () => {
    const p = await ask({ id: 'u1', role: 'Care Team', role_isDefault: false });
    expect(p.flags).toEqual(allFalse());
  });

});

describe('tooltips follow the answer', () => {
  it('a permission that is missing has its message', async () => {
    const p = await ask({ id: 'u1', role: 'client', role_isDefault: true });
    expect(p.tip('edit_patients')).toBe('Insufficient permissions to edit patients');
    expect(p.tip('prescribe_medications')).toBe('Only veterinarians can prescribe medications');
  });

  it('a permission that is there has an empty tooltip', async () => {
    const p = await ask({ id: 'u1', role: 'veterinarian', role_isDefault: true });
    expect(p.tip('prescribe_medications')).toBe('');
    expect(p.tip('delete_patients')).not.toBe('');
  });

});

describe('the hook does not log the user', () => {
  it('rendering for a veterinarian writes nothing about the user to the console', async () => {
    const user = { id: 'u1', role: 'veterinarian', role_isDefault: true, email: 'vet@clinic.test' };
    const log = vi.spyOn(console, 'log').mockImplementation(() => {});
    await ask(user);
    const mentions = log.mock.calls.filter((args) =>
      args.some((a) => a === user || (a && typeof a === 'object' && (a as any).user === user) || JSON.stringify(a ?? '').includes('vet@clinic.test'))
    );
    expect(mentions).toEqual([]);
  });
});

describe('the org admin pages follow the hook', () => {
  const disabledButtons = (html: string) => (html.match(/<button[^>]*>/g) || []).filter((b) => /\bdisabled\b/.test(b)).length;
  const render = async (modulePath: string, user: any) => {
    currentUser = user;
    const mod: any = await import(/* @vite-ignore */ modulePath);
    return renderToString(React.createElement(mod.default));
  };

  for (const [name, path] of [
    ['clinics', '@/pages/org-admin/ClinicsManagementPage'],
    ['users', '@/pages/org-admin/UsersManagementPage'],
    ['organization settings', '@/pages/org-admin/OrganizationSettingsPage'],
  ] as const) {
    it(`a super admin sees the ${name} page buttons enabled like an org admin`, async () => {
      const orgAdmin = disabledButtons(await render(path, { id: 'o1', role: 'org_admin', role_isDefault: true }));
      const superAdmin = disabledButtons(await render(path, { id: 's1', role: 'super_admin', role_isDefault: true }));
      const clinicAdmin = disabledButtons(await render(path, { id: 'c1', role: 'clinic_admin', role_isDefault: true }));
      expect(clinicAdmin).toBeGreaterThan(orgAdmin);
      expect(superAdmin).toBe(orgAdmin);
    });
  }
});
