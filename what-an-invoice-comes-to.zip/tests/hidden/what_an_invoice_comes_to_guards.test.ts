/**
 * What already holds about invoices and must keep holding once the pricing is in one place.
 *
 * Every test here passes on the base: the money formatter, what the whiteboard puts on a line and
 * asks of the backend, the page helper's ids, and which store action the SOAP page dispatches.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('@/features/invoices/api/backendInvoiceService', () => ({
  createBackendInvoice: vi.fn(),
  createBackendInvoiceItems: vi.fn(),
  getBackendInvoice: vi.fn(),
  getBackendInvoiceByAppointmentId: vi.fn(),
  updateBackendInvoice: vi.fn(),
  updateBackendInvoiceWithAllData: vi.fn(),
  getBackendInvoicesByClientId: vi.fn(),
  getBackendInvoicesByPetId: vi.fn(),
  getBackendInvoiceItem: vi.fn(),
  updateBackendInvoiceItem: vi.fn(),
}));
vi.mock('@/features/appointments/api/backendAppointmentService', () => ({
  getBackendAppointmentById: vi.fn(),
}));
vi.mock('@/services/whiteboard/backendWhiteboardService', () => ({
  getBackendPendingInvoiceItems: vi.fn(),
}));
vi.mock('@/features/clinics/api/clinicService', () => ({
  clinicService: { getClinic: vi.fn(async () => ({ id: 'clinic-1' })), updateInvoice: vi.fn() },
}));
vi.mock('@tanstack/react-query', () => ({
  useQuery: vi.fn(() => ({ data: undefined, isLoading: false, isError: false })),
  useMutation: vi.fn(() => ({ mutate: vi.fn(), mutateAsync: vi.fn() })),
  useQueryClient: vi.fn(() => ({ invalidateQueries: vi.fn(), setQueryData: vi.fn() })),
}));
vi.mock('@/features/clinics/hooks/useBackendClinics', () => ({
  useBackendClinic: vi.fn(() => ({ data: undefined, isLoading: false })),
  useBackendClinics: vi.fn(() => ({ data: [], isLoading: false })),
}));
vi.mock('react-redux', () => ({
  useSelector: vi.fn(() => undefined),
  useDispatch: vi.fn(() => vi.fn()),
}));
vi.mock('@/features/clinics/hooks/useBackendClinicSettings', () => ({
  useBackendClinicSettings: vi.fn(() => ({ clinicSettings: undefined, isLoading: false })),
}));
vi.mock('@/hooks/useClinicBranding', () => ({
  useClinicBranding: vi.fn(() => ({ clinic: undefined, branding: undefined })),
}));
vi.mock('@/hooks/useNotification', () => ({
  useNotification: () => ({ showNotification: vi.fn() }),
}));
vi.mock('@/store/store', () => {
  // A state in which every slice exists, holds nothing, and reads as empty.
  const empty = (): unknown =>
    new Proxy(
      {},
      {
        get: (_target, key) => {
          if (key === 'collection' || key === 'items' || key === 'list' || key === 'all') return [];
          if (key === 'data' || key === 'selected' || key === 'error') return null;
          if (key === 'loading' || key === 'isLoading') return false;
          if (typeof key === 'symbol' || key === 'then') return undefined;
          return empty();
        },
      }
    );
  const state = empty();
  return {
    dispatch: vi.fn(() => Promise.resolve({ payload: { id: 'inv-9' } })),
    useSelector: vi.fn((selector: (held: unknown) => unknown) => selector(state)),
    useDispatch: vi.fn(() => vi.fn()),
    useAppSelector: vi.fn((selector: (held: unknown) => unknown) => selector(state)),
    useAppDispatch: vi.fn(() => vi.fn()),
    store: { getState: () => state, dispatch: vi.fn() },
  };
});
vi.mock('@/store/slices/invoice', () => ({
  invoiceSave: vi.fn((args: unknown) => ({ type: 'invoice/save', args })),
  invoiceUpdate: vi.fn((args: unknown) => ({ type: 'invoice/update', args })),
}));

import {
  createBackendInvoice,
  createBackendInvoiceItems,
  getBackendInvoice,
  getBackendInvoiceByAppointmentId,
  updateBackendInvoice,
} from '@/features/invoices/api/backendInvoiceService';
import { getBackendAppointmentById } from '@/features/appointments/api/backendAppointmentService';
import { getBackendPendingInvoiceItems } from '@/services/whiteboard/backendWhiteboardService';
import { whiteboardInvoiceService } from '@/services/whiteboard/whiteboardInvoiceService';
import { AddInvoiceItemBackend } from '@/components/ui/TableFunctions/InvoiceItemsBackend';
import { useSOAPInvoice } from '@/components/appointments/soap/hooks/useSOAPInvoice';
import { formatCurrency } from '@/services/stripe/paymentService';
import { dispatch } from '@/store/store';

type Mock = ReturnType<typeof vi.fn>;
const mocked = {
  pendingItems: getBackendPendingInvoiceItems as unknown as Mock,
  getInvoice: getBackendInvoice as unknown as Mock,
  byAppointment: getBackendInvoiceByAppointmentId as unknown as Mock,
  createInvoice: createBackendInvoice as unknown as Mock,
  createItems: createBackendInvoiceItems as unknown as Mock,
  update: updateBackendInvoice as unknown as Mock,
  appointment: getBackendAppointmentById as unknown as Mock,
};

function pending(id: string, overrides: Record<string, unknown> = {}) {
  return {
    id,
    status: 'approved',
    service_id: 'svc-' + id,
    price: 10,
    appointment_id: 'apt-1',
    service: { id: 'svc-' + id, service_name: 'Thing ' + id, price: 10 },
    whiteboard_patients: { clinic_id: 'clinic-1', pet_id: 'pet-1', appointment_id: 'apt-1' },
    ...overrides,
  };
}

function invoice(overrides: Record<string, unknown> = {}) {
  return {
    id: 'inv-1',
    amount: 0,
    status: 'Active',
    treatments: [],
    prescriptions: [],
    invoice_items: ['item-old'],
    added_invoice_items: [],
    tenant_id: 'clinic-1',
    client_id: 'client-1',
    appointment_id: 'apt-1',
    issued_at: '',
    issued_by: '',
    ...overrides,
  };
}

/** Let a hook that dispatches after a detached promise finish before the dispatch is read. */
async function settle(): Promise<void> {
  for (let turn = 0; turn < 5; turn += 1) {
    await new Promise((resolve) => setTimeout(resolve, 5));
  }
}

describe('the money formatter', () => {
  it('formats dollars and cents with a thousands separator', () => {
    expect(formatCurrency(1234.5)).toBe('$1,234.50');
  });

  it('formats nought', () => {
    expect(formatCurrency(0)).toBe('$0.00');
  });

  it('formats a whole number with cents', () => {
    expect(formatCurrency(12)).toBe('$12.00');
  });
});

describe('the whiteboard talking to the backend', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocked.appointment.mockResolvedValue({ id: 'apt-1', client_id: 'client-1', tenant_id: 'clinic-1' });
    mocked.getInvoice.mockImplementation(async () => invoice());
    mocked.byAppointment.mockImplementation(async () => invoice());
    mocked.createItems.mockImplementation(async (_id: string, items: Array<Record<string, unknown>>) =>
      items.map((one, index) => ({ ...one, id: 'item-' + index }))
    );
    mocked.update.mockImplementation(async (_id: string, data: unknown) => data);
  });

  it('creates one invoice item per approved pending item', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a'), pending('b'), pending('c', { status: 'pending' })]);
    const made = await whiteboardInvoiceService.batchAddToInvoice(['a', 'b', 'c'], 'inv-1');
    expect(made).toHaveLength(2);
  });

  it('puts the service, the price, the name and the patient on the line', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 12.5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    const [item] = mocked.createItems.mock.calls[0][1];
    expect(item).toMatchObject({
      invoice_id: 'inv-1',
      client_id: 'client-1',
      service_id: 'svc-a',
      item_price: 12.5,
      item_name: 'Thing a',
      patient_id: 'pet-1',
    });
  });

  it('keeps the invoice item ids it already had and adds the new ones', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a')]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    const stored = mocked.update.mock.calls[0][1];
    expect(stored.invoice_items).toEqual(['item-old', 'item-0']);
  });

  it('updates each invoice once per batch', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a'), pending('b')]);
    await whiteboardInvoiceService.batchAddToInvoice(['a', 'b'], 'inv-1');
    expect(mocked.update).toHaveBeenCalledTimes(1);
  });

  it('refuses a single item that is not approved', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { status: 'pending' })]);
    await expect(whiteboardInvoiceService.addTreatmentToInvoice('a', 'inv-1')).rejects.toThrow();
  });

  it('refuses a batch with nothing approved in it', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { status: 'rejected' })]);
    await expect(whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1')).rejects.toThrow();
  });

  it('creates an invoice for an appointment that has none', async () => {
    mocked.byAppointment.mockResolvedValue(null);
    mocked.createInvoice.mockResolvedValue(invoice({ id: 'inv-new', amount: 0 }));
    const made = await whiteboardInvoiceService.getInvoiceForAppointment('apt-1');
    expect(made?.id).toBe('inv-new');
    expect(mocked.createInvoice.mock.calls[0][0].amount).toBe(0);
  });

  it('hands back the invoice an appointment already has', async () => {
    const made = await whiteboardInvoiceService.getInvoiceForAppointment('apt-1');
    expect(made?.id).toBe('inv-1');
    expect(mocked.createInvoice).not.toHaveBeenCalled();
  });

  it('syncs only the approved items of the appointment', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a'), pending('b', { status: 'pending' })]);
    const made = await whiteboardInvoiceService.syncPendingItemsToInvoice('apt-1', 'inv-1');
    expect(made).toHaveLength(1);
  });

  it('syncs nothing when nothing is approved', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { status: 'pending' })]);
    const made = await whiteboardInvoiceService.syncPendingItemsToInvoice('apt-1', 'inv-1');
    expect(made).toEqual([]);
    expect(mocked.update).not.toHaveBeenCalled();
  });
});

describe('the page helper adding items', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocked.createItems.mockImplementation(async (_id: string, items: Array<Record<string, unknown>>) =>
      items.map((one, index) => ({ ...one, id: 'item-' + index }))
    );
  });

  const item = (quantity: number, item_price: number, patient_id: string | null = 'pet-1') => ({
    quantity,
    item_price,
    patient_id,
    service_id: 'svc-1',
    created_by: 'user-1',
    clinic_id: 'clinic-1',
    invoice_id: 'inv-1',
    client_id: 'client-1',
  });

  it('hands back the ids of the items it created', async () => {
    const result = await AddInvoiceItemBackend([item(1, 10), item(2, 5)], 'inv-1', { id: 'user-1' } as never);
    expect(result.invoiceItemsIds).toEqual(['item-0', 'item-1']);
    expect(result.createdItems).toHaveLength(2);
  });

  it('sends a patient of none as no patient', async () => {
    await AddInvoiceItemBackend([item(1, 10, 'none')], 'inv-1', { id: 'user-1' } as never);
    expect(mocked.createItems.mock.calls[0][1][0].patient_id).toBeNull();
  });

  it('fails when nothing was created', async () => {
    mocked.createItems.mockResolvedValue([]);
    await expect(AddInvoiceItemBackend([item(1, 10)], 'inv-1', { id: 'user-1' } as never)).rejects.toThrow();
  });
});

describe('the SOAP page saving an invoice', () => {
  beforeEach(() => vi.clearAllMocks());

  const rx = { id: 'r1', qty_dispensed: 2, product_service: { id: 'p1', price: 4 } } as never;

  function hook(invoiceSelected: unknown = null) {
    return useSOAPInvoice({
      appointmentId: 'apt-1',
      clientId: 'client-1',
      user: { id: 'user-1', _uuid: 'user-1', role: 'veterinarian' } as never,
      invoiceSelected,
    });
  }

  function sent(): Array<{ type: string; args: Record<string, unknown> }> {
    return (dispatch as unknown as Mock).mock.calls.map((call) => call[0]);
  }

  it('saves a new invoice when none is selected', async () => {
    await hook().handleSaveInvoice([rx], null);
    await settle();
    expect(sent()[0].type).toBe('invoice/save');
    expect(sent()[0].args.appointment_id).toBe('apt-1');
  });

  it('updates the selected invoice', async () => {
    await hook({ data: { id: 'inv-1', amount: 0 } }).handleSaveInvoice([rx], null);
    await settle();
    expect(sent()[0].type).toBe('invoice/update');
    expect(sent()[0].args.invoiceId).toBe('inv-1');
  });

  it('lists the prescriptions and treatments it billed', async () => {
    const tx = { id: 't1', dosage: 1, product_service: { id: 'p2', price: 3 } } as never;
    await hook().handleSaveInvoice([rx], [tx]);
    await settle();
    const data = sent()[0].args.data as { prescriptions: string[]; treatments: string[] };
    expect(data.prescriptions).toEqual(['r1']);
    expect(data.treatments).toEqual(['t1']);
  });

  it('does nothing without a user', async () => {
    await useSOAPInvoice({ appointmentId: 'apt-1', clientId: 'client-1', user: null, invoiceSelected: null }).handleSaveInvoice([rx], null);
    await settle();
    expect(dispatch).not.toHaveBeenCalled();
  });
});
