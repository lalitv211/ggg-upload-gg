/**
 * The build check: the modules the change touches load in node, and the pricing module exports what
 * the request names. tsc, eslint and prettier fail on the base of this repository, so loading the
 * code under vitest is the check that can be run.
 */
import { describe, expect, it, vi } from 'vitest';

vi.mock('@/services/api/httpClient', () => ({ httpClient: { get: vi.fn(), post: vi.fn(), patch: vi.fn(), put: vi.fn(), delete: vi.fn() } }));
vi.mock('@/hooks/useNotification', () => ({ useNotification: () => ({ showNotification: vi.fn() }) }));
vi.mock('@/store/store', () => ({ dispatch: vi.fn(), getState: () => ({}), useSelector: () => undefined, useDispatch: () => vi.fn() }));

describe('the modules load', () => {
  it('loads the pricing module with its two functions', async () => {
    const pricing = await import('@/features/invoices/pricing');
    expect(typeof pricing.priceLines).toBe('function');
    expect(typeof pricing.invoiceTotals).toBe('function');
  });

  it('loads the whiteboard invoice service', async () => {
    const held = await import('@/services/whiteboard/whiteboardInvoiceService');
    expect(held.whiteboardInvoiceService).toBeTruthy();
  });

  it('loads the page helper', async () => {
    const held = await import('@/components/ui/TableFunctions/InvoiceItemsBackend');
    expect(typeof held.AddInvoiceItemBackend).toBe('function');
  });

  it('loads the SOAP invoice hook', async () => {
    const held = await import('@/components/appointments/soap/hooks/useSOAPInvoice');
    expect(typeof held.useSOAPInvoice).toBe('function');
  });

  it('loads the table presets', async () => {
    const held = await import('@/components/ui/TableHelpers');
    expect(typeof held.tablePresets.invoiceTxManagment).toBe('function');
  });

  it('loads the payment service with its formatter', async () => {
    const held = await import('@/services/stripe/paymentService');
    expect(typeof held.formatCurrency).toBe('function');
  });
});
