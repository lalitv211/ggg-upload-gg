/**
 * The billing page itself: the real page component, its real handlers, run in node. A small hooks
 * runtime stands in for react, so the test can pick a product, press ADD, read the line the page
 * built, press ADD ALL and read the amount it stored. Components from libraries are not run, the
 * test only reads their props, and nothing about the page's design is pinned: the tests look for
 * the buttons by their words and read the amount handed to whichever update call the page makes.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const rt = vi.hoisted(() => {
  const ELEMENT = Symbol.for('react.element');
  const state: any = { insts: new Map(), cur: null, idx: 0, order: [], dirty: false, root: null, elements: [] };
  const ids = new WeakMap<object, number>();
  let nextId = 1;
  const idOf = (fn: any) => {
    if (!ids.has(fn)) ids.set(fn, nextId++);
    return ids.get(fn);
  };
  const same = (a: any, b: any) =>
    Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((v: any, i: number) => Object.is(v, b[i]));
  const cell = (init: () => any) => {
    const inst = state.cur;
    if (!inst) throw new Error('hook called outside a component');
    const i = state.idx++;
    if (!(i in inst.cells)) inst.cells[i] = init();
    return inst.cells[i];
  };
  const effect = (fn: any, deps: any) => {
    const inst = state.cur;
    const i = state.idx++;
    const prev = inst.cells[i];
    const changed = !prev || !deps || !prev.deps || !same(deps, prev.deps);
    if (!prev) inst.cells[i] = { deps, cleanup: undefined, effect: true };
    else prev.deps = deps;
    if (changed) inst.pending.push({ i, fn });
  };
  const hooks: any = {
    useState(init: any) {
      const c = cell(() => {
        const s: any = { v: typeof init === 'function' ? init() : init };
        s.set = (nv: any) => {
          const next = typeof nv === 'function' ? nv(s.v) : nv;
          if (!Object.is(next, s.v)) {
            s.v = next;
            state.dirty = true;
          }
        };
        return s;
      });
      return [c.v, c.set];
    },
    useReducer(reducer: any, init: any, initFn?: any) {
      const c = cell(() => {
        const s: any = { v: initFn ? initFn(init) : init };
        s.dispatch = (action: any) => {
          const next = reducer(s.v, action);
          if (!Object.is(next, s.v)) {
            s.v = next;
            state.dirty = true;
          }
        };
        return s;
      });
      return [c.v, c.dispatch];
    },
    useRef(init: any) {
      return cell(() => ({ current: init }));
    },
    useEffect: effect,
    useLayoutEffect: effect,
    useMemo(fn: any, deps: any) {
      const inst = state.cur;
      const i = state.idx++;
      const prev = inst.cells[i];
      if (prev && same(deps, prev.deps)) return prev.v;
      const v = fn();
      inst.cells[i] = { v, deps };
      return v;
    },
    useCallback(fn: any, deps: any) {
      return hooks.useMemo(() => fn, deps);
    },
    useId() {
      return cell(() => ({ v: 'id-' + nextId++ })).v;
    },
    useContext(context: any) {
      return context?._currentValue;
    },
    useDebugValue() {},
    useImperativeHandle() {},
    useTransition() {
      return [false, (fn: any) => fn()];
    },
    useDeferredValue(v: any) {
      return v;
    },
  };
  const component = (fn: any, props: any, path: string) => {
    const key = path + '#' + idOf(fn);
    let inst = state.insts.get(key);
    if (!inst) {
      inst = { cells: [], pending: [], seen: false };
      state.insts.set(key, inst);
    }
    inst.seen = true;
    const saved = [state.cur, state.idx];
    state.cur = inst;
    state.idx = 0;
    let out: any;
    try {
      out = fn(props);
    } finally {
      [state.cur, state.idx] = saved;
    }
    walk(out, key);
    state.order.push(inst);
  };
  const walk = (node: any, path: string): void => {
    if (node === null || node === undefined || typeof node !== 'object') return;
    if (Array.isArray(node)) {
      node.forEach((child, i) => walk(child, path + '.' + (child && child.key != null ? 'k' + child.key : i)));
      return;
    }
    if (node.$$typeof !== ELEMENT) return;
    state.elements.push(node);
    const t = node.type;
    const props = node.props || {};
    // A plain function is a component of the app: it runs. Anything else is read, not run.
    if (typeof t === 'function' && !(t.prototype && t.prototype.isReactComponent)) return component(t, props, path);
    walk(props.children, path + '/' + (t && typeof t === 'object' ? 'h' + idOf(t) : String(t)));
  };
  const pass = () => {
    for (const inst of state.insts.values()) {
      inst.seen = false;
      inst.pending = [];
    }
    state.order = [];
    state.elements = [];
    walk({ $$typeof: ELEMENT, type: state.root, props: {}, key: null, ref: null }, 'root');
    for (const [key, inst] of [...state.insts.entries()]) {
      if (!inst.seen) {
        cleanup(inst);
        state.insts.delete(key);
      }
    }
    for (const inst of state.order) {
      for (const e of inst.pending) {
        const c = inst.cells[e.i];
        if (typeof c.cleanup === 'function') {
          const fn = c.cleanup;
          c.cleanup = undefined;
          fn();
        }
        const back = e.fn();
        c.cleanup = typeof back === 'function' ? back : undefined;
      }
      inst.pending = [];
    }
  };
  const cleanup = (inst: any) => {
    for (const c of inst.cells) {
      if (c && c.effect && typeof c.cleanup === 'function') {
        const fn = c.cleanup;
        c.cleanup = undefined;
        fn();
      }
    }
  };
  const render = () => {
    let guard = 0;
    do {
      state.dirty = false;
      pass();
    } while (state.dirty && ++guard < 30);
  };
  return {
    hooks,
    user: { id: 'user-1', _uuid: 'user-1', clinic_id: 'clinic-1', role: 'veterinarian' },
    mount(root: any) {
      state.insts = new Map();
      state.root = root;
      render();
    },
    rerender: render,
    unmount() {
      for (const inst of state.insts.values()) cleanup(inst);
      state.insts = new Map();
      state.root = null;
    },
    elements: (): any[] => state.elements,
  };
});

vi.mock('react', async (importOriginal) => {
  const actual = await importOriginal<any>();
  return { ...actual, ...rt.hooks, default: { ...actual.default, ...rt.hooks } };
});
vi.mock('react-router-dom', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  const params = new URLSearchParams();
  return {
    ...original,
    useParams: () => ({ id: 'inv-1' }),
    useNavigate: () => vi.fn(),
    useSearchParams: () => [params, vi.fn()],
  };
});
vi.mock('@tanstack/react-query', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  // A query runs its function once per key; the next render shows what it brought back.
  const cache = ((globalThis as unknown as { __mvQueries?: Map<string, any> }).__mvQueries ??= new Map());
  const useQuery = (options: { queryKey?: unknown; queryFn?: (context: unknown) => unknown; enabled?: boolean }) => {
    const idle = { data: undefined, isLoading: false, isFetching: false, isError: false, error: null, refetch: async () => undefined };
    if (options.enabled === false || !options.queryFn) return idle;
    const key = JSON.stringify(options.queryKey ?? []);
    if (!cache.has(key)) {
      const entry: any = { ...idle, isLoading: true };
      cache.set(key, entry);
      Promise.resolve()
        .then(() => options.queryFn!({ queryKey: options.queryKey }))
        .then(
          (value) => Object.assign(entry, { data: value, isLoading: false }),
          (error) => Object.assign(entry, { error, isError: true, isLoading: false })
        );
    }
    return cache.get(key);
  };
  const useMutation = (options: any) => {
    const run = async (variables: unknown) => {
      const context = await options.onMutate?.(variables);
      try {
        const data = await options.mutationFn(variables);
        await options.onSuccess?.(data, variables, context);
        await options.onSettled?.(data, null, variables, context);
        return data;
      } catch (error) {
        await options.onError?.(error, variables, context);
        await options.onSettled?.(undefined, error, variables, context);
        throw error;
      }
    };
    return { mutateAsync: run, mutate: (variables: unknown) => void run(variables).catch(() => undefined), isPending: false, isLoading: false };
  };
  const client = {
    invalidateQueries: async () => undefined,
    setQueryData: () => undefined,
    getQueryData: () => undefined,
    removeQueries: () => undefined,
    fetchQuery: async (options: { queryFn?: (context: unknown) => unknown; queryKey?: unknown }) =>
      options.queryFn?.({ queryKey: options.queryKey }),
  };
  return { ...original, useQuery, useMutation, useQueryClient: () => client };
});
vi.mock('@/hooks/useAuth', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original, useAuth: () => ({ user: rt.user, isAuthenticated: true, loading: false }) };
});
vi.mock('@/components/ui/Tables/TxRxTable', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original, TxRxTable: () => null };
});
vi.mock('@/pages/billing/InvoiceRightRail', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original, default: () => null };
});
// Every export of the pricing module counts a call made from outside it, so a test can tell that a
// path went through the module, whichever of its functions the path happens to use.
vi.mock('@/features/invoices/pricing', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  const seen = ((globalThis as unknown as { __mvPricingCalls?: { count: number } }).__mvPricingCalls ??= { count: 0 });
  const watched = (value: unknown): unknown =>
    typeof value !== 'function'
      ? value
      : new Proxy(value as (...args: unknown[]) => unknown, {
          apply(target, self, args) {
            seen.count += 1;
            return Reflect.apply(target, self, args);
          },
          construct(target, args) {
            seen.count += 1;
            return Reflect.construct(target as never, args);
          },
          get(target, key) {
            const member = Reflect.get(target, key) as unknown;
            if (typeof member !== 'function' || key === 'constructor') return member;
            return (...args: unknown[]) => {
              seen.count += 1;
              return (member as (...inner: unknown[]) => unknown).apply(target, args);
            };
          },
        });
  // setPricingClinic is read by the tests when a design has one, so the name has to exist here
  return { setPricingClinic: undefined, ...Object.fromEntries(Object.entries(original).map(([name, value]) => [name, watched(value)])) };
});
vi.mock('@/features/invoices/api/backendInvoiceService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  createBackendInvoice: vi.fn(),
  createBackendInvoiceItems: vi.fn(),
  getBackendInvoice: vi.fn(),
  getBackendInvoiceByAppointmentId: vi.fn(),
  updateBackendInvoice: vi.fn(async (_id: string, data: unknown) => data),
  updateBackendInvoiceWithAllData: vi.fn(async (_id: string, data: unknown) => data),
  getBackendInvoicesByClientId: vi.fn(),
  getBackendInvoicesByPetId: vi.fn(),
  getBackendInvoiceItem: vi.fn(),
  updateBackendInvoiceItem: vi.fn(),
 };
});
vi.mock('@/features/clinics/api/clinicService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  clinicService: { ...((original.clinicService as Record<string, unknown>) || {}), getManyProductService: vi.fn(async () => Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values())),
    getClinic: vi.fn(async () => ({ id: 'clinic-1', tax_rate: 10 })),
    createInvoiceItems: vi.fn(),
    updateInvoiceWithAllData: vi.fn(async (data: unknown) => data),
    updateInvoice: vi.fn(async (data: unknown) => data),
    getInvoice: vi.fn(),
  },
 };
});
vi.mock('@/features/clinics/hooks/useBackendClinics', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useBackendClinic: vi.fn(() => ({ data: { id: 'clinic-1', tax_rate: 10 }, isLoading: false })),
  useBackendClinics: vi.fn(() => ({ data: [{ id: 'clinic-1', tax_rate: 10 }], isLoading: false })),
 };
});
vi.mock('react-redux', async (importOriginal) => {
  // The same state the store mock holds, whichever module a component reads it through
  const store = await import('@/store/store');
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original, useSelector: store.useSelector, useDispatch: store.useDispatch };
});
vi.mock('@/features/clinics/hooks/useBackendClinicSettings', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useBackendClinicSettings: vi.fn(() => ({
    clinicSettings: { id: 'clinic-1', tax_rate: 10 },
    data: { id: 'clinic-1', tax_rate: 10 },
    isLoading: false,
  })),
 };
});
vi.mock('@/hooks/useClinicBranding', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useClinicBranding: vi.fn(() => ({ clinic: { id: 'clinic-1', tax_rate: 10 }, branding: undefined })),
 };
});
vi.mock('@/hooks/useNotification', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useNotification: () => ({ showNotification: vi.fn() }),
 };
});
vi.mock('@/services/api/httpClient', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  const quiet = { get: vi.fn(async () => null), post: vi.fn(async () => null), put: vi.fn(async () => null), patch: vi.fn(async () => null), delete: vi.fn(async () => null) };
  return { ...original, httpClient: { ...((original.httpClient as object) || {}), ...quiet } };
});
vi.mock('@/features/clinics/api/backendClinicService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original, getBackendClinic: vi.fn(async () => ({ id: 'clinic-1', tax_rate: 10 })), getBackendClinicById: vi.fn(async () => ({ id: 'clinic-1', tax_rate: 10 })), getBackendClinics: vi.fn(async () => [{ id: 'clinic-1' }]) };
});
vi.mock('@/components/billing/PaymentQRModal', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  PaymentQRModal: () => null,
 };
});
vi.mock('@/features/clinics/api/backendClinicSettingsService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  getBackendClinicSettings: vi.fn(async () => ({ id: 'clinic-1', tax_rate: 10 })),
  updateBackendClinicSettings: vi.fn(),
 };
});
vi.mock('@/features/clinics/api/backendClinicProductsServicesService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  getBackendClinicServices: vi.fn(async () => Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values())), getBackendServiceNames: vi.fn(async () => []), getBackendReferenceServices: vi.fn(async () => []),
  getBackendClinicProducts: vi.fn(async () => Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values())),
  getBackendClinicServicesProducts: vi.fn(async () => Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values())),
 };
});
vi.mock('@/store/store', () => {
  // A store whose state the tests fill: any slice not set reads as empty, and a thunk given to
  // dispatch runs against that state, the way the real store runs it.
  const held: Record<string, unknown> = {};
  const empty = (): unknown =>
    new Proxy(
      {},
      {
        get: (_target, key) => {
          if (key === 'collection' || key === 'items' || key === 'list' || key === 'all') return [];
          if (key === 'data' || key === 'selected' || key === 'error') return null;
          if (key === 'loading' || key === 'isLoading') return false;
          if (typeof key === 'symbol' || key === 'then') return undefined;
          return empty();
        },
      }
    );
  const catalogueSlice = () => ({
    collection: Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values()),
    loading: false,
    error: null,
    selected: null,
  });
  const getState = () =>
    new Proxy(held, {
      get: (target, key) =>
        key in target ? target[key as string] : key === 'clinicServicesProducts' ? catalogueSlice() : empty(),
    });
  const dispatch = vi.fn((action: unknown) =>
    typeof action === 'function'
      ? (action as (d: unknown, g: unknown, e: unknown) => unknown)(dispatch, getState, undefined)
      : action
  );
  const useSelector = vi.fn((selector: (state: unknown) => unknown) => selector(getState()));
  return {
    dispatch,
    getState,
    store: { getState, dispatch },
    persistor: {},
    useSelector,
    useDispatch: vi.fn(() => dispatch),
    useAppSelector: useSelector,
    useAppDispatch: vi.fn(() => dispatch),
    __held: held,
  };
});


import type { Invoice, InvoiceItem, ServicesProductsPriceSetting } from '@/features/clinics/api/types';
import {
  createBackendInvoiceItems,
  getBackendInvoice,
  getBackendInvoiceItem,
  updateBackendInvoice,
  updateBackendInvoiceWithAllData,
} from '@/features/invoices/api/backendInvoiceService';
import { clinicService } from '@/features/clinics/api/clinicService';
import * as pricing from '@/features/invoices/pricing';
import InvoicePage from '@/pages/billing/Invoice';
import * as storeModule from '@/store/store';

const { invoiceTotals, priceLines } = pricing;
const clinic = { id: 'clinic-1', tax_rate: 10 };
(pricing as unknown as { setPricingClinic?: (c: unknown) => void }).setPricingClinic?.(clinic);

/** Calls made into the pricing module from outside it. */
const pricingCalls = ((globalThis as unknown as { __mvPricingCalls?: { count: number } }).__mvPricingCalls ??= { count: 0 });

// The clinic's catalogue: what the store, the backend and the clinic service all hand back.
type CatalogueProduct = { id: string; [key: string]: unknown };
const catalogue = ((globalThis as unknown as { __mvCatalogue?: Map<string, CatalogueProduct> }).__mvCatalogue ??=
  new Map<string, CatalogueProduct>());

type Setting = ServicesProductsPriceSetting;

function setting(): Setting {
  return {
    selling_price: 0,
    min_price: 0,
    dispensing_fee_amt: 0,
    include_on_estimate_and_invoice_print: true,
    client_discount_eligible: true,
    hide_from_treatment_search: false,
    default_product_discount: false,
    taxable: false,
    discount: null,
  };
}

function product(id: string, price: number): CatalogueProduct {
  const held = { id: 'svc-' + id, service_name: 'Thing ' + id, price, price_setting: setting(), details: null };
  catalogue.set(held.id, held);
  return held;
}

function item(id: string, quantity: number, item_price: number): InvoiceItem {
  const service = product(id, item_price);
  return {
    id,
    quantity,
    item_price,
    service_id: service.id,
    item_name: 'Thing ' + id,
    invoice_id: 'inv-1',
    client_id: 'client-1',
    clinic_id: 'clinic-1',
    created_by: 'user-1',
    patient_id: 'pet-1',
    service,
  } as unknown as InvoiceItem;
}

function invoice(): Invoice {
  return {
    id: 'inv-1',
    amount: 999,
    status: 'Active',
    treatments: [],
    prescriptions: [],
    invoice_items: ['old'],
    added_invoice_items: [item('old', 2, 5)],
    tenant_id: 'clinic-1',
    client_id: 'client-1',
    appointment_id: 'apt-1',
    client: { patients: [] },
    issued_at: '',
    issued_by: '',
  } as unknown as Invoice;
}

/** What the lines come to, untaxed. */
function totalOf(lines: Array<[number, number]>): number {
  return invoiceTotals(
    priceLines(
      lines.map(([quantity, unit_price]) => ({ quantity, unit_price, price_setting: null })),
      clinic
    ),
    0,
    0
  ).total;
}

/** The last amount any invoice update call carried, whichever service the page went through. */
function storedAmount(): number | undefined {
  const calls = [
    ...vi.mocked(clinicService.updateInvoiceWithAllData).mock.calls,
    ...vi.mocked(clinicService.updateInvoice).mock.calls,
    ...vi.mocked(updateBackendInvoiceWithAllData).mock.calls,
    ...vi.mocked(updateBackendInvoice).mock.calls,
  ];
  let found: number | undefined;
  for (const call of calls) {
    for (const arg of call as unknown[]) {
      const amount = (arg as { amount?: unknown } | null)?.amount;
      if (typeof amount === 'number') found = amount;
    }
  }
  return found;
}

/** Lets what the page started finish, then renders again, a few times over. */
async function settled(): Promise<void> {
  for (let turn = 0; turn < 8; turn += 1) {
    await new Promise((resolve) => setTimeout(resolve, 5));
    rt.rerender();
  }
}

function textOf(node: any): string {
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(textOf).join('');
  return node?.props ? textOf(node.props.children) : '';
}

/** Presses the button with these words on it. */
async function press(words: string): Promise<void> {
  const button = rt.elements().find((one) => typeof one.props?.onClick === 'function' && textOf(one).trim() === words);
  expect(button, 'a button saying ' + words).toBeTruthy();
  await button.props.onClick({});
  await settled();
}

/** Picks a product in the page's list of things to add, the way the select reports it. */
async function pick(id: string): Promise<void> {
  const select = rt.elements().find((one) => one.props?.multiple === true && typeof one.props.onChange === 'function');
  expect(select, 'the list of things to add').toBeTruthy();
  const index = Array.from(catalogue.keys()).indexOf('svc-' + id);
  select.props.onChange({ target: { value: [index] } });
  await settled();
}

/** The table of the lines waiting to be added. */
function waiting(): any {
  const table = rt.elements().find((one) => one.props?.type === 'invoiceAddItems');
  expect(table, 'the table of items to add').toBeTruthy();
  return table;
}

describe('the billing page adding items', () => {
  const held = (storeModule as unknown as { __held: Record<string, unknown> }).__held;

  beforeEach(async () => {
    catalogue.clear();
    (globalThis as unknown as { __mvQueries?: Map<string, unknown> }).__mvQueries?.clear();
    vi.clearAllMocks();
    const current = invoice();
    product('n', 12.5);
    held.invoice = { selected: { data: current, index: 0 }, collection: [], loading: false, error: null };
    const made = new Map<string, InvoiceItem>();
    vi.mocked(getBackendInvoice).mockImplementation(async () => current);
    vi.mocked(createBackendInvoiceItems).mockImplementation((async (_id: string, items: InvoiceItem[]) =>
      items.map((one, index) => {
        const saved = { ...one, id: 'new-' + index };
        made.set(saved.id, saved);
        return saved;
      })) as never);
    vi.mocked(getBackendInvoiceItem).mockImplementation(
      async (id: string) => made.get(id) ?? (current.added_invoice_items as InvoiceItem[])[0]
    );
    vi.mocked(clinicService.getManyProductService).mockImplementation((async () => Array.from(catalogue.values())) as never);
    rt.mount(InvoicePage);
    await settled();
  });

  afterEach(() => {
    rt.unmount();
  });

  it('starts a line it adds at a quantity of one', async () => {
    await pick('n');
    await press('ADD');
    const lines = waiting().props.data;
    expect(lines).toHaveLength(1);
    expect(Number(lines[0].quantity)).toBe(1);
  });

  it('stores what all the lines come to, not the old amount with the new figure added', async () => {
    await pick('n');
    await press('ADD');
    await press('ADD ALL');
    expect(storedAmount()).toBe(totalOf([[2, 5], [1, 12.5]]));
  });

  it('counts the quantity a line was given before it was added', async () => {
    await pick('n');
    await press('ADD');
    const table = waiting();
    table.props.setData(table.props.data.map((line: InvoiceItem) => ({ ...line, quantity: 3 })));
    await settled();
    await press('ADD ALL');
    expect(storedAmount()).toBe(totalOf([[2, 5], [3, 12.5]]));
  });

  it('works the amount out through the pricing module', async () => {
    await pick('n');
    await press('ADD');
    pricingCalls.count = 0;
    await press('ADD ALL');
    expect(pricingCalls.count).toBeGreaterThan(0);
  });
});
