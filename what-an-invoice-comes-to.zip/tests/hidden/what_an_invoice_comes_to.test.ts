/**
 * What an invoice comes to: one module prices the lines, and every path that stores an amount
 * stores what the lines come to.
 *
 * The pricing module is tested case by case against the rules of the request (quantity, dispensing
 * fee once per line, the product's discount with the minimum price as a floor, tax at the clinic's
 * rate on taxable lines, cents). The whiteboard service and the SOAP hook are tested with the
 * backend modules mocked, asserting only the amount they store and the quantity they put on a line.
 * Figures avoid half-cent ties. No message, field order or internal is pinned.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest';

// The backend modules keep whatever they export (a change may add a call of its own); only the
// calls these tests drive are replaced. The real module is loaded when it can be, else nothing.
vi.mock('@/features/invoices/api/backendInvoiceService', async (importActual) => ({
  ...((await importActual().catch(() => ({}))) as Record<string, unknown>),
  createBackendInvoice: vi.fn(),
  createBackendInvoiceItems: vi.fn(),
  getBackendInvoice: vi.fn(),
  getBackendInvoiceByAppointmentId: vi.fn(),
  updateBackendInvoice: vi.fn(),
  updateBackendInvoiceWithAllData: vi.fn(),
  getBackendInvoicesByClientId: vi.fn(),
  getBackendInvoicesByPetId: vi.fn(),
  getBackendInvoiceItem: vi.fn(),
  updateBackendInvoiceItem: vi.fn(),
}));
vi.mock('@/features/appointments/api/backendAppointmentService', async (importActual) => ({
  ...((await importActual().catch(() => ({}))) as Record<string, unknown>),
  getBackendAppointmentById: vi.fn(),
}));
vi.mock('@/services/whiteboard/backendWhiteboardService', async (importActual) => ({
  ...((await importActual().catch(() => ({}))) as Record<string, unknown>),
  getBackendPendingInvoiceItems: vi.fn(),
}));
vi.mock('@/features/clinics/api/clinicService', async (importActual) => {
  const actual = (await importActual().catch(() => ({}))) as Record<string, unknown>;
  return {
    ...actual,
    clinicService: {
      ...((actual.clinicService as Record<string, unknown>) || {}),
      getClinic: vi.fn(async () => ({ id: 'clinic-1' })),
      createInvoice: vi.fn(),
      updateInvoice: vi.fn(async (data: unknown) => data),
      updateInvoiceWithAllData: vi.fn(async (data: unknown) => data),
      createInvoiceItems: vi.fn(async (items: Array<Record<string, unknown>>) =>
        items.map((one, index) => ({ ...one, id: 'item-' + index }))
      ),
    },
  };
});
vi.mock('@/hooks/useNotification', () => ({
  useNotification: () => ({ showNotification: vi.fn() }),
}));
vi.mock('@/store/store', () => {
  const state = {
    invoice: { selected: null, loading: false, collection: null },
    clinicServicesProducts: { selected: null, loading: false, collection: [] as unknown[] },
  };
  const dispatch = vi.fn(() => Promise.resolve({ payload: { id: 'inv-9' } }));
  return {
    dispatch,
    getState: () => state,
    useDispatch: () => dispatch,
    useSelector: (select: (s: unknown) => unknown) => select(state),
    store: { dispatch, getState: () => state },
    __state: state,
  };
});
// A change may reach for the clinic (its tax rate), the signed-in user or React Query to price an
// invoice; none of that is under test here, so each is a quiet stand-in with no tax rate.
// A call the change makes straight through the HTTP client (its own clinic or products request,
// say) gets the clinic the tests describe: no tax rate unless a test sets one.
const http = vi.hoisted(() => ({ clinic: { id: 'clinic-1' } as Record<string, unknown> }));
vi.mock('@/services/api/httpClient', () => {
  const quiet = vi.fn(async () => http.clinic);
  const silent = vi.fn(async () => null);
  return { httpClient: { get: quiet, post: silent, patch: silent, put: silent, delete: silent } };
});
vi.mock('@/features/clinics/api/backendClinicProductsServicesService', async (importActual) => ({
  ...((await importActual().catch(() => ({}))) as Record<string, unknown>),
  getBackendClinicServices: vi.fn(async () => []),
  getBackendServiceNames: vi.fn(async () => []),
  getBackendReferenceServices: vi.fn(async () => []),
  createBackendClinicService: vi.fn(),
  updateBackendClinicService: vi.fn(),
}));
vi.mock('@/features/clinics/api/backendClinicSettingsService', async (importActual) => ({
  ...((await importActual().catch(() => ({}))) as Record<string, unknown>),
  getBackendClinicSettings: vi.fn(async () => ({ id: 'clinic-1' })),
  updateBackendClinicSettings: vi.fn(async () => ({ id: 'clinic-1' })),
  uploadBackendClinicLogo: vi.fn(async () => ''),
}));
vi.mock('@/features/clinics/api/backendClinicService', async (importActual) => ({
  ...((await importActual().catch(() => ({}))) as Record<string, unknown>),
  getBackendClinics: vi.fn(async () => []),
  getBackendClinicById: vi.fn(async () => ({ id: 'clinic-1' })),
  getBackendUserRolesByClinic: vi.fn(async () => []),
  getClinicBranding: vi.fn(async () => ({})),
  createBackendClinic: vi.fn(),
  updateBackendClinic: vi.fn(),
  deleteBackendClinic: vi.fn(),
}));
vi.mock('@/features/clinics/hooks/useBackendClinicSettings', async (importActual) => ({
  ...((await importActual().catch(() => ({}))) as Record<string, unknown>),
  useBackendClinicSettings: () => ({ clinicSettings: null, isLoading: false, error: null }),
}));
vi.mock('@/hooks/useAuth', async (importActual) => ({
  ...((await importActual().catch(() => ({}))) as Record<string, unknown>),
  useAuth: () => ({
    user: { id: 'user-1', _uuid: 'user-1', role: 'veterinarian', clinic_id: 'clinic-1' },
  }),
}));
vi.mock('@tanstack/react-query', async (importActual) => {
  const actual = (await importActual()) as Record<string, unknown>;
  return {
    ...actual,
    useQuery: () => ({ data: undefined, isLoading: false, error: null, refetch: vi.fn() }),
    useQueryClient: () => ({ invalidateQueries: vi.fn(), setQueryData: vi.fn() }),
    useMutation: () => ({ mutate: vi.fn(), mutateAsync: vi.fn(), isPending: false }),
  };
});
vi.mock('react', async (importActual) => {
  const actual = (await importActual()) as Record<string, unknown>;
  return {
    ...actual,
    useMemo: (make: () => unknown) => make(),
    useCallback: (callback: unknown) => callback,
    useState: (initial: unknown) => [typeof initial === 'function' ? initial() : initial, () => undefined],
    useEffect: () => undefined,
    useLayoutEffect: () => undefined,
    useRef: (initial: unknown) => ({ current: initial }),
    useContext: () => undefined,
  };
});
vi.mock('@/store/slices/invoice', async (importActual) => ({
  ...((await importActual().catch(() => ({}))) as Record<string, unknown>),
  invoiceSave: vi.fn((args: unknown) => ({ type: 'invoice/save', args })),
  invoiceUpdate: vi.fn((args: unknown) => ({ type: 'invoice/update', args })),
}));

import type { ServicesProductsPriceSetting } from '@/features/clinics/api/types';
import {
  createBackendInvoiceItems,
  getBackendInvoice,
  getBackendInvoiceByAppointmentId,
  updateBackendInvoice,
  updateBackendInvoiceWithAllData,
} from '@/features/invoices/api/backendInvoiceService';
import { invoiceTotals, priceLines } from '@/features/invoices/pricing';
import { getBackendAppointmentById } from '@/features/appointments/api/backendAppointmentService';
import { getBackendPendingInvoiceItems } from '@/services/whiteboard/backendWhiteboardService';
import { whiteboardInvoiceService } from '@/services/whiteboard/whiteboardInvoiceService';
import { useSOAPInvoice } from '@/components/appointments/soap/hooks/useSOAPInvoice';
import { getBackendClinicServices } from '@/features/clinics/api/backendClinicProductsServicesService';
import { getBackendClinicSettings } from '@/features/clinics/api/backendClinicSettingsService';
import { getBackendClinicById } from '@/features/clinics/api/backendClinicService';
import { formatCurrency } from '@/services/stripe/paymentService';
import { clinicService } from '@/features/clinics/api/clinicService';
import { AddInvoiceItem } from '@/components/ui/TableFunctions/InvoiceItems';
import * as store from '@/store/store';
import { dispatch } from '@/store/store';

type Setting = ServicesProductsPriceSetting;

function setting(overrides: Partial<Setting> = {}): Setting {
  return {
    selling_price: 0,
    min_price: 0,
    dispensing_fee_amt: 0,
    include_on_estimate_and_invoice_print: true,
    client_discount_eligible: true,
    hide_from_treatment_search: false,
    default_product_discount: false,
    taxable: false,
    discount: null,
    ...overrides,
  };
}

function percentOff(amount: number, more: Partial<Setting> = {}): Setting {
  return setting({ default_product_discount: true, discount: { type: '%', discount: amount, note: '' }, ...more });
}

function dollarsOff(amount: number, more: Partial<Setting> = {}): Setting {
  return setting({ default_product_discount: true, discount: { type: '$', discount: amount, note: '' }, ...more });
}

const line = (quantity: number, unit_price: number, price_setting?: Setting | null) => ({
  quantity,
  unit_price,
  price_setting,
});

// ---------------------------------------------------------------------------------------------
// The pricing module, line by line, through the figures the request names (subtotal, discount,
// tax, total, paid, refunded, balance). How the clinic's rate and the payments reach priceLines
// and invoiceTotals is the change's own choice: a clinic object, a bare rate or an options
// object are all accepted, and the convention is found once with a line whose answer is known.

type Rate = number | null | undefined;
type Totals = { subtotal: number; discount: number; tax: number; total: number; paid: number; refunded: number; balance: number };
type Convention = (lines: ReturnType<typeof line>[], rate: Rate, paid?: number | null, refunded?: number | null) => Totals;

const clinicOf = (rate: Rate) => (rate === undefined ? null : { id: 'clinic-1', tax_rate: rate, taxRate: rate });
const optionsOf = (rate: Rate, paid?: number | null, refunded?: number | null) => ({
  paid,
  refunded,
  amount_paid: paid,
  amount_refunded: refunded,
  amountPaid: paid,
  amountRefunded: refunded,
  taxRate: rate ?? 0,
  tax_rate: rate ?? 0,
  clinic: clinicOf(rate),
});
const anyPrice = priceLines as unknown as (...args: unknown[]) => unknown;
const anyTotals = invoiceTotals as unknown as (...args: unknown[]) => Totals;

const CONVENTIONS: Convention[] = [
  (lines, rate, paid, refunded) => anyTotals(anyPrice(lines, clinicOf(rate)), paid, refunded),
  (lines, rate, paid, refunded) => anyTotals(anyPrice(lines, clinicOf(rate)), optionsOf(rate, paid, refunded)),
  (lines, rate, paid, refunded) => anyTotals(anyPrice(lines, rate ?? 0), paid, refunded),
  (lines, rate, paid, refunded) => anyTotals(anyPrice(lines, rate ?? 0), optionsOf(rate, paid, refunded)),
  (lines, rate, paid, refunded) => anyTotals(anyPrice(lines, optionsOf(rate)), paid, refunded),
  (lines, rate, paid, refunded) => anyTotals(anyPrice(lines, optionsOf(rate)), optionsOf(rate, paid, refunded)),
  (lines, rate, paid, refunded) => anyTotals(lines, optionsOf(rate, paid, refunded)),
  (lines, rate, paid, refunded) => anyTotals(lines, clinicOf(rate), paid, refunded),
  (lines, rate, paid, refunded) => anyTotals(lines, rate ?? 0, paid, refunded),
  (lines, rate, paid, refunded) => anyTotals(lines, rate ?? 0, optionsOf(rate, paid, refunded)),
  (lines, rate, paid, refunded) => anyTotals(anyPrice(lines, rate ?? 0), rate ?? 0, optionsOf(rate, paid, refunded)),
  (lines, rate, paid, refunded) => anyTotals(lines, clinicOf(rate), optionsOf(rate, paid, refunded)),
  (lines, rate, paid, refunded) => anyTotals(anyPrice(lines, clinicOf(rate)), { paid, refunded }),
  (lines, rate, paid, refunded) => anyTotals(anyPrice(lines, rate ?? 0), { paid, refunded }),
];

const near = (a: unknown, b: number) => typeof a === 'number' && Math.abs(a - b) < 0.000001;

let convention: Convention | null = null;
function totals(lines: ReturnType<typeof line>[], rate?: Rate, paid?: number | null, refunded?: number | null): Totals {
  if (!convention) {
    // two at 100 with a fee of 5 and ten percent off, taxed at ten: 205 less 20 is 185, tax 18.50
    const probe = [line(2, 100, percentOff(10, { taxable: true, dispensing_fee_amt: 5 }))];
    for (const candidate of CONVENTIONS) {
      try {
        const got = candidate(probe, 10, 60, 10);
        if (near(got.subtotal, 205) && near(got.discount, 20) && near(got.tax, 18.5) && near(got.total, 203.5) && near(got.paid, 60) && near(got.refunded, 10) && near(got.balance, 153.5)) {
          convention = candidate;
          break;
        }
      } catch {
        // not this shape
      }
    }
    convention = convention || CONVENTIONS[0];
  }
  return convention(lines, rate, paid, refunded);
}

interface LineCase {
  name: string;
  input: ReturnType<typeof line>;
  rate?: Rate;
  expect: Partial<{ subtotal: number; discount: number; tax: number; total: number }>;
}

const LINE_CASES: LineCase[] = [
  { name: 'three of a thing at 12.50 is 37.50', input: line(3, 12.5), expect: { subtotal: 37.5, discount: 0, tax: 0, total: 37.5 } },
  { name: 'one of a thing with no setting has no fee, discount or tax', input: line(1, 9.99), expect: { subtotal: 9.99, discount: 0, tax: 0, total: 9.99 } },
  { name: 'a dispensing fee is charged once per line, not per unit', input: line(2, 10, setting({ dispensing_fee_amt: 4 })), expect: { subtotal: 24, total: 24 } },
  { name: 'a percent discount takes that share of the goods', input: line(2, 10, percentOff(10)), expect: { subtotal: 20, discount: 2, total: 18 } },
  { name: 'a percent discount leaves the dispensing fee alone', input: line(2, 10, percentOff(10, { dispensing_fee_amt: 5 })), expect: { subtotal: 25, discount: 2, total: 23 } },
  { name: 'a dollar discount comes off each unit', input: line(3, 10, dollarsOff(1.5)), expect: { subtotal: 30, discount: 4.5, total: 25.5 } },
  { name: 'a discount the product does not apply by default is not applied', input: line(3, 10, setting({ default_product_discount: false, discount: { type: '$', discount: 1.5, note: '' } })), expect: { discount: 0, total: 30 } },
  { name: 'a discount of nought takes nothing off', input: line(3, 10, dollarsOff(0)), expect: { discount: 0, total: 30 } },
  { name: 'a dollar discount never takes a unit below its minimum price', input: line(2, 10, dollarsOff(3, { min_price: 9 })), expect: { discount: 2, total: 18 } },
  { name: 'a percent discount never takes a unit below its minimum price', input: line(1, 10, percentOff(20, { min_price: 9.5 })), expect: { discount: 0.5, total: 9.5 } },
  { name: 'a unit already under its minimum price gets no discount', input: line(2, 8, dollarsOff(1, { min_price: 9 })), expect: { discount: 0, total: 16 } },
  { name: 'a minimum price of nought is no floor', input: line(1, 10, dollarsOff(4, { min_price: 0 })), expect: { discount: 4, total: 6 } },
  { name: 'a dollar discount bigger than the unit leaves nothing, never a negative line', input: line(1, 10, dollarsOff(15, { min_price: 0 })), expect: { discount: 10, total: 0 } },
  { name: 'a percent discount over a hundred leaves nothing, never a negative line', input: line(2, 10, percentOff(150)), expect: { discount: 20, total: 0 } },
  { name: 'a taxable line is taxed at the clinic rate', input: line(1, 100, setting({ taxable: true })), rate: 8, expect: { tax: 8, total: 108 } },
  { name: 'tax is worked out after the discount', input: line(1, 100, percentOff(10, { taxable: true })), rate: 7.5, expect: { discount: 10, tax: 6.75, total: 96.75 } },
  { name: 'tax is worked out on the dispensing fee too', input: line(1, 10, setting({ taxable: true, dispensing_fee_amt: 5 })), rate: 10, expect: { subtotal: 15, tax: 1.5, total: 16.5 } },
  { name: 'a line that is not taxable is not taxed', input: line(1, 100, setting({ taxable: false })), rate: 8, expect: { tax: 0, total: 100 } },
  { name: 'no clinic means no tax', input: line(1, 100, setting({ taxable: true })), expect: { tax: 0, total: 100 } },
  { name: 'a clinic without a rate means no tax', input: line(1, 100, setting({ taxable: true })), rate: null, expect: { tax: 0, total: 100 } },
  { name: 'a rate with a fraction is a percent', input: line(1, 19.99, setting({ taxable: true })), rate: 8.25, expect: { tax: 1.65, total: 21.64 } },
  { name: 'a line is rounded to the cent', input: line(3, 1.111), expect: { subtotal: 3.33, total: 3.33 } },
  { name: 'a percent discount is rounded to the cent', input: line(1, 9.99, percentOff(15)), expect: { discount: 1.5, total: 8.49 } },
  { name: 'tax on a discounted fee line is rounded to the cent', input: line(2, 7.33, percentOff(5, { taxable: true, dispensing_fee_amt: 1.25 })), rate: 6, expect: { subtotal: 15.91, discount: 0.73, tax: 0.91, total: 16.09 } },
  { name: 'a setting of null is no setting', input: line(2, 5, null), expect: { discount: 0, tax: 0, total: 10 } },
];

describe('a priced line', () => {
  for (const held of LINE_CASES) {
    it(held.name, () => {
      const got = totals([held.input], held.rate);
      for (const [field, value] of Object.entries(held.expect)) {
        expect(got[field as keyof typeof held.expect], field).toBe(value);
      }
    });
  }

  it('prices a list of lines as the sum of each', () => {
    const got = totals([line(1, 10), line(2, 5, setting({ dispensing_fee_amt: 1 })), line(3, 2)]);
    expect(got.total).toBe(27);
  });
});

// ---------------------------------------------------------------------------------------------
// The totals.

describe('the totals of an invoice', () => {
  const lines = [line(2, 10, percentOff(10, { taxable: true })), line(1, 5.5, setting({ dispensing_fee_amt: 2 })), line(3, 1.111)];

  it('adds the subtotals of the lines', () => {
    expect(totals(lines, 10).subtotal).toBe(30.83);
  });

  it('adds the discounts of the lines', () => {
    expect(totals(lines, 10).discount).toBe(2);
  });

  it('adds the tax of the lines', () => {
    expect(totals(lines, 10).tax).toBe(1.8);
  });

  it('comes to subtotal less discount plus tax', () => {
    expect(totals(lines, 10).total).toBe(30.63);
  });

  it('is nought for no lines', () => {
    expect(totals([])).toMatchObject({ subtotal: 0, discount: 0, tax: 0, total: 0, balance: 0 });
  });

  it('takes what was paid off the balance', () => {
    const got = totals([line(1, 100)], undefined, 60);
    expect(got.paid).toBe(60);
    expect(got.balance).toBe(40);
  });

  it('puts a refund back on the balance', () => {
    const got = totals([line(1, 100)], undefined, 60, 10);
    expect(got.refunded).toBe(10);
    expect(got.balance).toBe(50);
  });

  it('treats a missing payment as nought', () => {
    const got = totals([line(1, 100)], undefined, null, undefined);
    expect(got.paid).toBe(0);
    expect(got.refunded).toBe(0);
    expect(got.balance).toBe(100);
  });

  it('is settled when paid in full', () => {
    expect(totals([line(2, 12.5)], undefined, 25).balance).toBe(0);
  });

  it('rounds the balance to the cent', () => {
    expect(totals([line(3, 1.111)], undefined, 1.11).balance).toBe(2.22);
  });

  it('sums rounded lines rather than rounding the sum', () => {
    expect(totals([line(1, 1.004), line(1, 1.004), line(1, 1.004)]).subtotal).toBe(3);
  });
});

// ---------------------------------------------------------------------------------------------
// The whiteboard: what it puts on a line and what it stores.

type Pending = Record<string, unknown>;

function pending(id: string, overrides: Pending = {}): Pending {
  return {
    id,
    status: 'approved',
    service_id: 'svc-' + id,
    price: 10,
    appointment_id: 'apt-1',
    service: { id: 'svc-' + id, service_name: 'Thing ' + id, price: 10 },
    whiteboard_patients: { clinic_id: 'clinic-1', pet_id: 'pet-1', appointment_id: 'apt-1' },
    ...overrides,
  };
}

function invoice(overrides: Record<string, unknown> = {}) {
  return {
    id: 'inv-1',
    amount: 999,
    status: 'Active',
    treatments: [],
    prescriptions: [],
    invoice_items: [],
    added_invoice_items: [],
    tenant_id: 'clinic-1',
    client_id: 'client-1',
    appointment_id: 'apt-1',
    issued_at: '',
    issued_by: '',
    ...overrides,
  };
}

const products = getBackendClinicServices as unknown as ReturnType<typeof vi.fn>;
const clinicSettings = getBackendClinicSettings as unknown as ReturnType<typeof vi.fn>;
const clinicById = getBackendClinicById as unknown as ReturnType<typeof vi.fn>;

/** A product the clinic knows: the products call and the store's collection hand it back. */
function knownProducts(...items: Array<ReturnType<typeof product>>) {
  products.mockResolvedValue(items);
  (store as unknown as { __state: { clinicServicesProducts: { collection: unknown[] } } }).__state.clinicServicesProducts.collection = items;
}

/** A product of the clinic, as the products call and the store's collection hand it back. */
const product = (id: string, price: number, price_setting: Setting | null = null) => ({
  id,
  clinic_id: 'clinic-1',
  service_name: 'Product ' + id,
  price,
  price_setting,
  is_active: true,
  type: 'Product',
});

const mocked = {
  pendingItems: getBackendPendingInvoiceItems as unknown as ReturnType<typeof vi.fn>,
  getInvoice: getBackendInvoice as unknown as ReturnType<typeof vi.fn>,
  byAppointment: getBackendInvoiceByAppointmentId as unknown as ReturnType<typeof vi.fn>,
  createItems: createBackendInvoiceItems as unknown as ReturnType<typeof vi.fn>,
  update: updateBackendInvoice as unknown as ReturnType<typeof vi.fn>,
  updateAll: updateBackendInvoiceWithAllData as unknown as ReturnType<typeof vi.fn>,
  appointment: getBackendAppointmentById as unknown as ReturnType<typeof vi.fn>,
};

/** Every call that stored an invoice, through either update call, in the order made. */
function storeCalls(): Array<[string, { amount: number; invoice_items?: string[] }]> {
  return [...mocked.update.mock.calls, ...mocked.updateAll.mock.calls] as never;
}

function storedAmount(): number {
  const calls = storeCalls();
  expect(calls.length).toBeGreaterThan(0);
  return calls[calls.length - 1][1].amount;
}

function createdItems(): Array<Record<string, unknown>> {
  return mocked.createItems.mock.calls.flatMap((call) => call[1]);
}

describe('the whiteboard adding treatments to an invoice', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocked.appointment.mockResolvedValue({ id: 'apt-1', client_id: 'client-1', tenant_id: 'clinic-1' });
    mocked.getInvoice.mockImplementation(async () => invoice());
    mocked.byAppointment.mockImplementation(async () => invoice());
    mocked.createItems.mockImplementation(async (_id: string, items: Array<Record<string, unknown>>) =>
      items.map((one, index) => ({ ...one, id: 'item-' + index }))
    );
    mocked.update.mockImplementation(async (_id: string, data: unknown) => data);
    mocked.updateAll.mockImplementation(async (_id: string, data: unknown) => data);
    products.mockResolvedValue([]);
    clinicSettings.mockResolvedValue({ id: 'clinic-1' });
    clinicById.mockResolvedValue({ id: 'clinic-1' });
    http.clinic = { id: 'clinic-1' };
    (store as unknown as { __state: { clinicServicesProducts: { collection: unknown[] } } }).__state.clinicServicesProducts.collection = [];
  });

  it('stores what the lines come to, not the old amount plus the new', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 12.5 }), pending('b', { price: 3 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a', 'b'], 'inv-1');
    expect(storedAmount()).toBe(15.5);
  });

  it('puts the pending quantity on the line', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 12.5, quantity: 3 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(createdItems()[0].quantity).toBe(3);
  });

  it('charges the pending quantity', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 12.5, quantity: 3 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(37.5);
  });

  it('counts one of a thing when the pending item gives no quantity', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 12.5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(createdItems()[0].quantity).toBe(1);
    expect(storedAmount()).toBe(12.5);
  });

  it('counts the lines already on the invoice', async () => {
    mocked.getInvoice.mockImplementation(async () =>
      invoice({ added_invoice_items: [{ quantity: 2, item_price: 10, service_id: 'svc-old', id: 'item-old' }] })
    );
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(25);
  });

  it('never lets a stale amount leak into what it stores', async () => {
    mocked.getInvoice.mockImplementation(async () => invoice({ amount: 999, added_invoice_items: [] }));
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(5);
  });

  it('takes the product discount off the line', async () => {
    knownProducts(product('svc-a', 12.5, dollarsOff(1)));
    mocked.pendingItems.mockResolvedValue([
      pending('a', { price: 12.5, quantity: 3, service: { id: 'svc-a', service_name: 'Thing', price: 12.5, price_setting: dollarsOff(1) } }),
    ]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(34.5);
  });

  it('charges the dispensing fee once', async () => {
    knownProducts(product('svc-a', 10, setting({ dispensing_fee_amt: 4 })));
    mocked.pendingItems.mockResolvedValue([
      pending('a', { price: 10, quantity: 2, service: { id: 'svc-a', service_name: 'Thing', price: 10, price_setting: setting({ dispensing_fee_amt: 4 }) } }),
    ]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(24);
  });

  it('keeps a discount from going under the minimum price', async () => {
    knownProducts(product('svc-a', 10, dollarsOff(3, { min_price: 9 })));
    mocked.pendingItems.mockResolvedValue([
      pending('a', { price: 10, quantity: 2, service: { id: 'svc-a', service_name: 'Thing', price: 10, price_setting: dollarsOff(3, { min_price: 9 }) } }),
    ]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(18);
  });

  it('stores the total through a single added treatment too', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 10, quantity: 2 })]);
    await whiteboardInvoiceService.addTreatmentToInvoice('a', 'inv-1');
    expect(createdItems()[0].quantity).toBe(2);
    expect(storedAmount()).toBe(20);
  });

  it('counts existing lines when a single treatment is added', async () => {
    mocked.getInvoice.mockImplementation(async () =>
      invoice({ amount: 0, added_invoice_items: [{ quantity: 1, item_price: 7, service_id: 'svc-old', id: 'item-old' }] })
    );
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 10 })]);
    await whiteboardInvoiceService.addTreatmentToInvoice('a', 'inv-1');
    expect(storedAmount()).toBe(17);
  });

  it('stores the total when approved items are synced', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 10, quantity: 2 }), pending('b', { price: 2.5, status: 'pending' })]);
    await whiteboardInvoiceService.syncPendingItemsToInvoice('apt-1', 'inv-1');
    expect(storedAmount()).toBe(20);
  });

  it('gives each appointment its own total', async () => {
    const second = invoice({ id: 'inv-2', appointment_id: 'apt-2', amount: 500 });
    mocked.byAppointment.mockImplementation(async (id: string) => (id === 'apt-2' ? second : invoice()));
    mocked.getInvoice.mockImplementation(async (id: string) => (id === 'inv-2' ? second : invoice()));
    mocked.appointment.mockImplementation(async (id: string) => ({ id, client_id: 'client-1', tenant_id: 'clinic-1' }));
    mocked.pendingItems.mockResolvedValue([
      pending('a', { price: 10, quantity: 2 }),
      pending('b', { price: 4, appointment_id: 'apt-2', whiteboard_patients: { clinic_id: 'clinic-1', pet_id: 'pet-2', appointment_id: 'apt-2' } }),
    ]);
    await whiteboardInvoiceService.batchAddToInvoice(['a', 'b']);
    const stored = Object.fromEntries(storeCalls().map((call) => [call[0], call[1].amount]));
    expect(stored).toEqual({ 'inv-1': 20, 'inv-2': 4 });
  });

  it('counts the invoice treatments and prescriptions as lines too', async () => {
    mocked.getInvoice.mockImplementation(async () =>
      invoice({
        amount: 0,
        added_invoice_items: [],
        ordered_treatments: [{ id: 't1', dosage: 1, product_service: { id: 'p1', price: 30 } }],
        ordered_prescriptions: [{ id: 'r1', qty_dispensed: 2, product_service: { id: 'p2', price: 4 } }],
      })
    );
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(43);
  });

  it('charges an invoice treatment once whatever its dosage', async () => {
    mocked.getInvoice.mockImplementation(async () =>
      invoice({ amount: 0, ordered_treatments: [{ id: 't1', dosage: 5, product_service: { id: 'p1', price: 30 } }] })
    );
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(35);
  });

  it('prices a line already on the invoice with its product discount', async () => {
    knownProducts(product('svc-old', 10, dollarsOff(1)), product('svc-a', 5));
    mocked.getInvoice.mockImplementation(async () =>
      invoice({ amount: 0, added_invoice_items: [{ id: 'item-old', quantity: 2, item_price: 10, service_id: 'svc-old' }] })
    );
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(23);
  });

  it('prices a line already on the invoice with its product dispensing fee', async () => {
    knownProducts(product('svc-old', 10, setting({ dispensing_fee_amt: 4 })), product('svc-a', 5));
    mocked.getInvoice.mockImplementation(async () =>
      invoice({ amount: 0, added_invoice_items: [{ id: 'item-old', quantity: 2, item_price: 10, service_id: 'svc-old' }] })
    );
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.addTreatmentToInvoice('a', 'inv-1');
    expect(storedAmount()).toBe(29);
  });

  it('taxes a taxable line at the clinic rate', async () => {
    knownProducts(product('svc-a', 10, setting({ taxable: true })));
    clinicSettings.mockResolvedValue({ id: 'clinic-1', tax_rate: 10 });
    clinicById.mockResolvedValue({ id: 'clinic-1', tax_rate: 10 });
    http.clinic = { id: 'clinic-1', tax_rate: 10 };
    mocked.pendingItems.mockResolvedValue([
      pending('a', { price: 10, service: { id: 'svc-a', service_name: 'Thing', price: 10, price_setting: setting({ taxable: true }) } }),
    ]);
    await (whiteboardInvoiceService as unknown as { batchAddToInvoice: (ids: string[], invoiceId?: string, clinic?: unknown) => Promise<unknown> }).batchAddToInvoice(['a'], 'inv-1', { id: 'clinic-1', tax_rate: 10 });
    expect(storedAmount()).toBe(11);
  });

  it('leaves a line that is not taxable alone at the clinic rate', async () => {
    knownProducts(product('svc-a', 10, setting({ taxable: false })));
    clinicSettings.mockResolvedValue({ id: 'clinic-1', tax_rate: 10 });
    clinicById.mockResolvedValue({ id: 'clinic-1', tax_rate: 10 });
    http.clinic = { id: 'clinic-1', tax_rate: 10 };
    mocked.pendingItems.mockResolvedValue([
      pending('a', { price: 10, service: { id: 'svc-a', service_name: 'Thing', price: 10, price_setting: setting({ taxable: false }) } }),
    ]);
    await (whiteboardInvoiceService as unknown as { batchAddToInvoice: (ids: string[], invoiceId?: string, clinic?: unknown) => Promise<unknown> }).batchAddToInvoice(['a'], 'inv-1', { id: 'clinic-1', tax_rate: 10 });
    expect(storedAmount()).toBe(10);
  });

  it('prices the line it creates the way it stores it', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 12.5, quantity: 3 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    const [item] = createdItems();
    expect(item.item_price).toBe(12.5);
    expect(storedAmount()).toBe(37.5);
  });
});

// ---------------------------------------------------------------------------------------------
// The SOAP page: a prescription is so many of its product, a treatment is one of it.

function rx(id: string, qty: number | string, price: number | string, price_setting?: Setting) {
  return { id, qty_dispensed: qty, product_service: { id: 'p-' + id, price, price_setting } } as never;
}

function tx(id: string, dosage: number | string, price: number | string, price_setting?: Setting) {
  return { id, dosage, product_service: { id: 'p-' + id, price, price_setting } } as never;
}

function dispatched(): Array<{ type: string; args: { data: { amount: number } } }> {
  return (dispatch as unknown as ReturnType<typeof vi.fn>).mock.calls.map((call) => call[0]);
}

function hook(invoiceSelected: unknown = null) {
  return useSOAPInvoice({
    appointmentId: 'apt-1',
    clientId: 'client-1',
    user: { id: 'user-1', _uuid: 'user-1', role: 'veterinarian', clinic_id: 'clinic-1' } as never,
    invoiceSelected,
  });
}

describe('the SOAP page pricing an invoice', () => {
  beforeEach(() => vi.clearAllMocks());

  it('charges a treatment once whatever its dosage', async () => {
    await hook().autoGenerateInvoice(null, [tx('t1', 5, 10)], null, null);
    expect(dispatched()[0].args.data.amount).toBe(10);
  });

  it('charges a prescription by what was dispensed', async () => {
    await hook().autoGenerateInvoice([rx('r1', '3', '2.5')], null, null, null);
    expect(dispatched()[0].args.data.amount).toBe(7.5);
  });

  it('adds prescriptions and treatments together', async () => {
    await hook().autoGenerateInvoice([rx('r1', 3, 2.5)], [tx('t1', 5, 10)], null, null);
    expect(dispatched()[0].args.data.amount).toBe(17.5);
  });

  it('charges treatments in progress and completed once each too', async () => {
    await hook().autoGenerateInvoice(null, [tx('t1', 2, 10)], [tx('t2', 3, 20)], [tx('t3', 4, 30)]);
    expect(dispatched()[0].args.data.amount).toBe(60);
  });

  it('takes the product discount off a prescription', async () => {
    await hook().autoGenerateInvoice([rx('r1', 2, 10, percentOff(10))], null, null, null);
    expect(dispatched()[0].args.data.amount).toBe(18);
  });

  it('charges a dispensing fee once on a prescription', async () => {
    await hook().autoGenerateInvoice([rx('r1', 2, 10, setting({ dispensing_fee_amt: 3 }))], null, null, null);
    expect(dispatched()[0].args.data.amount).toBe(23);
  });

  it('keeps a prescription discount above the minimum price', async () => {
    await hook().autoGenerateInvoice([rx('r1', 2, 10, dollarsOff(3, { min_price: 9 }))], null, null, null);
    expect(dispatched()[0].args.data.amount).toBe(18);
  });

  it('stores the same figure when the invoice is saved by hand', async () => {
    await hook().handleSaveInvoice([rx('r1', 3, 2.5)], [tx('t1', 5, 10)]);
    expect(dispatched()[0].args.data.amount).toBe(17.5);
  });

  it('updates an existing invoice with what the lines come to', async () => {
    await hook({ data: { id: 'inv-1', amount: 999 } }).handleSaveInvoice([rx('r1', 2, 4)], [tx('t1', 7, 1)]);
    const sent = dispatched()[0];
    expect(sent.type).toBe('invoice/update');
    expect(sent.args.data.amount).toBe(9);
  });

  it('rounds a prescription line to the cent', async () => {
    await hook().handleSaveInvoice([rx('r1', 3, 1.111)], null);
    expect(dispatched()[0].args.data.amount).toBe(3.33);
  });

  it('counts the items already on the invoice when it is saved by hand', async () => {
    await hook({ data: { id: 'inv-1', amount: 999, added_invoice_items: [{ id: 'i1', quantity: 2, item_price: 10, service_id: 's1' }] } }).handleSaveInvoice([rx('r1', 3, 2.5)], null);
    expect(dispatched()[0].args.data.amount).toBe(27.5);
  });

  it('counts the items already on the invoice when it is generated', async () => {
    await hook({ data: { id: 'inv-1', amount: 999, added_invoice_items: [{ id: 'i1', quantity: 1, item_price: 4, service_id: 's1' }] } }).autoGenerateInvoice([rx('r1', 2, 10)], null, null, null);
    expect(dispatched()[0].args.data.amount).toBe(24);
  });

  it('never counts a treatment twice when the invoice already lists it', async () => {
    await hook({ data: { id: 'inv-1', amount: 999, ordered_treatments: [{ id: 't1', dosage: 1, product_service: { id: 'p-t1', price: 10 } }] } }).handleSaveInvoice(null, [tx('t1', 1, 10)]);
    expect(dispatched()[0].args.data.amount).toBe(10);
  });
});

// ---------------------------------------------------------------------------------------------
// The store path: the page's add button goes through the redux thunks, and what they store is the
// total of all the invoice's lines as well.

describe('the store path adding items to the selected invoice', () => {
  type State = { invoice: { selected: unknown }; clinicServicesProducts: { collection: unknown[] } };
  const state = () => (store as unknown as { __state: State }).__state;

  beforeEach(() => {
    vi.clearAllMocks();
    mocked.createItems.mockImplementation(async (_id: string, items: Array<Record<string, unknown>>) =>
      items.map((one, index) => ({ ...one, id: 'item-' + index }))
    );
    mocked.update.mockImplementation(async (_id: string, data: unknown) => data);
    mocked.updateAll.mockImplementation(async (_id: string, data: unknown) => data);
    products.mockResolvedValue([]);
    clinicSettings.mockResolvedValue({ id: 'clinic-1' });
    http.clinic = { id: 'clinic-1' };
    state().clinicServicesProducts.collection = [];
    // a dispatch that runs a thunk the way the store would, and hands a plain action back
    (dispatch as unknown as ReturnType<typeof vi.fn>).mockImplementation((action: unknown) =>
      typeof action === 'function'
        ? (action as (d: unknown, g: unknown, e: unknown) => unknown)(dispatch, () => state(), undefined)
        : action
    );
  });

  /** Every amount handed to any call that stores an invoice, through the clinic service or the backend module. */
  function storedAmounts(): number[] {
    const calls = [
      ...(clinicService.updateInvoiceWithAllData as unknown as ReturnType<typeof vi.fn>).mock.calls,
      ...(clinicService.updateInvoice as unknown as ReturnType<typeof vi.fn>).mock.calls,
      ...mocked.update.mock.calls,
      ...mocked.updateAll.mock.calls,
    ];
    return calls.flatMap((call) =>
      call.filter((arg: unknown) => arg && typeof arg === 'object' && 'amount' in (arg as object)).map((arg: unknown) => (arg as { amount: number }).amount)
    );
  }

  it('stores what all the lines come to, not the old amount plus the new', async () => {
    state().invoice.selected = {
      data: invoice({ amount: 999, invoice_items: [], added_invoice_items: [{ id: 'item-old', quantity: 1, item_price: 5, service_id: 'svc-old' }] }),
    };
    await AddInvoiceItem(
      [{ quantity: 2, item_price: 10, service_id: 'svc-new', created_by: 'user-1', clinic_id: 'clinic-1', invoice_id: 'inv-1', client_id: 'client-1', patient_id: 'none' }],
      { id: 'user-1', _uuid: 'user-1', role: 'veterinarian', clinic_id: 'clinic-1' } as never
    );
    const amounts = storedAmounts();
    expect(amounts.length).toBeGreaterThan(0);
    expect(amounts[amounts.length - 1]).toBe(25);
  });
});

// ---------------------------------------------------------------------------------------------
// The tables: a row's price is the line priced by the same rules, written by the money formatter.

describe('the tables showing invoice lines', () => {
  const user = { id: 'user-1', _uuid: 'user-1', role: 'veterinarian' } as never;

  async function presets() {
    return (await import('@/components/ui/TableHelpers')).tablePresets as Record<string, (...args: unknown[]) => { data: Array<Record<string, unknown>> }>;
  }

  it('shows a treatment as one of its product whatever the dosage', async () => {
    const rows = (await presets()).invoiceTxManagment([{ id: 't1', dosage: 5, product_service: { id: 'p1', price: 10, service_name: 'Exam' } }], user).data;
    expect(rows[0].price).toBe(formatCurrency(10));
  });

  it('shows a prescription as what was dispensed of its product', async () => {
    const rows = (await presets()).invoiceRxManagment([{ id: 'r1', qty_dispensed: 3, product_service: { id: 'p1', price: 2.5, service_name: 'Pills' } }], user).data;
    expect(rows[0].price).toBe(formatCurrency(7.5));
  });

  it('shows an invoice item as its quantity at its price', async () => {
    const rows = (await presets()).invoiceItems([{ id: 'i1', quantity: 2, item_price: 10.5, item_name: 'Thing', service_id: 's1' }], user).data;
    expect(rows[0].price).toBe(formatCurrency(21));
  });

  it('shows an invoice amount through the money formatter', async () => {
    const rows = (await presets()).invoicesManagement([{ id: 'inv-1', amount: 1234.5, treatments: [], prescriptions: [], status: 'Active' }], user).data;
    expect(rows[0].amount).toBe('$1,234.50');
  });

  it('shows a fraction of a product priced to the cent', async () => {
    const rows = (await presets()).invoiceItems([{ id: 'i1', quantity: 1.5, item_price: 10, item_name: 'Thing', service_id: 's1' }], user).data;
    expect(rows[0].price).toBe(formatCurrency(15));
  });
});
