/**
 * What an invoice comes to: one module prices the lines, and every path that stores an amount
 * stores what the lines come to.
 *
 * The pricing module is tested case by case against the rules of the request (quantity, dispensing
 * fee once per line, the product's discount with the minimum price as a floor, tax at the clinic's
 * rate on taxable lines, cents). The whiteboard service and the SOAP hook are tested with the
 * backend modules mocked, asserting only the amount they store and the quantity they put on a line.
 * Figures avoid half-cent ties. No message, field order or internal is pinned.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';

// Every export of the pricing module counts a call made from outside it, so a test can tell that a
// path went through the module, whichever of its functions the path happens to use.
vi.mock('@/features/invoices/pricing', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  const seen = ((globalThis as unknown as { __mvPricingCalls?: { count: number } }).__mvPricingCalls ??= { count: 0 });
  const watched = (value: unknown): unknown =>
    typeof value !== 'function'
      ? value
      : new Proxy(value as (...args: unknown[]) => unknown, {
          apply(target, self, args) {
            seen.count += 1;
            return Reflect.apply(target, self, args);
          },
          construct(target, args) {
            seen.count += 1;
            return Reflect.construct(target as never, args);
          },
          get(target, key) {
            const member = Reflect.get(target, key) as unknown;
            if (typeof member !== 'function' || key === 'constructor') return member;
            return (...args: unknown[]) => {
              seen.count += 1;
              return (member as (...inner: unknown[]) => unknown).apply(target, args);
            };
          },
        });
  // setPricingClinic is read by the tests when a design has one, so the name has to exist here
  return { setPricingClinic: undefined, ...Object.fromEntries(Object.entries(original).map(([name, value]) => [name, watched(value)])) };
});
vi.mock('@/services/api/httpClient', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  const quiet = { get: vi.fn(async () => null), post: vi.fn(async () => null), put: vi.fn(async () => null), patch: vi.fn(async () => null), delete: vi.fn(async () => null) };
  return { ...original, httpClient: { ...((original.httpClient as object) || {}), ...quiet } };
});
vi.mock('@/features/clinics/api/backendClinicService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original, getBackendClinic: vi.fn(async () => ({ id: 'clinic-1' })), getBackendClinicById: vi.fn(async () => ({ id: 'clinic-1' })), getBackendClinics: vi.fn(async () => [{ id: 'clinic-1' }]) };
});
vi.mock('@/features/clinics/api/backendClinicSettingsService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original, getBackendClinicSettings: vi.fn(async () => ({ id: 'clinic-1' })) };
});
vi.mock('@/features/clinics/api/backendClinicProductsServicesService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original, getBackendClinicServices: vi.fn(async () => Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values())), getBackendServiceNames: vi.fn(async () => []), getBackendReferenceServices: vi.fn(async () => []), getBackendClinicProducts: vi.fn(async () => Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values())) };
});
vi.mock('@/features/invoices/api/backendInvoiceService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  createBackendInvoice: vi.fn(),
  createBackendInvoiceItems: vi.fn(),
  getBackendInvoice: vi.fn(),
  getBackendInvoiceByAppointmentId: vi.fn(),
  updateBackendInvoice: vi.fn(),
  updateBackendInvoiceWithAllData: vi.fn(),
  getBackendInvoicesByClientId: vi.fn(),
  getBackendInvoicesByPetId: vi.fn(),
  getBackendInvoiceItem: vi.fn(),
  updateBackendInvoiceItem: vi.fn(),
 };
});
vi.mock('@/features/appointments/api/backendAppointmentService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  getBackendAppointmentById: vi.fn(),
 };
});
vi.mock('@/services/whiteboard/backendWhiteboardService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  getBackendPendingInvoiceItems: vi.fn(),
 };
});
vi.mock('@/features/clinics/api/clinicService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  clinicService: { ...((original.clinicService as Record<string, unknown>) || {}), getManyProductService: vi.fn(async () => Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values())), getClinic: vi.fn(async () => ({ id: 'clinic-1' })), updateInvoice: vi.fn() },
 };
});
vi.mock('@tanstack/react-query', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useQuery: vi.fn(() => ({ data: undefined, isLoading: false, isError: false })),
  useMutation: vi.fn(() => ({ mutate: vi.fn(), mutateAsync: vi.fn() })),
  useQueryClient: vi.fn(() => ({ invalidateQueries: vi.fn(), setQueryData: vi.fn() })),
 };
});
vi.mock('@/features/clinics/hooks/useBackendClinics', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useBackendClinic: vi.fn(() => ({ data: undefined, isLoading: false })),
  useBackendClinics: vi.fn(() => ({ data: [], isLoading: false })),
 };
});
vi.mock('react-redux', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useSelector: vi.fn(() => undefined),
  useDispatch: vi.fn(() => vi.fn()),
 };
});
vi.mock('@/features/clinics/hooks/useBackendClinicSettings', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useBackendClinicSettings: vi.fn(() => ({ clinicSettings: undefined, isLoading: false })),
 };
});
vi.mock('@/hooks/useClinicBranding', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useClinicBranding: vi.fn(() => ({ clinic: undefined, branding: undefined })),
 };
});
vi.mock('@/hooks/useNotification', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useNotification: () => ({ showNotification: vi.fn() }),
 };
});
vi.mock('@/store/store', () => {
  // A state in which every slice exists, holds nothing, and reads as empty.
  const empty = (): unknown =>
    new Proxy(
      {},
      {
        get: (_target, key) => {
          if (key === 'collection' || key === 'items' || key === 'list' || key === 'all') return [];
          if (key === 'data' || key === 'selected' || key === 'error') return null;
          if (key === 'loading' || key === 'isLoading') return false;
          if (typeof key === 'symbol' || key === 'then') return undefined;
          return empty();
        },
      }
    );
  const catalogueSlice = () => ({
    collection: Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values()),
    loading: false,
    error: null,
    selected: null,
  });
  const state = new Proxy(empty() as Record<string, unknown>, {
    get: (target, key) => (key === 'clinicServicesProducts' ? catalogueSlice() : target[key as string]),
  });
  return {
    dispatch: vi.fn(() => Promise.resolve({ payload: { id: 'inv-9' } })),
    useSelector: vi.fn((selector: (held: unknown) => unknown) => selector(state)),
    useDispatch: vi.fn(() => vi.fn()),
    useAppSelector: vi.fn((selector: (held: unknown) => unknown) => selector(state)),
    useAppDispatch: vi.fn(() => vi.fn()),
    getState: () => state,
    persistor: {},
    store: { getState: () => state, dispatch: vi.fn(), subscribe: vi.fn() },
  };
});
vi.mock('@/store/slices/invoice', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  invoiceSave: vi.fn((args: unknown) => ({ type: 'invoice/save', args })),
  invoiceUpdate: vi.fn((args: unknown) => ({ type: 'invoice/update', args })),
 };
});

import type { ServicesProductsPriceSetting } from '@/features/clinics/api/types';
import {
  createBackendInvoiceItems,
  getBackendInvoice,
  getBackendInvoiceByAppointmentId,
  getBackendInvoiceItem,
  updateBackendInvoice,
} from '@/features/invoices/api/backendInvoiceService';
import { invoiceTotals, priceLines } from '@/features/invoices/pricing';
import { getBackendAppointmentById } from '@/features/appointments/api/backendAppointmentService';
import { getBackendPendingInvoiceItems } from '@/services/whiteboard/backendWhiteboardService';
import { whiteboardInvoiceService } from '@/services/whiteboard/whiteboardInvoiceService';
import { useSOAPInvoice } from '@/components/appointments/soap/hooks/useSOAPInvoice';
import { dispatch } from '@/store/store';

// ---------------------------------------------------------------------------------------------
// The clinic's catalogue: every product a fixture mentions is also what the backend, the
// clinic service and the store hand back, for a design that looks settings up by service id.
type CatalogueProduct = { id: string; [key: string]: unknown };
const catalogue = ((globalThis as unknown as { __mvCatalogue?: Map<string, CatalogueProduct> }).__mvCatalogue ??=
  new Map<string, CatalogueProduct>());
function remember(product: unknown): void {
  if (product && typeof product === 'object' && typeof (product as CatalogueProduct).id === 'string') {
    catalogue.set((product as CatalogueProduct).id, product as CatalogueProduct);
  }
}
function rememberInvoiceProducts(invoice: Record<string, unknown>): void {
  for (const key of ['ordered_prescriptions', 'ordered_treatments', 'added_invoice_items']) {
    for (const row of (invoice[key] as Array<Record<string, unknown>> | undefined) || []) {
      remember(row?.product_service);
      remember(row?.service);
    }
  }
}
function products(): CatalogueProduct[] {
  return Array.from(catalogue.values());
}

type Setting = ServicesProductsPriceSetting;

function setting(overrides: Partial<Setting> = {}): Setting {
  return {
    selling_price: 0,
    min_price: 0,
    dispensing_fee_amt: 0,
    include_on_estimate_and_invoice_print: true,
    client_discount_eligible: true,
    hide_from_treatment_search: false,
    default_product_discount: false,
    taxable: false,
    discount: null,
    ...overrides,
  };
}

function percentOff(amount: number, more: Partial<Setting> = {}): Setting {
  return setting({ default_product_discount: true, discount: { type: '%', discount: amount, note: '' }, ...more });
}

function dollarsOff(amount: number, more: Partial<Setting> = {}): Setting {
  return setting({ default_product_discount: true, discount: { type: '$', discount: amount, note: '' }, ...more });
}

const line = (quantity: number, unit_price: number, price_setting?: Setting | null) => ({
  quantity,
  unit_price,
  price_setting,
});

// ---------------------------------------------------------------------------------------------
// The pricing module, line by line.

interface LineCase {
  name: string;
  input: ReturnType<typeof line>;
  clinic?: { tax_rate?: number | null } | null;
  expect: Partial<{ dispensing_fee: number; subtotal: number; discount: number; tax: number; total: number }>;
}

const LINE_CASES: LineCase[] = [
  { name: 'three of a thing at 12.50 is 37.50', input: line(3, 12.5), expect: { subtotal: 37.5, discount: 0, tax: 0, total: 37.5 } },
  { name: 'one of a thing with no setting has no fee, discount or tax', input: line(1, 9.99), expect: { dispensing_fee: 0, subtotal: 9.99, discount: 0, tax: 0, total: 9.99 } },
  { name: 'a dispensing fee is charged once per line, not per unit', input: line(2, 10, setting({ dispensing_fee_amt: 4 })), expect: { dispensing_fee: 4, subtotal: 24, total: 24 } },
  { name: 'a percent discount takes that share of the goods', input: line(2, 10, percentOff(10)), expect: { subtotal: 20, discount: 2, total: 18 } },
  { name: 'a percent discount leaves the dispensing fee alone', input: line(2, 10, percentOff(10, { dispensing_fee_amt: 5 })), expect: { subtotal: 25, discount: 2, total: 23 } },
  { name: 'a dollar discount comes off each unit', input: line(3, 10, dollarsOff(1.5)), expect: { subtotal: 30, discount: 4.5, total: 25.5 } },
  { name: 'a discount the product does not apply by default is not applied', input: line(3, 10, setting({ default_product_discount: false, discount: { type: '$', discount: 1.5, note: '' } })), expect: { discount: 0, total: 30 } },
  { name: 'a discount of nought takes nothing off', input: line(3, 10, dollarsOff(0)), expect: { discount: 0, total: 30 } },
  { name: 'a dollar discount never takes a unit below its minimum price', input: line(2, 10, dollarsOff(3, { min_price: 9 })), expect: { discount: 2, total: 18 } },
  { name: 'a percent discount never takes a unit below its minimum price', input: line(1, 10, percentOff(20, { min_price: 9.5 })), expect: { discount: 0.5, total: 9.5 } },
  { name: 'a unit already under its minimum price gets no discount', input: line(2, 8, dollarsOff(1, { min_price: 9 })), expect: { discount: 0, total: 16 } },
  { name: 'a minimum price of nought is no floor', input: line(1, 10, dollarsOff(4, { min_price: 0 })), expect: { discount: 4, total: 6 } },
  { name: 'a taxable line is taxed at the clinic rate', input: line(1, 100, setting({ taxable: true })), clinic: { tax_rate: 8 }, expect: { tax: 8, total: 108 } },
  { name: 'tax is worked out after the discount', input: line(1, 100, percentOff(10, { taxable: true })), clinic: { tax_rate: 7.5 }, expect: { discount: 10, tax: 6.75, total: 96.75 } },
  { name: 'tax is worked out on the dispensing fee too', input: line(1, 10, setting({ taxable: true, dispensing_fee_amt: 5 })), clinic: { tax_rate: 10 }, expect: { subtotal: 15, tax: 1.5, total: 16.5 } },
  { name: 'a line that is not taxable is not taxed', input: line(1, 100, setting({ taxable: false })), clinic: { tax_rate: 8 }, expect: { tax: 0, total: 100 } },
  { name: 'no clinic means no tax', input: line(1, 100, setting({ taxable: true })), expect: { tax: 0, total: 100 } },
  { name: 'a clinic without a rate means no tax', input: line(1, 100, setting({ taxable: true })), clinic: { tax_rate: null }, expect: { tax: 0, total: 100 } },
  { name: 'a rate with a fraction is a percent', input: line(1, 19.99, setting({ taxable: true })), clinic: { tax_rate: 8.25 }, expect: { tax: 1.65, total: 21.64 } },
  { name: 'a line is rounded to the cent', input: line(3, 1.111), expect: { subtotal: 3.33, total: 3.33 } },
  { name: 'a percent discount is rounded to the cent', input: line(1, 9.99, percentOff(15)), expect: { discount: 1.5, total: 8.49 } },
  { name: 'tax on a discounted fee line is rounded to the cent', input: line(2, 7.33, percentOff(5, { taxable: true, dispensing_fee_amt: 1.25 })), clinic: { tax_rate: 6 }, expect: { subtotal: 15.91, discount: 0.73, tax: 0.91, total: 16.09 } },
  { name: 'a setting of null is no setting', input: line(2, 5, null), expect: { dispensing_fee: 0, discount: 0, tax: 0, total: 10 } },
];

/** Let a hook that dispatches after a detached promise finish before the dispatch is read. */
/** Calls made into the pricing module from outside it. */
const pricingCalls = ((globalThis as unknown as { __mvPricingCalls?: { count: number } }).__mvPricingCalls ??= { count: 0 });

async function settle(): Promise<void> {
  for (let turn = 0; turn < 5; turn += 1) {
    await new Promise((resolve) => setTimeout(resolve, 5));
  }
}

describe('a priced line', () => {
  for (const held of LINE_CASES) {
    it(held.name, () => {
      const [priced] = priceLines([held.input], held.clinic);
      for (const [field, value] of Object.entries(held.expect)) {
        expect(priced[field as keyof typeof held.expect], field).toBe(value);
      }
    });
  }

  it('keeps the quantity and the unit price it was given', () => {
    const [priced] = priceLines([line(4, 2.5)]);
    expect(priced.quantity).toBe(4);
    expect(priced.unit_price).toBe(2.5);
  });

  it('prices every line of a list in order', () => {
    const priced = priceLines([line(1, 10), line(2, 5, setting({ dispensing_fee_amt: 1 })), line(3, 2)]);
    expect(priced.map((one) => one.total)).toEqual([10, 11, 6]);
  });

  it('prices no lines as no lines', () => {
    expect(priceLines([])).toEqual([]);
  });
});

// ---------------------------------------------------------------------------------------------
// The totals.

describe('the totals of an invoice', () => {
  const priced = priceLines(
    [line(2, 10, percentOff(10, { taxable: true })), line(1, 5.5, setting({ dispensing_fee_amt: 2 })), line(3, 1.111)],
    { tax_rate: 10 }
  );

  it('adds the subtotals of the lines', () => {
    expect(invoiceTotals(priced).subtotal).toBe(30.83);
  });

  it('adds the discounts of the lines', () => {
    expect(invoiceTotals(priced).discount).toBe(2);
  });

  it('adds the tax of the lines', () => {
    expect(invoiceTotals(priced).tax).toBe(1.8);
  });

  it('comes to subtotal less discount plus tax', () => {
    expect(invoiceTotals(priced).total).toBe(30.63);
  });

  it('is nought for no lines', () => {
    expect(invoiceTotals([])).toMatchObject({ subtotal: 0, discount: 0, tax: 0, total: 0, balance: 0 });
  });

  it('takes what was paid off the balance', () => {
    const totals = invoiceTotals(priceLines([line(1, 100)]), 60);
    expect(totals.paid).toBe(60);
    expect(totals.balance).toBe(40);
  });

  it('puts a refund back on the balance', () => {
    const totals = invoiceTotals(priceLines([line(1, 100)]), 60, 10);
    expect(totals.refunded).toBe(10);
    expect(totals.balance).toBe(50);
  });

  it('treats a missing payment as nought', () => {
    const totals = invoiceTotals(priceLines([line(1, 100)]), null, undefined);
    expect(totals.paid).toBe(0);
    expect(totals.refunded).toBe(0);
    expect(totals.balance).toBe(100);
  });

  it('is settled when paid in full', () => {
    expect(invoiceTotals(priceLines([line(2, 12.5)]), 25).balance).toBe(0);
  });

  it('rounds the balance to the cent', () => {
    expect(invoiceTotals(priceLines([line(3, 1.111)]), 1.11).balance).toBe(2.22);
  });

  it('sums rounded lines rather than rounding the sum', () => {
    const lines = priceLines([line(1, 1.004), line(1, 1.004), line(1, 1.004)]);
    expect(invoiceTotals(lines).subtotal).toBe(3);
  });
});

// ---------------------------------------------------------------------------------------------
// The whiteboard: what it puts on a line and what it stores.

type Pending = Record<string, unknown>;

function pending(id: string, overrides: Pending = {}): Pending {
  const built = {
    id,
    status: 'approved',
    service_id: 'svc-' + id,
    price: 10,
    appointment_id: 'apt-1',
    service: { id: 'svc-' + id, service_name: 'Thing ' + id, price: 10 },
    whiteboard_patients: { clinic_id: 'clinic-1', pet_id: 'pet-1', appointment_id: 'apt-1' },
    ...overrides,
  };
  remember((built as { service?: unknown }).service);
  return built;
}

function invoice(overrides: Record<string, unknown> = {}) {
  rememberInvoiceProducts(overrides);
  return {
    id: 'inv-1',
    amount: 999,
    status: 'Active',
    treatments: [],
    prescriptions: [],
    invoice_items: [],
    added_invoice_items: [],
    tenant_id: 'clinic-1',
    client_id: 'client-1',
    appointment_id: 'apt-1',
    issued_at: '',
    issued_by: '',
    ...overrides,
  };
}

const mocked = {
  pendingItems: getBackendPendingInvoiceItems as unknown as ReturnType<typeof vi.fn>,
  getInvoice: getBackendInvoice as unknown as ReturnType<typeof vi.fn>,
  byAppointment: getBackendInvoiceByAppointmentId as unknown as ReturnType<typeof vi.fn>,
  createItems: createBackendInvoiceItems as unknown as ReturnType<typeof vi.fn>,
  update: updateBackendInvoice as unknown as ReturnType<typeof vi.fn>,
  appointment: getBackendAppointmentById as unknown as ReturnType<typeof vi.fn>,
  item: getBackendInvoiceItem as unknown as ReturnType<typeof vi.fn>,
};

function storedAmount(): number {
  const calls = mocked.update.mock.calls;
  expect(calls.length).toBeGreaterThan(0);
  return calls[calls.length - 1][1].amount;
}

function createdItems(): Array<Record<string, unknown>> {
  return mocked.createItems.mock.calls.flatMap((call) => call[1]);
}

describe('the whiteboard adding treatments to an invoice', () => {
  beforeEach(() => {
    catalogue.clear();
    vi.clearAllMocks();
    mocked.appointment.mockResolvedValue({ id: 'apt-1', client_id: 'client-1', tenant_id: 'clinic-1' });
    mocked.getInvoice.mockImplementation(async () => invoice());
    mocked.byAppointment.mockImplementation(async () => invoice());
    mocked.createItems.mockImplementation(async (_id: string, items: Array<Record<string, unknown>>) =>
      items.map((one, index) => ({ ...one, id: 'item-' + index }))
    );
    mocked.update.mockImplementation(async (_id: string, data: unknown) => data);
  });

  it('stores what the lines come to, not the old amount plus the new', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 12.5 }), pending('b', { price: 3 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a', 'b'], 'inv-1');
    expect(storedAmount()).toBe(15.5);
  });

  it('puts the pending quantity on the line', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 12.5, quantity: 3 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(createdItems()[0].quantity).toBe(3);
  });

  it('charges the pending quantity', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 12.5, quantity: 3 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(37.5);
  });

  it('counts one of a thing when the pending item gives no quantity', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 12.5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(createdItems()[0].quantity).toBe(1);
    expect(storedAmount()).toBe(12.5);
  });

  it('counts the lines already on the invoice', async () => {
    mocked.getInvoice.mockImplementation(async () =>
      invoice({ added_invoice_items: [{ quantity: 2, item_price: 10, service_id: 'svc-old', id: 'item-old' }] })
    );
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(25);
  });

  it('never lets a stale amount leak into what it stores', async () => {
    mocked.getInvoice.mockImplementation(async () => invoice({ amount: 999, added_invoice_items: [] }));
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(5);
  });

  it('takes the product discount off the line', async () => {
    mocked.pendingItems.mockResolvedValue([
      pending('a', { price: 12.5, quantity: 3, service: { id: 'svc-a', service_name: 'Thing', price: 12.5, price_setting: dollarsOff(1) } }),
    ]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(34.5);
  });

  it('charges the dispensing fee once', async () => {
    mocked.pendingItems.mockResolvedValue([
      pending('a', { price: 10, quantity: 2, service: { id: 'svc-a', service_name: 'Thing', price: 10, price_setting: setting({ dispensing_fee_amt: 4 }) } }),
    ]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(24);
  });

  it('keeps a discount from going under the minimum price', async () => {
    mocked.pendingItems.mockResolvedValue([
      pending('a', { price: 10, quantity: 2, service: { id: 'svc-a', service_name: 'Thing', price: 10, price_setting: dollarsOff(3, { min_price: 9 }) } }),
    ]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(18);
  });

  it('stores the total through a single added treatment too', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 10, quantity: 2 })]);
    await whiteboardInvoiceService.addTreatmentToInvoice('a', 'inv-1');
    expect(createdItems()[0].quantity).toBe(2);
    expect(storedAmount()).toBe(20);
  });

  it('counts existing lines when a single treatment is added', async () => {
    mocked.getInvoice.mockImplementation(async () =>
      invoice({ amount: 0, added_invoice_items: [{ quantity: 1, item_price: 7, service_id: 'svc-old', id: 'item-old' }] })
    );
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 10 })]);
    await whiteboardInvoiceService.addTreatmentToInvoice('a', 'inv-1');
    expect(storedAmount()).toBe(17);
  });

  it('stores the total when approved items are synced', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 10, quantity: 2 }), pending('b', { price: 2.5, status: 'pending' })]);
    await whiteboardInvoiceService.syncPendingItemsToInvoice('apt-1', 'inv-1');
    expect(storedAmount()).toBe(20);
  });

  it('gives each appointment its own total', async () => {
    const second = invoice({ id: 'inv-2', appointment_id: 'apt-2', amount: 500 });
    mocked.byAppointment.mockImplementation(async (id: string) => (id === 'apt-2' ? second : invoice()));
    mocked.appointment.mockImplementation(async (id: string) => ({ id, client_id: 'client-1', tenant_id: 'clinic-1' }));
    mocked.pendingItems.mockResolvedValue([
      pending('a', { price: 10, quantity: 2 }),
      pending('b', { price: 4, appointment_id: 'apt-2', whiteboard_patients: { clinic_id: 'clinic-1', pet_id: 'pet-2', appointment_id: 'apt-2' } }),
    ]);
    await whiteboardInvoiceService.batchAddToInvoice(['a', 'b']);
    const stored = Object.fromEntries(mocked.update.mock.calls.map((call) => [call[0], call[1].amount]));
    expect(stored).toEqual({ 'inv-1': 20, 'inv-2': 4 });
  });

  it('counts the prescriptions the SOAP page put on the invoice', async () => {
    mocked.getInvoice.mockImplementation(async () =>
      invoice({ ordered_prescriptions: [{ id: 'r1', qty_dispensed: 2, product_service: { id: 'p1', price: 4 } }] })
    );
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(13);
  });

  it('counts the treatments the SOAP page put on the invoice, one each', async () => {
    mocked.getInvoice.mockImplementation(async () =>
      invoice({ ordered_treatments: [{ id: 't1', dosage: 5, product_service: { id: 'p2', price: 10 } }] })
    );
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(15);
  });

  it('counts items, prescriptions and treatments together', async () => {
    mocked.getInvoice.mockImplementation(async () =>
      invoice({
        added_invoice_items: [{ id: 'item-old', quantity: 2, item_price: 10, service_id: 'svc-old' }],
        ordered_prescriptions: [{ id: 'r1', qty_dispensed: 2, product_service: { id: 'p1', price: 4 } }],
        ordered_treatments: [{ id: 't1', dosage: 5, product_service: { id: 'p2', price: 10 } }],
      })
    );
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(43);
  });

  it('prices a prescription on the invoice with its product setting', async () => {
    mocked.getInvoice.mockImplementation(async () =>
      invoice({ ordered_prescriptions: [{ id: 'r1', qty_dispensed: 2, product_service: { id: 'p1', price: 10, price_setting: percentOff(10) } }] })
    );
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(23);
  });

  it('reads the items it only knows by id', async () => {
    mocked.getInvoice.mockImplementation(async () =>
      invoice({ invoice_items: ['item-x', 'item-y'], added_invoice_items: undefined })
    );
    mocked.item.mockImplementation(async (id: string) =>
      id === 'item-x'
        ? { id, quantity: 2, item_price: 10, service_id: 'svc-x' }
        : { id, quantity: 1, item_price: 3, service_id: 'svc-y' }
    );
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(storedAmount()).toBe(28);
  });

  it('reads the items it only knows by id when a single treatment is added', async () => {
    mocked.getInvoice.mockImplementation(async () =>
      invoice({ invoice_items: ['item-x'], added_invoice_items: undefined })
    );
    mocked.item.mockResolvedValue({ id: 'item-x', quantity: 3, item_price: 2, service_id: 'svc-x' });
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    await whiteboardInvoiceService.addTreatmentToInvoice('a', 'inv-1');
    expect(storedAmount()).toBe(11);
  });

  it('works the amount out through the pricing module', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    pricingCalls.count = 0;
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    expect(pricingCalls.count).toBeGreaterThan(0);
  });

  it('works the amount out through the pricing module when a single treatment is added', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 5 })]);
    pricingCalls.count = 0;
    await whiteboardInvoiceService.addTreatmentToInvoice('a', 'inv-1');
    expect(pricingCalls.count).toBeGreaterThan(0);
  });

  it('prices the line it creates the way it stores it', async () => {
    mocked.pendingItems.mockResolvedValue([pending('a', { price: 12.5, quantity: 3 })]);
    await whiteboardInvoiceService.batchAddToInvoice(['a'], 'inv-1');
    const [item] = createdItems();
    expect(item.item_price).toBe(12.5);
    expect(storedAmount()).toBe(37.5);
  });
});

// ---------------------------------------------------------------------------------------------
// The SOAP page: a prescription is so many of its product, a treatment is one of it.

function rx(id: string, qty: number | string, price: number | string, price_setting?: Setting) {
  remember({ id: 'p-' + id, price, price_setting });
  return { id, qty_dispensed: qty, product_service: { id: 'p-' + id, price, price_setting } } as never;
}

function tx(id: string, dosage: number | string, price: number | string, price_setting?: Setting) {
  remember({ id: 'p-' + id, price, price_setting });
  return { id, dosage, product_service: { id: 'p-' + id, price, price_setting } } as never;
}

/** Calls a hook inside a server render, so whatever React hooks it uses inside work. */
function callHook<T>(run: () => T): T {
  let out!: T;
  renderToStaticMarkup(createElement(() => { out = run(); return null; }));
  return out;
}

function dispatched(): Array<{ type: string; args: { data: { amount: number } } }> {
  return (dispatch as unknown as ReturnType<typeof vi.fn>).mock.calls.map((call) => call[0]);
}

function hook(invoiceSelected: unknown = null) {
  vi.mocked(getBackendInvoice).mockImplementation(async () => (invoiceSelected as { data?: unknown } | null)?.data ?? null);
  return callHook(() =>
    useSOAPInvoice({
    appointmentId: 'apt-1',
    clientId: 'client-1',
    user: { id: 'user-1', _uuid: 'user-1', role: 'veterinarian' } as never,
    invoiceSelected,
  })
  );
}

describe('the SOAP page pricing an invoice', () => {
  beforeEach(() => {
    catalogue.clear();
    vi.clearAllMocks();
  });

  it('charges a treatment once whatever its dosage', async () => {
    await hook().autoGenerateInvoice(null, [tx('t1', 5, 10)], null, null);
    await settle();
    expect(dispatched()[0].args.data.amount).toBe(10);
  });

  it('charges a prescription by what was dispensed', async () => {
    await hook().autoGenerateInvoice([rx('r1', '3', '2.5')], null, null, null);
    await settle();
    expect(dispatched()[0].args.data.amount).toBe(7.5);
  });

  it('adds prescriptions and treatments together', async () => {
    await hook().autoGenerateInvoice([rx('r1', 3, 2.5)], [tx('t1', 5, 10)], null, null);
    await settle();
    expect(dispatched()[0].args.data.amount).toBe(17.5);
  });

  it('charges treatments in progress and completed once each too', async () => {
    await hook().autoGenerateInvoice(null, [tx('t1', 2, 10)], [tx('t2', 3, 20)], [tx('t3', 4, 30)]);
    await settle();
    expect(dispatched()[0].args.data.amount).toBe(60);
  });

  it('takes the product discount off a prescription', async () => {
    await hook().autoGenerateInvoice([rx('r1', 2, 10, percentOff(10))], null, null, null);
    await settle();
    expect(dispatched()[0].args.data.amount).toBe(18);
  });

  it('charges a dispensing fee once on a prescription', async () => {
    await hook().autoGenerateInvoice([rx('r1', 2, 10, setting({ dispensing_fee_amt: 3 }))], null, null, null);
    await settle();
    expect(dispatched()[0].args.data.amount).toBe(23);
  });

  it('keeps a prescription discount above the minimum price', async () => {
    await hook().autoGenerateInvoice([rx('r1', 2, 10, dollarsOff(3, { min_price: 9 }))], null, null, null);
    await settle();
    expect(dispatched()[0].args.data.amount).toBe(18);
  });

  it('stores the same figure when the invoice is saved by hand', async () => {
    await hook().handleSaveInvoice([rx('r1', 3, 2.5)], [tx('t1', 5, 10)]);
    await settle();
    expect(dispatched()[0].args.data.amount).toBe(17.5);
  });

  it('updates an existing invoice with what the lines come to', async () => {
    await hook({ data: { id: 'inv-1', amount: 999 } }).handleSaveInvoice([rx('r1', 2, 4)], [tx('t1', 7, 1)]);
    await settle();
    const sent = dispatched()[0];
    expect(sent.type).toBe('invoice/update');
    expect(sent.args.data.amount).toBe(9);
  });

  it('counts the items already on the invoice it updates', async () => {
    const held = { data: { id: 'inv-1', amount: 999, invoice_items: ['i1'], added_invoice_items: [{ id: 'i1', quantity: 2, item_price: 10, service_id: 's' }] } };
    await hook(held).handleSaveInvoice([rx('r1', 1, 4)], null);
    await settle();
    expect(dispatched()[0].args.data.amount).toBe(24);
  });

  it('counts the items already on the invoice when it auto-generates', async () => {
    const held = { data: { id: 'inv-1', amount: 999, invoice_items: ['i1'], added_invoice_items: [{ id: 'i1', quantity: 1, item_price: 7, service_id: 's' }] } };
    await hook(held).autoGenerateInvoice([rx('r1', 2, 4)], [tx('t1', 9, 10)], null, null);
    await settle();
    expect(dispatched()[0].args.data.amount).toBe(25);
  });

  it('reads the items it only knows by id', async () => {
    mocked.item.mockImplementation(async (id: string) => ({ id, quantity: 2, item_price: 10, service_id: 's' }));
    const held = { data: { id: 'inv-1', amount: 999, invoice_items: ['i1'] } };
    await hook(held).handleSaveInvoice([rx('r1', 1, 4)], null);
    await settle();
    expect(dispatched()[0].args.data.amount).toBe(24);
  });

  it('works the amount out through the pricing module', async () => {
    pricingCalls.count = 0;
    await hook().handleSaveInvoice([rx('r1', 3, 4)], null);
    await settle();
    expect(pricingCalls.count).toBeGreaterThan(0);
  });

  it('rounds a prescription line to the cent', async () => {
    await hook().handleSaveInvoice([rx('r1', 3, 1.111)], null);
    await settle();
    expect(dispatched()[0].args.data.amount).toBe(3.33);
  });
});
