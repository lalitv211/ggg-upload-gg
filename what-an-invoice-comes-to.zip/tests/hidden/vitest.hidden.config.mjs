// The grader's own vitest configuration: the repository's settings (node environment, the "@"
// alias, the Supabase defines) with nothing to import, so vite can load it from wherever it is
// copied, outside the locked node_modules.
import path from 'path';

export default {
  define: {
    'import.meta.env.VITE_SUPABASE_URL': JSON.stringify('http://127.0.0.1:54321'),
    'import.meta.env.VITE_SUPABASE_ANON_KEY': JSON.stringify('test-anon-key'),
  },
  test: {
    environment: 'node',
    include: ['src/**/*.{test,spec}.ts'],
    reporters: ['default'],
    fileParallelism: false,
  },
  resolve: {
    alias: {
      '@': path.resolve(process.cwd(), 'src'),
    },
  },
};
