/**
 * The two amount paths the first file leaves out: the invoice table's add (the Redux path through
 * AddInvoiceItem and the invoice slice) and the invoice summary (the right rail, rendered to
 * markup on the server, no DOM). Each stores or shows what the lines come to, never the stale
 * stored amount, whatever shape the invoice comes back in. Nothing about the designs is pinned:
 * the tests only read the amount handed to whichever update call the path makes, or the figures
 * in the rendered markup.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';

// Every export of the pricing module counts a call made from outside it, so a test can tell that a
// path went through the module, whichever of its functions the path happens to use.
vi.mock('@/features/invoices/pricing', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  const seen = ((globalThis as unknown as { __mvPricingCalls?: { count: number } }).__mvPricingCalls ??= { count: 0 });
  const watched = (value: unknown): unknown =>
    typeof value !== 'function'
      ? value
      : new Proxy(value as (...args: unknown[]) => unknown, {
          apply(target, self, args) {
            seen.count += 1;
            return Reflect.apply(target, self, args);
          },
          construct(target, args) {
            seen.count += 1;
            return Reflect.construct(target as never, args);
          },
          get(target, key) {
            const member = Reflect.get(target, key) as unknown;
            if (typeof member !== 'function' || key === 'constructor') return member;
            return (...args: unknown[]) => {
              seen.count += 1;
              return (member as (...inner: unknown[]) => unknown).apply(target, args);
            };
          },
        });
  // setPricingClinic is read by the tests when a design has one, so the name has to exist here
  return { setPricingClinic: undefined, ...Object.fromEntries(Object.entries(original).map(([name, value]) => [name, watched(value)])) };
});
// The real formatter, watched, so a test can tell a screen used it rather than a copy of it.
vi.mock('@/services/stripe/paymentService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original, formatCurrency: vi.fn(original.formatCurrency as (amount: number) => string) };
});
vi.mock('react-router-dom', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original, useNavigate: () => vi.fn() };
});
// The whiteboard's pending items come from the backend service; the panel's user from useAuth.
vi.mock('@/services/whiteboard/backendWhiteboardService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return {
    ...original,
    getBackendPendingInvoiceItems: vi.fn(original.getBackendPendingInvoiceItems as (...args: unknown[]) => unknown),
  };
});
vi.mock('@/hooks/useAuth', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  const user = { id: 'user-1', _uuid: 'user-1', clinic_id: 'clinic-1', role: 'veterinarian' };
  return {
    ...original,
    useAuth: () => ({ user, isAuthenticated: true, isAdmin: false, loading: false, signOut: async () => ({ error: null }) }),
  };
});
vi.mock('@/features/invoices/api/backendInvoiceService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  createBackendInvoice: vi.fn(),
  createBackendInvoiceItems: vi.fn(),
  getBackendInvoice: vi.fn(),
  getBackendInvoiceByAppointmentId: vi.fn(),
  updateBackendInvoice: vi.fn(async (_id: string, data: unknown) => data),
  updateBackendInvoiceWithAllData: vi.fn(async (_id: string, data: unknown) => data),
  getBackendInvoicesByClientId: vi.fn(),
  getBackendInvoicesByPetId: vi.fn(),
  getBackendInvoiceItem: vi.fn(),
  updateBackendInvoiceItem: vi.fn(),
 };
});
vi.mock('@/features/clinics/api/clinicService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  clinicService: { ...((original.clinicService as Record<string, unknown>) || {}), getManyProductService: vi.fn(async () => Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values())),
    getClinic: vi.fn(async () => ({ id: 'clinic-1', tax_rate: 10 })),
    createInvoiceItems: vi.fn(),
    updateInvoiceWithAllData: vi.fn(async (data: unknown) => data),
    updateInvoice: vi.fn(async (data: unknown) => data),
    getInvoice: vi.fn(),
  },
 };
});
vi.mock('@tanstack/react-query', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  // A query runs its function once per key and hands the result to the next render, the way
  // the real one re-renders when the data lands.
  const settled = ((globalThis as unknown as { __mvSettled?: Map<string, unknown> }).__mvSettled ??= new Map<string, unknown>());
  const pending = ((globalThis as unknown as { __mvPending?: Map<string, Promise<unknown>> }).__mvPending ??= new Map<string, Promise<unknown>>());
  const useQuery = vi.fn((options: { queryKey?: unknown; queryFn?: () => unknown; enabled?: boolean }) => {
    const key = JSON.stringify(options.queryKey ?? []);
    if (options.enabled === false || !options.queryFn) return { data: undefined, isLoading: false, isError: false };
    if (settled.has(key)) return { data: settled.get(key), isLoading: false, isError: false };
    if (!pending.has(key)) {
      pending.set(
        key,
        Promise.resolve()
          .then(() => options.queryFn!())
          .then((value) => settled.set(key, value))
      );
    }
    return { data: undefined, isLoading: true, isError: false };
  });
  return {
    ...original,
    useQuery,
    useMutation: vi.fn(() => ({ mutate: vi.fn(), mutateAsync: vi.fn() })),
    useQueryClient: vi.fn(() => ({ invalidateQueries: vi.fn(), setQueryData: vi.fn() })),
  };
});
vi.mock('@/features/clinics/hooks/useBackendClinics', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useBackendClinic: vi.fn(() => ({ data: { id: 'clinic-1', tax_rate: 10 }, isLoading: false })),
  useBackendClinics: vi.fn(() => ({ data: [{ id: 'clinic-1', tax_rate: 10 }], isLoading: false })),
 };
});
vi.mock('react-redux', async (importOriginal) => {
  // The same state the store mock holds, whichever module a component reads it through
  const store = await import('@/store/store');
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original, useSelector: store.useSelector, useDispatch: store.useDispatch };
});
vi.mock('@/features/clinics/hooks/useBackendClinicSettings', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useBackendClinicSettings: vi.fn(() => ({
    clinicSettings: { id: 'clinic-1', tax_rate: 10 },
    data: { id: 'clinic-1', tax_rate: 10 },
    isLoading: false,
  })),
 };
});
vi.mock('@/hooks/useClinicBranding', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useClinicBranding: vi.fn(() => ({ clinic: { id: 'clinic-1', tax_rate: 10 }, branding: undefined })),
 };
});
vi.mock('@/hooks/useNotification', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  useNotification: () => ({ showNotification: vi.fn() }),
 };
});
vi.mock('@/services/api/httpClient', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  const quiet = { get: vi.fn(async () => null), post: vi.fn(async () => null), put: vi.fn(async () => null), patch: vi.fn(async () => null), delete: vi.fn(async () => null) };
  return { ...original, httpClient: { ...((original.httpClient as object) || {}), ...quiet } };
});
vi.mock('@/features/clinics/api/backendClinicService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original, getBackendClinic: vi.fn(async () => ({ id: 'clinic-1', tax_rate: 10 })), getBackendClinicById: vi.fn(async () => ({ id: 'clinic-1', tax_rate: 10 })), getBackendClinics: vi.fn(async () => [{ id: 'clinic-1' }]) };
});
vi.mock('@/components/billing/PaymentQRModal', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  PaymentQRModal: () => null,
 };
});
vi.mock('@/features/clinics/api/backendClinicSettingsService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  getBackendClinicSettings: vi.fn(async () => ({ id: 'clinic-1', tax_rate: 10 })),
  updateBackendClinicSettings: vi.fn(),
 };
});
vi.mock('@/features/clinics/api/backendClinicProductsServicesService', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
  getBackendClinicServices: vi.fn(async () => Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values())), getBackendServiceNames: vi.fn(async () => []), getBackendReferenceServices: vi.fn(async () => []),
  getBackendClinicProducts: vi.fn(async () => Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values())),
  getBackendClinicServicesProducts: vi.fn(async () => Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values())),
 };
});
vi.mock('@/store/store', () => {
  // A store whose state the tests fill: any slice not set reads as empty, and a thunk given to
  // dispatch runs against that state, the way the real store runs it.
  const held: Record<string, unknown> = {};
  const empty = (): unknown =>
    new Proxy(
      {},
      {
        get: (_target, key) => {
          if (key === 'collection' || key === 'items' || key === 'list' || key === 'all') return [];
          if (key === 'data' || key === 'selected' || key === 'error') return null;
          if (key === 'loading' || key === 'isLoading') return false;
          if (typeof key === 'symbol' || key === 'then') return undefined;
          return empty();
        },
      }
    );
  const catalogueSlice = () => ({
    collection: Array.from(((globalThis as unknown as { __mvCatalogue?: Map<string, unknown> }).__mvCatalogue ?? new Map()).values()),
    loading: false,
    error: null,
    selected: null,
  });
  const getState = () =>
    new Proxy(held, {
      get: (target, key) =>
        key in target ? target[key as string] : key === 'clinicServicesProducts' ? catalogueSlice() : empty(),
    });
  const dispatch = vi.fn((action: unknown) =>
    typeof action === 'function'
      ? (action as (d: unknown, g: unknown, e: unknown) => unknown)(dispatch, getState, undefined)
      : action
  );
  const useSelector = vi.fn((selector: (state: unknown) => unknown) => selector(getState()));
  return {
    dispatch,
    getState,
    store: { getState, dispatch },
    persistor: {},
    useSelector,
    useDispatch: vi.fn(() => dispatch),
    useAppSelector: useSelector,
    useAppDispatch: vi.fn(() => dispatch),
    __held: held,
  };
});

import type { Invoice, InvoiceItem } from '@/features/clinics/api/types';
import type { User } from '@/types/common';
import {
  getBackendInvoice,
  getBackendInvoiceItem,
  getBackendInvoicesByPetId,
  updateBackendInvoice,
  updateBackendInvoiceWithAllData,
} from '@/features/invoices/api/backendInvoiceService';
import { clinicService } from '@/features/clinics/api/clinicService';
import * as pricing from '@/features/invoices/pricing';
import type { ServicesProductsPriceSetting } from '@/features/clinics/api/types';
import { tablePresets } from '@/components/ui/TableHelpers';
import { AddInvoiceItem } from '@/components/ui/TableFunctions/InvoiceItems';
import PatientInvoicesModule from '@/features/invoices/components/PatientInvoicesModule';
import { PendingInvoiceItemsPanel } from '@/components/whiteboard/PendingInvoiceItemsPanel';
import { getBackendPendingInvoiceItems } from '@/services/whiteboard/backendWhiteboardService';
import InvoiceRightRail from '@/pages/billing/InvoiceRightRail';
import { invoiceInsertItems } from '@/store/slices/invoice';
import { formatCurrency } from '@/services/stripe/paymentService';
import * as storeModule from '@/store/store';

const { invoiceTotals, priceLines } = pricing;
/** Calls made into the pricing module from outside it. */
const pricingCalls = ((globalThis as unknown as { __mvPricingCalls?: { count: number } }).__mvPricingCalls ??= { count: 0 });
/** The clinic whose rate applies, handed to the rail as a prop too, and registered if the module keeps one. */
const clinic = { id: 'clinic-1', tax_rate: 10 };
(pricing as unknown as { setPricingClinic?: (c: unknown) => void }).setPricingClinic?.(clinic);

// ---------------------------------------------------------------------------------------------
// The clinic's catalogue: every product a fixture mentions is also what the backend, the
// clinic service and the store hand back, for a design that looks settings up by service id.
type CatalogueProduct = { id: string; [key: string]: unknown };
const catalogue = ((globalThis as unknown as { __mvCatalogue?: Map<string, CatalogueProduct> }).__mvCatalogue ??=
  new Map<string, CatalogueProduct>());
function remember(product: unknown): void {
  if (product && typeof product === 'object' && typeof (product as CatalogueProduct).id === 'string') {
    catalogue.set((product as CatalogueProduct).id, product as CatalogueProduct);
  }
}
function rememberInvoiceProducts(invoice: Record<string, unknown>): void {
  for (const key of ['ordered_prescriptions', 'ordered_treatments', 'added_invoice_items']) {
    for (const row of (invoice[key] as Array<Record<string, unknown>> | undefined) || []) {
      remember(row?.product_service);
      remember(row?.service);
    }
  }
}
function products(): CatalogueProduct[] {
  return Array.from(catalogue.values());
}

/** The rail's props: the invoice, the clinic under the names a design may give it, the catalogue too. */
function railProps(invoice: Invoice): Record<string, unknown> {
  const pricing = { clinic, products: products(), services: products() };
  return { invoice, clinic, pricing, clinicSettings: clinic, products: products(), services: products(), servicesProducts: products() };
}

const held = (storeModule as unknown as { __held: Record<string, unknown> }).__held;
const user = { _uuid: 'user-1', clinic_id: 'clinic-1' } as unknown as User;

type Setting = ServicesProductsPriceSetting;

function setting(overrides: Partial<Setting> = {}): Setting {
  return {
    selling_price: 0,
    min_price: 0,
    dispensing_fee_amt: 0,
    include_on_estimate_and_invoice_print: true,
    client_discount_eligible: true,
    hide_from_treatment_search: false,
    default_product_discount: false,
    taxable: false,
    discount: null,
    ...overrides,
  };
}

/** The clinic's product a line is of, with its price setting. */
function service(id: string, price: number, price_setting: Setting) {
  const product = { id: 'svc-' + id, service_name: 'Thing ' + id, price, price_setting };
  remember(product);
  return product;
}

/** An invoice item; with a setting, it carries it as the backend joins it (on the item, on its service). */
function item(id: string, quantity: number, item_price: number, price_setting?: Setting): InvoiceItem {
  const product = price_setting
    ? { price_setting, service: service(id, item_price, price_setting) }
    : { service: service(id, item_price, setting()) };
  return {
    id,
    quantity,
    item_price,
    service_id: 'svc-' + id,
    item_name: 'Thing ' + id,
    invoice_id: 'inv-1',
    client_id: 'client-1',
    clinic_id: 'clinic-1',
    created_by: 'user-1',
    patient_id: 'pet-1',
    ...product,
  } as unknown as InvoiceItem;
}

function invoice(overrides: Record<string, unknown> = {}): Invoice {
  return {
    id: 'inv-1',
    amount: 999,
    status: 'Active',
    treatments: [],
    prescriptions: [],
    invoice_items: ['old'],
    added_invoice_items: [item('old', 2, 5)],
    tenant_id: 'clinic-1',
    client_id: 'client-1',
    appointment_id: 'apt-1',
    issued_at: '',
    issued_by: '',
    ...overrides,
  } as unknown as Invoice;
}

/** What the module says lines come to, untaxed, with a payment and a refund. */
function totalsOf(lines: Array<[number, number, Setting?]>, paid = 0, refunded = 0) {
  return invoiceTotals(
    priceLines(
      lines.map(([quantity, unit_price, price_setting]) => ({ quantity, unit_price, price_setting: price_setting ?? null })),
      clinic
    ),
    paid,
    refunded
  );
}

/** Let a path that dispatches after a detached promise finish before its calls are read. */
async function settle(): Promise<void> {
  for (let turn = 0; turn < 8; turn += 1) {
    await new Promise((resolve) => setTimeout(resolve, 5));
  }
}

/** The last amount any invoice update call carried, whichever service the path went through. */
function storedAmount(): number | undefined {
  const calls = [
    ...vi.mocked(clinicService.updateInvoiceWithAllData).mock.calls,
    ...vi.mocked(clinicService.updateInvoice).mock.calls,
    ...vi.mocked(updateBackendInvoiceWithAllData).mock.calls,
    ...vi.mocked(updateBackendInvoice).mock.calls,
  ];
  let found: number | undefined;
  for (const call of calls) {
    for (const arg of call as unknown[]) {
      const amount = (arg as { amount?: unknown } | null)?.amount;
      if (typeof amount === 'number') found = amount;
    }
  }
  return found;
}

/** The last list of invoice items any invoice update call carried. */
function storedItems(): unknown {
  const calls = [
    ...vi.mocked(clinicService.updateInvoiceWithAllData).mock.calls,
    ...vi.mocked(clinicService.updateInvoice).mock.calls,
    ...vi.mocked(updateBackendInvoiceWithAllData).mock.calls,
    ...vi.mocked(updateBackendInvoice).mock.calls,
  ];
  let found: unknown;
  for (const call of calls) {
    for (const arg of call as unknown[]) {
      const items = (arg as { invoice_items?: unknown } | null)?.invoice_items;
      if (Array.isArray(items)) found = items;
    }
  }
  return found;
}

// ---------------------------------------------------------------------------------------------
// The invoice table's add: the Redux path.

describe('the invoice table adding items through the store', () => {
  beforeEach(() => {
    catalogue.clear();
    vi.clearAllMocks();
    held.invoice = { selected: { data: invoice() }, collection: [], loading: false, error: null };
    // What was created reads back by id, for a path that reads the new items again
    const made = new Map<string, InvoiceItem>();
    vi.mocked(clinicService.createInvoiceItems).mockImplementation(async (items: InvoiceItem[]) =>
      items.map((one, index) => {
        const saved = { ...one, id: 'new-' + index };
        made.set(saved.id, saved);
        return saved;
      })
    );
    vi.mocked(getBackendInvoiceItem).mockImplementation(
      async (id: string) => made.get(id) ?? (id === 'old' ? item('old', 2, 5) : item(id, 1, 1))
    );
    vi.mocked(getBackendInvoice).mockImplementation(
      async () => (held.invoice as { selected?: { data?: unknown } } | undefined)?.selected?.data ?? null
    );
  });

  it('stores what all the lines come to, not the old amount with the new figure added', async () => {
    await AddInvoiceItem([item('n', 3, 10)], user);
    await settle();
    expect(storedAmount()).toBe(totalsOf([[2, 5], [3, 10]]).total);
  });

  it('counts the quantity of the line it adds', async () => {
    held.invoice = {
      selected: { data: invoice({ invoice_items: [], added_invoice_items: [] }) },
      collection: [],
      loading: false,
      error: null,
    };
    await AddInvoiceItem([item('n', 4, 2.5)], user);
    await settle();
    expect(storedAmount()).toBe(totalsOf([[4, 2.5]]).total);
  });

  it('still takes the ids of the new items with the figure they add', async () => {
    vi.mocked(getBackendInvoiceItem).mockImplementation(async (id: string) =>
      id === 'n1' ? item('n1', 3, 10) : item('old', 2, 5)
    );
    await storeModule.dispatch(invoiceInsertItems({ invoiceItemsId: ['n1'], totalAmountAdded: 30, user }) as never);
    await settle();
    expect(storedAmount()).toBe(totalsOf([[2, 5], [3, 10]]).total);
    expect(storedItems()).toEqual(['old', 'n1']);
  });

  it('works the amount out through the pricing module', async () => {
    pricingCalls.count = 0;
    await AddInvoiceItem([item('n', 3, 10)], user);
    await settle();
    expect(pricingCalls.count).toBeGreaterThan(0);
  });
});

// ---------------------------------------------------------------------------------------------
// The invoice summary: the right rail rendered to markup.

describe('the invoice summary', () => {
  const lines: Array<[number, number]> = [[2, 5], [1, 1234.5]];
  const summary = invoice({
    amount: 999,
    amount_paid: 10,
    amount_refunded: 4,
    invoice_items: ['a', 'b'],
    added_invoice_items: [item('a', 2, 5), item('b', 1, 1234.5)],
  });
  beforeEach(() => {
    catalogue.clear();
    vi.mocked(getBackendInvoiceItem).mockImplementation(async (id: string) =>
      id === 'a' ? item('a', 2, 5) : item('b', 1, 1234.5)
    );
    vi.mocked(getBackendInvoice).mockImplementation(async () => summary);
  });

  /** Rendered twice with a pause between, so a rail that loads its figures gets to show them. */
  async function render(): Promise<string> {
    renderToStaticMarkup(createElement(InvoiceRightRail, railProps(summary)));
    await settle();
    return renderToStaticMarkup(createElement(InvoiceRightRail, railProps(summary)));
  }

  it('shows the subtotal of the lines rather than the stored amount', async () => {
    const markup = await render();
    expect(markup).toContain(formatCurrency(totalsOf(lines).subtotal));
    expect(markup).not.toContain('999');
  });

  it('shows the balance with the refund counted', async () => {
    expect(await render()).toContain(formatCurrency(totalsOf(lines, 10, 4).balance));
  });

  it('works its figures out through the pricing module', async () => {
    // A rail may price inside a query: start with none of them run yet
    (globalThis as unknown as { __mvSettled?: Map<string, unknown> }).__mvSettled?.clear();
    (globalThis as unknown as { __mvPending?: Map<string, unknown> }).__mvPending?.clear();
    pricingCalls.count = 0;
    await render();
    expect(pricingCalls.count).toBeGreaterThan(0);
  });

  it('formats its figures with a thousands separator', async () => {
    const markup = await render();
    expect(markup).toContain('$1,244.50');
    expect(markup).not.toMatch(/\$\d{4}/);
  });
});

describe('the invoice summary with a discounted line', () => {
  const tenOff = setting({ default_product_discount: true, discount: { type: '%', discount: 10, note: '' } });
  const discounted = invoice({
    amount: 999,
    amount_paid: 0,
    amount_refunded: 0,
    invoice_items: ['d'],
    added_invoice_items: [item('d', 2, 10, tenOff)],
  });
  const expected = totalsOf([[2, 10, tenOff]]);

  beforeEach(() => {
    catalogue.clear();
    vi.mocked(getBackendInvoiceItem).mockImplementation(async () => item('d', 2, 10, tenOff));
    vi.mocked(getBackendInvoice).mockImplementation(async () => discounted);
    held.clinicServicesProducts = { collection: [service('d', 10, tenOff)], loading: false, error: null };
  });

  async function render(): Promise<string> {
    renderToStaticMarkup(createElement(InvoiceRightRail, railProps(discounted)));
    await settle();
    return renderToStaticMarkup(createElement(InvoiceRightRail, railProps(discounted)));
  }

  it('shows the discount the lines carry in the Discount row', async () => {
    expect(expected.discount).toBeGreaterThan(0);
    expect(await render()).toContain(formatCurrency(expected.discount));
  });

  it('shows the total of the lines less the discount in the Total row', async () => {
    const markup = await render();
    expect(markup).toContain(formatCurrency(expected.total));
    expect(markup).not.toContain('999');
  });
});

describe('the invoice summary with a taxable line', () => {
  const taxable = setting({ taxable: true });
  const taxed = invoice({
    amount: 999,
    amount_paid: 0,
    amount_refunded: 0,
    invoice_items: ['t'],
    added_invoice_items: [item('t', 1, 100, taxable)],
  });
  const expected = totalsOf([[1, 100, taxable]]);

  beforeEach(() => {
    catalogue.clear();
    vi.mocked(getBackendInvoiceItem).mockImplementation(async () => item('t', 1, 100, taxable));
    vi.mocked(getBackendInvoice).mockImplementation(async () => taxed);
    held.clinicServicesProducts = { collection: [service('t', 100, taxable)], loading: false, error: null };
  });

  it('shows the tax at the clinic rate in the Tax row', async () => {
    expect(expected.tax).toBeGreaterThan(0);
    renderToStaticMarkup(createElement(InvoiceRightRail, railProps(taxed)));
    await settle();
    const markup = renderToStaticMarkup(createElement(InvoiceRightRail, railProps(taxed)));
    expect(markup).toContain(formatCurrency(expected.tax));
    expect(markup).toContain(formatCurrency(expected.total));
  });
});

// ---------------------------------------------------------------------------------------------
// The invoices table: its amount column goes through the one formatter.

describe('the invoices table', () => {
  it('formats the amount column through formatCurrency', () => {
    const rows = tablePresets.invoicesManagement(
      [invoice({ amount: 1234.5, created_at: '2026-01-05T00:00:00Z' })],
      user,
      {}
    );
    expect(rows.data[0].amount).toBe(formatCurrency(1234.5));
  });
});

// ---------------------------------------------------------------------------------------------
// The tables of the billing page: every price cell comes out of the one formatter. The lines here
// are one of a thing with nothing on top, so what a cell counts does not change what it shows.

describe('the tables of the billing page', () => {
  const product = { id: 'p-1', service_name: 'Thing', price: 1234.5, details: null };
  const created_at = '2026-01-05T00:00:00Z';

  it('formats the price of a treatment', () => {
    const rows = tablePresets.invoiceTxManagment([{ id: 't1', dosage: 1, created_at, product_service: product } as never], user, {});
    expect(rows.data[0].price).toBe('$1,234.50');
  });

  it('formats the price of a prescription', () => {
    const rows = tablePresets.invoiceRxManagment([{ id: 'r1', qty_dispensed: 1, created_at, product_service: product } as never], user, {});
    expect(rows.data[0].price).toBe('$1,234.50');
  });

  it('formats the price of an invoice item', () => {
    const rows = tablePresets.invoiceItems([item('i', 1, 1234.5)], user, {});
    expect(rows.data[0].price).toBe('$1,234.50');
  });

  it('formats the price of an item about to be added', () => {
    const rows = tablePresets.invoiceAddItems([item('i', 1, 1234.5)], user, [], vi.fn(), {});
    expect(rows.data[0].price).toBe('$1,234.50');
  });
});

// ---------------------------------------------------------------------------------------------
// The patient's invoices: rendered to markup, its amount comes out of the payment service's
// formatter and not a copy of it.

describe('the patient invoices list', () => {
  it('shows an amount through formatCurrency from the payment service', async () => {
    vi.mocked(getBackendInvoicesByPetId).mockResolvedValue([
      invoice({ amount: 1234.5, serial_number: 7, created_at: '2026-01-05T00:00:00Z' }),
    ] as never);
    const tree = createElement(PatientInvoicesModule, { petId: 'pet-1' });
    renderToStaticMarkup(tree);
    await settle();
    vi.mocked(formatCurrency).mockClear();
    const markup = renderToStaticMarkup(tree);
    expect(markup).toContain('$1,234.50');
    expect(formatCurrency).toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------------------------
// The whiteboard's pending invoice items panel: the price cell of an item waiting for review and
// the price cell of an approved one both come out of the payment service's formatter.

describe('the pending invoice items panel', () => {
  function pendingItem(id: string, status: string, price: number) {
    return {
      id,
      whiteboard_treatment_id: 'wt-' + id,
      whiteboard_patient_id: 'wp-' + id,
      appointment_id: 'apt-' + id,
      service_id: 'svc-' + id,
      status,
      price,
      created_at: '2026-01-05T00:00:00Z',
      whiteboard_treatments: { id: 'wt-' + id, treatment_name: 'Fluids', completed_at: '2026-01-05T00:00:00Z' },
      whiteboard_patients: { id: 'wp-' + id, pets: { id: 'pet-1', name: 'Rex' } },
      service: { id: 'svc-' + id, service_name: 'Fluids', price },
    };
  }

  /** The panel's markup once its items have come back, with the formatter's calls from that render. */
  async function shown(item: ReturnType<typeof pendingItem>): Promise<string> {
    vi.mocked(getBackendPendingInvoiceItems).mockResolvedValue([item] as never);
    const tree = createElement(PendingInvoiceItemsPanel, { appointmentId: item.appointment_id });
    renderToStaticMarkup(tree);
    await settle();
    vi.mocked(formatCurrency).mockClear();
    return renderToStaticMarkup(tree);
  }

  const formatted = (amount: number) =>
    vi.mocked(formatCurrency).mock.calls.some(([value]) => Number(value) === amount);

  it('shows the price of an item waiting for review through formatCurrency from the payment service', async () => {
    const markup = await shown(pendingItem('p1', 'pending_review', 1234.5));
    expect(markup).toContain('$1,234.50');
    expect(formatted(1234.5)).toBe(true);
  });

  it('shows the price of an approved item through formatCurrency from the payment service', async () => {
    const markup = await shown(pendingItem('p2', 'approved', 2345.25));
    expect(markup).toContain('$2,345.25');
    expect(formatted(2345.25)).toBe(true);
  });
});
