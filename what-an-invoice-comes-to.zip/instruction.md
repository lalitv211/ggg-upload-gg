Clinic manager sent us a screenshot on Tuesday. The summary shows one figure as subtotal and total, discount and tax are zero, balance forgets the refund. Turns out every screen works out the amount its own way, and each one adds its figure onto old amount so it drifts.

I want one place working the amount out from the lines. Please put it in features/invoices/pricing.ts as priceLines and invoiceTotals. priceLines takes the lines and the clinic, a line has quantity, unit_price and price_setting. A priced line should come back with dispensing_fee, subtotal, discount, tax and total. invoiceTotals gets priced lines plus paid and refunded, returns those two with subtotal, discount, tax, total and balance.

Line is basically quantity times unit_price, product's dispensing fee goes on top once. Discount is the tricky part. It only counts when the product has it on by default, can be percent of goods or dollars off each unit, and a unit can't go under its minimum price. Tax comes after discount, at clinic's rate, taxable lines only. Round everything to the cent.

Whiteboard puts approved treatments in at one each, it has to take the pending quantity, one when there is none. Billing page adds a line with quantity zero, so it costs nothing. SOAP bills a treatment by its dosage, five milligrams turns into five of them. A treatment is charged once there and a prescription by what was dispensed. Whoever writes the amount stores the total of all lines, not old plus new. invoiceInsertItems keeps the arguments it takes today.

Money is formatted three ways too. Summary and tables should go through formatCurrency from the payment service.

Took me a while to see it, so tests next to the existing ones please, an invoice that comes with only its item ids too.
