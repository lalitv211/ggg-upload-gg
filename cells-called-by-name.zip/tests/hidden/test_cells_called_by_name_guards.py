"""What already holds and must keep holding once names are in.

Every test here passes on the base: a name nobody defined is #NAME?, a cell written like a cell is
a cell, a function is matched in any case, a book with no names is written exactly as before, and
the commands, reports and examples come to what they came to. Standard library only.
"""

import io
import os
import signal
import tempfile
import unittest

from trestle import Desk
from trestle.cli.main import main
from trestle.errors import TrestleError
from trestle.recalc import recalculate, recalculated_after
from trestle.report import check_names
from trestle.sheet import Sheet, filled_across, inserted_rows, removed_rows
from trestle.store import read_book, write_book
from trestle.values import failure_names

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUDGET = os.path.join(ROOT, "examples", "budget.book")

SMALL = """trestle-book 1
name Small
sheet Costs
  A1 item
  B1 10
  B2 =B1*2
sheet Left
  A1 =Costs!B2+1
"""

#: The same book as the package writes it today, a blank line between sheets.
SMALL_WRITTEN = SMALL.replace("\nsheet Left", "\n\nsheet Left")


def _stop(signum, frame):
    raise AssertionError("took too long")


class _Guarded(unittest.TestCase):
    """A test that hangs fails rather than waits."""

    def setUp(self):
        signal.signal(signal.SIGALRM, _stop)
        signal.alarm(60)

    def tearDown(self):
        signal.alarm(0)


def run(*argv):
    """The command line, run in this process, with what it printed."""
    stream = io.StringIO()
    code = main(list(argv), stream)
    return code, stream.getvalue().rstrip("\n")


def written(text, name="guard.book"):
    """A file holding some text, in a directory of its own."""
    path = os.path.join(tempfile.mkdtemp(), name)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return path


class UnknownNameGuard(_Guarded):
    """A name nobody defined is #NAME?, before and after."""

    def test_an_undefined_name_comes_to_name_error(self):
        desk = Desk.empty()
        desk.put("A1", "=Tax_Rate*2")
        self.assertEqual(desk.value_at("A1").written(), "#NAME?")

    def test_an_undefined_name_travels(self):
        desk = Desk.empty()
        desk.put("A1", "=Nothing")
        desk.put("A2", "=A1+1")
        self.assertEqual(desk.value_at("A2").written(), "#NAME?")

    def test_the_sheet_engine_gives_name_error_for_a_name_the_sheet_lacks(self):
        sheet = Sheet("Costs")
        sheet.put("A1", "=SUM(Items)")
        recalculate(sheet)
        self.assertEqual(sheet.value_at("A1").written(), "#NAME?")

    def test_a_function_nobody_wrote_is_name_error(self):
        desk = Desk.empty()
        desk.put("A1", "=TOTALISE(1,2)")
        self.assertEqual(desk.value_at("A1").written(), "#NAME?")

    def test_a_name_read_from_csv_is_name_error(self):
        desk = Desk.of_table("=Rate*2,5\n")
        self.assertEqual(desk.value_at("A1").written(), "#NAME?")
        self.assertEqual(desk.value_at("B1").written(), "5")


class StillACellGuard(_Guarded):
    """What reads as a cell, a function or a boolean is still that."""

    def test_a_cell_written_like_a_cell_is_a_cell(self):
        desk = Desk.empty()
        desk.put("AB12", "5")
        desk.put("A1", "=AB12+1")
        self.assertEqual(desk.value_at("A1").written(), "6")

    def test_a_held_cell_is_a_cell(self):
        desk = Desk.empty()
        desk.put("B2", "5")
        desk.put("A1", "=$B$2+1")
        self.assertEqual(desk.value_at("A1").written(), "6")

    def test_a_function_is_matched_in_any_case(self):
        desk = Desk.empty()
        desk.put("A1", "=sum(1,2)")
        self.assertEqual(desk.value_at("A1").written(), "3")

    def test_true_and_false_are_booleans(self):
        desk = Desk.empty()
        desk.put("A1", "=true")
        desk.put("A2", "=FALSE")
        self.assertEqual(desk.value_at("A1").written(), "TRUE")
        self.assertEqual(desk.value_at("A2").written(), "FALSE")

    def test_a_whole_column_is_still_not_a_range(self):
        desk = Desk.empty()
        desk.put("A2", "5")
        desk.put("A3", "6")
        desk.put("B1", "=SUM(A:A)")
        desk.recalculate()
        cell = desk.sheet().cell_at("B1")
        self.assertTrue(cell.is_broken or cell.value.is_error, cell.value.written())

    def test_a_rectangle_across_two_sheets_is_still_refused(self):
        desk = Desk.empty()
        desk.put("A1", "=SUM(Costs!A1:Other!B2)")
        desk.recalculate()
        self.assertTrue(desk.sheet().cell_at("A1").is_broken)

    def test_a_range_where_one_value_belongs_is_still_a_value_error(self):
        desk = Desk.empty()
        desk.put("A1", "=B1:B2+1")
        self.assertEqual(desk.value_at("A1").written(), "#VALUE!")

    def test_there_are_still_seven_errors(self):
        self.assertEqual(len(failure_names()), 7)


class FileGuard(_Guarded):
    """A book with no names is written exactly as before."""

    def test_a_book_with_no_names_is_written_as_it_was(self):
        self.assertEqual(write_book(read_book(SMALL)), SMALL_WRITTEN)

    def test_the_budget_example_is_written_twice_the_same(self):
        with open(BUDGET, encoding="utf-8") as handle:
            text = handle.read()
        once = write_book(read_book(text))
        self.assertEqual(write_book(read_book(once)), once)

    def test_the_budget_example_still_opens_and_comes_to_the_same(self):
        desk = Desk.of_file(BUDGET)
        self.assertEqual(desk.value_at("B4", "Income").written(), "3050")
        self.assertEqual(desk.value_at("B3", "Left").written(), "1090")

    def test_a_line_that_is_not_a_cell_is_still_refused(self):
        with self.assertRaises(TrestleError):
            read_book("trestle-book 1\nsheet S\n  A 5\n")

    def test_a_cell_line_whose_text_has_an_equals_in_it_is_still_a_cell(self):
        book = read_book("trestle-book 1\nsheet S\n  A1 x = y\n  A2 =1+1\n")
        self.assertEqual(book.sheet_named("S").text_at("A1"), "x = y")
        self.assertEqual(book.sheet_named("S").text_at("A2"), "=1+1")

    def test_csv_of_the_budget_example_is_unchanged(self):
        _, said = run("csv", BUDGET, "--sheet", "Left")
        self.assertEqual(said, "in,3050\nout,1960\nleft,1090\nshare spent,64.3")


class CommandGuard(_Guarded):
    """The commands come back what they came back."""

    def test_set_still_works_and_writes(self):
        out = os.path.join(tempfile.mkdtemp(), "raised.book")
        code, said = run("set", BUDGET, "Income!B2", "2600", "--out", out)
        self.assertEqual(code, 0)
        self.assertTrue(said.startswith("Wrote "))
        self.assertEqual(run("value", out, "Income!B4")[1], "3250")

    def test_eval_alone_still_works(self):
        self.assertEqual(run("eval", "=ROUND(2/3,4)"), (0, "0.6667"))

    def test_eval_with_a_book_still_works(self):
        self.assertEqual(run("eval", "=SUM(Left!B1:B2)", "--book", BUDGET), (0, "5010"))


    def test_value_still_works(self):
        self.assertEqual(run("value", BUDGET, "Income!B4"), (0, "3050"))

    def test_calc_still_comes_back_nought_on_the_budget(self):
        code, _ = run("calc", BUDGET)
        self.assertEqual(code, 0)

    def test_review_of_the_budget_is_unchanged(self):
        code, said = run("review", BUDGET, "--only", "constant-formula")
        self.assertEqual(code, 0)

    def test_a_constant_formula_is_still_noticed(self):
        path = written("trestle-book 1\nsheet S\n  A1 =2+2\n")
        desk = Desk.of_file(path)
        self.assertEqual(len(desk.review(["constant-formula"])), 1)

    def test_the_nine_checks_are_still_there(self):
        for name in (
            "errors", "unreadable", "cycles", "missing-sheet", "constant-formula",
            "long-formula", "lonely-cell", "written-in-number", "odd-one-out",
        ):
            self.assertIn(name, check_names())

    def test_the_order_report_of_the_budget_is_unchanged(self):
        desk = Desk.of_file(BUDGET)
        order = [one.written() for one in desk.order()]
        self.assertEqual(order[0], "Income!B4")
        self.assertEqual(len(order), 6)

    def test_the_links_of_the_budget_are_unchanged(self):
        desk = Desk.of_file(BUDGET)
        counts = desk.links().counts()
        self.assertEqual((counts["cells"], counts["spans"]), (6, 2))

    def test_the_demo_still_runs(self):
        code, said = run("demo", "budget")
        self.assertEqual(code, 0)

    def test_an_unknown_command_is_still_a_usage_error(self):
        code, _ = run("nosuchcommand", BUDGET)
        self.assertEqual(code, 2)


class EditingGuard(_Guarded):
    """Filling, inserting and the sheet engine on formulas with no names in them."""

    def _sheet(self):
        sheet = Sheet("S")
        for row, held in ((2, "10"), (3, "20"), (4, "30"), (5, "40")):
            sheet.put("B%d" % row, held)
        sheet.put("A1", "=SUM(B2:B5)")
        sheet.put("C2", "=B2*2")
        return sheet

    def test_filling_still_moves_a_reference(self):
        sheet = self._sheet()
        filled_across(sheet, "C2", "C2:C5")
        self.assertEqual(sheet.text_at("C5"), "=B5*2")

    def test_inserting_a_row_still_grows_a_rectangle(self):
        sheet = inserted_rows(self._sheet(), 3, 1)
        self.assertEqual(sheet.text_at("A1"), "=SUM(B2:B6)")

    def test_removing_every_row_of_a_rectangle_is_still_a_reference_error(self):
        sheet = removed_rows(self._sheet(), 2, 4)
        recalculate(sheet)
        self.assertEqual(sheet.value_at("A1").written(), "#REF!")

    def test_the_sheet_engine_still_works_a_sheet_out(self):
        sheet = self._sheet()
        recalculate(sheet)
        self.assertEqual(sheet.value_at("A1").written(), "100")

    def test_a_change_still_makes_its_readers_stale(self):
        sheet = self._sheet()
        recalculate(sheet)
        sheet.put("B3", "25")
        recalculated_after(sheet, ["B3"])
        self.assertEqual(sheet.value_at("A1").written(), "105")

    def test_a_renamed_sheet_still_holds_its_cells(self):
        sheet = self._sheet().renamed("T")
        self.assertEqual(sheet.text_at("A1"), "=SUM(B2:B5)")

    def test_a_book_rename_still_rewrites_references(self):
        desk = Desk.of_text(SMALL)
        desk.book.rename("Costs", "Spend")
        self.assertEqual(desk.text_at("A1", "Left"), "=Spend!B2+1")


if __name__ == "__main__":
    unittest.main()
