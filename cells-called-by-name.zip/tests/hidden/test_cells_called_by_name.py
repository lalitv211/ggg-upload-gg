"""Names for cells and rectangles, belonging to the sheet whose cells they stand for.

The readme's third gap, filled: a name stands for one cell or one rectangle on its own sheet, a
bare name in a formula is settled late like a bare reference, and in a formula a name is exactly
the reference written in its place.

Every assertion compares a formula written with a name against the same formula written with the
rectangle, worked out on the same book, or checks a rule the request states (which sheet a name
belongs to, #NAME? when nobody defined it, what inserting and removing do to it). No message,
spelling, file line or internal is pinned. Standard library only: unittest, one method per case.
"""

import io
import os
import re
import signal
import tempfile
import unittest

from trestle import Desk
from trestle.book import Book
from trestle.cli.main import main
from trestle.errors import TrestleError
from trestle.formula import parse, rendered_cell
from trestle.recalc import recalculate, recalculated_after
from trestle.sheet import (
    Sheet,
    filled_across,
    inserted_columns,
    inserted_rows,
    moved_block,
    removed_columns,
    removed_rows,
)
from trestle.store import read_book, write_book

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BOOK = """trestle-book 1
name Names
sheet Costs
  A1 item
  B1 amount
  A2 washer
  B2 10
  A3 bolt
  B3 20
  A4 nut
  B4 30
  A5 screw
  B5 40
  D1 7
  E1 =1/0
  D3 2
  E3 3
sheet Prices
  B2 99
  B3 100
sheet Old Costs
  B2 5
  B3 6
"""

#: Every name the tests define, by sheet: the name and the rectangle it stands for.
NAMES = {
    "Costs": (
        ("Rate", "B2"),
        ("Items", "B2:B5"),
        ("Seven", "D1"),
        ("Bad", "E1"),
        ("Blank", "F9"),
        ("Pair", "D3:E3"),
    ),
    "Prices": (("Rate", "B2"), ("Items", "B2:B3")),
    "Old Costs": (("Rate", "B2"), ("Items", "B2:B3")),
}


def _stop(signum, frame):
    raise AssertionError("took too long")


class _Guarded(unittest.TestCase):
    """A test that hangs fails rather than waits."""

    def setUp(self):
        signal.signal(signal.SIGALRM, _stop)
        signal.alarm(60)

    def tearDown(self):
        signal.alarm(0)


def run(*argv):
    """The command line, run in this process, with what it printed."""
    stream = io.StringIO()
    code = main(list(argv), stream)
    return code, stream.getvalue().rstrip("\n")


def written(text, name="names.book"):
    """A file holding some text, in a directory of its own."""
    path = os.path.join(tempfile.mkdtemp(), name)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return path


def named_desk(names=None):
    """The book above with the names defined through the desk."""
    desk = Desk.of_text(BOOK)
    for sheet, held in (names if names is not None else NAMES).items():
        for name, rectangle in held:
            desk.define(name, rectangle, sheet)
    return desk


def plain_desk():
    """The book above with no names at all."""
    return Desk.of_text(BOOK)


def value_of(desk, formula, where="Z1", sheet="Costs"):
    """What a formula comes to when typed into a cell of a desk."""
    desk.put(where, formula, sheet)
    return desk.value_at(where, sheet).written()


def names_of(sheet):
    """The names a sheet lists, whatever shape names() hands them back in."""
    found = []
    for one in sheet.names():
        found.append(one if isinstance(one, str) else one[0])
    return tuple(found)


def corners_of(held):
    """The first and last cell of what a name stands for, as written without the sheet."""
    if hasattr(held, "first"):
        return held.first.written(False), held.last.written(False)
    return held.written(False), held.written(False)


def slug(text):
    """A method name suffix made of a formula: letters, digits and underscores only."""
    spelled = {
        "$": " held ", "+": " plus ", "-": " minus ", "(": " open ", ")": " close ", ":": " to ",
        "!": " bang ", "%": " pct ", "*": " times ", "/": " over ", "^": " pow ", "=": " eq ",
        "<": " lt ", ">": " gt ", "&": " amp ", '"': " q ", "'": " qq ", ".": " dot ",
        ",": " comma ",
    }
    held = "".join(spelled.get(letter, letter) for letter in text)
    held = re.sub(r"[^A-Za-z0-9]+", "_", held).strip("_")
    return held or "formula"


def each(cls, prefix, cases, body):
    """Give a class one test method per case, named after the case."""
    seen = set()
    for case in cases:
        key = case if isinstance(case, str) else case[0]
        name = "%s_%s" % (prefix, slug(key))
        assert name not in seen, name
        seen.add(name)

        def method(self, case=case):
            body(self, case)

        method.__name__ = name
        setattr(cls, name, method)


# ---------------------------------------------------------------------------------------------
# A name in a formula is exactly the reference written in its place.

SAME_AS = [
    ("=Rate*2", "=B2*2"),
    ("=Rate", "=B2"),
    ("=SUM(Items)", "=SUM(B2:B5)"),
    ("=AVERAGE(Items)", "=AVERAGE(B2:B5)"),
    ("=COUNT(Items)", "=COUNT(B2:B5)"),
    ("=MAX(Items)-MIN(Items)", "=MAX(B2:B5)-MIN(B2:B5)"),
    ("=INDEX(Items,2)", "=INDEX(B2:B5,2)"),
    ("=MATCH(30,Items,0)", "=MATCH(30,B2:B5,0)"),
    ("=ROWS(Items)", "=ROWS(B2:B5)"),
    ("=COUNTBLANK(Items)", "=COUNTBLANK(B2:B5)"),
    ("=SUM(Rate)", "=SUM(B2)"),
    ("=Items*2", "=B2:B5*2"),
    ("=Items", "=B2:B5"),
    ("=IF(Items,1,2)", "=IF(B2:B5,1,2)"),
    ("=Rate+Seven", "=B2+D1"),
    ("=Blank+1", "=F9+1"),
    ('=Blank&"x"', '=F9&"x"'),
    ("=Bad*2", "=E1*2"),
    ("=IFERROR(Bad,Rate)", "=IFERROR(E1,B2)"),
    ('=IF(Rate>5,"big","small")', '=IF(B2>5,"big","small")'),
    ("=-Rate", "=-B2"),
    ("=Rate%", "=B2%"),
    ("=(Rate+Seven)*2", "=(B2+D1)*2"),
    ('=Rate&"x"', '=B2&"x"'),
    ("=Rate=10", "=B2=10"),
    ("=SUM(Pair)", "=SUM(D3:E3)"),
    ("=SUM(Items,Pair)", "=SUM(B2:B5,D3:E3)"),
    ("=SUM(Items)+SUM(Prices!Items)", "=SUM(B2:B5)+SUM(Prices!B2:B3)"),
    ("=Prices!Rate", "=Prices!B2"),
    ("=Prices!Rate*Rate", "=Prices!B2*B2"),
    ("='Old Costs'!Rate", "='Old Costs'!B2"),
    ("=SUM('Old Costs'!Items)", "=SUM('Old Costs'!B2:B3)"),
    ("=Costs!Rate", "=Costs!B2"),
    ("=VLOOKUP(30,Items,1,FALSE)", "=VLOOKUP(30,B2:B5,1,FALSE)"),
    ("=SUMIF(Items,\">15\")", "=SUMIF(B2:B5,\">15\")"),
]


class SameAsTheRectangleTest(_Guarded):
    """A formula with a name comes to what the same formula with the rectangle comes to."""


def _same_as(self, case):
    with_name, plain = case
    self.assertEqual(value_of(named_desk(), with_name), value_of(plain_desk(), plain))


each(SameAsTheRectangleTest, "test_same_answer_as", SAME_AS, _same_as)


class FromAnotherSheetTest(_Guarded):
    """The same formulas typed on another sheet, naming the sheet the name is on."""


FROM_PRICES = [
    ("=Costs!Rate*2", "=Costs!B2*2"),
    ("=SUM(Costs!Items)", "=SUM(Costs!B2:B5)"),
    ("=Rate", "=B2"),
    ("=SUM(Items)", "=SUM(B2:B3)"),
    ("='Old Costs'!Rate+Rate", "='Old Costs'!B2+B2"),
]


def _from_prices(self, case):
    with_name, plain = case
    self.assertEqual(
        value_of(named_desk(), with_name, sheet="Prices"),
        value_of(plain_desk(), plain, sheet="Prices"),
    )


each(FromAnotherSheetTest, "test_on_prices_same_answer_as", FROM_PRICES, _from_prices)


# ---------------------------------------------------------------------------------------------
# Which sheet a name belongs to.

class BelongsToASheetTest(_Guarded):
    """Each sheet keeps its own names, and a bare name is settled late."""

    def test_the_same_text_on_two_sheets_reads_two_names(self):
        desk = named_desk()
        self.assertEqual(value_of(desk, "=Rate*1", sheet="Costs"), "10")
        self.assertEqual(value_of(desk, "=Rate*1", sheet="Prices"), "99")

    def test_a_name_defined_on_one_sheet_is_unknown_on_another(self):
        desk = named_desk({"Costs": (("Only", "B2"),)})
        self.assertEqual(value_of(desk, "=Only*1", sheet="Prices"), "#NAME?")
        self.assertEqual(value_of(desk, "=Costs!Only*1", sheet="Prices"), "10")

    def test_names_are_compared_exactly(self):
        desk = named_desk()
        self.assertEqual(value_of(desk, "=rate*1"), "#NAME?")
        self.assertEqual(value_of(desk, "=RATE*1"), "#NAME?")

    def test_a_name_on_a_sheet_that_is_not_there_is_a_reference_error(self):
        desk = named_desk()
        self.assertEqual(value_of(desk, "=Missing!Rate*1"), "#REF!")

    def test_defining_a_name_again_replaces_it(self):
        desk = named_desk()
        self.assertEqual(value_of(desk, "=Rate*1"), "10")
        desk.define("Rate", "B3", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "20")

    def test_defining_a_name_again_keeps_its_place_in_the_list(self):
        sheet = Sheet("S")
        sheet.define("One", "A1")
        sheet.define("Two", "A2")
        sheet.define("One", "A3")
        self.assertEqual(sorted(names_of(sheet)), ["One", "Two"])

    def test_the_names_of_a_sheet_are_the_names_defined(self):
        desk = named_desk()
        self.assertEqual(
            sorted(names_of(desk.sheet("Costs"))), sorted(name for name, _ in NAMES["Costs"])
        )

    def test_the_names_of_one_sheet_are_not_the_names_of_another(self):
        desk = named_desk()
        self.assertEqual(sorted(names_of(desk.sheet("Prices"))), ["Items", "Rate"])

    def test_what_a_name_stands_for_is_a_span_on_its_sheet(self):
        sheet = named_desk().sheet("Costs")
        held = sheet.named("Items")
        self.assertEqual(corners_of(held), ("B2", "B5"))
        self.assertIn(held.sheet, ("Costs", ""))

    def test_a_name_for_one_cell_is_a_span_of_one_cell(self):
        held = named_desk().sheet("Costs").named("Rate")
        self.assertEqual(corners_of(held), ("B2", "B2"))

    def test_corners_either_way_round_are_the_same_rectangle(self):
        sheet = Sheet("S")
        self.assertEqual(sheet.define("Up", "B5:B2"), sheet.define("Down", "B2:B5"))

    def test_dollars_in_the_rectangle_mean_nothing(self):
        sheet = Sheet("S")
        self.assertEqual(sheet.define("Held", "$B$2:$B$5"), sheet.define("Loose", "B2:B5"))

    def test_the_rectangle_may_name_its_own_sheet(self):
        sheet = Sheet("Costs")
        self.assertEqual(sheet.define("Own", "Costs!B2:B5"), sheet.define("Bare", "B2:B5"))

    def test_a_rectangle_may_be_given_as_a_span(self):
        sheet = Sheet("Costs")
        span = sheet.span_of("B2:B5")
        self.assertEqual(sheet.define("Given", span), sheet.define("Typed", "B2:B5"))

    def test_a_name_may_be_defined_before_anything_is_typed_in_it(self):
        desk = Desk.empty("b", "S")
        desk.define("Later", "A1:A3")
        desk.put("B1", "=SUM(Later)")
        self.assertEqual(desk.value_at("B1").written(), "0")
        desk.put("A2", "5")
        self.assertEqual(desk.value_at("B1").written(), "5")

    def test_forgetting_a_name_takes_it_out_of_the_list(self):
        sheet = named_desk().sheet("Costs")
        sheet.forget("Seven")
        self.assertNotIn("Seven", names_of(sheet))
        self.assertIn("Rate", names_of(sheet))

    def test_a_forgotten_name_is_unknown_when_worked_out(self):
        desk = named_desk()
        self.assertEqual(value_of(desk, "=Seven*1"), "7")
        desk.forget("Seven", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "#NAME?")

    def test_forgetting_a_name_nobody_defined_is_refused(self):
        with self.assertRaises(TrestleError):
            Sheet("S").forget("Nothing")

    def test_asking_for_a_name_nobody_defined_gives_no_rectangle(self):
        try:
            found = Sheet("S").named("Nothing")
        except TrestleError:
            return
        self.assertFalse(found)


# ---------------------------------------------------------------------------------------------
# A name nobody defined is #NAME? when worked out, and the formula still reads.

class UndefinedNameTest(_Guarded):
    """A name nobody defined comes to #NAME?, as a value, from a formula that reads."""


    def test_a_formula_with_an_undefined_name_is_still_a_formula(self):
        desk = plain_desk()
        desk.put("Z1", "=Nothing*2", "Costs")
        desk.recalculate()
        cell = desk.sheet("Costs").cell_at("Z1")
        self.assertTrue(cell.is_formula)
        self.assertFalse(cell.is_broken)

    def test_a_formula_with_an_undefined_name_is_not_an_unreadable_one(self):
        desk = plain_desk()
        desk.put("Z1", "=SUM(Nothing)", "Costs")
        desk.recalculate()
        self.assertEqual(desk.review(["unreadable"]).counts()["warning"], 0)

    def test_defining_the_name_afterwards_makes_the_formula_work(self):
        desk = plain_desk()
        self.assertEqual(value_of(desk, "=SUM(Later)"), "#NAME?")
        desk.define("Later", "B2:B5", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "100")

    def test_an_undefined_name_inside_iferror_is_caught_like_any_error(self):
        self.assertEqual(value_of(plain_desk(), "=IFERROR(Nothing,5)"), "5")


    def test_eval_with_no_book_gives_name_error(self):
        code, said = run("eval", "=Rate*2")
        self.assertEqual(said, "#NAME?")
        self.assertEqual(code, 3)


# ---------------------------------------------------------------------------------------------
# What a name may be.

REFUSED_NAMES = ["A1", "AB12", "$A$1", "SUM", "sum", "TRUE", "false", "2x", "a-b", "a b", "", "A1:B2"]


class RefusedNameTest(_Guarded):
    """A name that reads as a cell, a function or a boolean is refused."""


def _refused_name(self, name):
    with self.assertRaises(TrestleError):
        Sheet("S").define(name, "B2")


each(RefusedNameTest, "test_refuses_the_name", [n if n else "nothing" for n in REFUSED_NAMES],
     lambda self, case: _refused_name(self, "" if case == "nothing" else case))


class RefusedRectangleTest(_Guarded):
    """A name stands for cells on its own sheet."""

    def test_a_rectangle_on_another_sheet_is_refused(self):
        with self.assertRaises(TrestleError):
            Sheet("Costs").define("Elsewhere", "Prices!B2:B5")

    def test_through_the_book_a_rectangle_never_lands_on_another_sheet(self):
        desk = plain_desk()
        try:
            desk.define("Elsewhere", "Prices!B2", "Costs")
        except TrestleError:
            return
        self.assertEqual(names_of(desk.sheet("Costs")), ())
        self.assertEqual(names_of(desk.sheet("Prices")), ("Elsewhere",))

    def test_something_that_is_not_a_rectangle_is_refused(self):
        with self.assertRaises(TrestleError):
            Sheet("S").define("Odd", "B2:Prices!B3")

    def test_a_refused_name_is_not_added(self):
        sheet = Sheet("S")
        with self.assertRaises(TrestleError):
            sheet.define("SUM", "B2")
        self.assertEqual(names_of(sheet), ())


ALLOWED_NAMES = ["Rate", "rate_2", "TaxRate", "x", "Total2024", "a1b", "RATE_OF_TAX"]


class AllowedNameTest(_Guarded):
    """Letters, digits and underscores, starting with a letter or underscore."""


def _allowed_name(self, name):
    desk = plain_desk()
    desk.define(name, "B2", "Costs")
    self.assertEqual(value_of(desk, "=%s*2" % name), "20")


each(AllowedNameTest, "test_allows_the_name", ALLOWED_NAMES, _allowed_name)


# ---------------------------------------------------------------------------------------------
# Through the book and the desk.

class ThroughTheBookTest(_Guarded):
    """Book and Desk take the sheet the way put does."""

    def test_the_book_defines_on_the_sheet_named(self):
        book = read_book(BOOK)
        book.define("Rate", "B3", "Prices")
        self.assertEqual(names_of(book.sheet_named("Prices")), ("Rate",))
        self.assertEqual(names_of(book.sheet_named("Costs")), ())

    def test_the_book_defines_on_the_rectangles_own_sheet(self):
        book = read_book(BOOK)
        book.define("Rate", "Prices!B3")
        self.assertEqual(names_of(book.sheet_named("Prices")), ("Rate",))

    def test_the_book_defines_on_the_first_sheet_when_nothing_says_which(self):
        book = read_book(BOOK)
        book.define("Rate", "B3")
        self.assertEqual(names_of(book.sheet_named("Costs")), ("Rate",))

    def test_the_book_forgets_on_the_sheet_named(self):
        book = read_book(BOOK)
        book.define("Rate", "B3", "Prices")
        book.forget("Rate", "Prices")
        self.assertEqual(names_of(book.sheet_named("Prices")), ())

    def test_the_book_refuses_a_sheet_it_does_not_have(self):
        with self.assertRaises(TrestleError):
            read_book(BOOK).define("Rate", "B3", "Missing")

    def test_the_desk_answers_right_after_a_name_is_defined(self):
        desk = plain_desk()
        desk.put("Z1", "=SUM(Items)", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "#NAME?")
        desk.define("Items", "B2:B5", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "100")

    def test_the_desk_answers_right_after_a_name_is_defined_again(self):
        desk = named_desk()
        desk.put("Z1", "=SUM(Items)", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "100")
        desk.define("Items", "B2:B3", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "30")

    def test_the_desk_answers_right_after_a_name_is_forgotten(self):
        desk = named_desk()
        desk.put("Z1", "=SUM(Items)", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "100")
        desk.forget("Items", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "#NAME?")

    def test_the_desk_answers_right_after_a_cell_the_name_covers_changes(self):
        desk = named_desk()
        desk.put("Z1", "=SUM(Items)", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "100")
        desk.put("B3", "25", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "105")

    def test_the_desk_answers_right_after_a_cell_the_name_covers_is_emptied(self):
        desk = named_desk()
        desk.put("Z1", "=SUM(Items)", "Costs")
        desk.value_at("Z1", "Costs")
        desk.put("B5", "", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "60")

    def test_the_desk_answers_right_after_a_cell_the_name_covers_is_filled_in(self):
        desk = named_desk()
        desk.put("Z1", "=SUM(Items)", "Costs")
        desk.put("Y1", "=COUNTBLANK(Items)", "Costs")
        self.assertEqual(desk.value_at("Y1", "Costs").written(), "0")
        desk.put("B5", "", "Costs")
        self.assertEqual(desk.value_at("Y1", "Costs").written(), "1")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "60")


# ---------------------------------------------------------------------------------------------
# The graph sees through a name: order, cycles, what a change makes stale, the links.

class GraphTest(_Guarded):
    """A formula reads, through a name, exactly the cells the rectangle covers."""

    def _links_of(self, desk, formula):
        desk.put("Z1", formula, "Costs")
        desk.recalculate()
        links = desk.links()
        where = desk.sheet("Costs").address_of("Z1")
        return links, where

    def test_what_a_cell_reads_through_a_name_is_what_it_reads_through_the_rectangle(self):
        named, at = self._links_of(named_desk(), "=SUM(Items)+Seven")
        plain, _ = self._links_of(plain_desk(), "=SUM(B2:B5)+D1")
        self.assertEqual(named.reads(at), plain.reads(at))
        self.assertEqual(len(named.reads(at)), 5)

    def test_what_a_cell_reads_through_a_name_on_another_sheet(self):
        named, at = self._links_of(named_desk(), "=SUM(Prices!Items)")
        plain, _ = self._links_of(plain_desk(), "=SUM(Prices!B2:B3)")
        self.assertEqual(named.reads(at), plain.reads(at))
        self.assertEqual(len(named.reads(at)), 2)

    def test_the_cells_a_name_covers_are_read_by_the_formula(self):
        named, at = self._links_of(named_desk(), "=SUM(Items)")
        inside = named_desk().sheet("Costs").address_of("B4")
        self.assertIn(at, named.read_by(inside))

    def test_a_cell_the_name_does_not_cover_is_not_read_by_the_formula(self):
        named, at = self._links_of(named_desk(), "=SUM(Items)")
        outside = named_desk().sheet("Costs").address_of("D1")
        self.assertNotIn(at, named.read_by(outside))

    def test_a_rectangle_stays_a_rectangle_in_the_graph(self):
        named, _ = self._links_of(named_desk(), "=SUM(Items)")
        plain, _ = self._links_of(plain_desk(), "=SUM(B2:B5)")
        self.assertEqual(named.counts(), plain.counts())

    def test_a_name_over_a_long_column_is_one_entry(self):
        desk = Desk.empty("big", "S")
        for row in range(1, 2001):
            desk.put("A%d" % row, str(row))
        desk.define("Figures", "A1:A2000")
        desk.put("B1", "=SUM(Figures)")
        self.assertEqual(desk.value_at("B1").written(), "2001000")
        self.assertEqual(desk.links().counts()["spans"], 1)

    def test_a_formula_inside_the_rectangle_it_sums_is_a_cycle(self):
        self.assertEqual(value_of(named_desk(), "=SUM(Items)", where="B3"), "#CYCLE!")

    def test_a_cycle_through_a_name_is_what_the_rectangle_gives(self):
        named = named_desk()
        plain = plain_desk()
        self.assertEqual(
            value_of(named, "=SUM(Items)", where="B3"), value_of(plain, "=SUM(B2:B5)", where="B3")
        )
        self.assertEqual(
            named.value_at("B2", "Costs").written(), plain.value_at("B2", "Costs").written()
        )

    def test_a_cycle_across_sheets_through_a_name(self):
        desk = named_desk()
        desk.put("B2", "=Costs!Z1", "Prices")
        self.assertEqual(value_of(desk, "=Prices!Rate", where="Z1"), "#CYCLE!")
        self.assertEqual(desk.value_at("B2", "Prices").written(), "#CYCLE!")

    def test_a_cell_reading_a_cycle_through_a_name_is_not_in_it(self):
        desk = named_desk()
        desk.put("B3", "=SUM(Items)", "Costs")
        self.assertEqual(value_of(desk, "=SUM(Items)*2", where="Z1"), "#CYCLE!")
        self.assertNotIn(desk.sheet("Costs").address_of("Z1"), desk.order().stuck)

    def test_a_chain_through_names_is_worked_out_in_order(self):
        desk = named_desk()
        desk.put("B2", "=Seven*2", "Costs")
        desk.put("D1", "=Prices!Rate+1", "Costs")
        self.assertEqual(value_of(desk, "=SUM(Items)"), "290")

    def test_the_order_through_a_name_is_the_order_through_the_rectangle(self):
        named = named_desk()
        named.put("B2", "=Seven*2", "Costs")
        named.put("Z1", "=SUM(Items)", "Costs")
        plain = plain_desk()
        plain.put("B2", "=D1*2", "Costs")
        plain.put("Z1", "=SUM(B2:B5)", "Costs")
        self.assertEqual(tuple(named.order()), tuple(plain.order()))

    def test_the_sheet_engine_resolves_a_bare_name(self):
        sheet = Sheet("Costs")
        sheet.put("B2", "10")
        sheet.put("B3", "20")
        sheet.define("Items", "B2:B3")
        sheet.put("A1", "=SUM(Items)*Items_Count")
        sheet.define("Items_Count", "C1")
        sheet.put("C1", "3")
        recalculate(sheet)
        self.assertEqual(sheet.value_at("A1").written(), "90")


    def test_a_change_inside_the_rectangle_makes_the_reader_stale(self):
        sheet = Sheet("Costs")
        for row, held in ((2, "10"), (3, "20"), (4, "30")):
            sheet.put("B%d" % row, held)
        sheet.define("Items", "B2:B4")
        sheet.put("A1", "=SUM(Items)")
        recalculate(sheet)
        sheet.put("B3", "25")
        after = recalculated_after(sheet, ["B3"])
        self.assertEqual(sheet.value_at("A1").written(), "65")
        self.assertIn(sheet.address_of("A1"), [step.at for step in after.trace])

    def test_a_change_outside_the_rectangle_leaves_the_reader_alone(self):
        sheet = Sheet("Costs")
        for row, held in ((2, "10"), (3, "20"), (4, "30"), (9, "1")):
            sheet.put("B%d" % row, held)
        sheet.define("Items", "B2:B4")
        sheet.put("A1", "=SUM(Items)")
        recalculate(sheet)
        sheet.put("B9", "2")
        after = recalculated_after(sheet, ["B9"])
        self.assertNotIn(sheet.address_of("A1"), [step.at for step in after.trace])

    def test_the_links_report_through_a_name_is_the_report_through_the_rectangle(self):
        named = named_desk()
        named.put("Z1", "=SUM(Items)+Prices!Rate", "Costs")
        plain = plain_desk()
        plain.put("Z1", "=SUM(B2:B5)+Prices!B2", "Costs")
        self.assertEqual(named.report("links").render("text"), plain.report("links").render("text"))

    def test_the_trace_through_a_name_is_the_trace_through_the_rectangle(self):
        named = named_desk()
        named.put("Z1", "=SUM(Items)", "Costs")
        plain = plain_desk()
        plain.put("Z1", "=SUM(B2:B5)", "Costs")
        self.assertEqual(named.trace().counts(), plain.trace().counts())


# ---------------------------------------------------------------------------------------------
# Filling leaves a name alone; inserting and removing move what it stands for.

class FillingTest(_Guarded):
    """A name is not a reference that moves."""

    def _sheet(self):
        sheet = named_desk().sheet("Costs")
        sheet.put("C2", "=Rate*B2")
        return sheet

    def test_filling_down_leaves_the_name_as_it_is(self):
        sheet = self._sheet()
        filled_across(sheet, "C2", "C2:C5")
        self.assertEqual(sheet.text_at("C3"), "=Rate*B3")
        self.assertEqual(sheet.text_at("C5"), "=Rate*B5")

    def test_a_filled_formula_with_a_name_comes_to_the_right_answer(self):
        sheet = self._sheet()
        filled_across(sheet, "C2", "C2:C5")
        recalculate(sheet)
        self.assertEqual(sheet.value_at("C5").written(), "400")

    def test_filling_across_leaves_the_name_as_it_is(self):
        sheet = self._sheet()
        sheet.put("C2", "=SUM(Items)+B2")
        filled_across(sheet, "C2", "C2:E2")
        self.assertEqual(sheet.text_at("E2"), "=SUM(Items)+D2")

    def test_filling_leaves_a_name_with_a_sheet_in_front_as_it_is(self):
        sheet = self._sheet()
        sheet.put("C2", "=Prices!Rate*B2")
        filled_across(sheet, "C2", "C2:C3")
        self.assertEqual(sheet.text_at("C3"), "=Prices!Rate*B3")

    def test_moving_a_block_leaves_the_name_as_it_is(self):
        sheet = self._sheet()
        moved_block(sheet, "C2", "G7")
        self.assertEqual(sheet.text_at("G7"), "=Rate*F7")

    def test_a_filled_run_of_formulas_with_a_name_is_one_run(self):
        desk = named_desk()
        desk.put("C2", "=Rate*B2", "Costs")
        filled_across(desk.sheet("Costs"), "C2", "C2:C5")
        self.assertEqual(len(desk.review(["odd-one-out"])), 0)

    def test_the_odd_one_out_is_still_found_beside_a_name(self):
        desk = named_desk()
        desk.put("C2", "=Rate*B2", "Costs")
        filled_across(desk.sheet("Costs"), "C2", "C2:C5")
        desk.put("C3", "=Rate*B3*2", "Costs")
        self.assertEqual(len(desk.review(["odd-one-out"])), 1)


def _named_sheet():
    """One sheet of numbers with a rectangle and a cell named."""
    sheet = Sheet("Costs")
    for row, held in ((2, "10"), (3, "20"), (4, "30"), (5, "40")):
        sheet.put("B%d" % row, held)
    sheet.put("D1", "7")
    sheet.define("Items", "B2:B5")
    sheet.define("Seven", "D1")
    sheet.put("A1", "=SUM(Items)")
    sheet.put("A2", "=Seven*2")
    return sheet


def _plain_sheet():
    """The same sheet with the rectangle written out."""
    sheet = Sheet("Costs")
    for row, held in ((2, "10"), (3, "20"), (4, "30"), (5, "40")):
        sheet.put("B%d" % row, held)
    sheet.put("D1", "7")
    sheet.put("A1", "=SUM(B2:B5)")
    sheet.put("A2", "=D1*2")
    return sheet


class InsertingAndRemovingTest(_Guarded):
    """What a name stands for moves the way a rectangle written in a formula moves."""

    def _both(self, change):
        named, plain = change(_named_sheet()), change(_plain_sheet())
        recalculate(named)
        recalculate(plain)
        return named, plain

    def test_inserting_a_row_inside_the_rectangle_grows_it(self):
        named, plain = self._both(lambda sheet: inserted_rows(sheet, 3, 1))
        self.assertEqual(corners_of(named.named("Items")), ("B2", "B6"))
        self.assertEqual(named.value_at("A1").written(), plain.value_at("A1").written())

    def test_inserting_a_row_inside_the_rectangle_leaves_the_formula_text_alone(self):
        named, _ = self._both(lambda sheet: inserted_rows(sheet, 3, 1))
        self.assertEqual(named.text_at("A1"), "=SUM(Items)")

    def test_inserting_rows_above_the_rectangle_moves_it_down(self):
        named, plain = self._both(lambda sheet: inserted_rows(sheet, 1, 2))
        self.assertEqual(corners_of(named.named("Items")), ("B4", "B7"))
        self.assertEqual(named.value_at("A3").written(), plain.value_at("A3").written())

    def test_inserting_rows_below_the_rectangle_leaves_it_alone(self):
        named, _ = self._both(lambda sheet: inserted_rows(sheet, 7, 2))
        self.assertEqual(corners_of(named.named("Items"))[1], "B5")

    def test_a_filled_in_inserted_row_is_inside_the_rectangle(self):
        named, _ = self._both(lambda sheet: inserted_rows(sheet, 3, 1))
        named.put("B3", "5")
        recalculate(named)
        self.assertEqual(named.value_at("A1").written(), "105")

    def test_removing_a_row_inside_the_rectangle_shrinks_it(self):
        named, plain = self._both(lambda sheet: removed_rows(sheet, 3, 1))
        self.assertEqual(corners_of(named.named("Items"))[1], "B4")
        self.assertEqual(named.value_at("A1").written(), plain.value_at("A1").written())
        self.assertEqual(named.value_at("A1").written(), "80")

    def test_removing_every_row_of_the_rectangle_leaves_the_name_standing_for_nothing(self):
        named, plain = self._both(lambda sheet: removed_rows(sheet, 2, 4))
        self.assertEqual(named.value_at("A1").written(), "#REF!")
        self.assertEqual(named.value_at("A1").written(), plain.value_at("A1").written())

    def test_a_name_standing_for_nothing_is_still_listed(self):
        named, _ = self._both(lambda sheet: removed_rows(sheet, 2, 4))
        self.assertIn("Items", names_of(named))

    def test_removing_the_cell_a_name_stands_for(self):
        named, plain = self._both(lambda sheet: removed_rows(sheet, 1, 1))
        self.assertEqual(named.value_at("A1").written(), "#REF!")
        self.assertEqual(named.value_at("A1").written(), plain.value_at("A1").written())

    def test_inserting_a_column_moves_a_rectangle_to_its_right(self):
        named, plain = self._both(lambda sheet: inserted_columns(sheet, 1, 1))
        self.assertEqual(corners_of(named.named("Items"))[0], "C2")
        self.assertEqual(corners_of(named.named("Seven"))[0], "E1")
        self.assertEqual(named.value_at("B1").written(), plain.value_at("B1").written())
        self.assertEqual(named.value_at("B2").written(), "14")

    def test_removing_a_column_the_name_stands_for(self):
        named, plain = self._both(lambda sheet: removed_columns(sheet, 2, 1))
        self.assertEqual(named.value_at("A1").written(), "#REF!")
        self.assertEqual(named.value_at("A1").written(), plain.value_at("A1").written())
        self.assertEqual(named.value_at("A2").written(), "14")

    def test_inserting_rows_keeps_every_name(self):
        named, _ = self._both(lambda sheet: inserted_rows(sheet, 3, 1))
        self.assertEqual(sorted(names_of(named)), ["Items", "Seven"])

    def test_a_copy_of_a_sheet_keeps_its_names(self):
        copied = _named_sheet().copy()
        self.assertEqual(sorted(names_of(copied)), ["Items", "Seven"])
        recalculate(copied)
        self.assertEqual(copied.value_at("A1").written(), "100")

    def test_a_renamed_sheet_keeps_its_names(self):
        renamed = _named_sheet().renamed("Other")
        self.assertEqual(sorted(names_of(renamed)), ["Items", "Seven"])
        recalculate(renamed)
        self.assertEqual(renamed.value_at("A1").written(), "100")


class RenamingAndRemovingSheetsTest(_Guarded):
    """A sheet name in front of a name follows a rename; a removed sheet is #REF!."""

    def _book(self, formula="=SUM(Costs!Items)+Costs!Rate"):
        desk = named_desk()
        desk.put("A1", formula, "Prices")
        desk.recalculate()
        return desk

    def test_renaming_a_sheet_rewrites_the_name_in_front(self):
        desk = self._book()
        desk.book.rename("Costs", "Spend")
        self.assertEqual(desk.text_at("A1", "Prices"), "=SUM(Spend!Items)+Spend!Rate")

    def test_renaming_a_sheet_to_a_name_with_a_space_quotes_it(self):
        desk = self._book("=Costs!Rate*2")
        desk.book.rename("Costs", "All Costs")
        self.assertEqual(desk.text_at("A1", "Prices"), "='All Costs'!Rate*2")

    def test_a_formula_still_comes_to_the_same_after_a_rename(self):
        desk = self._book()
        desk.book.rename("Costs", "Spend")
        desk.recalculate(again=True)
        self.assertEqual(desk.value_at("A1", "Prices").written(), "110")

    def test_a_renamed_sheet_keeps_its_names_in_the_book(self):
        desk = self._book()
        desk.book.rename("Costs", "Spend")
        self.assertEqual(sorted(names_of(desk.sheet("Spend"))), sorted(n for n, _ in NAMES["Costs"]))

    def test_renaming_leaves_a_bare_name_on_the_renamed_sheet_alone(self):
        desk = named_desk()
        desk.put("Z1", "=SUM(Items)", "Costs")
        desk.book.rename("Costs", "Spend")
        self.assertEqual(desk.text_at("Z1", "Spend"), "=SUM(Items)")
        desk.recalculate(again=True)
        self.assertEqual(desk.value_at("Z1", "Spend").written(), "100")

    def test_renaming_leaves_the_same_name_on_another_sheet_alone(self):
        desk = self._book("=Rate*2")
        desk.book.rename("Costs", "Spend")
        self.assertEqual(desk.text_at("A1", "Prices"), "=Rate*2")

    def test_a_name_on_a_removed_sheet_is_a_reference_error(self):
        desk = self._book("=Costs!Rate*2")
        desk.book.remove("Costs")
        desk.recalculate(again=True)
        self.assertEqual(desk.value_at("A1", "Prices").written(), "#REF!")


# ---------------------------------------------------------------------------------------------
# Writing back: a formula with a name renders as written, and the file keeps the names.

RENDERED = [
    "=SUM(Items)",
    "=Rate",
    "=Rate*2",
    "=Costs!Rate*2",
    "='Old Costs'!Rate",
    "=SUM('Old Costs'!Items)",
    "=rate_2+1",
    "=(Rate+Seven)*2",
    "=IF(Rate>5, Items, Pair)",
    "=-Rate",
    "=Rate%",
    "=SUM(Items, Prices!Items)",
]


class WrittenBackTest(_Guarded):
    """A formula with a name in it reads to the same tree and writes back as written."""


def _same_tree(self, formula):
    self.assertEqual(parse(rendered_cell(parse(formula))), parse(formula))


def _written_as_typed(self, formula):
    self.assertEqual(rendered_cell(parse(formula)), formula)


each(WrittenBackTest, "test_reads_back_to_the_same_tree", RENDERED, _same_tree)
each(WrittenBackTest, "test_is_written_as_typed", RENDERED, _written_as_typed)


class ShownAsTypedTest(_Guarded):
    """What was typed is what the commands show for a formula with a name."""

    def _file(self):
        desk = named_desk()
        desk.put("C2", "=SUM(Items)*Prices!Rate", "Costs")
        path = written("")
        desk.save(path)
        return path

    def test_show_with_formulas_shows_the_name(self):
        desk = named_desk()
        desk.put("C3", "=Rate*Seven", "Costs")
        path = written("")
        desk.save(path)
        code, said = run("show", path, "--formulas", "--over", "C3:C3")
        self.assertEqual(code, 3)
        self.assertIn("=Rate*Seven", said)

    def test_value_typed_shows_the_name(self):
        code, said = run("value", self._file(), "C2", "--typed")
        self.assertEqual(said, "=SUM(Items)*Prices!Rate")

    def test_csv_with_formulas_shows_the_name(self):
        code, said = run("csv", self._file(), "--formulas")
        self.assertIn("=SUM(Items)*Prices!Rate", said)

    def test_csv_shows_what_the_name_came_to(self):
        code, said = run("csv", self._file(), "--over", "C2:C2")
        self.assertEqual(said, "9900")


class FileTest(_Guarded):
    """Names go in the book file and come back the same."""

    def _round_trip(self, desk):
        text = write_book(desk.book)
        return text, Desk.of_text(text)

    def test_a_saved_book_has_the_same_names(self):
        _, back = self._round_trip(named_desk())
        for sheet, held in NAMES.items():
            self.assertEqual(sorted(names_of(back.sheet(sheet))), sorted(name for name, _ in held))

    def test_a_saved_book_has_names_standing_for_the_same_rectangles(self):
        desk = named_desk()
        _, back = self._round_trip(desk)
        for sheet, held in NAMES.items():
            for name, _ in held:
                self.assertEqual(
                    corners_of(back.sheet(sheet).named(name)), corners_of(desk.sheet(sheet).named(name))
                )

    def test_a_saved_book_comes_to_the_same_answers(self):
        desk = named_desk()
        desk.put("Z1", "=SUM(Items)+Prices!Rate+'Old Costs'!Rate", "Costs")
        _, back = self._round_trip(desk)
        self.assertEqual(back.value_at("Z1", "Costs").written(), "204")

    def test_writing_a_book_with_names_twice_gives_the_same_text(self):
        text, back = self._round_trip(named_desk())
        self.assertEqual(write_book(back.book), text)

    def test_names_survive_a_second_round_trip(self):
        text, back = self._round_trip(named_desk())
        _, again = self._round_trip(back)
        self.assertEqual(sorted(names_of(again.sheet("Costs"))), sorted(names_of(back.sheet("Costs"))))

    def test_a_name_defined_again_is_saved_once(self):
        desk = named_desk()
        desk.define("Rate", "B3", "Costs")
        _, back = self._round_trip(desk)
        self.assertEqual(names_of(back.sheet("Costs")).count("Rate"), 1)
        self.assertEqual(corners_of(back.sheet("Costs").named("Rate")), ("B3", "B3"))

    def test_a_forgotten_name_is_not_saved(self):
        desk = named_desk()
        desk.forget("Seven", "Costs")
        _, back = self._round_trip(desk)
        self.assertNotIn("Seven", names_of(back.sheet("Costs")))

    def test_the_file_keeps_names_on_a_sheet_with_a_space_in_its_name(self):
        _, back = self._round_trip(named_desk())
        self.assertEqual(sorted(names_of(back.sheet("Old Costs"))), ["Items", "Rate"])

    def test_saving_through_the_desk_keeps_the_names(self):
        desk = named_desk()
        path = written("")
        desk.save(path)
        back = Desk.of_file(path)
        self.assertEqual(sorted(names_of(back.sheet("Costs"))), sorted(n for n, _ in NAMES["Costs"]))

    def test_the_book_a_command_reads_has_the_names(self):
        desk = named_desk()
        desk.put("Z1", "=SUM(Items)", "Costs")
        path = written("")
        desk.save(path)
        self.assertEqual(run("value", path, "Z1")[1], "100")

    def test_reading_a_book_with_names_makes_a_book_with_names(self):
        text = write_book(named_desk().book)
        book = read_book(text)
        self.assertEqual(sorted(names_of(book.sheet_named("Prices"))), ["Items", "Rate"])


# ---------------------------------------------------------------------------------------------
# The command line.

class DefineCommandTest(_Guarded):
    """define, like set, works the book out again and writes it with --out."""

    def _file(self):
        desk = plain_desk()
        desk.put("Z1", "=SUM(Items)*Rate", "Costs")
        path = written("")
        desk.save(path)
        return path

    def test_define_with_out_writes_a_book_holding_the_name(self):
        path = self._file()
        out = os.path.join(os.path.dirname(path), "out.book")
        code, said = run("define", path, "Items", "B2:B5", "--out", out)
        run("define", out, "Rate", "B2", "--out", out)
        self.assertEqual(run("value", out, "Z1")[1], "1000")

    def test_define_names_the_sheet_with_the_sheet_option(self):
        path = self._file()
        out = os.path.join(os.path.dirname(path), "out.book")
        run("define", path, "Rate", "B3", "--sheet", "Prices", "--out", out)
        back = Desk.of_file(out)
        self.assertEqual(names_of(back.sheet("Prices")), ("Rate",))
        self.assertEqual(names_of(back.sheet("Costs")), ())

    def test_define_on_the_first_sheet_when_nothing_says_which(self):
        path = self._file()
        out = os.path.join(os.path.dirname(path), "out.book")
        run("define", path, "Rate", "B2", "--out", out)
        self.assertEqual(names_of(Desk.of_file(out).sheet("Costs")), ("Rate",))

    def test_define_comes_back_three_when_a_cell_is_an_error(self):
        path = self._file()
        out = os.path.join(os.path.dirname(path), "out.book")
        code, _ = run("define", path, "Items", "B2:B5", "--out", out)
        self.assertEqual(code, 3)

    def test_define_comes_back_nought_when_nothing_is_an_error(self):
        desk = Desk.empty("b", "S")
        desk.put("A1", "5")
        desk.put("A2", "=Five*2")
        path = written("")
        desk.save(path)
        out = os.path.join(os.path.dirname(path), "out.book")
        code, _ = run("define", path, "Five", "A1", "--out", out)
        self.assertEqual(code, 0)
        self.assertEqual(run("value", out, "A2")[1], "10")

    def test_define_without_out_leaves_the_file_alone(self):
        path = self._file()
        before = open(path, encoding="utf-8").read()
        code, _ = run("define", path, "Items", "B2:B5")
        self.assertEqual(code, 3)
        self.assertEqual(open(path, encoding="utf-8").read(), before)

    def _refused(self, *arguments):
        """The command exists (a good define works), and this define is refused (1 or 2)."""
        path = self._file()
        out = os.path.join(os.path.dirname(path), "out.book")
        self.assertIn(run("define", path, "Good", "B2", "--out", out)[0], (0, 3))
        code, _ = run("define", path, *arguments)
        self.assertIn(code, (1, 2))

    def test_define_refuses_a_name_that_is_a_cell(self):
        self._refused("A1", "B2:B5")

    def test_define_refuses_a_name_that_is_a_function(self):
        self._refused("SUM", "B2:B5")

    def test_define_never_puts_a_rectangle_on_another_sheet(self):
        path = self._file()
        out = os.path.join(os.path.dirname(path), "out.book")
        good = os.path.join(os.path.dirname(path), "good.book")
        self.assertIn(run("define", path, "Good", "B2", "--out", good)[0], (0, 3))
        code, _ = run("define", path, "Items", "Prices!B2:B3", "--sheet", "Costs", "--out", out)
        if not os.path.exists(out):
            self.assertNotEqual(code, 0)
            return
        back = Desk.of_file(out)
        self.assertEqual(names_of(back.sheet("Costs")), ())
        self.assertEqual(names_of(back.sheet("Prices")), ("Items",))

    def test_define_refuses_a_rectangle_across_two_sheets(self):
        self._refused("Items", "B2:Prices!B3")

    def test_define_refuses_a_sheet_that_is_not_there(self):
        self._refused("Items", "B2:B3", "--sheet", "Missing")


class NamesCommandTest(_Guarded):
    """names shows every name in the book, one row each."""

    def _file(self):
        path = written("")
        named_desk().save(path)
        return path

    def test_names_lists_every_name(self):
        code, said = run("names", self._file())
        for sheet, held in NAMES.items():
            for name, _ in held:
                self.assertIn(name, said)

    def test_names_says_which_sheet_each_is_on(self):
        _, said = run("names", self._file())
        self.assertIn("Old Costs", said)
        self.assertIn("Prices", said)

    def test_names_says_what_each_stands_for(self):
        _, said = run("names", self._file())
        self.assertIn("B2:B5", said)
        self.assertIn("D3:E3", said)

    def test_names_has_a_row_for_each_name(self):
        _, said = run("names", self._file())
        rows = [line for line in said.splitlines() if re.search(r"\bRate\b", line)]
        self.assertEqual(len(rows), 3)



    def test_names_has_a_header_row(self):
        _, said = run("names", self._file())
        head = said.splitlines()[0:3]
        self.assertTrue(any("Sheet" in line and "Name" in line for line in head), said)

    def test_names_renders_as_csv_like_the_other_tables(self):
        code, said = run("names", self._file(), "--format", "csv")
        self.assertIn("Items", said)
        self.assertIn("B2:B5", said)

    def test_names_is_a_report_of_the_desk(self):
        desk = named_desk()
        self.assertIn("names", desk.reports())
        self.assertIn("B2:B5", desk.report("names").render("text"))

    def test_names_on_a_book_with_none_comes_back_nought(self):
        path = written("trestle-book 1\nsheet S\n  A1 1\n  A2 =A1+1\n")
        code, _ = run("names", path)
        self.assertEqual(code, 0)


class EvalCommandTest(_Guarded):
    """eval resolves names on the first sheet of the book, or the sheet named."""

    def _file(self):
        path = written("")
        named_desk().save(path)
        return path

    def test_eval_resolves_a_name_on_the_first_sheet(self):
        self.assertEqual(run("eval", "=SUM(Items)", "--book", self._file())[1], "100")

    def test_eval_resolves_a_name_on_the_sheet_named(self):
        said = run("eval", "=SUM(Items)", "--book", self._file(), "--sheet", "Prices")[1]
        self.assertEqual(said, "199")

    def test_eval_resolves_a_name_with_a_sheet_in_front(self):
        self.assertEqual(run("eval", "=Prices!Rate*2", "--book", self._file())[1], "198")

    def test_eval_gives_name_error_for_a_name_the_sheet_lacks(self):
        code, said = run("eval", "=Seven", "--book", self._file(), "--sheet", "Prices")
        self.assertEqual(said, "#NAME?")

    def test_eval_comes_back_nought_for_a_name_that_works(self):
        code, _ = run("eval", "=Rate", "--book", self._file())
        self.assertEqual(code, 0)


class CalcAndShowTest(_Guarded):
    """The commands that work a book out see the names."""

    def _file(self):
        desk = named_desk()
        desk.put("C2", "=SUM(Items)", "Costs")
        desk.put("C3", "=Nothing", "Costs")
        path = written("")
        desk.save(path)
        return path

    def test_show_shows_what_a_name_came_to(self):
        _, said = run("show", self._file(), "--over", "C2:C2")
        self.assertIn("100", said)

    def test_value_shows_what_a_name_came_to(self):
        self.assertEqual(run("value", self._file(), "C2")[1], "100")

    def test_review_reports_an_undefined_name_as_an_error(self):
        _, said = run("review", self._file(), "--only", "errors")
        self.assertIn("#NAME?", said)
        self.assertIn("C3", said)


# ---------------------------------------------------------------------------------------------
# The review.

def _about(review, cell):
    """How many findings of a review are about one cell."""
    return sum(1 for one in review if one.where.endswith("!" + cell) or one.where == cell)


class ReviewTest(_Guarded):
    """A formula reading cells through a name reads cells."""

    def test_a_formula_reading_through_a_name_is_not_a_constant_formula(self):
        desk = named_desk()
        desk.put("Z1", "=SUM(Items)", "Costs")
        self.assertEqual(_about(desk.review(["constant-formula"]), "Z1"), 0)

    def test_a_formula_reading_one_cell_through_a_name_is_not_a_constant_formula(self):
        desk = named_desk()
        desk.put("Z1", "=Rate*2", "Costs")
        self.assertEqual(_about(desk.review(["constant-formula"]), "Z1"), 0)

    def test_a_formula_reading_another_sheets_name_is_not_a_constant_formula(self):
        desk = named_desk()
        desk.put("Z1", "=Costs!Rate*2", "Prices")
        self.assertEqual(_about(desk.review(["constant-formula"]), "Z1"), 0)

    def test_a_formula_with_a_name_and_a_number_is_still_a_written_in_number(self):
        desk = named_desk()
        desk.put("Z1", "=Rate*17", "Costs")
        self.assertEqual(len(desk.review(["written-in-number"])), 1)

    def test_the_whole_review_runs_over_a_book_with_names(self):
        desk = named_desk()
        desk.put("Z1", "=SUM(Items)", "Costs")
        desk.put("Z2", "=Nothing", "Costs")
        found = desk.review()
        self.assertGreaterEqual(len(found), 1)


# ---------------------------------------------------------------------------------------------
# A name for a cell as a corner of a rectangle: the rectangle with that cell held still.

CORNER_SAME_AS = [
    ("=SUM(Start:B5)", "=SUM($B$2:B5)"),
    ("=SUM(B2:Stop)", "=SUM(B2:$B$5)"),
    ("=SUM(Start:Stop)", "=SUM($B$2:$B$5)"),
    ("=SUM(Stop:Start)", "=SUM($B$5:$B$2)"),
    ("=SUM(Start:E3)", "=SUM($B$2:E3)"),
    ("=COUNT(Start:B9)", "=COUNT($B$2:B9)"),
    ("=AVERAGE(Start:Stop)", "=AVERAGE($B$2:$B$5)"),
    ("=MAX(Start:B5)-MIN(Start:B5)", "=MAX($B$2:B5)-MIN($B$2:B5)"),
    ("=INDEX(Start:B5,3)", "=INDEX($B$2:B5,3)"),
    ("=ROWS(Start:B9)", "=ROWS($B$2:B9)"),
    ("=COUNTBLANK(Start:B9)", "=COUNTBLANK($B$2:B9)"),
    ("=Start:B5*2", "=$B$2:B5*2"),
    ("=SUM(Costs!Start:B5)", "=SUM(Costs!$B$2:B5)"),
    ("=SUM(Prices!Start:B3)", "=SUM(Prices!$B$2:B3)"),
    ("=SUM('Old Costs'!Start:B3)", "=SUM('Old Costs'!$B$2:B3)"),
    ("=SUM(Start:B5)+Rate", "=SUM($B$2:B5)+B2"),
]

CORNER_NAMES = {
    "Costs": (("Rate", "B2"), ("Start", "B2"), ("Stop", "B5"), ("Seven", "D1")),
    "Prices": (("Start", "B2"),),
    "Old Costs": (("Start", "B2"),),
}


class CornerTest(_Guarded):
    """A name for one cell as a corner comes to what the held cell as a corner comes to."""


def _corner_same_as(self, case):
    with_name, plain = case
    self.assertEqual(
        value_of(named_desk(CORNER_NAMES), with_name), value_of(plain_desk(), plain)
    )


each(CornerTest, "test_same_answer_as", CORNER_SAME_AS, _corner_same_as)


class CornerSettledLateTest(_Guarded):
    """Which sheet a bare name corner means is the sheet the formula is on."""

    def test_a_bare_name_corner_on_another_sheet_is_that_sheets_name(self):
        desk = named_desk(CORNER_NAMES)
        self.assertEqual(value_of(desk, "=SUM(Start:B3)", sheet="Prices"), "199")
        self.assertEqual(value_of(desk, "=SUM(Start:B3)", sheet="Costs"), "30")

    def test_an_undefined_name_corner_is_a_name_error_from_a_formula_that_reads(self):
        desk = plain_desk()
        self.assertEqual(value_of(desk, "=SUM(Nothing:B5)"), "#NAME?")
        cell = desk.sheet("Costs").cell_at("Z1")
        self.assertTrue(cell.is_formula)
        self.assertFalse(cell.is_broken)

    def test_defining_the_corner_afterwards_makes_the_formula_work(self):
        desk = plain_desk()
        self.assertEqual(value_of(desk, "=SUM(Later:B5)"), "#NAME?")
        desk.define("Later", "B2", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "100")

    def test_a_name_corner_on_a_sheet_not_in_the_book_is_a_reference_error(self):
        self.assertEqual(value_of(named_desk(CORNER_NAMES), "=SUM(Missing!Start:B5)"), "#REF!")


    def test_a_corner_cycle(self):
        self.assertEqual(
            value_of(named_desk(CORNER_NAMES), "=SUM(Start:B9)", where="B4"), "#CYCLE!"
        )

    def test_eval_with_a_name_corner(self):
        path = written("")
        named_desk(CORNER_NAMES).save(path)
        self.assertEqual(run("eval", "=SUM(Start:B5)", "--book", path)[1], "100")


class CornerGraphTest(_Guarded):
    """A name corner reads what the held corner reads."""

    def _links_of(self, desk, formula):
        desk.put("Z1", formula, "Costs")
        desk.recalculate()
        return desk.links(), desk.sheet("Costs").address_of("Z1")

    def test_what_a_cell_reads_through_a_name_corner(self):
        named, at = self._links_of(named_desk(CORNER_NAMES), "=SUM(Start:B5)")
        plain, _ = self._links_of(plain_desk(), "=SUM($B$2:B5)")
        self.assertEqual(named.reads(at), plain.reads(at))
        self.assertEqual(len(named.reads(at)), 4)

    def test_a_cell_inside_the_rectangle_is_read_by_the_formula(self):
        named, at = self._links_of(named_desk(CORNER_NAMES), "=SUM(Start:B5)")
        inside = named_desk().sheet("Costs").address_of("B4")
        self.assertIn(at, named.read_by(inside))

    def test_the_counts_through_a_name_corner_are_the_counts_through_the_rectangle(self):
        named, _ = self._links_of(named_desk(CORNER_NAMES), "=SUM(Start:B5)")
        plain, _ = self._links_of(plain_desk(), "=SUM($B$2:B5)")
        self.assertEqual(named.counts(), plain.counts())

    def test_a_change_inside_a_name_corner_rectangle_is_seen_by_the_desk(self):
        desk = named_desk(CORNER_NAMES)
        desk.put("Z1", "=SUM(Start:B5)", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "100")
        desk.put("B3", "25", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "105")

    def test_redefining_the_corner_name_moves_the_rectangle(self):
        desk = named_desk(CORNER_NAMES)
        desk.put("Z1", "=SUM(Start:B5)", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "100")
        desk.define("Start", "B4", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "70")

    def test_the_sheet_engine_resolves_a_name_corner(self):
        sheet = Sheet("Costs")
        for row, held in ((2, "10"), (3, "20"), (4, "30")):
            sheet.put("B%d" % row, held)
        sheet.define("Start", "B2")
        sheet.put("A1", "=SUM(Start:B4)")
        recalculate(sheet)
        self.assertEqual(sheet.value_at("A1").written(), "60")


def _corner_sheet():
    """One sheet with a name corner formula and the same formula with a held corner."""
    sheet = Sheet("Costs")
    for row, held in ((2, "10"), (3, "20"), (4, "30"), (5, "40")):
        sheet.put("B%d" % row, held)
    sheet.define("Start", "B2")
    sheet.put("A1", "=SUM(Start:B5)")
    sheet.put("C1", "=SUM($B$2:B5)")
    return sheet


class CornerEditingTest(_Guarded):
    """Filling moves the cell corner only; inserting and removing move both like $B$2:B5."""

    def test_filling_down_moves_the_cell_corner_only(self):
        sheet = _corner_sheet()
        sheet.put("C2", "=SUM(Start:B2)")
        filled_across(sheet, "C2", "C2:C5")
        self.assertEqual(sheet.text_at("C5"), "=SUM(Start:B5)")

    def test_a_filled_name_corner_comes_to_the_running_total(self):
        sheet = _corner_sheet()
        sheet.put("C2", "=SUM(Start:B2)")
        filled_across(sheet, "C2", "C2:C5")
        recalculate(sheet)
        self.assertEqual(
            [sheet.value_at("C%d" % row).written() for row in (2, 3, 4, 5)],
            ["10", "30", "60", "100"],
        )

    def test_filling_across_leaves_a_name_corner_where_it_is(self):
        sheet = _corner_sheet()
        sheet.put("D2", "=SUM(Start:B5)")
        filled_across(sheet, "D2", "D2:E2")
        self.assertEqual(sheet.text_at("E2"), "=SUM(Start:C5)")

    def test_a_filled_run_of_name_corner_formulas_is_one_run(self):
        desk = named_desk(CORNER_NAMES)
        desk.put("C2", "=SUM(Start:B2)", "Costs")
        filled_across(desk.sheet("Costs"), "C2", "C2:C5")
        self.assertEqual(desk.value_at("C5", "Costs").written(), "100")
        self.assertEqual(len(desk.review(["odd-one-out"])), 0)

    def _both(self, change):
        named = change(_corner_sheet())
        recalculate(named)
        return named

    def test_inserting_rows_inside_moves_both_corners_like_a_held_corner(self):
        sheet = self._both(lambda held: inserted_rows(held, 3, 2))
        self.assertEqual(sheet.text_at("A1"), "=SUM(Start:B7)")
        self.assertEqual(sheet.value_at("A1").written(), sheet.value_at("C1").written())
        self.assertEqual(sheet.value_at("A1").written(), "100")

    def test_inserting_rows_above_moves_both_corners_like_a_held_corner(self):
        sheet = self._both(lambda held: inserted_rows(held, 1, 1))
        self.assertEqual(sheet.text_at("A2"), "=SUM(Start:B6)")
        self.assertEqual(sheet.value_at("A2").written(), sheet.value_at("C2").written())
        self.assertEqual(corners_of(sheet.named("Start")), ("B3", "B3"))

    def test_removing_rows_inside_shrinks_it_like_a_held_corner(self):
        sheet = self._both(lambda held: removed_rows(held, 4, 1))
        self.assertEqual(sheet.text_at("A1"), "=SUM(Start:B4)")
        self.assertEqual(sheet.value_at("A1").written(), sheet.value_at("C1").written())
        self.assertEqual(sheet.value_at("A1").written(), "70")

    def test_inserting_columns_moves_both_corners_like_a_held_corner(self):
        sheet = self._both(lambda held: inserted_columns(held, 2, 1))
        self.assertEqual(sheet.text_at("A1"), "=SUM(Start:C5)")
        self.assertEqual(sheet.value_at("A1").written(), sheet.value_at("D1").written())

    def test_a_name_corner_is_written_as_typed(self):
        for formula in ("=SUM(Start:B5)", "=SUM(Start:Stop)", "=SUM(Costs!Start:B5)", "=Start:B5"):
            with self.subTest(formula=formula):
                self.assertEqual(rendered_cell(parse(formula)), formula)

    def test_a_name_corner_reads_back_to_the_same_tree(self):
        for formula in ("=SUM(Start:B5)", "=SUM(B2:Stop)", "=SUM('Old Costs'!Start:B3)"):
            with self.subTest(formula=formula):
                self.assertEqual(parse(rendered_cell(parse(formula))), parse(formula))

    def test_renaming_a_sheet_rewrites_the_sheet_in_front_of_a_name_corner(self):
        desk = named_desk(CORNER_NAMES)
        desk.put("A1", "=SUM(Costs!Start:B5)", "Prices")
        desk.recalculate()
        desk.book.rename("Costs", "Spend")
        self.assertEqual(desk.text_at("A1", "Prices"), "=SUM(Spend!Start:B5)")
        desk.recalculate(again=True)
        self.assertEqual(desk.value_at("A1", "Prices").written(), "100")

    def test_a_name_corner_formula_is_not_a_constant_formula(self):
        desk = named_desk(CORNER_NAMES)
        desk.put("Z1", "=SUM(Start:B5)", "Costs")
        self.assertEqual(desk.value_at("Z1", "Costs").written(), "100")
        self.assertEqual(_about(desk.review(["constant-formula"]), "Z1"), 0)

    def test_a_saved_book_with_a_name_corner_comes_to_the_same(self):
        desk = named_desk(CORNER_NAMES)
        desk.put("Z1", "=SUM(Start:Stop)", "Costs")
        back = Desk.of_text(write_book(desk.book))
        self.assertEqual(back.value_at("Z1", "Costs").written(), "100")
        self.assertEqual(back.text_at("Z1", "Costs"), "=SUM(Start:Stop)")


# ---------------------------------------------------------------------------------------------
# The readme and the changelog.

class ReadmeTest(unittest.TestCase):
    """The gap is gone from the list."""

    def test_the_readme_lists_fourteen_gaps(self):
        with open(os.path.join(ROOT, "README.md"), encoding="utf-8") as handle:
            text = handle.read()
        after = text.split("## What it does not do", 1)[1]
        numbered = re.findall(r"^\d+\. \*\*", after, re.M)
        self.assertEqual(len(numbered), 14)

    def test_the_readme_no_longer_says_no_named_ranges(self):
        with open(os.path.join(ROOT, "README.md"), encoding="utf-8") as handle:
            text = handle.read()
        self.assertNotIn("**No named ranges.**", text)


BASE_ENTRIES = 37
BASE_LINES = 74


class ChangelogTest(unittest.TestCase):
    """The changelog records the change."""

    def test_the_changelog_gains_an_entry(self):
        with open(os.path.join(ROOT, "CHANGELOG.md"), encoding="utf-8") as handle:
            text = handle.read()
        lines = [line for line in text.splitlines() if line.strip()]
        entries = [line for line in lines if line.lstrip().startswith(("- ", "* "))]
        self.assertTrue(len(entries) > BASE_ENTRIES or len(lines) > BASE_LINES, (len(entries), len(lines)))


if __name__ == "__main__":
    unittest.main()
