"""Hidden tests, endpoint side: what the search returns for the documented operators, through the
test client against a small mailbox. Every assertion is a set of subjects."""
from datetime import datetime, timedelta, timezone

import pytest

from app.models.attachment import Attachment
from app.models.email_recipient import EmailRecipient
from app.models.label import Label
from app.models.thread_label import ThreadLabel
from app.models.thread_user_metadata import ThreadUserMetadata
from app.models.user import User
from tests.conftest import create_received_email_for_user


def _user(db, first, last, email):
    user = User(first_name=first, last_name=last, email=email, role="user", active=True)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@pytest.fixture
def mailbox(client_with_auth, db_session):
    """The test user's inbox: eight received emails with recipients, attachments, a label and a star."""
    client, token, me = client_with_auth
    headers = {"Authorization": "Bearer %s" % token}
    john = _user(db_session, "John", "Doe", "john@example.com")
    jane = _user(db_session, "Jane", "Roe", "jane@example.com")
    now = datetime.now(timezone.utc)
    made = {}

    def mail(subject, sender, body="body", is_read=False, days_ago=1, cc=(), bcc=(), to=(), attach=()):
        email = create_received_email_for_user(db_session, me, subject=subject, body=body, is_read=is_read, sender=sender)
        email.received_at = now - timedelta(days=days_ago)
        email.sent_at = email.received_at
        for kind, addresses in (("cc", cc), ("bcc", bcc), ("to", to)):
            for address, name in addresses:
                db_session.add(EmailRecipient(email_id=email.id, recipient_email=address, recipient_name=name, recipient_type=kind))
        for name, size in attach:
            db_session.add(Attachment(email_id=email.id, filename=name, content_type="application/octet-stream", size_bytes=size, storage_path="/x/" + name))
        db_session.commit()
        made[subject] = email
        return email

    mail("team meeting notes", john, body="agenda", days_ago=2)
    mail("lunch plans", jane, body="team meeting tomorrow", days_ago=40)
    mail("budget", john, cc=(("bob@example.com", "Bob Builder"),), bcc=(("eve@example.com", "Eve Online"),), days_ago=3)
    mail("report attached", jane, attach=(("report.pdf", 2 * 1024 * 1024),), days_ago=10)
    mail("tiny attachment", jane, attach=(("note.txt", 100),), days_ago=1, is_read=True)
    mail("delivered one", john, to=(("me-alias@example.com", "Me Alias"),), days_ago=5)
    mail("starred thing", jane, days_ago=1, is_read=True)
    mail("quarterly numbers", john, body="the agenda for the team meeting is attached", to=(("second@example.com", "Second Box"),),
         attach=(("quarterly report.pdf", 3000),), days_ago=6)
    parent = Label(name="Projects", owner_id=me.id)
    db_session.add(parent)
    db_session.commit()
    child = Label(name="Client B", owner_id=me.id, parent_id=parent.id)
    db_session.add(child)
    db_session.commit()
    db_session.add(ThreadLabel(thread_id=made["budget"].thread_id, label_id=child.id, user_id=me.id))
    db_session.add(ThreadUserMetadata(thread_id=made["budget"].thread_id, user_id=me.id, is_important=True))
    db_session.commit()
    response = client.patch("/api/v1/emails/%s/star" % made["lunch plans"].id, json={"is_starred": True}, headers=headers)
    assert response.status_code == 200, response.text

    def search(query, **params):
        response = client.get("/api/v1/search", params={"q": query, **params}, headers=headers)
        return response.status_code, response.json()

    def subjects(query, **params):
        code, body = search(query, **params)
        assert code == 200, (query, body)
        return {item["subject"] for item in body["data"]["results"]}

    return client, headers, subjects, search


JOHNS = {"team meeting notes", "budget", "delivered one", "quarterly numbers"}
ALL = JOHNS | {"lunch plans", "report attached", "tiny attachment", "starred thing"}
LAST_WEEK = {"team meeting notes", "budget", "tiny attachment", "delivered one", "starred thing", "quarterly numbers"}

WHOLE_NAMES = [
    ("bcc-address", "bcc:eve@example.com", {"budget"}),
    ("bcc-name", "bcc:Eve", {"budget"}),
    ("bcc-is-not-cc", "bcc:bob@example.com", set()),
    ("deliveredto", "deliveredto:second@example.com", {"quarterly numbers"}),
    ("deliveredto-with-a-word", "deliveredto:second@example.com numbers", {"quarterly numbers"}),
    ("bcc-with-a-word", "bcc:eve@example.com budget", {"budget"}),
    ("to-and-deliveredto-together", "to:second@example.com deliveredto:second@example.com", {"quarterly numbers"}),
    ("bcc-upper-name", "BCC:eve@example.com", {"budget"}),
    ("bcc-and-flag", "bcc:eve@example.com is:unread", {"budget"}),
    ("deliveredto-and-flag", "deliveredto:second@example.com is:unread", {"quarterly numbers"}),
]

QUOTED = [
    ("subject", 'subject:"team meeting"', {"team meeting notes"}),
    ("subject-and-word", 'subject:"team meeting" agenda', {"team meeting notes"}),
    ("from-name", 'from:"John Doe"', JOHNS),
    ("to-name", 'to:"Me Alias"', {"delivered one"}),
    ("cc-name", 'cc:"Bob Builder"', {"budget"}),
    ("bcc-name", 'bcc:"Eve Online"', {"budget"}),
    ("label", 'label:"Client B"', {"budget"}),
    ("filename", 'filename:"quarterly report"', {"quarterly numbers"}),
    ("label-with-flag", 'label:"Client B" is:unread', {"budget"}),
    ("from-name-and-subject", 'from:"John Doe" subject:"team meeting"', {"team meeting notes"}),
    ("to-name-and-flag", 'to:"Me Alias" is:unread', {"delivered one"}),
    ("subject-upper-operator", 'SUBJECT:"team meeting"', {"team meeting notes"}),
    ("label-path-quoted", 'label:"Projects/Client B"', {"budget"}),
]

CASE = [
    ("in-Inbox", "in:Inbox", ALL),
    ("in-INBOX", "in:INBOX", ALL),
    ("in-Sent", "in:Sent", set()),
    ("newer_than-7D", "newer_than:7D", LAST_WEEK),
    ("older_than-1M", "older_than:1M", {"lunch plans"}),
    ("newer_than-2W", "newer_than:2W", LAST_WEEK | {"report attached"}),
    ("in-Spam", "in:Spam", set()),
    ("folder-and-unit", "in:INBOX newer_than:7D", LAST_WEEK),
    ("older_than-1M-with-a-word", "older_than:1M team", {"lunch plans"}),
    ("mixed-case-name", "Older_Than:1M", {"lunch plans"}),
]

KEYWORDS = [
    ("subject-and-body", "team meeting agenda", {"team meeting notes", "quarterly numbers"}),
    ("reversed", "agenda team", {"team meeting notes", "quarterly numbers"}),
    ("two-fields", "notes agenda", {"team meeting notes"}),
    ("any-case", "Agenda TEAM", {"team meeting notes", "quarterly numbers"}),
    ("with-an-operator", "from:john agenda team", {"team meeting notes", "quarterly numbers"}),
    ("with-a-flag", "is:unread agenda team", {"team meeting notes", "quarterly numbers"}),
    ("three-words-one-email", "quarterly agenda attached", {"quarterly numbers"}),
    ("words-and-a-phrase", '"team meeting" agenda notes', {"team meeting notes"}),
    ("words-and-attachment-flag", "has:attachment agenda team", {"quarterly numbers"}),
    ("words-in-capitals-with-a-flag", "is:unread AGENDA Team", {"team meeting notes", "quarterly numbers"}),
    ("two-words-in-the-body", "tomorrow team", {"lunch plans"}),
    ("words-and-a-sender", 'from:"John Doe" agenda team', {"team meeting notes", "quarterly numbers"}),
    ("words-and-a-label", 'label:"Client B" budget', {"budget"}),
    ("word-in-subject-word-in-body-with-exclusion", "notes agenda -quarterly", {"team meeting notes"}),
]


def test_free_words_are_not_one_phrase(mailbox):
    """The same words find the mail whatever their order, and only as a phrase do they need to touch."""
    _, headers, subjects, _ = mailbox
    assert subjects("agenda team meeting") == subjects("team meeting agenda") == {"team meeting notes", "quarterly numbers"}
    assert subjects('"agenda team meeting"') == set()


def test_a_quoted_operator_value_is_not_searched_as_free_text(mailbox):
    """subject:"team meeting" must not match the mail whose body holds the phrase."""
    _, headers, subjects, _ = mailbox
    found = subjects('subject:"team meeting"')
    assert "lunch plans" not in found and "quarterly numbers" not in found
    assert found == {"team meeting notes"}


def test_bcc_and_cc_are_told_apart_both_ways(mailbox):
    _, headers, subjects, _ = mailbox
    assert subjects("bcc:eve@example.com") == {"budget"}
    assert subjects("bcc:bob@example.com") == set()
    assert subjects("cc:bob@example.com") == {"budget"}
    assert subjects("cc:eve@example.com") == set()


@pytest.mark.parametrize("case", WHOLE_NAMES, ids=[c[0] for c in WHOLE_NAMES])
def test_an_operator_is_its_whole_name(mailbox, case):
    _, headers, subjects, _ = mailbox
    _, query, expected = case
    assert subjects(query) == expected


@pytest.mark.parametrize("case", QUOTED, ids=[c[0] for c in QUOTED])
def test_a_quoted_value_belongs_to_its_operator(mailbox, case):
    _, headers, subjects, _ = mailbox
    _, query, expected = case
    assert subjects(query) == expected


@pytest.mark.parametrize("case", CASE, ids=[c[0] for c in CASE])
def test_a_value_is_read_whatever_its_case(mailbox, case):
    _, headers, subjects, _ = mailbox
    _, query, expected = case
    assert subjects(query) == expected


def test_a_folder_in_capitals_is_not_refused(mailbox):
    _, headers, subjects, search = mailbox
    code, body = search("in:Inbox")
    assert code == 200, body
    assert subjects("in:Inbox") == subjects("in:inbox")


@pytest.mark.parametrize("case", KEYWORDS, ids=[c[0] for c in KEYWORDS])
def test_free_words_are_keywords(mailbox, case):
    _, headers, subjects, _ = mailbox
    _, query, expected = case
    assert subjects(query) == expected


SUGGESTED = [
    ("From", "From:j", "contacts", {"john@example.com", "jane@example.com"}),
    ("FROM", "FROM:j", "contacts", {"john@example.com", "jane@example.com"}),
    ("TO", "TO:j", "contacts", {"john@example.com", "jane@example.com"}),
    ("Label", "Label:cli", "labels", {"Projects/Client B"}),
    ("LABEL", "LABEL:cli", "labels", {"Projects/Client B"}),
    ("In", "In:in", "folders", {"inbox"}),
    ("IN", "IN:IN", "folders", {"inbox"}),
    ("Category", "Category:p", "categories", {"primary", "promotions"}),
]


@pytest.mark.parametrize("case", SUGGESTED, ids=[c[0] for c in SUGGESTED])
def test_suggestions_read_an_operator_whatever_its_case(mailbox, case):
    client, headers, _, _ = mailbox
    _, query, kind, expected = case
    response = client.get("/api/v1/search/suggestions", params={"q": query}, headers=headers)
    assert response.status_code == 200, response.text
    values = {item["value"] for item in response.json()["data"][kind]}
    assert expected <= values
    lower = client.get("/api/v1/search/suggestions", params={"q": query.lower()}, headers=headers)
    assert values == {item["value"] for item in lower.json()["data"][kind]}
