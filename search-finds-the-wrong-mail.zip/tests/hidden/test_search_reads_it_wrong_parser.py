"""Hidden tests, parser side: an operator is its whole name, a quoted value belongs to it, case does
not matter. No database: these only call parse_search_query."""
from datetime import timedelta

import pytest

from app.utils.search_utils import parse_search_query


def _no_text(parsed):
    """Nothing an operator consumed is left over as free text, whatever key a design keeps it under."""
    leftovers = [parsed.get(k) for k in ("text", "keywords", "words", "terms") if parsed.get(k)]
    return not leftovers


WHOLE_NAMES = [
    ("bcc-address", "bcc:eve@example.com", "bcc_email", "eve@example.com", ("cc_email", "to_email")),
    ("bcc-name", "bcc:Eve", "bcc_email", "Eve", ("cc_email", "to_email")),
    ("deliveredto-address", "deliveredto:a@x.com", "deliveredto", "a@x.com", ("to_email", "cc_email")),
    ("bcc-upper", "BCC:eve@example.com", "bcc_email", "eve@example.com", ("cc_email", "to_email")),
    ("deliveredto-upper", "DeliveredTo:a@x.com", "deliveredto", "a@x.com", ("to_email", "cc_email")),
    ("bcc-beside-a-flag", "bcc:eve@example.com is:unread", "bcc_email", "eve@example.com", ("cc_email",)),
    ("deliveredto-beside-a-flag", "has:attachment deliveredto:a@x.com", "deliveredto", "a@x.com", ("to_email",)),
]

TWO_OPERATORS = [
    ("cc-and-bcc", "cc:bob@example.com bcc:eve@example.com", {"cc_email": "bob@example.com", "bcc_email": "eve@example.com"}),
    ("to-and-deliveredto", "to:a@x.com deliveredto:b@x.com", {"to_email": "a@x.com", "deliveredto": "b@x.com"}),
    ("bcc-and-to", "bcc:eve@example.com to:me", {"bcc_email": "eve@example.com", "to_email": "me"}),
    ("deliveredto-and-from", "deliveredto:b@x.com from:john", {"deliveredto": "b@x.com", "from_email": "john"}),
]


@pytest.mark.parametrize("case", TWO_OPERATORS, ids=[c[0] for c in TWO_OPERATORS])
def test_two_operators_with_a_shared_ending_are_both_read(case):
    _, query, expected = case
    parsed = parse_search_query(query)
    for key, value in expected.items():
        assert parsed.get(key) == value
    assert _no_text(parsed)


@pytest.mark.parametrize("case", WHOLE_NAMES, ids=[c[0] for c in WHOLE_NAMES])
def test_an_operator_is_its_whole_name(case):
    _, query, key, value, absent = case
    parsed = parse_search_query(query)
    assert parsed.get(key) == value
    for other in absent:
        assert other not in parsed
    assert _no_text(parsed)


def test_a_word_after_bcc_is_the_only_free_text():
    parsed = parse_search_query("bcc:eve@example.com report")
    assert parsed.get("bcc_email") == "eve@example.com"
    assert "cc_email" not in parsed
    words = " ".join(str(parsed.get(k, "")) for k in ("text", "keywords", "words", "terms"))
    assert "report" in words and "b " not in (words + " ") and words.strip() != "b"


def test_a_word_after_deliveredto_is_the_only_free_text():
    parsed = parse_search_query("deliveredto:a@x.com report")
    assert parsed.get("deliveredto") == "a@x.com"
    assert "to_email" not in parsed
    words = " ".join(str(parsed.get(k, "")) for k in ("text", "keywords", "words", "terms"))
    assert "report" in words and "delivered" not in words


QUOTED = [
    ("subject", 'subject:"team meeting"', "subject", "team meeting"),
    ("from", 'from:"John Doe"', "from_email", "John Doe"),
    ("to", 'to:"Me Alias"', "to_email", "Me Alias"),
    ("cc", 'cc:"Bob Builder"', "cc_email", "Bob Builder"),
    ("bcc", 'bcc:"Eve Online"', "bcc_email", "Eve Online"),
    ("label", 'label:"Client B"', "label_name", "Client B"),
    ("filename", 'filename:"quarterly report.pdf"', "filename", "quarterly report.pdf"),
    ("deliveredto", 'deliveredto:"a@x.com"', "deliveredto", "a@x.com"),
    ("subject-upper-operator", 'SUBJECT:"team meeting"', "subject", "team meeting"),
    ("from-three-words", 'from:"John Q Doe"', "from_email", "John Q Doe"),
    ("label-with-a-slash", 'label:"Projects/Client B"', "label_name", "Projects/Client B"),
]

QUOTED_WITH_MORE = [
    ("subject-then-flag", 'subject:"team meeting" is:unread', {"subject": "team meeting", "is_read": False}),
    ("flag-then-subject", 'is:starred subject:"team meeting"', {"subject": "team meeting", "is_starred": True}),
    ("two-quoted-operators", 'from:"John Doe" subject:"team meeting"', {"from_email": "John Doe", "subject": "team meeting"}),
    ("quoted-label-and-flag", 'label:"Client B" is:unread', {"label_name": "Client B", "is_read": False}),
    ("quoted-and-bare-operator", 'to:"Me Alias" has:attachment', {"to_email": "Me Alias", "has_attachment": True}),
]


@pytest.mark.parametrize("case", QUOTED_WITH_MORE, ids=[c[0] for c in QUOTED_WITH_MORE])
def test_a_quoted_value_sits_beside_other_operators(case):
    _, query, expected = case
    parsed = parse_search_query(query)
    for key, value in expected.items():
        assert parsed.get(key) == value
    assert not parsed.get("exact_phrases")
    assert _no_text(parsed)


def test_a_quoted_value_keeps_free_words_apart():
    parsed = parse_search_query('subject:"team meeting" agenda')
    assert parsed.get("subject") == "team meeting"
    assert not parsed.get("exact_phrases")
    words = " ".join(str(parsed.get(k, "")) for k in ("text", "keywords", "words", "terms"))
    assert "agenda" in words and "subject" not in words and "meeting" not in words


@pytest.mark.parametrize("case", QUOTED, ids=[c[0] for c in QUOTED])
def test_a_quoted_value_belongs_to_its_operator(case):
    _, query, key, value = case
    parsed = parse_search_query(query)
    assert parsed.get(key) == value
    assert not parsed.get("exact_phrases")
    assert _no_text(parsed)


def test_a_quoted_subject_and_a_quoted_phrase_are_kept_apart():
    parsed = parse_search_query('subject:"team meeting" "agenda item"')
    assert parsed.get("subject") == "team meeting"
    assert parsed.get("exact_phrases") == ["agenda item"]
    assert _no_text(parsed)


def test_a_quoted_sender_mixes_with_a_flag():
    parsed = parse_search_query('from:"John Doe" is:unread')
    assert parsed.get("from_email") == "John Doe"
    assert parsed.get("is_read") is False
    assert _no_text(parsed)


FOLDER_CASE = [("Inbox", "in:Inbox"), ("INBOX", "in:INBOX"), ("Sent", "in:Sent"), ("Trash", "in:Trash"), ("mixed", "In:DrAfTs"),
               ("Spam", "in:Spam"), ("Scheduled", "IN:SCHEDULED")]


@pytest.mark.parametrize("case", FOLDER_CASE, ids=[c[0] for c in FOLDER_CASE])
def test_a_folder_value_is_read_whatever_its_case(case):
    _, query = case
    parsed = parse_search_query(query)
    assert parsed.get("folder_type") == query.split(":", 1)[1].lower()
    assert _no_text(parsed)


UNITS = [("7D", "newer_than:7D", "newer_than:7d", "date_from"), ("1M", "older_than:1M", "older_than:1m", "date_to"),
         ("2W", "newer_than:2W", "newer_than:2w", "date_from"), ("1Y", "older_than:1Y", "older_than:1y", "date_to"),
         ("upper-name", "NEWER_THAN:3D", "newer_than:3d", "date_from"), ("Older_Than-mixed", "Older_Than:2W", "older_than:2w", "date_to"),
         ("with-a-folder", "in:Inbox newer_than:7D", "in:inbox newer_than:7d", "date_from")]


def test_a_capital_unit_and_a_capital_folder_together():
    parsed = parse_search_query("in:Inbox older_than:1M")
    assert parsed.get("folder_type") == "inbox"
    assert parsed.get("date_to") is not None
    assert _no_text(parsed)


@pytest.mark.parametrize("case", UNITS, ids=[c[0] for c in UNITS])
def test_a_relative_date_unit_is_read_whatever_its_case(case):
    _, upper, lower, key = case
    got, want = parse_search_query(upper), parse_search_query(lower)
    assert got.get(key) is not None and want.get(key) is not None
    assert abs(got[key] - want[key]) < timedelta(seconds=5)
    assert _no_text(got)
