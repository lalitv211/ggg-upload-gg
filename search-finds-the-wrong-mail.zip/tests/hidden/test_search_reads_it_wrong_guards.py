"""Hidden guards: searches that already answer right at the base keep answering right."""
import pytest

from app.utils.search_utils import parse_search_query
from tests.test_hidden_test_search_reads_it_wrong_endpoint import ALL, JOHNS, LAST_WEEK, mailbox  # noqa: F401

STILL_RIGHT = [
    ("from-address", "from:john@example.com", JOHNS),
    ("from-name-partial", "from:John", JOHNS),
    ("from-upper", "FROM:JOHN@EXAMPLE.COM", JOHNS),
    ("from-two-addresses", "from:john@example.com,jane@example.com", ALL),
    ("to-me", "to:me", ALL),
    ("to-address", "to:me-alias@example.com", {"delivered one"}),
    ("cc-address", "cc:bob@example.com", {"budget"}),
    ("cc-is-not-bcc", "cc:eve@example.com", set()),
    ("cc-and-bcc-together", "cc:bob@example.com bcc:eve@example.com", {"budget"}),
    ("phrase-words-and-an-exclusion", "team meeting -notes", {"lunch plans", "quarterly numbers"}),
    ("quoted-phrase-must-be-as-written", '"team meeting agenda"', set()),
    ("cc-name", "cc:Bob", {"budget"}),
    ("subject-word", "subject:meeting", {"team meeting notes"}),
    ("subject-any-case", "subject:Team", {"team meeting notes"}),
    ("subject-group", "subject:(lunch budget)", {"budget", "lunch plans"}),
    ("bare-phrase", '"team meeting"', {"lunch plans", "team meeting notes", "quarterly numbers"}),
    ("one-word", "agenda", {"team meeting notes", "quarterly numbers"}),
    ("has-attachment", "has:attachment", {"report attached", "tiny attachment", "quarterly numbers"}),
    ("has-attachment-any-case", "has:Attachment", {"report attached", "tiny attachment", "quarterly numbers"}),
    ("filename", "filename:report", {"report attached", "quarterly numbers"}),
    ("filename-extension", "filename:pdf", {"report attached", "quarterly numbers"}),
    ("size", "size:2M", {"report attached"}),
    ("larger", "larger:1M", {"report attached"}),
    ("larger-lower-unit", "larger:1m", {"report attached"}),
    ("smaller", "smaller:1K", ALL - {"report attached", "quarterly numbers"}),
    ("is-read", "is:read", {"tiny attachment", "starred thing"}),
    ("is-unread", "is:unread", ALL - {"tiny attachment", "starred thing"}),
    ("is-unread-any-case", "is:Unread", ALL - {"tiny attachment", "starred thing"}),
    ("is-important", "is:important", {"budget"}),
    ("is-starred", "is:starred", {"lunch plans"}),
    ("in-starred", "in:starred", {"lunch plans"}),
    ("in-inbox", "in:inbox", ALL),
    ("in-upper-name", "IN:inbox", ALL),
    ("in-anywhere", "in:anywhere", ALL),
    ("label-leaf", "label:Client B", {"budget"}),
    ("label-path", "label:Projects/Client B", {"budget"}),
    ("label-any-case", "label:projects/client b", {"budget"}),
    ("label-partial", "label:client", {"budget"}),
    ("has-userlabels", "has:userlabels", {"budget"}),
    ("has-nouserlabels", "has:nouserlabels", ALL - {"budget"}),
    ("newer-than", "newer_than:7d", LAST_WEEK),
    ("older-than", "older_than:30d", {"lunch plans"}),
    ("newer-than-month", "newer_than:1m", ALL - {"lunch plans"}),
    ("exclusion", "meeting -lunch", {"team meeting notes", "quarterly numbers"}),
    ("exclusion-body", "meeting -agenda", {"lunch plans"}),
    ("or-group", "lunch OR budget", {"budget", "lunch plans"}),
    ("exact-word", "+agenda", {"team meeting notes", "quarterly numbers"}),
    ("category-primary", "category:primary", ALL),
    ("flag-and-operator", "is:unread from:john", JOHNS),
    ("nothing", "nothing-matches-this", set()),
    ("from-other-sender", "from:jane", ALL - JOHNS),
    ("from-me-is-nobody", "from:me", set()),
    ("two-flags", "is:unread has:attachment", {"report attached", "quarterly numbers"}),
    ("phrase-and-flag", '"team meeting" is:read', set()),
    ("one-word-in-capitals", "AGENDA", {"team meeting notes", "quarterly numbers"}),
    ("exclusion-of-a-sender-word", "agenda -quarterly", {"team meeting notes"}),
    ("or-with-a-flag", "lunch OR budget is:unread", {"budget", "lunch plans"}),
    ("filename-any-case", "filename:REPORT", {"report attached", "quarterly numbers"}),
    ("label-leaf-any-case", "label:client b", {"budget"}),
    ("size-larger-and-flag", "larger:1M is:unread", {"report attached"}),
    ("date-before", "before:%s" % __import__("datetime").date.today().isoformat(), ALL),
]


@pytest.mark.parametrize("case", STILL_RIGHT, ids=[c[0] for c in STILL_RIGHT])
def test_a_search_that_answered_right_still_does(mailbox, case):
    _, headers, subjects, _ = mailbox
    _, query, expected = case
    assert subjects(query) == expected


def test_the_page_size_still_bounds_a_search(mailbox):
    client, headers, subjects, search = mailbox
    code, body = search("to:me", page_size=3)
    assert code == 200
    assert len(body["data"]["results"]) == 3
    assert body["data"]["total"] == 8


def test_a_search_still_pages(mailbox):
    client, headers, subjects, search = mailbox
    first = search("to:me", page_size=5, page=1)[1]["data"]["results"]
    second = search("to:me", page_size=5, page=2)[1]["data"]["results"]
    assert len(first) == 5 and len(second) == 3
    assert {item["subject"] for item in first}.isdisjoint({item["subject"] for item in second})


def test_an_unknown_category_is_still_refused(mailbox):
    _, headers, subjects, search = mailbox
    code, body = search("category:nope")
    assert code == 400


def test_suggestions_still_name_contacts_and_labels(mailbox):
    client, headers, subjects, search = mailbox
    response = client.get("/api/v1/search/suggestions", params={"q": "from:j"}, headers=headers)
    assert response.status_code == 200
    contacts = {item["value"] for item in response.json()["data"]["contacts"]}
    assert {"john@example.com", "jane@example.com"} <= contacts
    response = client.get("/api/v1/search/suggestions", params={"q": "label:cli"}, headers=headers)
    assert [item["value"] for item in response.json()["data"]["labels"]] == ["Projects/Client B"]


PARSER_STILL_RIGHT = [
    ("from", "from:john@example.com", {"from_email": "john@example.com"}),
    ("to", "to:team@example.com", {"to_email": "team@example.com"}),
    ("cc", "cc:bob@example.com", {"cc_email": "bob@example.com"}),
    ("subject", "subject:meeting", {"subject": "meeting"}),
    ("subject-single-quotes", "subject:'single quoted'", {"subject": "single quoted"}),
    ("has-attachment", "has:attachment", {"has_attachment": True}),
    ("is-starred", "is:starred", {"is_starred": True}),
    ("is-unread", "is:unread", {"is_read": False}),
    ("is-read", "is:read", {"is_read": True}),
    ("is-important", "is:important", {"is_important": True}),
    ("in-inbox", "in:inbox", {"folder_type": "inbox"}),
    ("in-anywhere", "in:anywhere", {"in_anywhere": True}),
    ("in-snoozed", "in:snoozed", {"is_snoozed": True}),
    ("label", "label:work", {"label_name": "work"}),
    ("label-multiword-then-operator", "label:projects client b from:john", {"from_email": "john", "label_name": "projects client b"}),
    ("category", "category:primary", {"category": "primary"}),
    ("filename", "filename:report.pdf", {"filename": "report.pdf"}),
    ("size", "size:10M", {"size": 10 * 1024 * 1024}),
    ("larger", "larger:1M", {"size_larger": 1024 * 1024}),
    ("smaller", "smaller:500K", {"size_smaller": 500 * 1024}),
    ("has-userlabels", "has:userlabels", {"has_userlabels": True}),
    ("has-nouserlabels", "has:nouserlabels", {"has_userlabels": False}),
    ("exclusion", "meeting -spam", {"exclusions": ["spam"]}),
    ("or-group", "dinner OR movie", {"or_groups": [["dinner", "movie"]]}),
    ("grouped", "subject:(dinner movie)", {"grouped_terms": {"subject": ["dinner", "movie"]}}),
    ("exact-match", "+report", {"exact_matches": ["report"]}),
    ("upper-operator", "FROM:John@Example.com", {"from_email": "John@Example.com"}),
]


@pytest.mark.parametrize("case", PARSER_STILL_RIGHT, ids=[c[0] for c in PARSER_STILL_RIGHT])
def test_the_parser_still_reads_what_it_read(case):
    _, query, expected = case
    parsed = parse_search_query(query)
    for key, value in expected.items():
        assert parsed.get(key) == value


def test_a_before_and_after_pair_still_give_two_dates():
    parsed = parse_search_query("before:2024-12-31 after:2024-01-01")
    assert parsed["date_from"].date().isoformat() == "2024-01-01"
    assert parsed["date_to"].date().isoformat() == "2024-12-31"


def test_free_words_are_still_carried():
    parsed = parse_search_query("report from:john has:attachment is:unread")
    assert parsed.get("from_email") == "john" and parsed.get("has_attachment") is True and parsed.get("is_read") is False
    words = " ".join(str(parsed.get(k, "")) for k in ("text", "keywords", "words", "terms"))
    assert "report" in words
