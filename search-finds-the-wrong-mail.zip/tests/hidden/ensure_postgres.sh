#!/bin/bash
# Make sure a PostgreSQL server answers for the backend tests, and print the DATABASE_URL to use.
#
# If the server named by DATABASE_URL (or the tests' default, 127.0.0.1:5436) already answers,
# nothing is done. Otherwise, when the image holds a PostgreSQL server, one is started for this
# command: as the current user from a data directory under its home when that user is not root
# (PostgreSQL will not run as root), or as the postgres account when it is. The caller evals the
# output, which is one `export DATABASE_URL=...` line or nothing.
# Standard library and the backend's own dependencies only.
python - <<'PY' && exit 0
import os, sys
import psycopg2
url = os.environ.get("DATABASE_URL", "postgresql+psycopg2://mailg:mailg@127.0.0.1:5436/postgres").replace("+psycopg2", "")
try:
    psycopg2.connect(url, connect_timeout=3).close()
except Exception:
    sys.exit(1)
PY
PGBIN="$(ls -d /usr/lib/postgresql/*/bin 2>/dev/null | head -1)"
[ -n "$PGBIN" ] || { echo "no PostgreSQL server answers and none is installed" >&2; exit 0; }
PORT=5432
if [ "$(id -u)" = "0" ]; then
  PGDATA=/var/lib/postgresql/verifier
  mkdir -p "$PGDATA" && chown postgres:postgres "$PGDATA"
  as_pg() { su postgres -c "$*"; }
else
  # The first writable place wins: the user's home, the command's own directory, then /tmp.
  PGDATA=""
  for candidate in "${HOME:-}/verifier-pgdata" "${VERIFIER_DIR:-}/pgdata"; do
    case "$candidate" in /*) ;; *) continue ;; esac
    if mkdir -p "$candidate" 2>/dev/null && [ -w "$candidate" ]; then PGDATA="$candidate"; break; fi
  done
  [ -n "$PGDATA" ] || PGDATA="$(mktemp -d /tmp/verifier-pgdata.XXXXXX)" || { echo "nowhere to put a data directory" >&2; exit 0; }
  as_pg() { bash -c "$*"; }
fi
if [ ! -f "$PGDATA/PG_VERSION" ]; then
  as_pg "$PGBIN/initdb -D '$PGDATA' --auth=trust -U mailg" >/dev/null 2>&1 || { echo "initdb failed" >&2; exit 0; }
fi
as_pg "$PGBIN/pg_ctl -D '$PGDATA' -l '$PGDATA/server.log' -o '-c listen_addresses=127.0.0.1 -p $PORT -c unix_socket_directories=$PGDATA' start" >/dev/null 2>&1
for i in $(seq 1 30); do as_pg "$PGBIN/pg_isready -h 127.0.0.1 -p $PORT" >/dev/null 2>&1 && break; sleep 1; done
echo "export DATABASE_URL=postgresql+psycopg2://mailg:mailg@127.0.0.1:$PORT/postgres"
