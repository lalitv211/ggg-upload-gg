Search finds the wrong mail in few cases and readme operator table says otherwise. Try bcc:eve@example.com, it gives nothing even when Eve is in bcc. Looks like bcc: is read as cc: and a stray b is searched as text. Operator should be read as its whole name, and nothing it took should be left as search text.

Value in quotes is lost too. subject:"team meeting" returns nothing, same for from:"John Doe" and label:"Client B". Quotes should belong to the operator, for each operator which takes value. Without quotes it works like now.

Case is odd. FROM: and IS:UNREAD work, but in:Inbox gives 400 and newer_than:7D quietly drops the date, so all mail comes back. Case should not matter in operator and in its value, everywhere.

Plain words are searched as one phrase. Mail with "team meeting" in subject and "agenda" in body is not found by team meeting agenda. Readme says keywords. Each word should be found in subject or body, in any of them. Phrase in quotes still has to be found as written in one field. -word, OR and +word work like today.

Please keep readme search operators part in line with this. Please add tests for all of it.
