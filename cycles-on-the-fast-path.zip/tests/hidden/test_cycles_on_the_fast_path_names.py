"""Sheet names that match in any case (README gap 13), the third part of cycles-on-the-fast-path.

A sheet name matches a sheet whose name differs only in case, the way function names already do:
in a formula, in every lookup on a book or a desk, in renaming and removing. Names are kept as
they were typed, and a book never holds two sheets whose names differ only in case. The fast path
and the cycles follow: a change reaches a reader that wrote the sheet's name in another case, and
a cycle across sheets named that way settles. Standard library only: unittest, one method per case.
"""

import os
import signal
import unittest

import trestle.graph.links as links_module
from trestle import Desk, write_book
from trestle.errors import TrestleError
from trestle.sheet import Sheet
from trestle.store import read_book

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHEETS = 12
ROWS = 20


def _stop(signum, frame):
    raise AssertionError("took too long")


class _Guarded(unittest.TestCase):
    """A test that hangs fails rather than waits, and the note counter is always put back."""

    def setUp(self):
        signal.signal(signal.SIGALRM, _stop)
        signal.alarm(120)
        self.notes = 0
        original = links_module.Links.note
        self._original_note = original
        test = self

        def counting(held, where, tree, filled=True):
            test.notes += 1
            return original(held, where, tree, filled)

        links_module.Links.note = counting

    def tearDown(self):
        links_module.Links.note = self._original_note
        signal.alarm(0)

    def reset(self):
        self.notes = 0


COSTS = (
    "trestle-book 1\n"
    "name Names\n"
    "sheet Main\n"
    "  B1 =costs!A1*2\n"
    "  B2 =COSTS!A1+1\n"
    "  B3 =SUM(cOsTs!A1:A3)\n"
    "sheet Costs\n"
    "  A1 5\n"
    "  A2 7\n"
)


def big_book(sheets=SHEETS, rows=ROWS):
    """Chained sheets, each sheet's B1 reading the one before it with its name in lower case."""
    lines = ["trestle-book 1", "name Big"]
    for k in range(1, sheets + 1):
        lines.append("sheet S%d" % k)
        lines.append("  A1 %d" % k)
        for row in range(2, rows + 2):
            lines.append("  A%d =A%d+1" % (row, row - 1))
        if k > 1:
            lines.append("  B1 =s%d!A%d+1" % (k - 1, rows + 1))
    return "\n".join(lines) + "\n"


def chain(k, rows=ROWS):
    return {"S%d!A%d" % (k, row) for row in range(2, rows + 2)}


def readers_of(k):
    return {"S%d!B1" % (k + 1)} if k < SHEETS else set()


def traced(desk):
    return [step.at.written() for step in desk.trace()]


def fresh(desk):
    held = Desk.of_text(write_book(desk.book))
    held.recalculate()
    return held


def values_of(desk):
    found = {}
    for sheet in desk.book.sheets():
        for address, cell in sheet.cells():
            found[address.in_sheet(sheet.name).written()] = desk.value_at(
                address.in_sheet(sheet.name)).written()
    return found


def same_as_fresh(test, desk):
    other = fresh(desk)
    test.assertEqual(values_of(desk), values_of(other))
    test.assertEqual(set(desk.links().edges()), set(other.links().edges()))
    test.assertEqual([one.written() for one in desk.order()], [one.written() for one in other.order()])
    test.assertEqual(desk.review().summary(), other.review().summary())


class LookupTest(_Guarded):
    """A name in a formula or a lookup finds the sheet whatever its case."""

    def test_a_formula_naming_a_sheet_in_another_case_reads_it(self):
        desk = Desk.of_text(COSTS)
        desk.recalculate()
        self.assertEqual(desk.value_at("Main!B1").written(), "10")
        self.assertEqual(desk.value_at("Main!B2").written(), "6")
        self.assertEqual(desk.value_at("Main!B3").written(), "12")

    def test_the_desk_finds_a_sheet_in_any_case(self):
        desk = Desk.of_text(COSTS)
        desk.recalculate()
        self.assertEqual(desk.sheet("COSTS").name, "Costs")
        self.assertEqual(desk.value_at("costs!A1").written(), "5")
        self.assertEqual(desk.text_at("A2", sheet="cOSTS"), "7")
        desk.put("costs!A3", 9)
        self.assertEqual(desk.value_at("Costs!A3").written(), "9")
        self.assertEqual(desk.value_at("Main!B3").written(), "21")

    def test_the_book_finds_a_sheet_in_any_case(self):
        book = read_book(COSTS)
        self.assertEqual(book.sheet_named("costs").name, "Costs")
        self.assertIn("COSTS", book)
        book.recalculate()
        self.assertEqual(book.value_at("cosTS!A2").written(), "7")

    def test_nothing_is_called_missing(self):
        desk = Desk.of_text(COSTS)
        desk.recalculate()
        self.assertEqual(tuple(desk.book.missing_sheets()), ())
        self.assertEqual(len(desk.review(only=["missing-sheet"])), 0)


class OneBookOneCaseTest(_Guarded):
    """A book never holds two sheets whose names differ only in case."""

    def test_adding_a_sheet_in_another_case_is_refused(self):
        book = read_book(COSTS)
        with self.assertRaises(TrestleError):
            book.add(Sheet("costs"))
        self.assertEqual(tuple(book.names()), ("Main", "Costs"))

    def test_a_file_with_both_is_refused(self):
        with self.assertRaises(TrestleError):
            read_book(COSTS + "sheet COSTS\n  A1 1\n")

    def test_renaming_onto_another_sheet_in_another_case_is_refused(self):
        book = read_book(COSTS)
        with self.assertRaises(TrestleError):
            book.rename("Main", "COSTS")
        self.assertEqual(tuple(book.names()), ("Main", "Costs"))

    def test_a_sheet_renamed_to_another_case_of_itself_keeps_its_values(self):
        desk = Desk.of_text(COSTS)
        desk.recalculate()
        desk.book.rename("costs", "COSTS")
        self.assertEqual(tuple(desk.book.names()), ("Main", "COSTS"))
        desk.recalculate()
        self.assertEqual(desk.value_at("Main!B1").written(), "10")
        self.assertEqual(desk.value_at("Main!B3").written(), "12")

    def test_renaming_rewrites_formulas_that_named_it_in_any_case(self):
        book = read_book(COSTS)
        book.rename("Costs", "Spend")
        self.assertEqual(book.sheet_named("Main").text_at("B1"), "=Spend!A1*2")
        self.assertEqual(book.sheet_named("Main").text_at("B2"), "=Spend!A1+1")
        book.recalculate()
        self.assertEqual(book.value_at("Main!B3").written(), "12")


class FastPathTest(_Guarded):
    """The fast path finds the readers that wrote a sheet's name in another case."""

    def test_a_change_reaches_a_reader_that_wrote_the_sheet_in_another_case(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.put("S4!A1", 1000)
        self.assertEqual(desk.value_at("S5!B1").written(), "1021")
        self.assertEqual(set(traced(desk)), chain(4) | readers_of(4))
        self.assertLessEqual(self.notes, ROWS + 1)

    def test_a_new_reader_in_another_case_counts_from_then_on(self):
        desk = Desk.of_text(big_book())
        desk.put("S9!C1", "=SUM(s4!A1:A21)")
        desk.recalculate()
        self.reset()
        desk.put("S4!A1", 100)
        self.assertEqual(desk.value_at("S9!C1").written(), fresh(desk).value_at("S9!C1").written())
        self.assertEqual(set(traced(desk)), chain(4) | readers_of(4) | {"S9!C1"})

    def test_a_change_typed_through_another_case_reaches_the_readers(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.put("s4!A1", 1000)
        self.assertEqual(desk.value_at("S5!B1").written(), "1021")
        self.assertEqual(set(traced(desk)), chain(4) | readers_of(4))

    def test_a_rename_reaches_readers_that_wrote_it_in_another_case(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        desk.book.rename("S4", "Four")
        desk.recalculate()
        self.assertEqual(desk.sheet("S5").text_at("B1"), "=Four!A21+1")
        self.assertEqual(desk.value_at("S5!B1").written(), "25")
        self.reset()
        desk.put("four!A1", 40)
        self.assertEqual(desk.value_at("S5!B1").written(), "61")
        self.assertIn("S5!B1", traced(desk))

    def test_removing_a_sheet_in_another_case_breaks_its_readers(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.book.remove("s4")
        desk.recalculate()
        self.assertEqual(desk.value_at("S5!B1").written(), "#REF!")
        self.assertEqual(set(traced(desk)), {"S5!B1"})
        self.assertEqual(desk.value_at("S6!B1").written(), "26")

    def test_adding_a_sheet_back_brings_back_readers_that_wrote_it_in_another_case(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        desk.book.remove("S4")
        desk.recalculate()
        self.reset()
        desk.book.add(Sheet("S4", {"A21": 7}))
        desk.recalculate()
        self.assertEqual(desk.value_at("S5!B1").written(), "8")
        self.assertIn("S5!B1", traced(desk))

    def test_agrees_with_a_fresh_desk_after_changes_in_any_case(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        desk.put("s7!A1", 70)
        desk.put("S9!C1", "=S8!A3+s7!A2")
        desk.recalculate()
        desk.book.rename("s2", "Two")
        desk.put("two!A1", 20)
        desk.recalculate()
        desk.book.remove("S11")
        desk.put("S12!C1", "=TWO!A21+s11!A1")
        desk.recalculate()
        same_as_fresh(self, desk)


ROUND = (
    "trestle-book 1\n"
    "name Round\n"
    "iterate 100 0\n"
    "sheet Main\n"
    "  B1 6\n"
    "  A1 =IF(other!A1>=B1,other!A1,other!A1+1)\n"
    "sheet Other\n"
    "  A1 =MAIN!A1\n"
)


class CyclesTest(_Guarded):
    """A cycle across sheets that name each other in another case."""

    def test_the_cycle_settles(self):
        desk = Desk.of_text(ROUND)
        desk.recalculate()
        self.assertEqual(desk.value_at("Main!A1").written(), "6")
        self.assertEqual(desk.value_at("Other!A1").written(), "6")

    def test_a_change_in_the_cycle_goes_round_it_again(self):
        desk = Desk.of_text(ROUND)
        desk.recalculate()
        desk.put("main!B1", 9)
        self.assertEqual(desk.value_at("Main!A1").written(), "9")
        self.assertEqual(desk.value_at("Other!A1").written(), "9")
        self.assertTrue({"Main!A1", "Other!A1"} <= set(traced(desk)))
        same_as_fresh(self, desk)


class PagesTest(_Guarded):
    """The readme no longer lists case-sensitive sheet names."""

    def test_the_readme_no_longer_says_sheet_names_are_compared_exactly(self):
        with open(os.path.join(ROOT, "README.md"), encoding="utf-8") as handle:
            said = " ".join(handle.read().split())
        self.assertNotIn("Sheet names are compared exactly", said)
        self.assertNotIn("`Costs` and `costs` are two sheets", said)


if __name__ == "__main__":
    unittest.main()
