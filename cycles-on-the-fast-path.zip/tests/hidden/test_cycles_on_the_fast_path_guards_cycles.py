"""What already holds and must go on holding once a book may ask its cycles to settle.

A book that does not ask keeps every cycle an error: #CYCLE! in the cells, a warning from the
review, a count from calc and exit code 3; readers of a cycle read the error; books without the
line read and write as before; the worked examples answer as before. Standard library only.
"""

import io
import os
import signal
import tempfile
import unittest

from trestle import Desk, write_book
from trestle.cli.main import main
from trestle.graph import cycles_in, in_a_cycle, links_of, order_of
from trestle.recalc import recalculate, recalculated_after
from trestle.sheet import Sheet
from trestle.store import digest_of_book, read_book

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _stop(signum, frame):
    raise AssertionError("took too long")


class _Guarded(unittest.TestCase):
    """A test that hangs fails rather than waits."""

    def setUp(self):
        signal.signal(signal.SIGALRM, _stop)
        signal.alarm(60)

    def tearDown(self):
        signal.alarm(0)


def run(*argv):
    """The command line, run in this process, with what it printed."""
    stream = io.StringIO()
    code = main(list(argv), stream)
    return code, stream.getvalue().rstrip("\n")


def written(text, name="plain.book"):
    """A file holding some text, in a directory of its own."""
    path = os.path.join(tempfile.mkdtemp(), name)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return path


PLAIN = "trestle-book 1\nname Plain\nsheet Main\n  A1 =IF(A1>=B1,A1,A1+5)\n  B1 20\n  D1 =A1*2\n"


class StillAnErrorTest(_Guarded):
    """A book that does not ask keeps a cycle an error."""

    def test_a_cycle_is_still_a_cycle_error_through_the_desk(self):
        desk = Desk.of_text(PLAIN)
        self.assertEqual(desk.value_at("A1").written(), "#CYCLE!")
        self.assertEqual(desk.value_at("D1").written(), "#CYCLE!")

    def test_a_cell_needing_itself_is_still_a_cycle_error(self):
        desk = Desk.empty()
        desk.put("A1", "=A1+1")
        self.assertEqual(desk.value_at("A1").written(), "#CYCLE!")

    def test_calc_still_counts_the_cycle_and_answers_three(self):
        code, text = run("calc", written(PLAIN))
        self.assertEqual(code, 3)
        self.assertIn("1 cell in a cycle", text)

    def test_the_review_still_warns(self):
        code, text = run("review", written(PLAIN), "--only", "cycles")
        self.assertEqual(code, 1)
        self.assertIn("Main!A1", text)
        self.assertIn("1 warning", text)

    def test_a_sheet_on_its_own_still_gives_a_cycle_error(self):
        sheet = Sheet("Main", {"B1": 20, "A1": "=IF(A1>=B1,A1,A1+5)", "D1": "=A1*2"})
        held = recalculate(sheet)
        self.assertEqual(held.value_at("A1").written(), "#CYCLE!")
        self.assertEqual(held.value_at("D1").written(), "#CYCLE!")
        self.assertTrue(held.has_cycle)
        again = recalculated_after(sheet, ["B1"])
        self.assertEqual(again.value_at("A1").written(), "#CYCLE!")

    def test_the_graph_still_finds_the_cycle(self):
        sheet = Sheet("Main", {"A1": "=B1+1", "B1": "=A1", "C1": "=A1"})
        links = links_of(sheet)
        self.assertEqual(len(cycles_in(links)), 1)
        self.assertEqual(sorted(one.written(False) for one in in_a_cycle(links)), ["A1", "B1"])
        order = order_of(links)
        self.assertEqual(sorted(one.written(False) for one in order.stuck), ["A1", "B1"])
        self.assertEqual([one.written(False) for one in order], ["C1"])

    def test_a_cycle_across_sheets_is_still_an_error(self):
        desk = Desk.of_text("trestle-book 1\nsheet Main\n  A1 =Other!A1+1\nsheet Other\n  A1 =Main!A1\n")
        self.assertEqual(desk.value_at("Main!A1").written(), "#CYCLE!")
        self.assertEqual(desk.value_at("Other!A1").written(), "#CYCLE!")


class StillTheFileTest(_Guarded):
    """Books without the line read and write as before."""

    def test_a_plain_book_round_trips_unchanged(self):
        self.assertEqual(write_book(read_book(PLAIN)), PLAIN)

    def test_an_unknown_line_kind_is_still_refused_with_its_line(self):
        from trestle.errors import StoreError

        with self.assertRaises(StoreError) as caught:
            read_book("trestle-book 1\nfoo bar\nsheet Main\n  A1 1\n")
        self.assertIn("line 2", str(caught.exception))

    def test_the_digest_of_a_plain_book_ignores_its_name(self):
        one = read_book("trestle-book 1\nname One\nsheet Main\n  A1 1\n")
        other = read_book("trestle-book 1\nname Two\nsheet Main\n  A1 1\n")
        self.assertEqual(digest_of_book(one), digest_of_book(other))

    def test_the_examples_still_read_and_come_to_the_same(self):
        for name, where, wanted in (("budget", "Left!B3", "1090"), ("invoice", None, None),
                                    ("loan", None, None), ("marks", None, None)):
            desk = Desk.demo(name)
            desk.recalculate()
            if where:
                with self.subTest(example=name):
                    self.assertEqual(desk.value_at(where).written(), wanted)
            again = Desk.of_text(write_book(desk.book))
            with self.subTest(example=name):
                self.assertEqual(desk.digest(values=True), again.digest(values=True))

    def test_the_broken_book_still_reviews_the_same(self):
        code, text = run("calc", os.path.join(ROOT, "examples", "broken.book"))
        self.assertEqual(code, 3)
        self.assertIn("review: 10 warnings, 6 notices", text)


class StillTheRestTest(_Guarded):
    """Ordinary books are worked out as before."""

    def test_the_budget_links_and_order_are_unchanged(self):
        code, text = run("links", "budget")
        self.assertEqual(code, 0)
        self.assertIn("6 formulas, 12 links", text)
        code, text = run("order", "budget")
        self.assertEqual([line.split()[-1] for line in text.splitlines()[3:9]],
                         ["Income!B4", "Left!B1", "Spending!B6", "Left!B2", "Left!B3", "Left!B4"])

    def test_a_chain_without_a_cycle_is_worked_out_once_each(self):
        desk = Desk.of_text("trestle-book 1\nsheet Main\n  A1 1\n  B1 =A1+1\n  C1 =B1+1\n")
        desk.recalculate()
        self.assertEqual(desk.value_at("C1").written(), "3")
        self.assertEqual(len(desk.trace()), 2)

    def test_the_functions_are_still_seventy_nine(self):
        code, text = run("functions")
        self.assertEqual(code, 0)
        self.assertRegex(text, r"\b(79|80) functions")

    def test_an_error_still_travels_and_counts(self):
        code, text = run("calc", written("trestle-book 1\nsheet Main\n  A1 =1/0\n  B1 =A1+1\n"))
        self.assertEqual(code, 3)
        self.assertIn("2 in error", text)
        self.assertNotIn("cycle", text.lower())

    def test_a_reader_of_a_cycle_still_reads_the_error(self):
        desk = Desk.of_text("trestle-book 1\nsheet Main\n  A1 =A1+1\n  B1 =IFERROR(A1,9)\n  C1 =A1\n")
        self.assertEqual(desk.value_at("B1").written(), "9")
        self.assertEqual(desk.value_at("C1").written(), "#CYCLE!")


if __name__ == "__main__":
    unittest.main()
