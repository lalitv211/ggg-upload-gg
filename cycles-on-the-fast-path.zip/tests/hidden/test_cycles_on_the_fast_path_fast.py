"""A fast path for one sheet (README gap 9), the other half of cycles-on-the-fast-path.

After the first recalculation, a change to one cell costs that cell's sheet and what reads it:
the next recalculation works out exactly the formulas the change made stale (on any sheet, each
once, in the book's order) and builds the graph again for the changed sheet at most, measured by
counting calls of Links.note. Renaming, adding and removing a sheet are changes too, a cycle made
or broken by a change is worked out, and nothing ever differs from a fresh desk over the same text.
Standard library only: unittest, one method per case.
"""

import os
import re
import signal
import unittest

import trestle.graph.links as links_module
from trestle import Desk, write_book
from trestle.book import Book
from trestle.sheet import Sheet
from trestle.store import read_book

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHEETS = 40
ROWS = 50


def _stop(signum, frame):
    raise AssertionError("took too long")


class _Guarded(unittest.TestCase):
    """A test that hangs fails rather than waits, and the note counter is always put back."""

    def setUp(self):
        signal.signal(signal.SIGALRM, _stop)
        signal.alarm(120)
        self.notes = 0
        original = links_module.Links.note
        self._original_note = original
        test = self

        def counting(held, where, tree, filled=True):
            test.notes += 1
            return original(held, where, tree, filled)

        links_module.Links.note = counting

    def tearDown(self):
        links_module.Links.note = self._original_note
        signal.alarm(0)

    def reset(self):
        self.notes = 0


def big_book(sheets=SHEETS, rows=ROWS):
    """Forty sheets of fifty chained formulas, each sheet's B1 reading the one before it."""
    lines = ["trestle-book 1", "name Big"]
    for k in range(1, sheets + 1):
        lines.append("sheet S%d" % k)
        lines.append("  A1 %d" % k)
        for row in range(2, rows + 2):
            lines.append("  A%d =A%d+1" % (row, row - 1))
        if k > 1:
            lines.append("  B1 =S%d!A%d+1" % (k - 1, rows + 1))
    return "\n".join(lines) + "\n"


FORMULAS_IN_BIG = SHEETS * ROWS + (SHEETS - 1)


def chain(k, rows=ROWS):
    return {"S%d!A%d" % (k, row) for row in range(2, rows + 2)}


def readers_of(k):
    """The B1 cells downstream of a change on sheet k: only the next sheet reads sheet k."""
    return {"S%d!B1" % (k + 1)} if k < SHEETS else set()


def traced(desk):
    """The cells of the desk's trace as written, in order."""
    return [step.at.written() for step in desk.trace()]


def fresh(desk):
    """A new desk over the same text, worked out from nothing."""
    held = Desk.of_text(write_book(desk.book))
    held.recalculate()
    return held


def values_of(desk):
    """Every filled cell's value, by its written address."""
    found = {}
    for sheet in desk.book.sheets():
        for address, cell in sheet.cells():
            found[address.in_sheet(sheet.name).written()] = desk.value_at(
                address.in_sheet(sheet.name)).written()
    return found


class BudgetTest(_Guarded):
    """What one change costs, counted in links noted and cells worked out."""

    def test_one_number_on_one_sheet_costs_that_sheet_and_its_readers(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.put("S20!A1", 100)
        self.assertEqual(desk.value_at("S20!A51").written(), "150")
        self.assertEqual(desk.value_at("S21!B1").written(), "151")
        self.assertLessEqual(self.notes, ROWS + 1, "the graph of a sheet nobody changed is not built again")
        held = traced(desk)
        self.assertEqual(set(held), chain(20) | readers_of(20))
        self.assertEqual(len(held), len(set(held)), "each cell once")

    def test_a_number_nobody_reads_works_out_nothing(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.put("S5!C1", 7)
        desk.recalculate()
        self.assertEqual(traced(desk), [])
        self.assertLessEqual(self.notes, ROWS + 1)

    def test_a_label_nobody_reads_works_out_nothing(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.put("S5!C1", "note to self")
        desk.recalculate()
        self.assertEqual(traced(desk), [])

    def test_a_new_formula_is_worked_out_itself(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.put("S5!C1", "=A51*2")
        self.assertEqual(desk.value_at("S5!C1").written(), "110")
        self.assertEqual(traced(desk), ["S5!C1"])
        self.assertLessEqual(self.notes, ROWS + 2)

    def test_emptying_a_cell_is_a_change_to_it(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.put("S5!A1", "")
        self.assertEqual(desk.value_at("S5!A51").written(), "50")
        self.assertEqual(set(traced(desk)), chain(5) | readers_of(5))
        self.assertLessEqual(self.notes, ROWS + 1)

    def test_several_changes_give_one_trace_in_the_book_s_order(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.put("S7!A1", 70)
        desk.put("S3!A1", 30)
        desk.recalculate()
        noted = self.notes
        held = traced(desk)
        self.assertEqual(set(held), chain(3) | chain(7) | readers_of(3) | readers_of(7))
        self.assertEqual(len(held), len(set(held)))
        positions = {one.written(): index for index, one in enumerate(fresh(desk).order())}
        self.assertEqual(held, sorted(held, key=lambda one: positions[one]))
        self.assertLessEqual(noted, 2 * (ROWS + 1))

    def test_a_change_with_the_sheet_given_beside_the_cell(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.put("A1", 100, sheet="S20")
        self.assertEqual(desk.value_at("A51", sheet="S20").written(), "150")
        self.assertEqual(set(traced(desk)), chain(20) | readers_of(20))
        self.assertLessEqual(self.notes, ROWS + 1)

    def test_the_book_path_works_out_only_what_changed(self):
        book = read_book(big_book())
        book.recalculate()
        self.reset()
        book.put("S20!A1", 100)
        held = book.recalculated_after(["S20!A1"])
        trace = getattr(held, "trace", held)
        self.assertEqual({step.at.written() for step in trace}, chain(20) | readers_of(20))
        self.assertEqual(book.value_at("S21!B1").written(), "151")
        self.assertLessEqual(self.notes, ROWS + 1)

    def test_a_change_after_a_change_costs_the_same(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        for number in (100, 200, 300):
            self.reset()
            desk.put("S20!A1", number)
            desk.recalculate()
            self.assertLessEqual(self.notes, ROWS + 1)
            self.assertEqual(set(traced(desk)), chain(20) | readers_of(20))
        self.assertEqual(desk.value_at("S21!B1").written(), "351")


class CrossSheetTest(_Guarded):
    """What makes a formula stale crosses sheets both ways, and follows the formulas as typed."""

    def test_a_reader_through_a_rectangle_on_another_sheet(self):
        desk = Desk.of_text(big_book())
        desk.put("S9!C1", "=SUM(S4!A1:A51)")
        desk.recalculate()
        self.reset()
        desk.put("S4!A1", 1000)
        self.assertEqual(desk.value_at("S9!C1").written(), fresh(desk).value_at("S9!C1").written())
        self.assertIn("S9!C1", traced(desk))
        self.assertEqual(set(traced(desk)), chain(4) | readers_of(4) | {"S9!C1"})

    def test_a_reader_typed_after_the_first_recalculation_counts_from_then_on(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        desk.put("S9!C1", "=S4!A51+1")
        self.assertEqual(traced(desk), ["S9!C1"])
        self.reset()
        desk.put("S4!A1", 50)
        self.assertEqual(desk.value_at("S9!C1").written(), "101")
        self.assertEqual(set(traced(desk)), chain(4) | readers_of(4) | {"S9!C1"})
        self.assertLessEqual(self.notes, ROWS + 1)

    def test_an_emptied_reader_is_read_no_more(self):
        desk = Desk.of_text(big_book())
        desk.put("S9!C1", "=S4!A51+1")
        desk.recalculate()
        desk.put("S9!C1", "")
        desk.recalculate()
        self.reset()
        desk.put("S4!A1", 50)
        desk.recalculate()
        self.assertEqual(set(traced(desk)), chain(4) | readers_of(4))

    def test_a_reader_moved_to_another_cell_reads_from_there(self):
        desk = Desk.of_text(big_book())
        desk.put("S9!C1", "=S4!A51+1")
        desk.recalculate()
        desk.put("S9!C1", "=S6!A51+1")
        desk.recalculate()
        self.reset()
        desk.put("S4!A1", 50)
        desk.recalculate()
        self.assertNotIn("S9!C1", traced(desk))
        desk.put("S6!A1", 60)
        desk.recalculate()
        self.assertIn("S9!C1", traced(desk))
        self.assertEqual(desk.value_at("S9!C1").written(), "111")

    def test_a_chain_of_readers_across_three_sheets(self):
        desk = Desk.of_text(big_book())
        desk.put("S10!C1", "=S4!A51*2")
        desk.put("S30!C1", "=S10!C1+S20!A51")
        desk.recalculate()
        self.reset()
        desk.put("S4!A1", 1)
        self.assertEqual(desk.value_at("S30!C1").written(), fresh(desk).value_at("S30!C1").written())
        self.assertEqual(set(traced(desk)), chain(4) | readers_of(4) | {"S10!C1", "S30!C1"})


class EditsTest(_Guarded):
    """Renaming, adding and removing a sheet are changes."""

    def test_renaming_a_sheet_makes_the_formulas_that_named_it_stale_and_nothing_else(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.book.rename("S4", "Four")
        desk.recalculate()
        self.assertEqual(desk.sheet("S5").text_at("B1"), "=Four!A51+1")
        held = set(traced(desk))
        self.assertIn("S5!B1", held)
        own = {"Four!A%d" % row for row in range(2, ROWS + 2)} | {"Four!B1"}
        self.assertTrue(held <= {"S5!B1"} | own, held)
        self.assertEqual(desk.value_at("S5!B1").written(), "55")
        self.assertLessEqual(self.notes, 2 * (ROWS + 1))

    def test_a_change_on_a_renamed_sheet_reaches_its_readers(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        desk.book.rename("S4", "Four")
        desk.recalculate()
        self.reset()
        desk.put("Four!A1", 400)
        self.assertEqual(desk.value_at("S5!B1").written(), "451")
        self.assertEqual(set(traced(desk)), {"Four!A%d" % row for row in range(2, ROWS + 2)} | {"S5!B1"})
        self.assertLessEqual(self.notes, ROWS + 1)

    def test_removing_a_sheet_makes_its_readers_reference_errors(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.book.remove("S4")
        desk.recalculate()
        self.assertEqual(desk.value_at("S5!B1").written(), "#REF!")
        self.assertEqual(set(traced(desk)), {"S5!B1"})
        self.assertEqual(desk.value_at("S6!B1").written(), "56")

    def test_adding_a_sheet_brings_its_formulas_into_the_graph(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.book.add(Sheet("New", {"A1": "=S3!A51*2"}))
        desk.recalculate()
        self.assertEqual(desk.value_at("New!A1").written(), "106")
        self.assertEqual(set(traced(desk)), {"New!A1"})
        self.reset()
        desk.put("S3!A1", 30)
        self.assertEqual(desk.value_at("New!A1").written(), "160")
        self.assertEqual(set(traced(desk)), chain(3) | readers_of(3) | {"New!A1"})

    def test_a_sheet_added_then_read_by_a_new_formula(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        desk.book.add(Sheet("Rates", {"A1": 0.5}))
        desk.put("S2!C1", "=Rates!A1*A51")
        self.assertEqual(desk.value_at("S2!C1").written(), "26")
        self.reset()
        desk.put("Rates!A1", 2)
        self.assertEqual(desk.value_at("S2!C1").written(), "104")
        self.assertEqual(set(traced(desk)), {"S2!C1"})


class CyclesTest(_Guarded):
    """A change that makes or breaks a cycle, on one sheet or across sheets."""

    def test_a_cycle_made_across_sheets_by_a_change(self):
        desk = Desk.of_text(big_book())
        desk.put("S1!C1", "=S2!C1+1")
        desk.recalculate()
        self.reset()
        desk.put("S2!C1", "=S1!C1+1")
        self.assertEqual(desk.value_at("S1!C1").written(), "#CYCLE!")
        self.assertEqual(desk.value_at("S2!C1").written(), "#CYCLE!")
        self.assertEqual(set(traced(desk)), {"S1!C1", "S2!C1"})
        self.assertLessEqual(self.notes, ROWS + 2)

    def test_a_cycle_across_sheets_broken_by_a_change(self):
        desk = Desk.of_text(big_book())
        desk.put("S1!C1", "=S2!C1+1")
        desk.put("S2!C1", "=S1!C1+1")
        desk.recalculate()
        self.reset()
        desk.put("S2!C1", 5)
        self.assertEqual(desk.value_at("S1!C1").written(), "6")
        self.assertEqual(set(traced(desk)), {"S1!C1"})

    def test_a_cycle_on_one_sheet_made_by_a_change(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.reset()
        desk.put("S8!A1", "=A51")
        self.assertEqual(desk.value_at("S8!A1").written(), "#CYCLE!")
        self.assertEqual(desk.value_at("S8!A51").written(), "#CYCLE!")
        self.assertEqual(desk.value_at("S9!B1").written(), "#CYCLE!")
        self.assertEqual(set(traced(desk)), {"S8!A1"} | chain(8) | readers_of(8))
        self.assertLessEqual(self.notes, ROWS + 2)


class PagesTest(_Guarded):
    """The readme list, the performance page, the changelog."""

    def readme(self):
        with open(os.path.join(ROOT, "README.md"), encoding="utf-8") as handle:
            return handle.read()

    def test_the_readme_no_longer_says_there_is_no_fast_path(self):
        said = self.readme()
        found = re.findall(r"^(\d+)\. \*\*", said, re.M)
        self.assertIn(found, tuple([str(one) for one in range(1, n)] for n in (14, 15, 16)))
        self.assertNotIn("A book has no fast path for one sheet", said)
        self.assertNotIn("Changing one cell builds the graph for the whole book", said)

    def test_the_performance_page_no_longer_says_there_is_no_fast_path(self):
        with open(os.path.join(ROOT, "docs", "performance.md"), encoding="utf-8") as handle:
            said = " ".join(handle.read().split())
        self.assertNotIn("still builds the graph for the whole book", said)

    def test_the_changelog_records_the_change(self):
        with open(os.path.join(ROOT, "CHANGELOG.md"), encoding="utf-8") as handle:
            text = handle.read()
        self.assertGreater(len(re.findall(r"^- ", text, re.M)), 37)


if __name__ == "__main__":
    unittest.main()
