"""Cycles that settle: README gap 6 filled for a book that asks for it.

An `iterate <passes> <tolerance>` line in the book file turns a cycle from an error into
something worked out by passes from blank until no cell moves by more than the tolerance, or
into #CYCLE! when the passes run out. A cycle waits for what it reads and its readers wait for
it; every recalculation starts the passes from blank again, so the same book gives the same
answers whatever the cells held before. Standard library only: unittest, one method per case.
"""

import io
import os
import re
import signal
import tempfile
import unittest

from trestle import Desk, write_book
from trestle.book import Book
from trestle.cli.main import main
from trestle.sheet import Sheet
from trestle.store import compared_books, digest_of_book, read_book, same_input

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _stop(signum, frame):
    raise AssertionError("took too long")


class _Guarded(unittest.TestCase):
    """A test that hangs fails rather than waits."""

    def setUp(self):
        signal.signal(signal.SIGALRM, _stop)
        signal.alarm(60)

    def tearDown(self):
        signal.alarm(0)


def run(*argv):
    """The command line, run in this process, with what it printed."""
    stream = io.StringIO()
    code = main(list(argv), stream)
    return code, stream.getvalue().rstrip("\n")


def written(text, name="settle.book"):
    """A file holding some text, in a directory of its own."""
    path = os.path.join(tempfile.mkdtemp(), name)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return path


def book(cells, setting="iterate 100 0", name="Settle", more_sheets=""):
    """A book file text: one sheet called Main holding some cell lines, iterating or not."""
    head = ["trestle-book 1", "name %s" % name]
    if setting:
        head.append(setting)
    return "\n".join(head) + "\nsheet Main\n" + cells + more_sheets


def pair(setting):
    """A setting as (passes, tolerance), whatever shape the library gives it."""
    if setting is None:
        return None
    if hasattr(setting, "passes") and hasattr(setting, "tolerance"):
        return (setting.passes, setting.tolerance)
    return tuple(setting)


STEPPING = "  B1 20\n  A1 =IF(A1>=B1,A1,A1+5)\n  D1 =A1*2\n"


class FileTest(_Guarded):
    """The iterate line: where it goes, how it is written back, what is refused."""

    def test_the_line_is_read_and_written_back_in_its_place(self):
        text = book(STEPPING)
        held = read_book(text)
        self.assertEqual(pair(held.iteration), (100, 0))
        lines = write_book(held).splitlines()
        self.assertEqual(lines[0], "trestle-book 1")
        self.assertIn("iterate 100 0", lines[1:3])
        self.assertEqual(lines[3], "sheet Main")
        self.assertEqual(write_book(read_book(write_book(held))), write_book(held))

    def test_a_tolerance_with_a_fraction_is_kept(self):
        held = read_book(book(STEPPING, "iterate 50 0.001"))
        self.assertEqual(pair(held.iteration), (50, 0.001))
        self.assertIn("iterate 50 0.001", write_book(held))

    def test_a_book_without_the_line_does_not_iterate(self):
        self.assertIsNone(pair(read_book(book(STEPPING, "")).iteration))
        self.assertNotIn("iterate", write_book(read_book(book(STEPPING, ""))))

    def test_a_second_line_is_refused_at_its_line(self):
        from trestle.errors import TrestleError

        with self.assertRaises(TrestleError) as caught:
            read_book("trestle-book 1\niterate 100 0\niterate 50 0\nsheet Main\n  A1 1\n")
        self.assertIn("line 3", str(caught.exception))

    def test_a_line_under_a_sheet_is_refused_at_its_line(self):
        from trestle.errors import TrestleError

        self.assertEqual(pair(read_book("trestle-book 1\niterate 9 0\nsheet Main\n  A1 1\n").iteration),
                         (9, 0))
        with self.assertRaises(TrestleError) as caught:
            read_book("trestle-book 1\nsheet Main\n  A1 1\niterate 9 0\n")
        self.assertIn("line 4", str(caught.exception))

    def test_bad_numbers_are_refused_and_good_ones_taken(self):
        from trestle.errors import TrestleError

        for bad in ("iterate 0 0.1", "iterate ten 0.1", "iterate 100", "iterate 100 -1",
                    "iterate", "iterate 2.5 0", "iterate -3 0", "iterate 100 none"):
            with self.subTest(line=bad):
                with self.assertRaises(TrestleError) as caught:
                    read_book("trestle-book 1\n%s\nsheet Main\n  A1 1\n" % bad)
                self.assertIn("line 2", str(caught.exception))
        for good, wanted in (("iterate 1 0", (1, 0)), ("iterate 100 0.5", (100, 0.5)),
                             ("iterate 7 1", (7, 1))):
            with self.subTest(line=good):
                self.assertEqual(pair(read_book("trestle-book 1\n%s\nsheet Main\n  A1 1\n" % good).iteration),
                                 wanted)

    def test_the_library_sets_and_refuses_the_same_way(self):
        from trestle.errors import TrestleError

        held = Book("B")
        held.add(Sheet("Main", {"A1": 1}))
        self.assertIsNone(pair(held.iteration))
        held.iterate(20, 0.01)
        self.assertEqual(pair(held.iteration), (20, 0.01))
        for passes, tolerance in ((0, 0), (-1, 0), (10, -0.5), ("ten", 0), (2.5, 0)):
            with self.subTest(passes=passes, tolerance=tolerance):
                with self.assertRaises(TrestleError):
                    held.iterate(passes, tolerance)
        self.assertEqual(pair(held.iteration), (20, 0.01))

    def test_the_desk_sets_it_too(self):
        desk = Desk.empty()
        desk.put("B1", 20)
        desk.put("A1", "=IF(A1>=B1,A1,A1+5)")
        self.assertEqual(desk.value_at("A1").written(), "#CYCLE!")
        desk.iterate(100, 0)
        self.assertEqual(pair(desk.iteration), (100, 0))
        self.assertEqual(desk.value_at("A1").written(), "20")

    def test_a_book_read_through_the_desk_keeps_the_setting(self):
        desk = Desk.of_file(written(book(STEPPING)))
        self.assertEqual(pair(desk.iteration), (100, 0))
        self.assertEqual(desk.value_at("A1").written(), "20")

    def test_the_digest_sees_the_setting(self):
        plain = read_book(book(STEPPING, ""))
        settles = read_book(book(STEPPING))
        other = read_book(book(STEPPING, "iterate 50 0"))
        same = read_book(book(STEPPING))
        self.assertNotEqual(digest_of_book(plain), digest_of_book(settles))
        self.assertNotEqual(digest_of_book(other), digest_of_book(settles))
        self.assertEqual(digest_of_book(same), digest_of_book(settles))
        self.assertFalse(same_input(plain, settles))
        self.assertTrue(same_input(same, settles))

    def test_comparing_two_books_sees_the_setting(self):
        plain = read_book(book("  A1 1\n", ""))
        settles = read_book(book("  A1 1\n"))
        plain.recalculate()
        settles.recalculate()
        self.assertFalse(compared_books(plain, settles).is_empty)
        self.assertTrue(compared_books(settles, settles).is_empty)
        code, text = run("diff", written(book("  A1 1\n", ""), "one.book"),
                         written(book("  A1 1\n"), "two.book"))
        self.assertIn(code, (0, 1, 3))
        self.assertNotIn("Nothing changed", text)


class SettleTest(_Guarded):
    """Passes from blank until nothing moves, or #CYCLE! when the passes run out."""

    def test_a_cycle_that_steps_up_to_a_number_settles_there(self):
        desk = Desk.of_text(book(STEPPING))
        self.assertEqual(desk.value_at("A1").written(), "20")
        self.assertEqual(desk.value_at("D1").written(), "40")

    def test_the_command_line_sees_the_settled_value(self):
        path = written(book(STEPPING))
        self.assertEqual(run("value", path, "Main!A1"), (0, "20"))
        self.assertEqual(run("value", path, "Main!D1"), (0, "40"))
        code, text = run("calc", path)
        self.assertEqual(code, 0)
        self.assertNotIn("cycle", text.lower())

    def test_too_few_passes_is_a_cycle_error(self):
        desk = Desk.of_text(book(STEPPING, "iterate 3 0"))
        self.assertEqual(desk.value_at("A1").written(), "#CYCLE!")
        self.assertEqual(desk.value_at("D1").written(), "#CYCLE!")
        code, text = run("calc", written(book(STEPPING, "iterate 3 0")))
        self.assertEqual(code, 3)
        self.assertIn("1 cell in a cycle", text)

    def test_enough_passes_is_not(self):
        desk = Desk.of_text(book(STEPPING, "iterate 10 0"))
        self.assertEqual(desk.value_at("A1").written(), "20")

    def test_a_two_cell_cycle_settles_together(self):
        desk = Desk.of_text(book("  A1 =IF(B1>=5,B1,B1+1)\n  B1 =A1\n  C1 =A1+B1\n"))
        self.assertEqual([desk.value_at(one).written() for one in ("A1", "B1", "C1")],
                         ["5", "5", "10"])

    def test_a_cycle_that_never_settles_is_a_cycle_error(self):
        desk = Desk.of_text(book("  A1 =A1+1\n  B1 =A1*2\n"))
        self.assertEqual(desk.value_at("A1").written(), "#CYCLE!")
        self.assertEqual(desk.value_at("B1").written(), "#CYCLE!")

    def test_the_tolerance_stops_a_slow_slide(self):
        text = book("  A1 =B1/2\n  B1 =A1+1\n", "iterate 100 0.001")
        desk = Desk.of_text(text)
        self.assertAlmostEqual(float(desk.value_at("A1").written()), 1.0, delta=0.01)
        self.assertAlmostEqual(float(desk.value_at("B1").written()), 2.0, delta=0.01)

    def test_a_slow_slide_with_no_tolerance_and_few_passes_does_not_settle(self):
        desk = Desk.of_text(book("  A1 =B1/2\n  B1 =A1+1\n", "iterate 5 0"))
        self.assertEqual(desk.value_at("A1").written(), "#CYCLE!")

    def test_a_cycle_of_text_settles_by_equality(self):
        desk = Desk.of_text(book('  A1 =IF(LEN(B1)>=3,B1,B1&"x")\n  B1 =A1\n'))
        self.assertEqual(desk.value_at("A1").written(), "xxx")
        self.assertEqual(desk.value_at("B1").written(), "xxx")

    def test_the_first_pass_starts_from_blank(self):
        """A cell that holds itself plus nothing settles at once on 0, not on what it held."""
        desk = Desk.of_text(book("  A1 =A1\n  B1 =A1+1\n"))
        self.assertEqual(desk.value_at("A1").written(), "")
        self.assertEqual(desk.value_at("B1").written(), "1")


class WaitsTest(_Guarded):
    """A cycle waits for what it reads, and what reads a cycle waits for it."""

    def test_a_cycle_reading_an_ordered_formula_sees_it_worked_out(self):
        text = book("  C1 10\n  B1 =C1*2\n  A1 =IF(A1>=B1,A1,A1+5)\n")
        desk = Desk.of_text(text)
        self.assertEqual(desk.value_at("B1").written(), "20")
        self.assertEqual(desk.value_at("A1").written(), "20")
        self.assertEqual(run("value", written(text), "Main!A1"), (0, "20"))

    def test_a_cycle_reading_a_chain_of_formulas_sees_the_end_of_the_chain(self):
        text = book("  E1 2\n  D1 =E1+3\n  C1 =D1*2\n  B1 =C1+10\n  A1 =IF(A1>=B1,A1,A1+5)\n")
        desk = Desk.of_text(text)
        self.assertEqual(desk.value_at("B1").written(), "20")
        self.assertEqual(desk.value_at("A1").written(), "20")

    def test_a_cycle_on_one_sheet_reading_a_formula_on_another(self):
        text = book("  A1 =IF(A1>=Other!B1,A1,A1+5)\n", more_sheets="sheet Other\n  C1 4\n  B1 =C1*5\n")
        desk = Desk.of_text(text)
        self.assertEqual(desk.value_at("Main!A1").written(), "20")

    def test_what_reads_a_settled_cycle_sees_the_settled_value(self):
        text = book(STEPPING + '  E1 =IF(ISERROR(A1),"bad","ok")\n  F1 =A1+D1\n')
        desk = Desk.of_text(text)
        self.assertEqual(desk.value_at("E1").written(), "ok")
        self.assertEqual(desk.value_at("F1").written(), "60")

    def test_a_reader_on_another_sheet_sees_the_settled_value(self):
        text = book(STEPPING, more_sheets="sheet Other\n  A1 =Main!A1+1\n")
        desk = Desk.of_text(text)
        self.assertEqual(desk.value_at("Other!A1").written(), "21")

    def test_a_settled_cycle_feeding_another_cycle(self):
        text = book("  A1 =IF(A1>=6,A1,A1+1)\n  B1 =IF(B1>=A1*2,B1,B1+2)\n  C1 =B1\n")
        desk = Desk.of_text(text)
        self.assertEqual(desk.value_at("A1").written(), "6")
        self.assertEqual(desk.value_at("B1").written(), "12")
        self.assertEqual(desk.value_at("C1").written(), "12")


class FreshTest(_Guarded):
    """Every recalculation starts the passes from blank: the same book gives the same answers."""

    def test_a_change_to_what_the_cycle_reads_gives_the_fresh_answer(self):
        desk = Desk.of_text(book(STEPPING))
        self.assertEqual(desk.value_at("A1").written(), "20")
        desk.put("B1", 10)
        self.assertEqual(desk.value_at("A1").written(), "10", "a fresh desk over the same text says 10")
        self.assertEqual(desk.value_at("D1").written(), "20")
        fresh = Desk.of_text(write_book(desk.book))
        self.assertEqual(fresh.value_at("A1").written(), "10")

    def test_a_pass_limit_a_fresh_book_cannot_meet_is_a_cycle_error_even_after_a_near_miss(self):
        desk = Desk.of_text(book("  B1 8\n  A1 =IF(A1>=B1,A1,A1+1)\n", "iterate 10 0"))
        self.assertEqual(desk.value_at("A1").written(), "8")
        desk.put("B1", 15)
        self.assertEqual(desk.value_at("A1").written(), "#CYCLE!",
                         "fifteen steps do not fit in ten passes, whatever A1 held before")

    def test_working_the_book_out_again_changes_nothing(self):
        desk = Desk.of_text(book(STEPPING))
        first = desk.value_at("A1").written()
        desk.recalculate(again=True)
        self.assertEqual(desk.value_at("A1").written(), first)
        self.assertEqual(desk.digest(values=True), Desk.of_text(book(STEPPING)).digest(values=True))

    def test_a_change_inside_the_cycle_starts_again_from_blank(self):
        desk = Desk.of_text(book("  B1 6\n  A1 =IF(A1>=B1,A1,A1+1)\n", "iterate 100 0"))
        self.assertEqual(desk.value_at("A1").written(), "6")
        desk.put("A1", "=IF(A1>=B1,A1,A1+2)")
        self.assertEqual(desk.value_at("A1").written(), "6")
        desk.put("A1", "=IF(A1>=B1,A1,A1+4)")
        self.assertEqual(desk.value_at("A1").written(), "8", "0, 4, 8: the first pass starts from blank")


class SeparateTest(_Guarded):
    """Each cycle settles or fails on its own."""

    def test_one_cycle_failing_leaves_another_settled(self):
        text = book("  A1 =IF(B1>=5,B1,B1+1)\n  B1 =A1\n  C1 =C1+1\n  D1 =C1\n  E1 =A1\n")
        desk = Desk.of_text(text)
        self.assertEqual([desk.value_at(one).written() for one in ("A1", "B1", "E1")],
                         ["5", "5", "5"])
        self.assertEqual(desk.value_at("C1").written(), "#CYCLE!")
        self.assertEqual(desk.value_at("D1").written(), "#CYCLE!")
        code, out = run("calc", written(text))
        self.assertEqual(code, 3)
        self.assertIn("1 cell in a cycle", out)

    def test_two_settling_cycles_on_two_sheets(self):
        text = book("  A1 =IF(A1>=3,A1,A1+1)\n",
                    more_sheets="sheet Other\n  A1 =IF(A1>=7,A1,A1+1)\n  B1 =A1+Main!A1\n")
        desk = Desk.of_text(text)
        self.assertEqual(desk.value_at("Main!A1").written(), "3")
        self.assertEqual(desk.value_at("Other!A1").written(), "7")
        self.assertEqual(desk.value_at("Other!B1").written(), "10")


class ErrorTest(_Guarded):
    """An error inside a cycle is a value like any other."""

    def test_a_cycle_that_settles_on_an_error_holds_the_error(self):
        text = book("  A1 =B1+1\n  B1 =A1/0\n  C1 =A1\n")
        desk = Desk.of_text(text)
        self.assertEqual(desk.value_at("A1").written(), "#DIV/0!")
        self.assertEqual(desk.value_at("B1").written(), "#DIV/0!")
        self.assertEqual(desk.value_at("C1").written(), "#DIV/0!")
        code, out = run("calc", written(text))
        self.assertEqual(code, 3)
        self.assertNotIn("in a cycle", out)

    def test_an_error_read_by_a_cycle_from_outside(self):
        text = book("  B1 =1/0\n  A1 =IF(A1>=5,A1,A1+1)+B1\n")
        desk = Desk.of_text(text)
        self.assertEqual(desk.value_at("A1").written(), "#DIV/0!")


class AcrossSheetsTest(_Guarded):
    """A cycle through several sheets settles the same way."""

    def test_a_cycle_through_two_sheets_settles(self):
        text = book("  A1 =IF(Other!A1>=5,Other!A1,Other!A1+1)\n",
                    more_sheets="sheet Other\n  A1 =Main!A1\n  B1 =A1*2\n")
        desk = Desk.of_text(text)
        self.assertEqual(desk.value_at("Main!A1").written(), "5")
        self.assertEqual(desk.value_at("Other!A1").written(), "5")
        self.assertEqual(desk.value_at("Other!B1").written(), "10")
        path = written(text)
        self.assertEqual(run("value", path, "Other!B1"), (0, "10"))
        self.assertEqual(run("calc", path)[0], 0)

    def test_a_cycle_through_three_sheets_that_runs_out_of_passes(self):
        text = book("  A1 =Other!A1+1\n", "iterate 20 0",
                    more_sheets="sheet Other\n  A1 =Third!A1\nsheet Third\n  A1 =Main!A1\n")
        desk = Desk.of_text(text)
        for where in ("Main!A1", "Other!A1", "Third!A1"):
            self.assertEqual(desk.value_at(where).written(), "#CYCLE!", where)
        code, out = run("calc", written(text))
        self.assertEqual(code, 3)
        self.assertIn("3 cells in a cycle", out)


class ReportsTest(_Guarded):
    """What calc, review and the trace say about a settled cycle."""

    def test_the_review_notices_a_settled_cycle_and_warns_about_one_that_did_not(self):
        code, text = run("review", written(book(STEPPING)), "--only", "cycles")
        self.assertEqual(code, 0)
        self.assertIn("Main!A1", text)
        self.assertIn("notice", text.lower())
        self.assertIn("0 warnings", text)
        code, text = run("review", written(book(STEPPING, "iterate 3 0")), "--only", "cycles")
        self.assertEqual(code, 1)
        self.assertIn("Main!A1", text)
        self.assertIn("1 warning", text)

    def test_the_review_of_a_whole_settled_book_has_no_cycle_warning(self):
        desk = Desk.of_text(book(STEPPING))
        held = desk.review(only=["cycles"])
        self.assertEqual([one.level for one in held], ["notice"])

    def test_the_trace_holds_a_settled_cell_once_with_its_settled_value(self):
        desk = Desk.of_text(book(STEPPING))
        desk.recalculate()
        steps = [one for one in desk.trace() if one.at.written(False) == "A1"]
        self.assertGreaterEqual(len(steps), 1)
        self.assertEqual(steps[-1].after.written(), "20")

    def test_the_calc_summary_counts_only_cycles_that_did_not_settle(self):
        text = book("  A1 =IF(A1>=3,A1,A1+1)\n  C1 =C1+1\n  D1 =D1+1\n")
        code, out = run("calc", written(text))
        self.assertEqual(code, 3)
        self.assertIn("2 cells in a cycle", out)

    def test_the_cells_table_shows_the_settled_value(self):
        code, text = run("cells", written(book(STEPPING)), "--sheet", "Main")
        self.assertEqual(code, 0)
        row = [line for line in text.splitlines() if line.startswith("A1")][0]
        self.assertEqual(row.split()[-1], "20")


class PagesTest(_Guarded):
    """The readme list, the format page, the changelog."""

    def readme(self):
        with open(os.path.join(ROOT, "README.md"), encoding="utf-8") as handle:
            return handle.read()

    def test_the_readme_lists_fourteen_things_and_iteration_is_not_one(self):
        said = self.readme()
        found = re.findall(r"^(\d+)\. \*\*", said, re.M)
        self.assertIn(found, tuple([str(one) for one in range(1, n)] for n in (14, 15, 16)))
        self.assertNotIn("There is no setting to turn that into a feature", said)

    def test_the_format_page_documents_the_iterate_line(self):
        with open(os.path.join(ROOT, "docs", "format.md"), encoding="utf-8") as handle:
            text = handle.read()
        self.assertIn("iterate", text)

    def test_the_changelog_records_the_feature(self):
        with open(os.path.join(ROOT, "CHANGELOG.md"), encoding="utf-8") as handle:
            text = handle.read()
        self.assertGreater(len(re.findall(r"^- ", text, re.M)), 37)


if __name__ == "__main__":
    unittest.main()
