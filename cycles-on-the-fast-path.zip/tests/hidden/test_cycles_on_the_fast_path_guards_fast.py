"""What already holds and must go on holding once a book has a fast path for one sheet.

Nothing a desk answers ever differs from a fresh desk over the same text, after any sequence of
changes: values, the graph's edges, the order, the review and the summary. The full
recalculation still works everything out, the sheet-level functions are unchanged, cycles are
still errors, and the worked examples answer as before. Standard library only.
"""

import io
import os
import signal
import unittest

from trestle import Desk, write_book
from trestle.cli.main import main
from trestle.recalc import recalculate, recalculated_after
from trestle.sheet import Sheet

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _stop(signum, frame):
    raise AssertionError("took too long")


class _Guarded(unittest.TestCase):
    """A test that hangs fails rather than waits."""

    def setUp(self):
        signal.signal(signal.SIGALRM, _stop)
        signal.alarm(120)

    def tearDown(self):
        signal.alarm(0)


def run(*argv):
    """The command line, run in this process, with what it printed."""
    stream = io.StringIO()
    code = main(list(argv), stream)
    return code, stream.getvalue().rstrip("\n")


def big_book(sheets=12, rows=20):
    """Sheets of chained formulas, each sheet's B1 reading the one before it."""
    lines = ["trestle-book 1", "name Big"]
    for k in range(1, sheets + 1):
        lines.append("sheet S%d" % k)
        lines.append("  A1 %d" % k)
        for row in range(2, rows + 2):
            lines.append("  A%d =A%d+1" % (row, row - 1))
        if k > 1:
            lines.append("  B1 =S%d!A%d+1" % (k - 1, rows + 1))
    return "\n".join(lines) + "\n"


def fresh(desk):
    held = Desk.of_text(write_book(desk.book))
    held.recalculate()
    return held


def values_of(desk):
    found = {}
    for sheet in desk.book.sheets():
        for address, cell in sheet.cells():
            where = address.in_sheet(sheet.name)
            found[where.written()] = desk.value_at(where).written()
    return found


def same_as_fresh(test, desk):
    """Values, edges, order, review and summary all agree with a fresh desk."""
    other = fresh(desk)
    test.assertEqual(values_of(desk), values_of(other))
    test.assertEqual(set(desk.links().edges()), set(other.links().edges()))
    test.assertEqual([one.written() for one in desk.order()], [one.written() for one in other.order()])
    test.assertEqual([one.written() for one in desk.order().stuck],
                     [one.written() for one in other.order().stuck])
    test.assertEqual(desk.review().summary(), other.review().summary())


class NeverDiffersTest(_Guarded):
    """After any sequence of changes a desk agrees with a fresh one."""

    def test_after_numbers_formulas_and_emptied_cells(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        desk.put("S3!A1", 300)
        desk.recalculate()
        desk.put("S5!C1", "=S2!A21*2")
        desk.put("S7!C1", "=SUM(S5!A1:A21)")
        desk.recalculate()
        desk.put("S2!A1", "")
        desk.recalculate()
        desk.put("S5!C1", "")
        desk.recalculate()
        same_as_fresh(self, desk)

    def test_after_a_rename_a_removal_and_an_addition(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        desk.book.rename("S4", "Four")
        desk.recalculate()
        desk.book.remove("S8")
        desk.recalculate()
        desk.book.add(Sheet("New", {"A1": "=Four!A21+S3!A21"}))
        desk.recalculate()
        desk.put("Four!A1", 4000)
        desk.recalculate()
        same_as_fresh(self, desk)

    def test_after_cycles_made_and_broken(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        desk.put("S1!C1", "=S2!C1+1")
        desk.put("S2!C1", "=S1!C1+1")
        desk.recalculate()
        same_as_fresh(self, desk)
        desk.put("S2!C1", 5)
        desk.recalculate()
        same_as_fresh(self, desk)
        desk.put("S6!A1", "=A21")
        desk.recalculate()
        same_as_fresh(self, desk)

    def test_without_recalculating_in_between(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        desk.put("S3!A1", 300)
        desk.put("S9!C1", "=S3!A21")
        desk.put("S3!A1", 3)
        desk.book.rename("S9", "Nine")
        same_as_fresh(self, desk)


class StillTheSameTest(_Guarded):
    """The full recalculation, the sheet-level functions, cycles and the examples."""

    def test_the_full_recalculation_still_works_everything_out(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.assertEqual(len(desk.trace()), 12 * 20 + 11)
        desk.put("S3!A1", 300)
        desk.recalculate(again=True)
        self.assertEqual(len(desk.trace()), 12 * 20 + 11)
        self.assertEqual(desk.value_at("S4!B1").written(), "321")

    def test_the_first_recalculation_works_everything_out(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        self.assertEqual(len(desk.trace()), 12 * 20 + 11)

    def test_nothing_changed_means_nothing_more_is_built(self):
        desk = Desk.of_text(big_book())
        desk.recalculate()
        before = desk.value_at("S12!B1").written()
        import trestle.graph.links as links_module
        counted = {"notes": 0}
        original = links_module.Links.note

        def counting(held, where, tree, filled=True):
            counted["notes"] += 1
            return original(held, where, tree, filled)

        links_module.Links.note = counting
        try:
            desk.recalculate()
        finally:
            links_module.Links.note = original
        self.assertEqual(desk.value_at("S12!B1").written(), before)
        self.assertEqual(counted["notes"], 0)

    def test_the_book_s_full_recalculation_is_unchanged(self):
        from trestle.store import read_book

        book = read_book(big_book())
        trace = book.recalculate()
        self.assertEqual(len(trace), 12 * 20 + 11)
        self.assertEqual(book.value_at("S12!B1").written(), "32")

    def test_a_sheet_on_its_own_still_works_out_only_what_changed(self):
        sheet = Sheet("Main", {"A1": 1, "A2": "=A1+1", "A3": "=A2+1", "C1": 5, "C2": "=C1*2"})
        recalculate(sheet)
        sheet.put("A1", 10)
        held = recalculated_after(sheet, ["A1"])
        self.assertEqual([one.at.written(False) for one in held.trace], ["A2", "A3"])
        self.assertEqual(held.value_at("A3").written(), "12")

    def test_a_cycle_is_still_an_error(self):
        desk = Desk.empty()
        desk.put("A1", "=A1+1")
        self.assertEqual(desk.value_at("A1").written(), "#CYCLE!")
        desk = Desk.of_text("trestle-book 1\nsheet Main\n  A1 =Other!A1+1\nsheet Other\n  A1 =Main!A1\n")
        self.assertEqual(desk.value_at("Main!A1").written(), "#CYCLE!")

    def test_the_budget_links_order_and_values_are_unchanged(self):
        code, text = run("links", "budget")
        self.assertEqual(code, 0)
        self.assertIn("6 formulas, 12 links", text)
        code, text = run("order", "budget")
        self.assertEqual([line.split()[-1] for line in text.splitlines()[3:9]],
                         ["Income!B4", "Left!B1", "Spending!B6", "Left!B2", "Left!B3", "Left!B4"])
        desk = Desk.demo("budget")
        self.assertEqual(desk.value_at("Left!B3").written(), "1090")

    def test_the_examples_still_come_to_the_same(self):
        for name, where, wanted in (("budget", "Left!B3", "1090"), ("invoice", None, None),
                                    ("loan", None, None), ("marks", None, None)):
            desk = Desk.demo(name)
            desk.recalculate()
            if where:
                with self.subTest(example=name):
                    self.assertEqual(desk.value_at(where).written(), wanted)
            again = Desk.of_text(write_book(desk.book))
            with self.subTest(example=name):
                self.assertEqual(desk.digest(values=True), again.digest(values=True))

    def test_the_broken_book_still_reviews_the_same(self):
        code, text = run("calc", os.path.join(ROOT, "examples", "broken.book"))
        self.assertEqual(code, 3)
        self.assertIn("review: 10 warnings, 6 notices", text)

    def test_typing_through_the_desk_still_shows_the_text_and_the_value(self):
        desk = Desk.empty()
        desk.put("A1", 2)
        desk.put("B1", "=A1*3")
        self.assertEqual(desk.text_at("B1"), "=A1*3")
        self.assertEqual(desk.value_at("B1").written(), "6")
        desk.put("A1", 5)
        self.assertEqual(desk.value_at("B1").written(), "15")


if __name__ == "__main__":
    unittest.main()
