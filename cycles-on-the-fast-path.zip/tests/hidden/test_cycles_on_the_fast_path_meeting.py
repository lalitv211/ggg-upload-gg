"""Where cycles that settle and the fast path meet.

In an iterating book a change makes a cycle stale when it touches a cell in it or a cell it
reads; a stale cycle is gone round again from blank and its cells are in the trace once; a
cycle nothing stale reaches is left alone, keeps its settled values and spends no pass, which a
counting function registered here can tell. The note budget holds with cycles, a change that
makes or breaks a cycle in an iterating book settles or works it out, turning iteration on or off
makes every cycle stale, renaming and removing sheets a cycle runs through behave as the rules
say, and everything agrees with a fresh desk. Standard library only: unittest.
"""

import os
import signal
import unittest

import trestle.graph.links as links_module
from trestle import Desk, write_book
from trestle.functions.registry import register
from trestle.sheet import Sheet
from trestle.values import number

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

TALLY = {"worked out": 0}


@register("TALLYFORTHISTEST", 0, 0, "info", "counts how often it is worked out, for a test")
def _tally(arguments, setting):
    """Nought, and one more count each time it is worked out."""
    TALLY["worked out"] += 1
    return number(0)


def _stop(signum, frame):
    raise AssertionError("took too long")


class _Guarded(unittest.TestCase):
    """A test that hangs fails rather than waits; the note counter is always put back."""

    def setUp(self):
        signal.signal(signal.SIGALRM, _stop)
        signal.alarm(120)
        self.notes = 0
        original = links_module.Links.note
        self._original_note = original
        test = self

        def counting(held, where, tree, filled=True):
            test.notes += 1
            return original(held, where, tree, filled)

        links_module.Links.note = counting
        TALLY["worked out"] = 0

    def tearDown(self):
        links_module.Links.note = self._original_note
        signal.alarm(0)

    def reset(self):
        self.notes = 0
        TALLY["worked out"] = 0


def book(cells, setting="iterate 100 0", more=""):
    """An iterating book with one sheet called Main, and more sheets after it."""
    head = ["trestle-book 1", "name Meet"]
    if setting:
        head.append(setting)
    return "\n".join(head) + "\nsheet Main\n" + cells + more


# One stepping cycle in A1 that counts its passes, a plain chain in C, a second cycle in E.
TWO_CYCLES = ("  B1 20\n  A1 =TALLYFORTHISTEST()+IF(A1>=B1,A1,A1+5)\n  D1 =A1*2\n"
              "  C1 1\n  C2 =C1+1\n  C3 =C2+1\n"
              "  F1 3\n  E1 =IF(E1>=F1,E1,E1+1)\n  G1 =E1+1\n")


def traced(desk):
    return [step.at.written() for step in desk.trace()]


def fresh(desk):
    held = Desk.of_text(write_book(desk.book))
    held.recalculate()
    return held


def values_of(desk):
    found = {}
    for sheet in desk.book.sheets():
        for address, cell in sheet.cells():
            where = address.in_sheet(sheet.name)
            found[where.written()] = desk.value_at(where).written()
    return found


def same_as_fresh(test, desk):
    other = fresh(desk)
    test.assertEqual(values_of(desk), values_of(other))
    test.assertEqual(set(desk.links().edges()), set(other.links().edges()))
    test.assertEqual([one.written() for one in desk.order()], [one.written() for one in other.order()])
    test.assertEqual(desk.review().summary(), other.review().summary())


class StaleCyclesTest(_Guarded):
    """Only the cycles a change reaches are gone round again."""

    def test_a_change_nothing_in_the_cycle_reads_spends_no_pass_on_it(self):
        desk = Desk.of_text(book(TWO_CYCLES))
        desk.recalculate()
        self.assertEqual(desk.value_at("A1").written(), "20")
        passes = TALLY["worked out"]
        self.assertGreaterEqual(passes, 5)
        self.reset()
        desk.put("C1", 10)
        self.assertEqual(desk.value_at("C3").written(), "12")
        self.assertEqual(TALLY["worked out"], 0, "the cycle in A1 was not gone round again")
        self.assertEqual(set(traced(desk)), {"Main!C2", "Main!C3"})
        self.assertEqual(desk.value_at("A1").written(), "20")
        self.assertEqual(desk.value_at("D1").written(), "40")

    def test_a_change_to_what_the_cycle_reads_goes_round_it_again_from_blank(self):
        desk = Desk.of_text(book(TWO_CYCLES))
        desk.recalculate()
        self.reset()
        desk.put("B1", 10)
        self.assertEqual(desk.value_at("A1").written(), "10")
        self.assertEqual(desk.value_at("D1").written(), "20")
        self.assertEqual(TALLY["worked out"], fresh_passes(book(TWO_CYCLES).replace("B1 20", "B1 10")))
        held = traced(desk)
        self.assertEqual(set(held), {"Main!A1", "Main!D1"})
        self.assertEqual([step.after.written() for step in desk.trace() if step.at.written() == "Main!A1"][-1], "10")

    def test_a_change_inside_the_cycle_goes_round_it_again(self):
        desk = Desk.of_text(book(TWO_CYCLES))
        desk.recalculate()
        self.reset()
        desk.put("A1", "=TALLYFORTHISTEST()+IF(A1>=B1,A1,A1+4)")
        self.assertEqual(desk.value_at("A1").written(), "20")
        self.assertGreaterEqual(TALLY["worked out"], 5)
        self.assertEqual(set(traced(desk)), {"Main!A1", "Main!D1"})
        self.assertEqual(desk.value_at("E1").written(), "3")

    def test_the_other_cycle_is_left_alone(self):
        desk = Desk.of_text(book(TWO_CYCLES))
        desk.recalculate()
        self.reset()
        desk.put("F1", 7)
        self.assertEqual(desk.value_at("E1").written(), "7")
        self.assertEqual(desk.value_at("G1").written(), "8")
        self.assertEqual(TALLY["worked out"], 0)
        self.assertEqual(set(traced(desk)), {"Main!E1", "Main!G1"})

    def test_a_reader_of_a_settled_cycle_changed_elsewhere_does_not_go_round_it(self):
        desk = Desk.of_text(book(TWO_CYCLES + "  H1 =D1+C3\n"))
        desk.recalculate()
        self.reset()
        desk.put("C1", 100)
        self.assertEqual(desk.value_at("H1").written(), "142")
        self.assertEqual(TALLY["worked out"], 0)
        self.assertEqual(set(traced(desk)), {"Main!C2", "Main!C3", "Main!H1"})


def fresh_passes(text):
    """How often the counting cell is worked out when a fresh desk works the book out."""
    TALLY["worked out"] = 0
    Desk.of_text(text).recalculate()
    found = TALLY["worked out"]
    TALLY["worked out"] = 0
    return found


class BudgetWithCyclesTest(_Guarded):
    """The note budget and the trace hold when cycles are among the formulas."""

    def test_a_change_on_a_sheet_with_a_cycle_notes_at_most_that_sheet(self):
        more = "sheet Other\n  A1 =Main!D1+1\n  A2 =IF(A2>=A1,A2,A2+10)\n"
        desk = Desk.of_text(book(TWO_CYCLES, more=more))
        desk.recalculate()
        self.assertEqual(desk.value_at("Other!A2").written(), "50")
        self.reset()
        desk.put("B1", 10)
        self.assertEqual(desk.value_at("Other!A2").written(), "30")
        self.assertLessEqual(self.notes, 9)
        self.assertEqual(set(traced(desk)), {"Main!A1", "Main!D1", "Other!A1", "Other!A2"})

    def test_a_cycle_across_sheets_made_by_a_change_settles(self):
        desk = Desk.of_text(book("  A1 =IF(Other!A1>=5,Other!A1,Other!A1+1)\n", more="sheet Other\n  A1 7\n"))
        desk.recalculate()
        self.assertEqual(desk.value_at("Main!A1").written(), "7")
        self.reset()
        desk.put("Other!A1", "=Main!A1")
        self.assertEqual(desk.value_at("Main!A1").written(), "5")
        self.assertEqual(desk.value_at("Other!A1").written(), "5")
        self.assertEqual(set(traced(desk)), {"Main!A1", "Other!A1"})
        self.assertLessEqual(self.notes, 2)

    def test_a_cycle_broken_by_a_change_is_worked_out_as_plain_formulas(self):
        desk = Desk.of_text(book("  A1 =IF(Other!A1>=5,Other!A1,Other!A1+1)\n", more="sheet Other\n  A1 =Main!A1\n"))
        desk.recalculate()
        self.assertEqual(desk.value_at("Main!A1").written(), "5")
        self.reset()
        desk.put("Other!A1", 9)
        self.assertEqual(desk.value_at("Main!A1").written(), "9")
        self.assertEqual(set(traced(desk)), {"Main!A1"})

    def test_a_cycle_that_runs_out_of_passes_after_a_change(self):
        desk = Desk.of_text(book("  B1 3\n  A1 =IF(A1>=B1,A1,A1+1)\n  D1 =A1\n", "iterate 6 0"))
        desk.recalculate()
        self.assertEqual(desk.value_at("A1").written(), "3")
        desk.put("B1", 30)
        self.assertEqual(desk.value_at("A1").written(), "#CYCLE!")
        self.assertEqual(desk.value_at("D1").written(), "#CYCLE!")
        self.assertEqual(set(traced(desk)), {"Main!A1", "Main!D1"})
        desk.put("B1", 4)
        self.assertEqual(desk.value_at("A1").written(), "4")


class SwitchingTest(_Guarded):
    """Turning iteration on or off makes every cycle stale and nothing else."""

    def test_turning_iteration_on_settles_the_cycles_and_touches_nothing_else(self):
        desk = Desk.of_text(book(TWO_CYCLES, ""))
        desk.recalculate()
        self.assertEqual(desk.value_at("A1").written(), "#CYCLE!")
        self.reset()
        desk.iterate(100, 0)
        self.assertEqual(desk.value_at("A1").written(), "20")
        self.assertEqual(desk.value_at("E1").written(), "3")
        self.assertTrue({"Main!A1", "Main!E1"} <= set(traced(desk)))

    def test_a_desk_that_iterates_from_the_start_agrees_with_one_switched_on_later(self):
        later = Desk.of_text(book(TWO_CYCLES, ""))
        later.recalculate()
        later.iterate(100, 0)
        later.recalculate()
        always = Desk.of_text(book(TWO_CYCLES))
        always.recalculate()
        self.assertEqual(values_of(later), values_of(always))


class SheetsTest(_Guarded):
    """Sheets a cycle runs through, renamed or removed."""

    def test_renaming_a_sheet_a_cycle_runs_through_keeps_it_settled(self):
        text = book("  A1 =IF(Other!A1>=5,Other!A1,Other!A1+1)\n  B1 =A1*2\n", more="sheet Other\n  A1 =Main!A1\n")
        desk = Desk.of_text(text)
        desk.recalculate()
        desk.book.rename("Other", "Elsewhere")
        self.assertEqual(desk.value_at("Main!A1").written(), "5")
        self.assertEqual(desk.value_at("Elsewhere!A1").written(), "5")
        self.assertEqual(desk.value_at("Main!B1").written(), "10")
        same_as_fresh(self, desk)

    def test_removing_a_sheet_a_cycle_runs_through_breaks_it(self):
        text = book("  A1 =IF(Other!A1>=5,Other!A1,Other!A1+1)\n  B1 =A1*2\n", more="sheet Other\n  A1 =Main!A1\n")
        desk = Desk.of_text(text)
        desk.recalculate()
        desk.book.remove("Other")
        self.assertEqual(desk.value_at("Main!A1").written(), "#REF!")
        self.assertEqual(desk.value_at("Main!B1").written(), "#REF!")
        same_as_fresh(self, desk)

    def test_adding_a_sheet_that_closes_a_cycle(self):
        desk = Desk.of_text(book("  A1 =IF(Other!A1>=5,Other!A1,Other!A1+1)\n"))
        desk.recalculate()
        self.assertEqual(desk.value_at("Main!A1").written(), "#REF!")
        desk.book.add(Sheet("Other", {"A1": "=Main!A1"}))
        self.assertEqual(desk.value_at("Main!A1").written(), "5")
        self.assertEqual(desk.value_at("Other!A1").written(), "5")
        same_as_fresh(self, desk)


class AgreesTest(_Guarded):
    """After any sequence of changes an iterating desk agrees with a fresh one."""

    def test_after_changes_in_and_around_cycles(self):
        desk = Desk.of_text(book(TWO_CYCLES, more="sheet Other\n  A1 =Main!D1+1\n  A2 =IF(A2>=A1,A2,A2+10)\n"))
        desk.recalculate()
        desk.put("B1", 10)
        desk.recalculate()
        desk.put("C1", 7)
        desk.put("E1", "=IF(E1>=F1*2,E1,E1+2)")
        desk.recalculate()
        desk.put("Other!A3", "=A2*A1")
        desk.put("F1", 9)
        same_as_fresh(self, desk)
        desk.iterate(3, 0)
        same_as_fresh(self, desk)


if __name__ == "__main__":
    unittest.main()
