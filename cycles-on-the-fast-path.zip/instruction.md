Three readme gaps. Loan sheet's interest and balance read each other, an error. Planning book, forty sheets of fifty formulas: one number on sheet twenty rebuilds the whole graph, reworks every formula. And =costs!A1 is #REF! next to Costs.

Book file gets a line, iterate 100 0.001, passes and tolerance, after the header, before the first sheet, written back the same, digest and diff see it. Book and desk get iterate and iteration. With it each cycle is worked out by passes, every cell in it once per pass in reading order, first pass from blank. Settled when a pass moves no cell by more than the tolerance, #CYCLE! for the whole cycle when passes run out, each cycle on its own, errors inside are values, across sheets too. All settled, calc says nothing about cycles and review gives a notice.

After the first recalculation a change costs its sheet and what reads it, nothing else. Only what it made stale is worked out, once each, in the book's order. A cycle is stale when the change touches a cell in it or one it reads, and goes round again from blank. A cycle nothing stale reaches is left alone, no pass spent. Graph of a sheet nobody changed is not built again, at most that sheet's formulas get noted. Answers never differ from a fresh desk over the same text. Renaming a sheet is a change too, cycles made or broken get worked out, book gets recalculated_after like a sheet.

Sheet names match in any case like function names, kept as typed, never Costs and costs in one book.

Keep readme, format, model and performance pages and changelog right. Tests next to existing ones, counting links noted and cells worked out, never timing, one with a sheet renamed.
