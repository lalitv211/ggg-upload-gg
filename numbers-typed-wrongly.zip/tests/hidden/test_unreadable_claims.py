"""A claim that is not a figure is a finding, not a crash.

``wolf = about 36`` in a ``[claims]`` section cannot be compared with
anything. It is reported as unreadable, the file does not agree, the
other claims in the file are still checked, and the commands that
read files -- ``claims``, ``verdict`` and ``survey`` -- answer rather
than fall over. A survey stops at nothing, so the instruments after
one with an unreadable claim are still checked too.

A field a claim needs, given in a form the package cannot use, is not
a field left out: the claims report names the field and what was
written there, the claims that need it are not compared, and the
file does not agree. Which verdict those claims carry is not decided
here.
"""

from __future__ import annotations

import pytest

from wolf.cli.main import run
from wolf.errors import Inconsistent
from wolf.io import bundle
from wolf.io import check as checking
from wolf.io.write import from_mapping

#: Things somebody might write where a figure belongs.
NOT_FIGURES = ("about 36", "", "35,68", "yes", "35.68 cents", "1/0")


def made(**sections):
    """A record from plain mappings."""

    return from_mapping(sections, "test.stops")


def meantone(**claims):
    """A quarter-comma instrument at A440 with the given claims."""

    return made(tuning={"temperament": "quarter_comma",
                        "standard": "a440", "tonic": "C"},
                claims=claims)


def figure(text, name):
    """The value printed beside a name in a report's figure part."""

    for line in text.splitlines():
        words = line.split()
        if words and words[0] == name:
            return words[-1]
    raise AssertionError("no line for {0!r} in:\n{1}".format(name, text))


@pytest.mark.parametrize("written", NOT_FIGURES,
                         ids=lambda one: one or "nothing")
def test_a_claim_that_is_not_a_figure_is_unreadable(written):
    """And nothing raises."""

    found = meantone(wolf=written)
    rows = checking.check(found)
    assert len(rows) == 1
    assert rows[0]["verdict"] == "unreadable"
    assert rows[0]["claim"] == "wolf"
    assert rows[0]["written"] == written


@pytest.mark.parametrize("written", NOT_FIGURES,
                         ids=lambda one: one or "nothing")
def test_a_file_with_an_unreadable_claim_does_not_agree(written):
    """It is not a disagreement and it is not agreement either."""

    found = meantone(wolf=written, a4="440")
    assert not checking.agreed(found)
    with pytest.raises(Inconsistent) as bad:
        checking.must_agree(found)
    assert "wolf" in str(bad.value)


def test_the_other_claims_in_the_file_are_still_checked():
    """One claim nobody can read does not stop the rest."""

    found = meantone(a4="440", wolf="about 36", worst_third="41.06",
                     middle_c="100", smell="damp")
    rows = {one["claim"]: one["verdict"] for one in checking.check(found)}
    assert rows == {"a4": "agrees", "wolf": "unreadable",
                    "worst_third": "agrees", "middle_c": "disagrees",
                    "smell": "unknown"}


def test_every_claim_is_counted_once():
    """The counts add up to the claims, whatever the verdicts."""

    found = meantone(a4="440", wolf="about 36", middle_c="100",
                     smell="damp", key_range="")
    counted = checking.verdicts(found)
    assert sum(counted.values()) == 5
    assert counted["agrees"] == 1
    assert counted["disagrees"] == 1
    assert counted["unknown"] == 1
    assert counted["unreadable"] == 2
    assert checking.summary(found)["checked"] == 5


def test_the_precision_rule_is_untouched_by_the_new_verdict():
    """A figure written to one place is still held to one."""

    found = meantone(wolf="35.7")
    assert checking.check(found)[0]["verdict"] == "agrees"
    found = meantone(wolf="35.69")
    assert checking.check(found)[0]["verdict"] == "disagrees"
    found = meantone(wolf="about 35.7")
    assert checking.check(found)[0]["verdict"] == "unreadable"


def test_a_bundle_goes_on_past_an_unreadable_claim():
    """The instrument is named as failing and the others are checked."""

    text = "\n".join([
        "[defaults]", "tuning.standard = a440", "tuning.tonic = C",
        "---",
        "[instrument]", "place = One", "[tuning]",
        "temperament = equal", "[claims]", "a4 = 440",
        "---",
        "[instrument]", "place = Two", "[tuning]",
        "temperament = quarter_comma", "[claims]", "wolf = about 36",
        "---",
        "[instrument]", "place = Three", "[tuning]",
        "temperament = quarter_comma", "[claims]", "wolf = 0",
        "---",
        "[instrument]", "place = Four", "[tuning]",
        "temperament = equal", "[claims]", "a4 = 440",
    ])
    found = bundle.with_defaults(bundle.split(text, "t.stops"))
    assert len(found) == 4
    assert bundle.failing(found) == ("Two", "Three")
    rows = bundle.check_all(found)
    assert [one["agreed"] for one in rows] == [True, False, False, True]
    assert rows[1]["verdicts"]["unreadable"] == 1
    assert rows[2]["verdicts"]["disagrees"] == 1
    assert bundle.summary(found)["agreeing"] == 2
    with pytest.raises(Inconsistent) as bad:
        bundle.must_all_agree(found)
    assert "Two" in str(bad.value)


def test_claims_command_reports_an_unreadable_claim(tmp_path):
    """Exit nought, the verdict and the words written both shown."""

    one = tmp_path / "odd.stops"
    one.write_text("[tuning]\ntemperament = quarter_comma\n"
                   "standard = a440\n[claims]\na4 = 440\n"
                   "wolf = about 36\n", encoding="utf-8")
    code, text = run(["claims", str(one)])
    assert code == 0, text
    assert "unreadable" in text
    assert "about 36" in text
    assert "agrees" in text


def test_verdict_command_counts_an_unreadable_claim(tmp_path):
    """The file does not agree, and the count is there to see."""

    one = tmp_path / "odd.stops"
    one.write_text("[tuning]\ntemperament = quarter_comma\n"
                   "standard = a440\n[claims]\na4 = 440\n"
                   "wolf = about 36\n", encoding="utf-8")
    code, text = run(["verdict", str(one)])
    assert code == 0, text
    assert figure(text, "agreed") == "no"
    assert figure(text, "agrees") == "1"
    assert figure(text, "unreadable") == "1"
    assert figure(text, "checked") == "2"


def test_survey_command_goes_on_past_an_unreadable_claim(tmp_path):
    """Every instrument is in the table and the command answers."""

    one = tmp_path / "survey.stops"
    one.write_text("\n".join([
        "[defaults]", "tuning.standard = a440", "tuning.tonic = C",
        "---",
        "[instrument]", "place = One", "[tuning]",
        "temperament = equal", "[claims]", "a4 = 440",
        "---",
        "[instrument]", "place = Two", "[tuning]",
        "temperament = quarter_comma", "[claims]", "wolf = about 36",
        "---",
        "[instrument]", "place = Three", "[tuning]",
        "temperament = equal", "[claims]", "a4 = 440",
    ]), encoding="utf-8")
    code, text = run(["survey", str(one)])
    assert code == 0, text
    for place in ("One", "Two", "Three"):
        assert place in text, place
    code, text = run(["census", str(one)])
    assert code == 0, text


def test_a_blank_claim_is_unreadable_and_a_blank_field_is_a_value():
    """``wolf =`` under [tuning] is a builder saying there is no wolf;
    under [claims] it is a figure nobody wrote."""

    found = made(tuning={"temperament": "equal", "wolf": ""},
                 claims={"wolf": ""})
    assert found.get("tuning", "wolf", "unset") == ""
    assert checking.check(found)[0]["verdict"] == "unreadable"
    assert not checking.agreed(found)


#: A field written in a form the package cannot use: its section, its
#: name, what was written, and the claims worked out from it.
WRONG_FIELDS = [
    ("pipes", "bottom_hertz", "65,41", ("bottom_pipe",)),
    ("pipes", "degrees", "20C", ("bottom_pipe",)),
    ("tuning", "temperament", "quater_comma", ("wolf", "a4", "middle_c")),
    ("tuning", "standard", "a439", ("a4", "middle_c")),
]


def wrongly(section, field, written):
    """A meantone organ at A440, one field written wrongly, and a claim
    on four figures, every one of them right."""

    sections = {
        "tuning": {"temperament": "quarter_comma", "standard": "a440",
                   "tonic": "C"},
        "pipes": {"bottom_hertz": "65.41", "degrees": "20"},
        "claims": {"wolf": "35.68", "a4": "440", "middle_c": "263.18",
                   "bottom_pipe": "8.6"},
    }
    sections[section] = dict(sections[section], **{field: written})
    return sections


def as_text(sections):
    """Sections as the text of a file."""

    out = []
    for name, body in sections.items():
        out.append("[" + name + "]")
        out.extend("{0} = {1}".format(one, two) for one, two in body.items())
    return "\n".join(out) + "\n"


@pytest.mark.parametrize("section,field,written,needing", WRONG_FIELDS,
                         ids=[one[1] for one in WRONG_FIELDS])
def test_a_field_written_wrongly_is_not_a_field_left_out(
        section, field, written, needing):
    """The claims that need it are not compared, the others are, and
    the file does not agree."""

    found = made(**wrongly(section, field, written))
    rows = {one["claim"]: one["verdict"] for one in checking.check(found)}
    assert set(rows) == {"wolf", "a4", "middle_c", "bottom_pipe"}
    for claim, verdict in rows.items():
        if claim in needing:
            assert verdict not in ("agrees", "disagrees"), (claim, verdict)
        else:
            assert verdict == "agrees", (claim, verdict)
    assert not checking.agreed(found)
    with pytest.raises(Inconsistent):
        checking.must_agree(found)


@pytest.mark.parametrize("section,field,written,needing", WRONG_FIELDS,
                         ids=[one[1] for one in WRONG_FIELDS])
def test_the_claims_report_names_the_field_and_what_was_written(
        tmp_path, section, field, written, needing):
    """So the writer knows which line to look at."""

    path = tmp_path / "organ.stops"
    path.write_text(as_text(wrongly(section, field, written)),
                    encoding="utf-8")
    code, text = run(["claims", str(path)])
    assert code == 0, text
    body = text.replace(str(path), "")
    assert field in body, body
    assert written in body, body
    for claim in needing:
        assert claim in body


@pytest.mark.parametrize("section,field,written,needing", WRONG_FIELDS,
                         ids=[one[1] for one in WRONG_FIELDS])
def test_the_verdict_on_a_field_written_wrongly_is_no(
        tmp_path, section, field, written, needing):
    """Not the agreement it used to be."""

    path = tmp_path / "organ.stops"
    path.write_text(as_text(wrongly(section, field, written)),
                    encoding="utf-8")
    code, text = run(["verdict", str(path)])
    assert code == 0, text
    assert figure(text, "agreed") == "no", text


def test_a_wrong_default_is_found_in_every_instrument_it_reaches(
        tmp_path):
    """The survey names each instrument the default reached, checks
    the one that set its own standard, and still answers."""

    text = "\n".join([
        "[defaults]", "tuning.standard = a439", "tuning.tonic = C",
        "---",
        "[instrument]", "place = One", "[tuning]",
        "temperament = equal", "[claims]", "a4 = 439",
        "---",
        "[instrument]", "place = Two", "[tuning]",
        "temperament = equal", "standard = a440", "[claims]", "a4 = 440",
        "---",
        "[instrument]", "place = Three", "[tuning]",
        "temperament = quarter_comma", "[claims]", "middle_c = 263",
    ])
    found = bundle.with_defaults(bundle.split(text, "t.stops"))
    assert bundle.failing(found) == ("One", "Three")
    assert bundle.summary(found)["agreeing"] == 1
    path = tmp_path / "survey.stops"
    path.write_text(text, encoding="utf-8")
    code, shown = run(["survey", str(path)])
    assert code == 0, shown
    for place in ("One", "Two", "Three"):
        assert place in shown
