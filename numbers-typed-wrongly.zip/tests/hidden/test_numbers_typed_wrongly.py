"""A number typed wrongly on the command line is a usage error.

The command line documents three exit codes: nought for an answer,
two for a command line asked wrongly, with the text saying what to
type instead, and three for a refusal. A word that is not a number is
the second kind, whichever command and whichever option or argument
it was typed in; so are nan and inf, a decimal where a whole number
belongs, and one option given two different values. An absurd number
is refused quickly, as asked wrongly or as a refusal. Nothing here
raises past ``run`` or fails to come back.

Only outcomes are tested: the exit code, that the option or the
argument is named, and that the word typed is in the text. How the
check is arranged inside the command modules is not.
"""

from __future__ import annotations

import re
import signal

import pytest

from wolf.cli.main import CODES, run
from wolf.format.report import parts_of

#: Words that are not numbers: nan and inf, whatever a float makes of
#: them, and 1/0, which Fraction refuses differently from the rest.
NOT_NUMBERS = ("lots", "1/0", "4.5.6", "nan", "inf", "-inf")

#: Numbers that are not whole. Nothing here decides what a whole
#: number written with a decimal point of nought comes to.
NOT_WHOLE = ("4.5", "-0.5")

#: Every option that takes a number, with a command line it belongs
#: to and whether a whole number is wanted.
OPTIONS = [
    (["scale"], "--octave", True),
    (["beats", "C", "G"], "--octave", True),
    (["bearings", "equal"], "--octave", True),
    (["intervals", "quarter_comma"], "--steps", True),
    (["spread", "equal"], "--steps", True),
    (["rank"], "--compass", True),
    (["unit"], "--compass", True),
    (["thinning", "24"], "--compass", True),
    (["mixture", "mixture_iv"], "--compass", True),
    (["pipe", "65.41"], "--degrees", False),
    (["pipe", "65.41"], "--diameter", False),
    (["ends", "65.41"], "--degrees", False),
    (["rank"], "--bottom", False),
    (["mixture", "mixture_iv"], "--ceiling", False),
]

#: Every argument that is a number: the command line with the slot
#: marked, and whether a whole number is wanted.
ARGUMENTS = [
    (["circle", "?"], True),
    (["names", "?"], True),
    (["addnames", "?", "3"], True),
    (["addnames", "3", "?"], True),
    (["rounding", "?"], True),
    (["divide", "?"], True),
    (["thinning", "?", "36"], True),
    (["thinning", "24", "?"], True),
    (["pipe", "?"], False),
    (["ends", "?"], False),
    (["warming", "?", "25"], False),
    (["warming", "15", "?"], False),
    (["draw", "?", "--stops", "8,4"], False),
    (["which"] + ["261.6"] * 5 + ["?"] + ["261.6"] * 6, False),
]


def naming(argv):
    """A readable id for a command line."""

    return re.sub(r"[^A-Za-z0-9.-]+", "_", "-".join(argv))


def option_cases():
    """Every numeric option with every word it must refuse."""

    out = []
    for before, option, whole in OPTIONS:
        words = NOT_NUMBERS + (NOT_WHOLE if whole else ())
        for word in words:
            argv = before + [option, word]
            out.append(pytest.param(argv, option, word, id=naming(argv)))
    return out


def argument_cases():
    """Every numeric argument with every word it must refuse."""

    out = []
    for shape, whole in ARGUMENTS:
        words = NOT_NUMBERS + (NOT_WHOLE if whole else ())
        for word in words:
            argv = [word if one == "?" else one for one in shape]
            name = naming(shape) + "-" + naming([word or "nothing"])
            out.append(pytest.param(argv, word, id=name))
    return out


@pytest.mark.parametrize("argv,option,word", option_cases())
def test_an_option_that_is_not_a_number_is_a_usage_error(
        argv, option, word):
    """Exit two, the option named, the word named, on one line."""

    code, text = run(argv)
    assert code == 2, (argv, code, text)
    assert option in text, (argv, text)
    if word:
        assert word in text, (argv, text)
    assert len(text.splitlines()) == 1, (argv, text)
    assert text.startswith("wolf " + argv[0]), (argv, text)


@pytest.mark.parametrize("argv,word", argument_cases())
def test_an_argument_that_is_not_a_number_is_a_usage_error(argv, word):
    """Exit two and the word named, on one line."""

    code, text = run(argv)
    assert code == 2, (argv, code, text)
    if word:
        assert word in text, (argv, text)
    assert len(text.splitlines()) == 1, (argv, text)
    assert text.startswith("wolf " + argv[0]), (argv, text)


@pytest.mark.parametrize("argv", [
    ["scale", "--octave", "4.5"],
    ["beats", "C", "G", "--octave", "4.5"],
    ["bearings", "equal", "--octave", "3.5"],
    ["intervals", "quarter_comma", "--steps", "7.5"],
    ["spread", "equal", "--steps", "4.5"],
    ["rank", "--compass", "61.5"],
    ["unit", "--compass", "61.5"],
    ["mixture", "mixture_iv", "--compass", "61.5"],
    ["circle", "12.5"],
    ["names", "5.5"],
    ["rounding", "1.5"],
    ["divide", "31.5"],
    ["thinning", "24.5", "36"],
], ids=naming)
def test_a_decimal_is_not_cut_down_to_a_whole_number(argv):
    """The answer for the whole number is not given for the decimal."""

    code, text = run(argv)
    assert code == 2, (argv, code, text)
    whole = [one.split(".")[0] if re.fullmatch(r"-?\d+\.\d+", one)
             else one for one in argv]
    code, answer = run(whole)
    assert code == 0, (whole, answer)
    assert text != answer


def test_nothing_reaches_the_caller_as_a_traceback():
    """Every bad number, through every command that reads one, comes
    back as an exit code the command line documents."""

    tried = 0
    extra = ("x", "-", "")
    for before, option, _ in OPTIONS:
        for word in NOT_NUMBERS + NOT_WHOLE + extra:
            code, text = run(before + [option, word])
            assert code in CODES, (before, option, word, text)
            assert text.strip(), (before, option, word)
            tried += 1
    for shape, _ in ARGUMENTS:
        for word in NOT_NUMBERS + NOT_WHOLE + extra:
            argv = [word if one == "?" else one for one in shape]
            code, text = run(argv)
            assert code in CODES, (argv, text)
            assert text.strip(), argv
            tried += 1
    assert tried >= 200


def test_a_bad_number_is_two_and_a_refused_number_is_three():
    """The two failures a script tells apart: a word that is not a
    temperature, and a temperature no organ is voiced in."""

    assert run(["pipe", "65.41", "--degrees", "hot"])[0] == 2
    assert run(["pipe", "65.41", "--degrees", "200"])[0] == 3
    assert run(["divide", "many"])[0] == 2
    assert run(["divide", "1"])[0] == 3
    assert run(["names", "x"])[0] == 2
    assert run(["names", "9"])[0] == 3
    assert run(["circle", "lots"])[0] == 2
    assert run(["circle", "-1"])[0] == 3
    assert run(["pipe", "low"])[0] == 2
    assert run(["pipe", "0"])[0] == 3


def test_the_usage_text_names_the_option_the_way_places_does():
    """``--places lots`` always named its option; the others do now,
    and the text is not a traceback or a Python repr."""

    for argv, option in (
            (["scale", "--octave", "lots"], "--octave"),
            (["pipe", "65.41", "--degrees", "hot"], "--degrees"),
            (["rank", "--bottom", "six"], "--bottom"),
            (["mixture", "mixture_iv", "--ceiling", "high"],
             "--ceiling")):
        code, text = run(argv)
        assert code == 2, (argv, text)
        assert option in text
        for mark in ("Traceback", "Fraction("):
            assert mark not in text, (argv, text)


def test_a_halving_number_is_taken_as_a_number():
    """``--halving 20`` is what the hint under ``--halving`` asks for.

    The named scales are numbers in a table, so the one called
    normal and the number it stands for give the same rank.
    """

    code, text = run(["rank", "--halving", "20"])
    assert code == 0, text
    code, normal = run(["rank", "--halving", "normal"])
    assert code == 0, normal
    assert parts_of(text)["figure"] != parts_of(normal)["figure"]
    code, seventeen = run(["rank", "--halving", "17"])
    assert code == 0, seventeen
    assert parts_of(seventeen)["figure"] == parts_of(normal)["figure"]


def test_a_whole_number_may_be_negative():
    """A fraction of a whole number is refused and its sign is not:
    the rounding command's own default is minus one."""

    assert run(["rounding", "-2"])[0] == 0
    assert run(["scale", "--octave", "-1"])[0] == 0
    assert run(["scale", "--octave", "4.5"])[0] == 2


def test_a_twelfth_reading_that_is_not_a_number_is_named():
    """``which`` reads twelve numbers and any one of them can be
    typed wrongly."""

    good = ["261.6", "277.2", "293.7", "311.1", "329.6", "349.2",
            "370", "392", "415.3", "440", "466.2", "493.9"]
    for where in (0, 5, 11):
        argv = list(good)
        argv[where] = "about 440"
        code, text = run(["which"] + argv)
        assert code == 2, (where, text)
        assert "about 440" in text
    assert run(["which"] + good)[0] == 0


def test_the_steps_option_still_picks_the_just_interval_by_the_number():
    """Seven steps are measured against 3:2 and four against 5:4, as
    before, and the title still carries the number."""

    code, sevens = run(["intervals", "quarter_comma", "--steps", "7"])
    assert code == 0, sevens
    assert "3:2" in sevens
    assert "7 steps" in sevens
    code, fours = run(["intervals", "quarter_comma", "--steps", "4"])
    assert code == 0, fours
    assert "5:4" in fours
    assert run(["intervals", "quarter_comma", "--steps", "7.5"])[0] == 2


#: Numbers far too large for their slot, or for any figure at all, each
#: of which overflowed or hung somewhere before.
ABSURD = [
    ["scale", "--octave", "100000"],
    ["beats", "C", "G", "--octave", "100000"],
    ["bearings", "equal", "--octave", "100000"],
    ["rank", "--compass", "100000"],
    ["mixture", "mixture_iv", "--compass", "100000"],
    ["circle", "100000"],
    ["rounding", "100000"],
    ["rounding", "-100000"],
    ["pipe", "-1e999"],
    ["pipe", "65.41", "--degrees", "1e999"],
    ["pipe", "65.41", "--diameter", "1e999"],
    ["ends", "65.41", "--degrees", "1e999"],
    ["warming", "1e999", "25"],
    ["warming", "15", "1e999"],
    ["which"] + ["261.6"] * 11 + ["1e999"],
    ["part", "--part", "1e999"],
    ["meantone", "--part", "1e999"],
]


def answered_in(argv, seconds=10):
    """``run``, failing rather than waiting when it does not come back."""

    def late(*_):
        raise TimeoutError("{0} did not come back in {1} seconds".format(
            " ".join(argv), seconds))

    before = signal.signal(signal.SIGALRM, late)
    signal.alarm(seconds)
    try:
        return run(argv)
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, before)


@pytest.mark.parametrize("argv", ABSURD, ids=naming)
def test_an_absurd_number_is_refused_quickly(argv):
    """Refused on one line, not after a hang and not as a traceback.
    Whether as asked wrongly or as a refusal is not decided here."""

    code, text = answered_in(argv)
    assert code in (2, 3), (argv, code, text)
    assert len(text.splitlines()) == 1, (argv, text)
    assert text.startswith("wolf " + argv[0]), (argv, text)


@pytest.mark.parametrize("argv,option", [
    (["scale", "--octave", "4", "--octave", "5"], "--octave"),
    (["pipe", "65.41", "--degrees", "15", "--degrees", "20"],
     "--degrees"),
    (["rank", "--compass", "56", "--compass", "61"], "--compass"),
    (["size", "3:2", "--places", "2", "--places", "4"], "--places"),
    (["hertz", "C4", "--standard", "a415", "--standard", "a440"],
     "--standard"),
    (["hertz", "C4", "--temperament", "equal", "--temperament",
      "quarter_comma"], "--temperament"),
    (["scale", "--tonic", "C", "--tonic", "G"], "--tonic"),
    (["meantone", "--part", "1/4", "--part", "1/6"], "--part"),
], ids=lambda one: one if isinstance(one, str) else naming(one))
def test_an_option_given_two_values_is_a_usage_error(argv, option):
    """Exit two with the option named; the last value no longer wins."""

    code, text = run(argv)
    assert code == 2, (argv, code, text)
    assert option in text, (argv, text)
    assert len(text.splitlines()) == 1, (argv, text)
    assert text.startswith("wolf " + argv[0]), (argv, text)
