"""What already held about numbers on the command line, and has to go
on holding.

A good number still answers, a number the package will not take is
still refused with exit three, a ratio typed wrongly is still refused
with its hint, ``--places``, ``--part`` and ``--weights`` still say
what they said, and a claim written as a figure is still checked to
the places it was written at. These pass at the base commit; they are
here so a change that mends the bad numbers cannot quietly break the
good ones.
"""

from __future__ import annotations

import pytest

from wolf.cli.main import CODES, COMMANDS, run
from wolf.io import check as checking
from wolf.io.write import from_mapping


@pytest.mark.parametrize("argv", [
    ["scale", "--octave", "3"],
    ["scale", "--octave", "-1"],
    ["beats", "C", "G", "--octave", "5"],
    ["bearings", "equal", "--octave", "2"],
    ["intervals", "quarter_comma", "--steps", "4"],
    ["spread", "equal", "--steps", "7"],
    ["rank", "--compass", "56"],
    ["rank", "--bottom", "5.5"],
    ["rank", "--halving", "normal"],
    ["unit", "--compass", "32"],
    ["thinning", "24", "36", "--compass", "61"],
    ["mixture", "mixture_iv", "--ceiling", "5000"],
    ["mixture", "mixture_iv", "--compass", "56"],
    ["pipe", "65.41"],
    ["pipe", "65.41", "--degrees", "15.5"],
    ["pipe", "65.41", "--diameter", "4"],
    ["ends", "130.81", "--degrees", "-5"],
    ["warming", "-5", "25"],
    ["draw", "65.41", "--stops", "8,4,2"],
    ["circle", "12"],
    ["circle", "53"],
    ["names", "5"],
    ["addnames", "3", "3"],
    ["rounding", "-2"],
    ["rounding"],
    ["divide", "31"],
    ["which", "261.6", "277.2", "293.7", "311.1", "329.6", "349.2",
     "370", "392", "415.3", "440", "466.2", "493.9"],
    ["size", "3:2", "--places", "2"],
    ["part", "--part", "1/4"],
    ["meantone", "--part", "1/6"],
    ["optimum", "--weights", "fifth=1,major_third=2"],
], ids=lambda one: "-".join(one[:3]).replace(" ", "_"))
def test_a_good_number_still_answers(argv):
    """Exit nought and a report with something in it."""

    code, text = run(argv)
    assert code == 0, (argv, text)
    assert text.strip()


@pytest.mark.parametrize("argv", [
    ["pipe", "65.41", "--degrees", "200"],
    ["pipe", "0"],
    ["pipe", "-65"],
    ["divide", "1"],
    ["divide", "500"],
    ["names", "9"],
    ["circle", "-1"],
    ["rank", "--halving", "2"],
    ["hertz", "C4", "--temperament", "ptolemaic"],
    ["hertz", "C4", "--standard", "a500"],
    ["tuning", "nonesuch"],
], ids=lambda one: "-".join(one[:3]))
def test_a_refusal_is_still_a_refusal(argv):
    """A number the package will not take, or a name it has not got,
    is exit three on one line."""

    code, text = run(argv)
    assert code == 3, (argv, text)
    assert len(text.splitlines()) == 1


@pytest.mark.parametrize("argv", [
    ["size", "3:x"],
    ["size", "lots"],
    ["stack", "3:2", "x"],
    ["trip", "x"],
    ["size", "3:2", "--against", "x"],
], ids=lambda one: "-".join(one[:2]))
def test_a_ratio_typed_wrongly_is_refused_with_its_hint(argv):
    """A ratio has its own words and they still say what to type."""

    code, text = run(argv)
    assert code in (2, 3), (argv, text)
    assert "3:2" in text
    assert len(text.splitlines()) == 1


def test_the_three_options_that_always_checked_still_do():
    """``--places``, ``--part`` and ``--weights`` keep naming
    themselves."""

    code, text = run(["size", "3:2", "--places", "lots"])
    assert code == 2
    assert "--places" in text
    assert run(["size", "3:2", "--places", "40"])[0] == 2
    code, text = run(["part", "--part", "quarter"])
    assert code == 2
    assert "--part" in text
    code, text = run(["meantone", "--part", "1/x"])
    assert code == 2
    assert "--part" in text
    code, text = run(["optimum", "--weights", "fifth=lots"])
    assert code == 2
    assert "--weights" in text


def test_places_still_changes_the_answer():
    """Two places and four places are different text."""

    two = run(["size", "3:2", "--places", "2"])[1]
    four = run(["size", "3:2", "--places", "4"])[1]
    assert "701.96" in two
    assert "701.9550" in four


@pytest.mark.parametrize("name", sorted(COMMANDS))
def test_every_command_still_answers_with_nothing(name):
    """Called with nothing, every command answers or says what to
    type; none of them raise."""

    code, text = run([name])
    assert code in CODES, name
    assert text.strip(), name


def test_the_documented_figures_are_unchanged():
    """Four answers from the documentation, to the figure."""

    assert "701.955" in run(["size", "3:2"])[1]
    assert "263.1814" in run(["hertz", "C4", "--temperament",
                              "quarter_comma"])[1]
    text = run(["pipe", "65.41"])[1]
    assert "frequency" in text
    assert "65.41" in text
    assert "35.6823" in run(["wolves", "quarter_comma"])[1]


def made(**sections):
    """A record from plain mappings."""

    return from_mapping(sections, "test.stops")


def test_a_claim_written_as_a_figure_is_checked_as_before():
    """The precision rule, the unknown and the uncheckable verdicts."""

    found = made(tuning={"temperament": "quarter_comma",
                         "standard": "a440", "tonic": "C"},
                 claims={"wolf": "35.7", "a4": "440", "smell": "damp"})
    rows = {one["claim"]: one["verdict"] for one in checking.check(found)}
    assert rows == {"wolf": "agrees", "a4": "agrees", "smell": "unknown"}
    assert not checking.agreed(found)
    found = made(claims={"wolf": "35.68"})
    assert checking.check(found)[0]["verdict"] == "uncheckable"
    found = made(tuning={"temperament": "quarter_comma",
                         "standard": "a440", "tonic": "C"},
                 claims={"wolf": "35.69"})
    assert checking.check(found)[0]["verdict"] == "disagrees"


def test_the_example_files_still_say_what_they_said():
    """The chapel disagrees about its wolf and the village agrees."""

    code, text = run(["claims", "examples/chapel.stops"])
    assert code == 0, text
    assert "disagrees" in text
    assert "23.46" in text
    code, text = run(["verdict", "examples/village.stops"])
    assert code == 0, text
    assert "yes" in text
    code, text = run(["survey", "examples/survey.stops"])
    assert code == 0, text
    assert "St Mary the Virgin" in text


def test_a_whole_number_claim_agrees_within_half():
    """``agrees`` itself is unchanged: a figure is held to the places
    it was written at and no more."""

    assert checking.agrees("36", 35.68)
    assert checking.agrees("440", 440)
    assert not checking.agrees("440", 441)
    assert checking.agrees("35.68", 35.6823)
    assert not checking.agrees("35.68", 35.6923)


def test_a_halving_number_outside_the_range_is_still_refused():
    """A number that is a number and not a halving number anybody
    scales a rank at: exit three, the same as before. A name the
    scaling table has not got is refused as well, as a usage error
    or as a refusal."""

    code, text = run(["rank", "--halving", "2"])
    assert code == 3, text
    assert run(["rank", "--halving", "100"])[0] == 3
    assert run(["rank", "--halving", "lots"])[0] in (2, 3)


def test_an_unreadable_claim_in_a_file_that_says_too_little():
    """Still not a crash, still counted once, and still not a
    claim that agrees; whether the file or the claim is at fault
    first is not decided here."""

    found = made(claims={"wolf": "about 36"})
    rows = checking.check(found)
    assert len(rows) == 1
    assert rows[0]["verdict"] not in ("agrees", "disagrees")
    assert sum(checking.verdicts(found).values()) == 1
    assert checking.verdicts(found)["agrees"] == 0


def test_a_halving_that_is_not_a_halving_number_is_still_refused():
    """nan, inf and a number far too large are not halving numbers, as
    a usage error or as a refusal."""

    for word in ("nan", "inf", "1e999"):
        code, text = run(["rank", "--halving", word])
        assert code in (2, 3), (word, text)
        assert len(text.splitlines()) == 1


def test_a_field_left_out_still_leaves_its_claim_uncheckable():
    """And a file of such claims still agrees: nothing in it is
    wrong, it only says too little."""

    for sections in (
            {"claims": {"wolf": "35.68"}},
            {"tuning": {"temperament": "quarter_comma"},
             "claims": {"bottom_pipe": "8.6"}},
            {"tuning": {"temperament": "quarter_comma"},
             "pipes": {"bottom_hertz": "65.41"},
             "claims": {"bottom_pipe": "8.6"}}):
        found = made(**sections)
        assert checking.check(found)[0]["verdict"] == "uncheckable"
        assert checking.agreed(found)


def test_a_standard_left_out_is_still_a440():
    """A file that names no standard is at A440, as before."""

    found = made(tuning={"temperament": "quarter_comma"},
                 claims={"a4": "440", "middle_c": "263.18"})
    assert {one["verdict"] for one in checking.check(found)} == {"agrees"}
