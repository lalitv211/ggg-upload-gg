"""Hidden guards: what already holds at the base commit and must keep holding.

Cache-only and disabled searches never reach the provider, fetched fares land in the deals cache,
cached deals are folded into targeted results, leg fares come back per hop, a provider missing a
method is tolerated, and the metadata already counts what one provider instance sent.
"""

from datetime import date
from urllib.parse import urlparse

import httpx
import pytest
from sqlalchemy.orm import sessionmaker

from app.config import settings
from app.db.repositories.cached_deals_repository import CachedDealsRepository
from app.deals.refresher import refresh_deals
from app.models import ProviderMetadata, TripSearchRequest
from app.providers.travelpayouts.mapper import RoundTripFare
from app.services.flight_search_service import FlightSearchService

OCTOBER = (date(2027, 10, 1), date(2027, 10, 31))


class FakeResponse:
    def __init__(self, payload, status_code: int = 200):
        self.payload = payload
        self.status_code = status_code

    def json(self):
        return self.payload


def round_trip_row(origin: str, destination: str, month: str, index: int = 0, price: float = 120.0) -> dict:
    return {
        "origin": origin,
        "destination": destination,
        "price": price + index,
        "airline": "VY",
        "transfers": 0,
        "departure_at": f"{month}-{5 + index:02d}T09:00:00+02:00",
        "return_at": f"{month}-{12 + index:02d}T18:00:00+02:00",
        "link": "/search/x",
    }


class FakeTravelpayouts:
    def __init__(self):
        self.requests: list[tuple[str, dict]] = []
        self.refuse_from: int | None = None
        self.refuse_status = 429

    def __call__(self, url, params=None, headers=None, timeout=None):
        params = dict(params or {})
        path = urlparse(url).path
        self.requests.append((path, params))
        if self.refuse_from is not None and len(self.requests) >= self.refuse_from:
            return FakeResponse({}, self.refuse_status)
        return FakeResponse(self.payload(path, params))

    def payload(self, path: str, params: dict) -> dict:
        origin = params.get("origin", "VIE")
        if path.endswith("/prices_for_dates"):
            month = params["departure_at"]
            destination = params.get("destination")
            if destination is None:
                rows = [round_trip_row(origin, code, month, index) for index, code in enumerate(["CPH", "LIS"])]
            else:
                rows = [round_trip_row(origin, destination, month, index) for index in range(3)]
            return {"success": True, "currency": "eur", "data": rows}
        if path.endswith("/prices/calendar"):
            month = params["depart_date"]
            destination = params["destination"]
            return {
                "success": True,
                "currency": "eur",
                "data": {f"{month}-05": round_trip_row(origin, destination, month, 0, 130.0)},
            }
        if path.endswith("/city-directions"):
            return {"success": True, "currency": "eur", "data": {"CPH": round_trip_row(origin, "CPH", "2027-06", 0, 90.0)}}
        if path.endswith("/month-matrix"):
            month = params["month"][:7]
            return {
                "success": True,
                "currency": "eur",
                "data": [
                    {
                        "origin": origin,
                        "destination": params["destination"],
                        "value": 60 + index,
                        "depart_date": f"{month}-{5 + index:02d}",
                        "number_of_changes": 0,
                        "duration": 150,
                        "found_at": "2027-09-20T10:00:00",
                    }
                    for index in range(3)
                ],
            }
        raise AssertionError(f"unexpected Travelpayouts path {path}")

    def keys(self, since: int = 0) -> list[tuple]:
        out = []
        for path, params in self.requests[since:]:
            month = params.get("departure_at") or params.get("depart_date") or params.get("month")
            out.append((path.rsplit("/", 1)[-1], params.get("origin"), params.get("destination"), (month or "")[:7]))
        return out


@pytest.fixture()
def live(monkeypatch, db_session):
    monkeypatch.setattr(settings, "travelpayouts_api_enabled", True)
    monkeypatch.setattr(settings, "travelpayouts_api_token", "test-token")
    monkeypatch.setattr(settings, "travelpayouts_marker", None)
    monkeypatch.setattr(settings, "live_flight_provider", "travelpayouts")
    monkeypatch.setattr(settings, "travelpayouts_cache_enabled", False)
    monkeypatch.setattr("app.deals.refresher.SessionLocal", sessionmaker(bind=db_session.get_bind()))
    fake = FakeTravelpayouts()
    monkeypatch.setattr(httpx, "get", fake)
    return fake


def request(origins, start=OCTOBER[0], end=OCTOBER[1], places=None) -> TripSearchRequest:
    return TripSearchRequest(
        originAirports=origins,
        destinationAirports=places,
        startDate=start,
        endDate=end,
        minTripLengthDays=3,
        maxTripLengthDays=10,
        maxBudget=900,
        maxGroundTransferHours=4,
        tripStyle="one city" if places else "surprise me",
    )


def cached_fare(destination: str, month: str = "2027-10", day: int = 5, price: float = 150.0) -> RoundTripFare:
    return RoundTripFare(
        origin="VIE", destination=destination, price=price, currency="EUR",
        departureDate=f"{month}-{day:02d}", returnDate=f"{month}-{day + 7:02d}", airline="OS", stops=0,
        bookingUrl="https://aviasales.com/x", affiliateUrl=None, observedAt=None,
    )


# ------------------------------------------------------------------- nobody asks when told not to

@pytest.mark.parametrize("places", [None, ["BCN"]])
def test_a_cache_only_search_never_asks_the_provider(db_session, live, places):
    CachedDealsRepository(db_session).upsert_deals([cached_fare("BCN")])
    service = FlightSearchService(db=db_session, provider_name="travelpayouts", cache_only=True)

    fares = service.discover_round_trip_fares(request(["VIE"], places=places))

    assert live.requests == []
    assert {fare.destination for fare in fares} == {"BCN"}


def test_a_disabled_api_is_never_asked(db_session, live, monkeypatch):
    monkeypatch.setattr(settings, "travelpayouts_api_enabled", False)

    FlightSearchService(db=db_session, provider_name="travelpayouts").discover_round_trip_fares(request(["VIE"], places=["BCN"]))
    FlightSearchService(db=db_session, provider_name="travelpayouts").discover_round_trip_fares(request(["VIE"]))

    assert live.requests == []


# ------------------------------------------------------------------ what a search gives back

def test_a_targeted_search_caches_its_fares_and_folds_in_the_cache(db_session, live):
    CachedDealsRepository(db_session).upsert_deals([cached_fare("CPH")])

    fares = FlightSearchService(db=db_session, provider_name="travelpayouts").discover_round_trip_fares(
        request(["VIE"], places=["BCN"])
    )

    assert {fare.destination for fare in fares} == {"BCN"}, "a named destination filters the answer"
    cached = {fare.destination for fare in CachedDealsRepository(db_session).fresh_deals(["VIE"])}
    assert {"BCN", "CPH"} <= cached, "what was fetched is cached next to what was there"
    assert CachedDealsRepository(db_session).has_fresh(["VIE"]) is True


def test_a_cold_open_search_returns_the_window_and_the_discovery_fares(db_session, live):
    fares = FlightSearchService(db=db_session, provider_name="travelpayouts").discover_round_trip_fares(request(["VIE"]))

    destinations = {fare.destination for fare in fares}
    assert {"CPH", "LIS"} <= destinations
    assert all(fare.origin == "VIE" for fare in fares)
    assert live.requests, "a cold origin is asked"


def test_leg_fares_come_back_per_hop(db_session, live):
    service = FlightSearchService(db=db_session, provider_name="travelpayouts")

    fares = service.one_way_fares_for(request(["VIE"]), [("VIE", "BCN"), ("BCN", "LIS")])

    assert set(fares) == {("VIE", "BCN"), ("BCN", "LIS")}
    assert all(len(items) >= 3 for items in fares.values())
    assert {key[0] for key in live.keys()} == {"month-matrix"}


def test_a_provider_without_the_round_trip_methods_is_tolerated(db_session, live):
    class Thin:
        name = "travelpayouts"
        warnings: list[str] = []
        requests_attempted = 0

        def discover_round_trips(self, origins):
            return [cached_fare("BCN")]

    service = FlightSearchService(db=db_session, provider_name="travelpayouts", provider=Thin())

    fares = service.discover_round_trip_fares(request(["VIE"]))

    assert {fare.destination for fare in fares} == {"BCN"}
    assert live.requests == []


# ---------------------------------------------------------------- what the metadata already said

def test_the_metadata_in_travelpayouts_mode_counts_the_requests(db_session, live):
    service = FlightSearchService(db=db_session, provider_name="travelpayouts")
    service.discover_round_trip_fares(request(["VIE"], places=["BCN"]))

    metadata = service.apply_deal_metadata(ProviderMetadata(providerUsed="travelpayouts", providerName="travelpayouts"))

    assert metadata.requestsAttempted == len(live.requests) == 2
    assert metadata.liveProviderAttempted is True


def test_a_refusal_is_reported_in_the_warnings(db_session, live):
    live.refuse_from = 1
    service = FlightSearchService(db=db_session, provider_name="travelpayouts")

    service.discover_round_trip_fares(request(["VIE"], places=["BCN"]))
    metadata = service.apply_deal_metadata(ProviderMetadata(providerUsed="travelpayouts", providerName="travelpayouts"))

    assert any("rate limit" in warning.lower() for warning in metadata.providerWarnings)


def test_a_cold_tick_fetches_and_caches_something_for_every_warmed_origin(db_session, live):
    summary = refresh_deals()

    assert summary["origins"] >= 8
    assert summary["upserted"] > 0
    assert len({params.get("origin") for _, params in live.requests}) >= 8
    assert CachedDealsRepository(db_session).has_fresh(["VIE"]) is True
