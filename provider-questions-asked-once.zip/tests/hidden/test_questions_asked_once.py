"""Hidden tests: a question put to the fare provider is asked once while its answer is fresh.

A question is one thing we ask the Travelpayouts data API: a route for a month (a city or a
country), "anywhere from here" for a month, or the broad discovery for an origin. Every request
the client sends is one ``httpx.get``, so these tests count requests by endpoint and parameters,
never timing. What is asked depends on what was asked before, per origin, kept in the database;
never on how many rows the deals cache happens to hold.
"""

from datetime import date
from urllib.parse import urlparse

import httpx
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.config import settings
from app.database import Base
from app.db import models  # noqa: F401  (every table is registered before create_all)
from app.db.repositories.cached_deals_repository import CachedDealsRepository
from app.db.seed import seed_session
from app.models import TripSearchRequest
from app.providers.travelpayouts.mapper import RoundTripFare
from app.services.flight_search_service import FlightSearchService

OCTOBER = (date(2027, 10, 1), date(2027, 10, 31))


class FakeResponse:
    def __init__(self, payload, status_code: int = 200):
        self.payload = payload
        self.status_code = status_code

    def json(self):
        return self.payload


def round_trip_row(origin: str, destination: str, month: str, index: int = 0, price: float = 120.0) -> dict:
    return {
        "origin": origin,
        "destination": destination,
        "price": price + index,
        "airline": "VY",
        "transfers": 0,
        "departure_at": f"{month}-{5 + index:02d}T09:00:00+02:00",
        "return_at": f"{month}-{12 + index:02d}T18:00:00+02:00",
        "link": "/search/x",
    }


class FakeTravelpayouts:
    """Stands in for ``httpx.get``: answers the data API by path and records every request.

    Fewer than eight fares come back per origin on purpose, so a cache that only
    counts rows would keep asking.
    """

    def __init__(self):
        self.requests: list[tuple[str, dict]] = []
        self.failing: set[tuple[str, str, str | None]] = set()
        self.refuse_from: int | None = None
        self.refuse_status = 429

    def __call__(self, url, params=None, headers=None, timeout=None):
        params = dict(params or {})
        path = urlparse(url).path
        self.requests.append((path, params))
        if self.refuse_from is not None and len(self.requests) >= self.refuse_from:
            return FakeResponse({}, self.refuse_status)
        if (path.rsplit("/", 1)[-1], params.get("origin"), params.get("destination")) in self.failing:
            return FakeResponse({"error": "boom"}, 500)
        return FakeResponse(self.payload(path, params))

    def payload(self, path: str, params: dict) -> dict:
        origin = params.get("origin", "VIE")
        if path.endswith("/prices_for_dates"):
            month = params["departure_at"]
            destination = params.get("destination")
            if destination is None:
                rows = [round_trip_row(origin, code, month, index) for index, code in enumerate(["CPH", "LIS"])]
            elif len(destination) == 2:
                rows = [round_trip_row(origin, "TYO", month, index, 480.0) for index in range(2)]
            else:
                rows = [round_trip_row(origin, destination, month, index) for index in range(3)]
            return {"success": True, "currency": "eur", "data": rows}
        if path.endswith("/prices/calendar"):
            month = params["depart_date"]
            destination = params["destination"]
            return {
                "success": True,
                "currency": "eur",
                "data": {
                    f"{month}-05": round_trip_row(origin, destination, month, 0, 130.0),
                    f"{month}-06": round_trip_row(origin, destination, month, 1, 130.0),
                },
            }
        if path.endswith("/city-directions"):
            return {"success": True, "currency": "eur", "data": {"CPH": round_trip_row(origin, "CPH", "2027-06", 0, 90.0)}}
        if path.endswith("/month-matrix"):
            month = params["month"][:7]
            return {
                "success": True,
                "currency": "eur",
                "data": [
                    {
                        "origin": origin,
                        "destination": params["destination"],
                        "value": 60 + index,
                        "depart_date": f"{month}-{5 + index:02d}",
                        "number_of_changes": 0,
                        "duration": 150,
                        "found_at": "2027-09-20T10:00:00",
                    }
                    for index in range(3)
                ],
            }
        raise AssertionError(f"unexpected Travelpayouts path {path}")

    def keys(self, since: int = 0) -> list[tuple]:
        """(endpoint, origin, destination, month) for every request sent since ``since``."""
        out = []
        for path, params in self.requests[since:]:
            month = params.get("departure_at") or params.get("depart_date") or params.get("month")
            out.append((path.rsplit("/", 1)[-1], params.get("origin"), params.get("destination"), (month or "")[:7]))
        return out


@pytest.fixture()
def live(monkeypatch):
    monkeypatch.setattr(settings, "travelpayouts_api_enabled", True)
    monkeypatch.setattr(settings, "travelpayouts_api_token", "test-token")
    monkeypatch.setattr(settings, "travelpayouts_marker", None)
    monkeypatch.setattr(settings, "live_flight_provider", "travelpayouts")
    monkeypatch.setattr(settings, "travelpayouts_cache_enabled", False)
    fake = FakeTravelpayouts()
    monkeypatch.setattr(httpx, "get", fake)
    return fake


def request(origins, start=OCTOBER[0], end=OCTOBER[1], places=None, countries=None) -> TripSearchRequest:
    return TripSearchRequest(
        originAirports=origins,
        destinationAirports=places,
        destinationCountries=countries or [],
        startDate=start,
        endDate=end,
        minTripLengthDays=3,
        maxTripLengthDays=10,
        maxBudget=900,
        maxGroundTransferHours=4,
        tripStyle="one city" if places or countries else "surprise me",
    )


def search(db, req: TripSearchRequest, mode: str = "travelpayouts"):
    """A fresh service per search, the way every request to the API gets one."""
    return FlightSearchService(db=db, provider_name=mode).discover_round_trip_fares(req)


def cached_fare(destination: str, month: str = "2027-08", day: int = 5, price: float = 150.0) -> RoundTripFare:
    return RoundTripFare(
        origin="VIE", destination=destination, price=price, currency="EUR",
        departureDate=f"{month}-{day:02d}", returnDate=f"{month}-{day + 7:02d}", airline="OS", stops=0,
        bookingUrl="https://aviasales.com/x", affiliateUrl=None, observedAt=None,
    )


def second_database():
    engine = create_engine(
        "sqlite+pysqlite:///:memory:", connect_args={"check_same_thread": False}, poolclass=StaticPool
    )
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine, autoflush=False, autocommit=False)()
    seed_session(session)
    return session


# ------------------------------------------------------------------ a route is one question

def test_a_targeted_route_is_asked_once_while_fresh(db_session, live):
    first = search(db_session, request(["VIE"], places=["BCN"]))
    sent = live.keys()

    assert first, "the first search returns the fares it fetched"
    assert ("prices_for_dates", "VIE", "BCN", "2027-10") in sent
    assert ("calendar", "VIE", "BCN", "2027-10") in sent
    assert len(sent) == 2

    second = search(db_session, request(["VIE"], places=["BCN"]))

    assert live.keys(since=2) == []
    assert {fare.destination for fare in second} >= {"BCN"}, "the second search is served from the cache"


def test_a_wider_search_asks_only_about_the_new_target(db_session, live):
    search(db_session, request(["VIE"], places=["BCN"]))
    mark = len(live.requests)

    search(db_session, request(["VIE"], places=["BCN", "MAD"]))
    new = live.keys(since=mark)

    assert len(new) == 2
    assert {key[2] for key in new} == {"MAD"}
    assert {key[1] for key in new} == {"VIE"}


def test_a_country_is_one_request_and_is_asked_once(db_session, live):
    search(db_session, request(["VIE"], countries=["JP"]))

    assert live.keys() == [("prices_for_dates", "VIE", "JP", "2027-10")]

    search(db_session, request(["VIE"], countries=["JP"]))

    assert len(live.requests) == 1


def test_a_covered_origin_is_not_asked_again_for_a_cold_one(db_session, live):
    search(db_session, request(["VIE"], places=["BCN"]))
    mark = len(live.requests)

    search(db_session, request(["VIE", "ZAG"], places=["BCN"]))
    new = live.keys(since=mark)

    assert len(new) == 2
    assert {key[1] for key in new} == {"ZAG"}


# ------------------------------------------------------- "anywhere" is a question per month

def test_each_month_of_an_open_search_is_its_own_question(db_session, live):
    search(db_session, request(["VIE"], start=date(2027, 10, 1), end=date(2027, 11, 15)))
    sent = set(live.keys())

    assert ("prices_for_dates", "VIE", None, "2027-10") in sent
    assert ("prices_for_dates", "VIE", None, "2027-11") in sent
    assert ("city-directions", "VIE", None, "") in sent
    assert len(live.requests) == 3

    search(db_session, request(["VIE"], start=date(2027, 10, 1), end=date(2027, 11, 15)))
    assert len(live.requests) == 3, "the same open search asks nothing"

    search(db_session, request(["VIE"], start=date(2027, 11, 1), end=date(2027, 12, 15)))
    assert live.keys(since=3) == [("prices_for_dates", "VIE", None, "2027-12")]


def test_rows_in_the_cache_do_not_decide_whether_to_ask(db_session, live):
    """Ten fresh August rows say nothing about January; the January question has never been asked."""
    CachedDealsRepository(db_session).upsert_deals(
        [cached_fare(code, "2027-08", 3 + index) for index, code in enumerate(["CPH", "LIS", "BCN", "MAD", "OPO", "PRG", "BUD", "ARN", "OSL", "HEL"])]
    )

    search(db_session, request(["VIE"], start=date(2028, 1, 1), end=date(2028, 1, 31)))
    sent = set(live.keys())

    assert ("prices_for_dates", "VIE", None, "2028-01") in sent, "January was never asked, so it is asked now"
    # Whether the broad discovery for VIE is asked as well is the solver's call; nothing else is.
    assert sent <= {("prices_for_dates", "VIE", None, "2028-01"), ("city-directions", "VIE", None, "")}


def test_each_origin_has_its_own_record(db_session, live):
    search(db_session, request(["VIE"]))
    mark = len(live.requests)

    search(db_session, request(["VIE", "ZAG"]))
    new = live.keys(since=mark)

    assert {key[1] for key in new} == {"ZAG"}, "VIE was covered; only ZAG is asked"
    assert set(new) == {("prices_for_dates", "ZAG", None, "2027-10"), ("city-directions", "ZAG", None, "")}


# ------------------------------------------------------------- freshness, failures, the database

def test_a_question_is_asked_again_once_it_is_no_longer_fresh(db_session, live, monkeypatch):
    search(db_session, request(["VIE"], places=["BCN"]))
    search(db_session, request(["VIE"], places=["BCN"]))
    assert len(live.requests) == 2

    monkeypatch.setattr(settings, "deals_serve_ttl_hours", 0)
    search(db_session, request(["VIE"], places=["BCN"]))

    assert ("prices_for_dates", "VIE", "BCN", "2027-10") in live.keys(since=2)


def test_a_failed_question_is_asked_again_but_an_answered_one_is_not(db_session, live):
    live.failing = {("prices_for_dates", "VIE", "MAD"), ("calendar", "VIE", "MAD")}
    search(db_session, request(["VIE"], places=["BCN", "MAD"]))
    mark = len(live.requests)
    assert ("prices_for_dates", "VIE", "BCN", "2027-10") in live.keys()

    search(db_session, request(["VIE"], places=["BCN", "MAD"]))
    new = live.keys(since=mark)

    assert new, "the failed question is asked again"
    assert {key[2] for key in new} == {"MAD"}
    assert ("prices_for_dates", "VIE", "MAD", "2027-10") in new


def test_a_separate_database_has_its_own_record(db_session, live):
    search(db_session, request(["VIE"], places=["BCN"]))
    search(db_session, request(["VIE"], places=["BCN"]))
    assert len(live.requests) == 2

    other = second_database()
    try:
        search(other, request(["VIE"], places=["BCN"]))
    finally:
        other.close()

    assert len(live.requests) == 4, "another database has not asked yet"
    assert {key[1:3] for key in live.keys(since=2)} == {("VIE", "BCN")}
