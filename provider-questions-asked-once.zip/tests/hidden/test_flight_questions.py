"""Hidden tests: the one-way flight questions behind multi-city searches are questions too.

A multi-city or open-jaw request searches flights hop by hop: one request per origin,
destination and month, one way. Those answers already land in the flights cache, so the same
question asked a minute later is served from there and never sent again while fresh. The flight
search, the deals discovery and the legs of one search share one budget, the metadata reports
what was really sent, and a refusal during the flight search stops the rest of that search.
Requests are counted at the HTTP boundary (``httpx.get``), never timed.
"""

from datetime import date
from urllib.parse import urlparse

import httpx
import pytest

from app.config import settings
from app.models import ProviderMetadata, TripSearchRequest
from app.services.flight_search_service import FlightSearchService

OCTOBER = (date(2027, 10, 1), date(2027, 10, 31))


class FakeResponse:
    def __init__(self, payload, status_code: int = 200):
        self.payload = payload
        self.status_code = status_code

    def json(self):
        return self.payload


def round_trip_row(origin: str, destination: str, month: str, index: int = 0, price: float = 120.0) -> dict:
    return {
        "origin": origin,
        "destination": destination,
        "price": price + index,
        "airline": "VY",
        "transfers": 0,
        "departure_at": f"{month}-{5 + index:02d}T09:00:00+02:00",
        "return_at": f"{month}-{12 + index:02d}T18:00:00+02:00",
        "link": "/search/x",
    }


def one_way_row(origin: str, destination: str, month: str, index: int = 0, price: float = 80.0) -> dict:
    return {
        "origin": origin,
        "destination": destination,
        "price": price + index,
        "airline": "VY",
        "transfers": 0,
        "departure_at": f"{month}-{5 + index:02d}T09:00:00+02:00",
        "duration_to": 150,
        "link": "/search/x",
    }


class FakeTravelpayouts:
    """Stands in for ``httpx.get``; answers by path and parameters, records every request."""

    def __init__(self):
        self.requests: list[tuple[str, dict]] = []
        self.refuse_from: int | None = None
        self.refuse_status = 429

    def __call__(self, url, params=None, headers=None, timeout=None):
        params = dict(params or {})
        path = urlparse(url).path
        self.requests.append((path, params))
        if self.refuse_from is not None and len(self.requests) >= self.refuse_from:
            return FakeResponse({}, self.refuse_status)
        return FakeResponse(self.payload(path, params))

    def payload(self, path: str, params: dict) -> dict:
        origin = params.get("origin", "VIE")
        if path.endswith("/prices_for_dates"):
            month = params["departure_at"]
            destination = params.get("destination")
            if params.get("one_way") == "true" and destination:
                rows = [one_way_row(origin, destination, month, index) for index in range(3)]
            elif destination is None:
                rows = [round_trip_row(origin, code, month, index) for index, code in enumerate(["CPH", "LIS"])]
            else:
                rows = [round_trip_row(origin, destination, month, index) for index in range(3)]
            return {"success": True, "currency": "eur", "data": rows}
        if path.endswith("/prices/calendar"):
            month = params["depart_date"]
            destination = params["destination"]
            return {
                "success": True,
                "currency": "eur",
                "data": {f"{month}-05": round_trip_row(origin, destination, month, 0, 130.0)},
            }
        if path.endswith("/city-directions"):
            return {"success": True, "currency": "eur", "data": {"CPH": round_trip_row(origin, "CPH", "2027-06", 0, 90.0)}}
        if path.endswith("/month-matrix"):
            month = params["month"][:7]
            return {
                "success": True,
                "currency": "eur",
                "data": [
                    {
                        "origin": origin,
                        "destination": params["destination"],
                        "value": 60 + index,
                        "depart_date": f"{month}-{5 + index:02d}",
                        "number_of_changes": 0,
                        "duration": 150,
                        "found_at": "2027-09-20T10:00:00",
                    }
                    for index in range(3)
                ],
            }
        raise AssertionError(f"unexpected Travelpayouts path {path}")

    def keys(self, since: int = 0) -> list[tuple]:
        """(endpoint, origin, destination, month, one way?) for every request sent since ``since``."""
        out = []
        for path, params in self.requests[since:]:
            month = params.get("departure_at") or params.get("depart_date") or params.get("month")
            out.append(
                (
                    path.rsplit("/", 1)[-1],
                    params.get("origin"),
                    params.get("destination"),
                    (month or "")[:7],
                    params.get("one_way") == "true",
                )
            )
        return out


@pytest.fixture()
def live(monkeypatch):
    monkeypatch.setattr(settings, "travelpayouts_api_enabled", True)
    monkeypatch.setattr(settings, "travelpayouts_api_token", "test-token")
    monkeypatch.setattr(settings, "travelpayouts_marker", None)
    monkeypatch.setattr(settings, "live_flight_provider", "travelpayouts")
    # The flights cache is where a one-way answer lives, so it stays on here.
    monkeypatch.setattr(settings, "travelpayouts_cache_enabled", True)
    fake = FakeTravelpayouts()
    monkeypatch.setattr(httpx, "get", fake)
    return fake


def open_jaw(origins, destination="BCN", fly_home="MAD", start=OCTOBER[0], end=OCTOBER[1]) -> TripSearchRequest:
    """Out to one city, home from another: the shape that searches flights hop by hop."""
    return TripSearchRequest(
        originAirports=origins,
        destinationAirports=[destination],
        returnOriginAirports=[fly_home],
        startDate=start,
        endDate=end,
        minTripLengthDays=3,
        maxTripLengthDays=10,
        maxBudget=900,
        maxGroundTransferHours=4,
        tripStyle="one city",
        tripPlan="open_jaw",
    )


def round_trip_to(origins, destination="BCN", start=OCTOBER[0], end=OCTOBER[1]) -> TripSearchRequest:
    return TripSearchRequest(
        originAirports=origins,
        destinationAirports=[destination],
        startDate=start,
        endDate=end,
        minTripLengthDays=3,
        maxTripLengthDays=10,
        maxBudget=900,
        maxGroundTransferHours=4,
        tripStyle="one city",
    )


def one_way_keys(fake: FakeTravelpayouts, since: int = 0) -> set[tuple]:
    return {(origin, destination, month) for _, origin, destination, month, one_way in fake.keys(since) if one_way}


# ------------------------------------------------------- a one-way flight question is asked once

def test_a_flight_question_is_asked_once_and_then_served_from_the_flights_cache(db_session, live):
    first = FlightSearchService(db=db_session, provider_name="hybrid").search_candidate_flights_with_metadata(open_jaw(["VIE"]))

    assert one_way_keys(live) == {("VIE", "BCN", "2027-10"), ("MAD", "VIE", "2027-10"), ("MAD", "VIE", "2027-11")}
    assert len(live.requests) == 3
    assert len(first.flights) >= 3

    second = FlightSearchService(db=db_session, provider_name="hybrid").search_candidate_flights_with_metadata(open_jaw(["VIE"]))

    assert len(live.requests) == 3, "the same flight questions are not sent again"
    assert len(second.flights) >= 3, "the answer comes from the flights cache"
    assert {flight.origin for flight in second.flights} >= {"VIE", "MAD"}


def test_a_later_month_asks_only_the_new_flight_questions(db_session, live):
    FlightSearchService(db=db_session, provider_name="hybrid").search_candidate_flights_with_metadata(open_jaw(["VIE"]))
    mark = len(live.requests)

    FlightSearchService(db=db_session, provider_name="hybrid").search_candidate_flights_with_metadata(
        open_jaw(["VIE"], start=date(2027, 11, 1), end=date(2027, 11, 30))
    )

    assert one_way_keys(live, since=mark) == {("VIE", "BCN", "2027-11"), ("MAD", "VIE", "2027-12")}
    assert len(live.requests) == mark + 2


def test_a_flight_question_and_a_round_trip_question_are_different_questions(db_session, live):
    FlightSearchService(db=db_session, provider_name="hybrid").search_candidate_flights_with_metadata(open_jaw(["VIE"]))
    FlightSearchService(db=db_session, provider_name="hybrid").search_candidate_flights_with_metadata(open_jaw(["VIE"]))
    mark = len(live.requests)
    assert mark == 3

    FlightSearchService(db=db_session, provider_name="hybrid").discover_round_trip_fares(round_trip_to(["VIE"]))
    new = live.keys(since=mark)

    assert ("prices_for_dates", "VIE", "BCN", "2027-10", False) in new, "the return fare for the same route is still a new question"
    assert all(not one_way for *_, one_way in new)


# ---------------------------------------------------- one budget and honest numbers across paths

def test_one_search_shares_its_budget_across_flights_deals_and_legs(db_session, live, monkeypatch):
    monkeypatch.setattr(settings, "travelpayouts_max_requests_per_search", 6)
    request = open_jaw(["VIE", "MUC"], start=date(2027, 10, 1), end=date(2027, 12, 31))
    service = FlightSearchService(db=db_session, provider_name="hybrid")

    result = service.search_candidate_flights_with_metadata(request)
    service.discover_round_trip_fares(request)
    service.one_way_fares_for(request, [("VIE", "BCN"), ("BCN", "LIS"), ("LIS", "VIE")])
    metadata = service.apply_deal_metadata(result.metadata)

    assert 1 <= len(live.requests) <= 6
    assert metadata.requestsAttempted == len(live.requests)


def test_the_metadata_counts_the_flight_requests_and_the_deal_requests_together(db_session, live):
    service = FlightSearchService(db=db_session, provider_name="hybrid")

    result = service.search_candidate_flights_with_metadata(open_jaw(["VIE"]))
    flights_sent = len(live.requests)
    service.discover_round_trip_fares(open_jaw(["VIE"]))
    metadata = service.apply_deal_metadata(result.metadata)

    assert len(live.requests) > flights_sent, "the deals path asked its own questions"
    assert metadata.requestsAttempted == len(live.requests)


@pytest.mark.parametrize("status", [429, 403])
def test_a_refusal_during_the_flight_search_stops_the_rest_of_the_search(db_session, live, status):
    live.refuse_from = 1
    live.refuse_status = status
    service = FlightSearchService(db=db_session, provider_name="hybrid")

    result = service.search_candidate_flights_with_metadata(open_jaw(["VIE"]))
    assert len(live.requests) == 1
    assert result.metadata.liveProviderSucceeded is False, "the live half did not answer; whatever is shown comes from the database"

    service.discover_round_trip_fares(open_jaw(["VIE"]))
    metadata = service.apply_deal_metadata(result.metadata)

    assert len(live.requests) == 1, "nothing more is sent in a search the provider refused"
    text = " ".join(metadata.providerWarnings).lower()
    assert "rate limit" in text or "token" in text or "unavailable" in text
