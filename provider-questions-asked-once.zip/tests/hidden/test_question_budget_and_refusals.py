"""Hidden tests: one search spends one budget, a refusal stops the spending, the tick is bounded.

Requests are counted at the HTTP boundary (``httpx.get``), never timed. The hourly tick
(``refresh_deals``) and the search share the same record of questions, so what one asked the
other does not ask again while it is fresh.
"""

from datetime import date, timedelta
from urllib.parse import urlparse

import httpx
import pytest
from sqlalchemy.orm import sessionmaker

from app.config import settings
from app.db.repositories.cached_deals_repository import CachedDealsRepository
from app.deals import refresher
from app.deals.refresher import refresh_deals
from app.models import ProviderMetadata, TripSearchRequest
from app.providers.travelpayouts.mapper import RoundTripFare
from app.services.flight_search_service import FlightSearchService

OCTOBER = (date(2027, 10, 1), date(2027, 10, 31))


class FakeResponse:
    def __init__(self, payload, status_code: int = 200):
        self.payload = payload
        self.status_code = status_code

    def json(self):
        return self.payload


def round_trip_row(origin: str, destination: str, month: str, index: int = 0, price: float = 120.0) -> dict:
    return {
        "origin": origin,
        "destination": destination,
        "price": price + index,
        "airline": "VY",
        "transfers": 0,
        "departure_at": f"{month}-{5 + index:02d}T09:00:00+02:00",
        "return_at": f"{month}-{12 + index:02d}T18:00:00+02:00",
        "link": "/search/x",
    }


class FakeTravelpayouts:
    """Stands in for ``httpx.get``; answers by path, records every request, can refuse from request N on."""

    def __init__(self):
        self.requests: list[tuple[str, dict]] = []
        self.refuse_from: int | None = None
        self.refuse_status = 429

    def __call__(self, url, params=None, headers=None, timeout=None):
        params = dict(params or {})
        path = urlparse(url).path
        self.requests.append((path, params))
        if self.refuse_from is not None and len(self.requests) >= self.refuse_from:
            return FakeResponse({}, self.refuse_status)
        return FakeResponse(self.payload(path, params))

    def payload(self, path: str, params: dict) -> dict:
        origin = params.get("origin", "VIE")
        if path.endswith("/prices_for_dates"):
            month = params["departure_at"]
            destination = params.get("destination")
            if destination is None:
                rows = [round_trip_row(origin, code, month, index) for index, code in enumerate(["CPH", "LIS"])]
            else:
                rows = [round_trip_row(origin, destination, month, index) for index in range(3)]
            return {"success": True, "currency": "eur", "data": rows}
        if path.endswith("/prices/calendar"):
            month = params["depart_date"]
            destination = params["destination"]
            return {
                "success": True,
                "currency": "eur",
                "data": {f"{month}-05": round_trip_row(origin, destination, month, 0, 130.0)},
            }
        if path.endswith("/city-directions"):
            return {"success": True, "currency": "eur", "data": {"CPH": round_trip_row(origin, "CPH", "2027-06", 0, 90.0)}}
        if path.endswith("/month-matrix"):
            month = params["month"][:7]
            return {
                "success": True,
                "currency": "eur",
                "data": [
                    {
                        "origin": origin,
                        "destination": params["destination"],
                        "value": 60 + index,
                        "depart_date": f"{month}-{5 + index:02d}",
                        "number_of_changes": 0,
                        "duration": 150,
                        "found_at": "2027-09-20T10:00:00",
                    }
                    for index in range(3)
                ],
            }
        raise AssertionError(f"unexpected Travelpayouts path {path}")

    def keys(self, since: int = 0) -> list[tuple]:
        out = []
        for path, params in self.requests[since:]:
            month = params.get("departure_at") or params.get("depart_date") or params.get("month")
            out.append((path.rsplit("/", 1)[-1], params.get("origin"), params.get("destination"), (month or "")[:7]))
        return out


@pytest.fixture()
def live(monkeypatch, db_session):
    monkeypatch.setattr(settings, "travelpayouts_api_enabled", True)
    monkeypatch.setattr(settings, "travelpayouts_api_token", "test-token")
    monkeypatch.setattr(settings, "travelpayouts_marker", None)
    monkeypatch.setattr(settings, "live_flight_provider", "travelpayouts")
    monkeypatch.setattr(settings, "travelpayouts_cache_enabled", False)
    # The tick opens its own session; point it at this test's database.
    monkeypatch.setattr("app.deals.refresher.SessionLocal", sessionmaker(bind=db_session.get_bind()))
    fake = FakeTravelpayouts()
    monkeypatch.setattr(httpx, "get", fake)
    return fake


def request(origins, start=OCTOBER[0], end=OCTOBER[1], places=None) -> TripSearchRequest:
    return TripSearchRequest(
        originAirports=origins,
        destinationAirports=places,
        startDate=start,
        endDate=end,
        minTripLengthDays=3,
        maxTripLengthDays=10,
        maxBudget=900,
        maxGroundTransferHours=4,
        tripStyle="one city" if places else "surprise me",
    )


def cached_fare(destination: str, month: str = "2027-10", day: int = 5, price: float = 150.0) -> RoundTripFare:
    return RoundTripFare(
        origin="VIE", destination=destination, price=price, currency="EUR",
        departureDate=f"{month}-{day:02d}", returnDate=f"{month}-{day + 7:02d}", airline="OS", stops=0,
        bookingUrl="https://aviasales.com/x", affiliateUrl=None, observedAt=None,
    )


def mentions_the_refusal(warnings: list[str]) -> bool:
    text = " ".join(warnings).lower()
    return "rate limit" in text or "token" in text


# ------------------------------------------------------------------- one search, one budget

def test_one_search_spends_one_budget_in_hybrid_mode(db_session, live, monkeypatch):
    """Discovery and the leg prices used to each get a fresh provider, and so a fresh budget."""
    monkeypatch.setattr(settings, "travelpayouts_max_requests_per_search", 6)
    service = FlightSearchService(db=db_session, provider_name="hybrid")
    open_search = request(["VIE", "MUC"], start=date(2027, 10, 1), end=date(2027, 12, 31))

    service.discover_round_trip_fares(open_search)
    service.one_way_fares_for(open_search, [("VIE", "BCN"), ("BCN", "LIS"), ("LIS", "VIE")])

    assert len(live.requests) <= 6
    assert len(live.requests) >= 1


def test_the_per_search_cap_counts_discovery_too(db_session, live, monkeypatch):
    """The cap stopped the per-month questions but never the city-directions call behind them."""
    monkeypatch.setattr(settings, "travelpayouts_max_requests_per_search", 4)
    service = FlightSearchService(db=db_session, provider_name="travelpayouts")

    service.discover_round_trip_fares(request(["VIE", "MUC", "ZRH"], start=date(2027, 10, 1), end=date(2027, 12, 31)))

    assert 1 <= len(live.requests) <= 4


def test_a_half_asked_question_is_asked_again_next_time(db_session, live, monkeypatch):
    """The budget ran out between the two requests of the second route; that route is not answered yet."""
    monkeypatch.setattr(settings, "travelpayouts_max_requests_per_search", 3)
    FlightSearchService(db=db_session, provider_name="travelpayouts").discover_round_trip_fares(
        request(["VIE"], places=["BCN", "MAD"])
    )
    first = len(live.requests)
    assert 2 <= first <= 3, "Barcelona's two requests, and Madrid's first one or none of it"
    assert ("calendar", "VIE", "BCN", "2027-10") in live.keys(), "Barcelona was fully asked"

    FlightSearchService(db=db_session, provider_name="travelpayouts").discover_round_trip_fares(
        request(["VIE"], places=["BCN", "MAD"])
    )
    new = live.keys(since=first)

    assert new, "Madrid is asked again"
    assert {key[2] for key in new} == {"MAD"}
    assert 1 <= len(new) <= 2


def test_the_metadata_reports_what_was_actually_sent(db_session, live):
    service = FlightSearchService(db=db_session, provider_name="hybrid")
    service.discover_round_trip_fares(request(["VIE"]))
    assert live.requests, "a cold open search asks the provider"

    metadata = service.apply_deal_metadata(ProviderMetadata(providerUsed="hybrid", providerName="travelpayouts"))

    assert metadata.requestsAttempted == len(live.requests)


# ---------------------------------------------------------------- a refusal stops the spending

@pytest.mark.parametrize("status", [429, 401, 403])
def test_a_refusal_stops_the_search_and_pauses_the_next_one(db_session, live, status):
    CachedDealsRepository(db_session).upsert_deals([cached_fare("CPH"), cached_fare("LIS", day=9)])
    live.refuse_from = 1
    live.refuse_status = status
    service = FlightSearchService(db=db_session, provider_name="travelpayouts")

    fares = service.discover_round_trip_fares(request(["VIE"], start=date(2027, 10, 1), end=date(2027, 11, 30)))
    metadata = service.apply_deal_metadata(ProviderMetadata(providerUsed="travelpayouts", providerName="travelpayouts"))

    assert len(live.requests) == 1, "nothing more is sent after the provider said no"
    assert mentions_the_refusal(metadata.providerWarnings)
    assert {fare.destination for fare in fares} >= {"CPH", "LIS"}, "the cache is still served"

    FlightSearchService(db=db_session, provider_name="travelpayouts").discover_round_trip_fares(request(["VIE"]))

    assert len(live.requests) == 1, "a refusal pauses every search for a while"


def test_a_pause_holds_the_tick_as_well(db_session, live):
    live.refuse_from = 1
    FlightSearchService(db=db_session, provider_name="travelpayouts").discover_round_trip_fares(request(["VIE"]))
    assert len(live.requests) == 1

    summary = refresh_deals()

    assert len(live.requests) == 1
    assert summary["upserted"] == 0


def test_a_refused_tick_run_stops_and_says_so(db_session, live):
    live.refuse_from = 3

    summary = refresh_deals()

    assert len(live.requests) == 3
    assert summary["warnings"], "the refusal reaches the run summary"
    assert mentions_the_refusal(summary["warnings"])


# ------------------------------------------------------------------------- the tick's budget

def test_the_tick_budget_is_a_ceiling_for_every_kind_of_request(db_session, live, monkeypatch):
    """A hundred and twenty origins at four requests each would be well past the budget."""
    from app.data.flight_places import places_by_code
    from app.db.models import UserDB, UserTravelProfileDB

    european = [
        code for code, places in places_by_code().items()
        if len(code) == 3 and any(place.continent == "Europe" for place in places)
    ]
    monkeypatch.setattr(settings, "deals_max_warmed_origins", 120)
    db_session.add(UserDB(id="u-many", email="many@example.com", password_hash="x"))
    db_session.add(UserTravelProfileDB(user_id="u-many", origin_airports=european[:120]))
    db_session.commit()
    assert len(refresher.origins_to_warm(db_session)) >= 110

    refresh_deals()

    assert 100 <= len(live.requests) <= refresher.WARM_REQUEST_BUDGET


def test_the_tick_asks_each_question_once(db_session, live):
    first = refresh_deals()
    sent = len(live.requests)
    assert sent >= 8 and first["upserted"] > 0

    refresh_deals()

    assert len(live.requests) == sent, "an hour later the same questions are still fresh"


# ------------------------------------------------------ the tick and a search share the record

def test_a_search_does_not_ask_what_the_tick_covered(db_session, live):
    refresh_deals()
    sent = len(live.requests)
    today = date.today()

    fares = FlightSearchService(db=db_session, provider_name="travelpayouts").discover_round_trip_fares(
        request(["VIE"], start=today, end=today + timedelta(days=30))
    )

    assert len(live.requests) == sent, "the tick already asked these months for VIE"
    assert fares, "and the search is served from what the tick cached"


def test_the_tick_skips_what_a_search_asked(db_session, live):
    today = date.today()
    FlightSearchService(db=db_session, provider_name="travelpayouts").discover_round_trip_fares(
        request(["VIE"], start=today, end=today + timedelta(days=20))
    )
    asked = set(live.keys())
    assert asked
    mark = len(live.requests)

    refresh_deals()
    tick_keys = live.keys(since=mark)

    assert tick_keys, "other origins and later months still have to be asked"
    assert not (asked & set(tick_keys)), "but nothing the search asked is asked again"
