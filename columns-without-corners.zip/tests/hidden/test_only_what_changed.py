"""Only what a change made stale is worked out again, through the desk, across the book.

The model page promises that changing one cell marks it and everything downstream of it as dirty
and that only those are worked out again. These tests type into a desk and read the trace of the
next recalculation: it must hold exactly the stale formulas, each once, and the
answers must be the ones a full recalculation gives. The order of the steps is the book's own. Where a whole column stops is part of what a
formula over it reads, so a cell typed below everything on a sheet makes the whole columns on that
sheet stale. Standard library only: unittest, one method per case.
"""

import signal
import unittest

from trestle import Desk, write_book

LEDGER = """trestle-book 1
name Ledger
sheet Items
  A1 item
  B1 qty
  C1 price
  A2 nut
  B2 10
  C2 0.5
  A3 bolt
  B3 4
  C3 1.25
  A4 washer
  B4 25
  C4 0.1
  E1 =SUM(B:B)
  E2 =COUNTBLANK(C:C)
  E3 =ROWS(A:A)
  E4 =SUM(B2:B4)
  E5 =E1*2
sheet Costs
  A1 part
  B1 each
  A2 bracket
  B2 4.5
  A3 bearing
  B3 17.25
  A4 seal
  B4 2.1
  D1 =SUM(B:B)
  D2 =Items!E1+1
"""


def _stop(signum, frame):
    raise AssertionError("took too long")


class _Guarded(unittest.TestCase):
    """A test that hangs fails rather than waits."""

    def setUp(self):
        signal.signal(signal.SIGALRM, _stop)
        signal.alarm(60)

    def tearDown(self):
        signal.alarm(0)

    @staticmethod
    def cells(trace):
        """The cells a trace worked out, as written, in the order they happened."""
        return [one.at.written() for one in trace]

    def assertTrace(self, desk, wanted):
        """The next recalculation works out exactly these cells, each once.

        The order is the book's own, which its order tests cover; here only the set and that
        no cell is worked out twice are checked.
        """
        found = self.cells(desk.recalculate())
        self.assertEqual(len(found), len(set(found)))
        self.assertEqual(sorted(found), sorted(wanted))

    def assertSameAsFresh(self, desk):
        """What the desk came to is what a fresh desk over the same text comes to."""
        again = Desk.of_text(write_book(desk.book), desk.name)
        self.assertEqual(desk.digest(values=True), again.digest(values=True))


class BudgetTest(_Guarded):
    """The worked example whose six formulas the base works out again on every change."""

    def worked(self):
        desk = Desk.demo("budget")
        desk.recalculate()
        return desk

    def test_typing_one_number_works_out_only_its_readers(self):
        desk = self.worked()
        desk.put("Income!B2", 2600)
        self.assertTrace(desk, ["Income!B4", "Left!B1", "Left!B3", "Left!B4"])
        self.assertEqual(desk.value_at("Left!B3").written(), "1290")
        self.assertSameAsFresh(desk)

    def test_typing_a_label_works_out_nothing(self):
        desk = self.worked()
        desk.put("Left!A1", "money in")
        self.assertTrace(desk, [])
        self.assertEqual(desk.value_at("Left!B3").written(), "1090")

    def test_typing_on_the_other_sheet_follows_its_own_readers(self):
        desk = self.worked()
        desk.put("Spending!B2", 1200)
        self.assertTrace(desk, ["Spending!B6", "Left!B2", "Left!B3", "Left!B4"])
        self.assertEqual(desk.value_at("Left!B3").written(), "990")

    def test_a_new_formula_is_worked_out_itself(self):
        desk = self.worked()
        desk.put("Left!C1", "=B1*2")
        self.assertTrace(desk, ["Left!C1"])
        self.assertEqual(desk.value_at("Left!C1").written(), "6100")

    def test_a_value_typed_over_a_formula_makes_its_readers_stale_and_is_no_step(self):
        desk = self.worked()
        desk.put("Income!B4", 100)
        self.assertTrace(desk, ["Left!B1", "Left!B3", "Left!B4"])
        self.assertEqual(desk.value_at("Income!B4").written(), "100")
        self.assertEqual(desk.value_at("Left!B3").written(), "-1860")
        self.assertSameAsFresh(desk)

    def test_emptying_a_cell_is_a_change_to_it(self):
        desk = self.worked()
        desk.put("Income!B2", "")
        self.assertTrace(desk, ["Income!B4", "Left!B1", "Left!B3", "Left!B4"])
        self.assertEqual(desk.value_at("Income!B4").written(), "650")
        self.assertSameAsFresh(desk)

    def test_two_changes_give_one_trace_in_the_book_s_order(self):
        desk = self.worked()
        desk.put("Left!B4", "=ROUND(B2/B1*100,2)")
        desk.put("Income!B3", 700)
        self.assertTrace(desk, ["Income!B4", "Left!B1", "Left!B3", "Left!B4"])
        self.assertEqual(desk.value_at("Left!B4").written(), "63.23")
        self.assertSameAsFresh(desk)

    def test_a_change_nobody_reads_further_stops_there(self):
        desk = self.worked()
        desk.put("Left!B4", "=ROUND(B2/B1*100,2)")
        self.assertTrace(desk, ["Left!B4"])
        self.assertEqual(desk.value_at("Left!B4").written(), "64.26")

    def test_nothing_changed_means_nothing_more_is_worked_out(self):
        desk = self.worked()
        desk.put("Income!B2", 2600)
        first = self.cells(desk.recalculate())
        self.assertEqual(len(first), 4)
        self.assertEqual(self.cells(desk.recalculate()), first)
        self.assertEqual(desk.value_at("Left!B3").written(), "1290")


class CycleTest(_Guarded):
    """Cycles made or broken by a change."""

    def test_a_change_that_makes_a_cycle_marks_every_cell_in_it(self):
        desk = Desk.empty()
        desk.put("A1", "=B1+1")
        desk.put("B1", 5)
        desk.put("C1", "=A1*2")
        desk.put("D1", "=1+1")
        desk.recalculate()
        self.assertEqual(desk.value_at("C1").written(), "12")
        desk.put("B1", "=A1")
        found = sorted(self.cells(desk.recalculate()))
        self.assertEqual(found, ["Sheet1!A1", "Sheet1!B1", "Sheet1!C1"])
        self.assertEqual(desk.value_at("A1").written(), "#CYCLE!")
        self.assertEqual(desk.value_at("B1").written(), "#CYCLE!")
        self.assertEqual(desk.value_at("C1").written(), "#CYCLE!")
        self.assertSameAsFresh(desk)

    def test_a_change_that_breaks_a_cycle_works_the_cells_out(self):
        desk = Desk.empty()
        desk.put("A1", "=B1+1")
        desk.put("B1", "=A1")
        desk.put("C1", "=A1*2")
        desk.put("D1", "=1+1")
        desk.recalculate()
        self.assertEqual(desk.value_at("C1").written(), "#CYCLE!")
        desk.put("B1", 5)
        self.assertTrace(desk, ["Sheet1!A1", "Sheet1!C1"])
        self.assertEqual(desk.value_at("A1").written(), "6")
        self.assertEqual(desk.value_at("C1").written(), "12")
        self.assertSameAsFresh(desk)


class WholeColumnTest(_Guarded):
    """Where a whole column stops is part of what a formula over it reads."""

    def ledger(self):
        desk = Desk.of_text(LEDGER)
        desk.recalculate()
        return desk

    def test_typing_below_everything_makes_the_whole_columns_of_that_sheet_stale(self):
        desk = self.ledger()
        self.assertEqual(desk.value_at("Items!E3").written(), "5")
        desk.put("Items!D9", "note")
        self.assertTrace(desk, ["Items!E1", "Items!E2", "Items!E3", "Items!E5", "Costs!D2"])
        self.assertEqual(desk.value_at("Items!E2").written(), "5")
        self.assertEqual(desk.value_at("Items!E3").written(), "9")
        self.assertSameAsFresh(desk)

    def test_typing_in_the_middle_of_a_column_nothing_reads_makes_no_whole_column_stale(self):
        desk = self.ledger()
        desk.put("Items!D2", "note")
        self.assertTrace(desk, [])

    def test_typing_inside_a_column_makes_only_the_formulas_over_it_stale(self):
        desk = self.ledger()
        desk.put("Items!C3", 2)
        self.assertTrace(desk, ["Items!E2"])
        self.assertEqual(desk.value_at("Items!E2").written(), "1")

    def test_emptying_the_last_cell_moves_where_the_columns_stop(self):
        desk = self.ledger()
        desk.put("Items!D9", "note")
        desk.recalculate()
        desk.put("Items!D9", "")
        self.assertTrace(desk, ["Items!E1", "Items!E2", "Items!E3", "Items!E5", "Costs!D2"])
        self.assertEqual(desk.value_at("Items!E3").written(), "5")
        self.assertSameAsFresh(desk)

    def test_a_whole_column_on_the_other_sheet_is_not_touched(self):
        desk = self.ledger()
        desk.put("Costs!A7", "washer")
        self.assertTrace(desk, ["Costs!D1"])
        self.assertEqual(desk.value_at("Costs!D1").written(), "23.85")


class NotWorkedOutTest(_Guarded):
    """A formula no change made stale is not worked out again, whatever the trace says.

    A value put straight into a worked-out cell, behind the desk's back, survives every
    recalculation that does not make that cell stale; and a counting function registered for
    the test is called again only in the cells a change made stale.
    """

    def worked(self):
        desk = Desk.demo("budget")
        desk.recalculate()
        return desk

    def test_a_cell_nothing_changed_keeps_the_value_it_held(self):
        from trestle.values import number

        desk = self.worked()
        desk.sheet("Income").put_value("B4", number(999))
        desk.put("Left!A1", "label")
        desk.recalculate()
        self.assertEqual(desk.value_at("Income!B4").written(), "999")
        self.assertEqual(desk.value_at("Left!B1").written(), "3050")

    def test_a_change_elsewhere_leaves_the_other_chain_alone(self):
        from trestle.values import number

        desk = self.worked()
        desk.sheet("Income").put_value("B4", number(999))
        desk.put("Spending!B2", 1200)
        desk.recalculate()
        self.assertEqual(desk.value_at("Income!B4").written(), "999")
        self.assertEqual(desk.value_at("Left!B1").written(), "3050")
        self.assertEqual(desk.value_at("Spending!B6").written(), "2060")
        self.assertEqual(desk.value_at("Left!B3").written(), "990")

    def test_a_counting_function_is_called_only_where_a_change_landed(self):
        from trestle.functions.registry import register
        from trestle.values import number

        calls = []
        name = "TALLYFORTHISTEST"
        try:
            from trestle.functions import FUNCTIONS

            if name not in FUNCTIONS:
                @register(name, 1, 1, "maths", "counts its own calls, for one test")
                def tally(arguments, setting):
                    """Count a call and hand the argument back."""
                    calls.append(1)
                    return arguments[0]
            else:
                self.skipTest("the counting function is already registered")
        except Exception as problem:
            self.skipTest("could not register a function: %s" % problem)
        desk = Desk.empty()
        desk.put("A1", 1)
        desk.put("A2", 2)
        desk.put("B1", "=%s(A1)*2" % name)
        desk.put("B2", "=%s(A2)*2" % name)
        desk.put("C1", "=B1+B2")
        desk.recalculate()
        self.assertEqual(len(calls), 2)
        desk.put("A2", 5)
        desk.recalculate()
        self.assertEqual(len(calls), 3)
        self.assertEqual(desk.value_at("C1").written(), "12")
        desk.put("D1", "label")
        desk.recalculate()
        self.assertEqual(len(calls), 3)


if __name__ == "__main__":
    unittest.main()
