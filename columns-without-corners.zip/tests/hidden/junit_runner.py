"""Run unittest modules and write a JUnit report, with nothing but the standard library.

    python junit_runner.py REPORT.xml tests.test_book tests.test_cli ...

Every test case is written as <testcase classname="tests.test_book.BookTest" name="test_x">,
which is the id the grader lists. A test whose subTests fail is a failure. The exit code is 0
when every test passed and 1 otherwise; a module that will not import is a failed test of its
own, so the report is written whatever happens.
"""

import os
import sys
import time
import traceback
import unittest
from xml.etree import ElementTree


class _Recording(unittest.TestResult):
    """A result that remembers the outcome of every test by its id."""

    def __init__(self):
        super().__init__()
        self.outcomes = []
        self._current = None

    @staticmethod
    def _id(test):
        kind = type(test)
        return "%s.%s" % (kind.__module__, kind.__qualname__), getattr(test, "_testMethodName", str(test))

    def startTest(self, test):
        super().startTest(test)
        self._current = [self._id(test), "passed", "", time.time()]

    def stopTest(self, test):
        super().stopTest(test)
        if self._current is not None:
            self._current[3] = time.time() - self._current[3]
            self.outcomes.append(tuple(self._current))
            self._current = None

    def _note(self, status, err):
        if self._current is not None and self._current[1] == "passed":
            self._current[1] = status
            self._current[2] = "".join(traceback.format_exception(*err)) if err else ""

    def addError(self, test, err):
        super().addError(test, err)
        self._note("error", err)

    def addFailure(self, test, err):
        super().addFailure(test, err)
        self._note("failure", err)

    def addSubTest(self, test, subtest, err):
        super().addSubTest(test, subtest, err)
        if err is not None:
            self._note("failure", err)

    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        self._note("skipped", None)
        if self._current is not None:
            self._current[2] = reason

    def addExpectedFailure(self, test, err):
        super().addExpectedFailure(test, err)

    def addUnexpectedSuccess(self, test):
        super().addUnexpectedSuccess(test)
        self._note("failure", None)


def main(argv):
    """Run the modules named and write the report; the exit code says whether all passed."""
    if len(argv) < 3:
        print(__doc__, file=sys.stderr)
        return 2
    report, modules = argv[1], argv[2:]
    sys.path.insert(0, os.getcwd())
    loader = unittest.defaultTestLoader
    suite = unittest.TestSuite()
    for name in modules:
        suite.addTests(loader.loadTestsFromName(name))
    result = _Recording()
    suite.run(result)
    root = ElementTree.Element("testsuites")
    held = ElementTree.SubElement(root, "testsuite", name="hidden", tests=str(len(result.outcomes)))
    counts = {"passed": 0, "failure": 0, "error": 0, "skipped": 0}
    for (classname, name), status, text, took in result.outcomes:
        counts[status] = counts.get(status, 0) + 1
        case = ElementTree.SubElement(
            held, "testcase", classname=classname, name=name, time="%.3f" % took
        )
        if status in ("failure", "error", "skipped"):
            note = ElementTree.SubElement(case, status)
            note.text = text[-4000:]
    held.set("failures", str(counts["failure"]))
    held.set("errors", str(counts["error"]))
    held.set("skipped", str(counts["skipped"]))
    directory = os.path.dirname(os.path.abspath(report))
    if directory and not os.path.isdir(directory):
        os.makedirs(directory, exist_ok=True)
    ElementTree.ElementTree(root).write(report, encoding="utf-8", xml_declaration=True)
    print(
        "%d tests: %d passed, %d failed, %d errors, %d skipped"
        % (len(result.outcomes), counts["passed"], counts["failure"], counts["error"], counts["skipped"])
    )
    for (classname, name), status, text, _ in result.outcomes:
        if status in ("failure", "error"):
            last = [line for line in text.strip().splitlines() if line.strip()]
            print("%s: %s.%s: %s" % (status.upper(), classname, name, last[-1][:160] if last else ""))
    return 0 if counts["failure"] == 0 and counts["error"] == 0 and result.outcomes else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
