"""What already holds, and must go on holding once whole columns are in the language.

Rectangles, the two moving rules, the exit codes, the worked examples, the reports and the
refusals of the base all answer the same way after the change. Nothing here names a whole column.
Standard library only: unittest, one method per case.
"""

import io
import os
import re
import signal
import tempfile
import unittest

from trestle import Desk
from trestle.cli.main import main
from trestle.formula import parse, rendered_cell
from trestle.recalc import recalculate
from trestle.refs import is_span, read_span
from trestle.sheet import (
    Sheet,
    filled_across,
    inserted_columns,
    inserted_rows,
    removed_columns,
    removed_rows,
)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

LEDGER = """trestle-book 1
name Ledger
sheet Items
  A1 item
  B1 qty
  C1 price
  A2 nut
  B2 10
  C2 0.5
  A3 bolt
  B3 4
  C3 1.25
  A4 washer
  B4 25
  C4 0.1
  A6 note
  D7 7
sheet Costs
  A1 part
  B1 each
  A2 bracket
  B2 4.5
  A3 bearing
  B3 17.25
  A4 seal
  B4 2.1
"""


def _stop(signum, frame):
    raise AssertionError("took too long")


class _Guarded(unittest.TestCase):
    """A test that hangs fails rather than waits."""

    def setUp(self):
        signal.signal(signal.SIGALRM, _stop)
        signal.alarm(60)

    def tearDown(self):
        signal.alarm(0)


def run(*argv):
    """The command line, run in this process, with what it printed."""
    stream = io.StringIO()
    code = main(list(argv), stream)
    return code, stream.getvalue().rstrip("\n")


def written(text, name="ledger.book"):
    """A file holding some text, in a directory of its own."""
    path = os.path.join(tempfile.mkdtemp(), name)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return path


def slug(text):
    """A method name suffix made of a formula: letters, digits and underscores only."""
    held = re.sub(r"[^A-Za-z0-9]+", "_", text.replace("$", "held")).strip("_")
    return held or "formula"


def each(cls, prefix, cases, body):
    """Give a class one test method per case, named after the case."""
    seen = set()
    for case in cases:
        key = case if isinstance(case, str) else case[0]
        name = "%s_%s" % (prefix, slug(key))
        assert name not in seen, name
        seen.add(name)

        def method(self, case=case):
            body(self, case)

        method.__name__ = name
        setattr(cls, name, method)


class RectangleTest(_Guarded):
    """A rectangle still comes to what it came to."""


def _still_comes_to(self, case):
    formula, answer = case
    book = written(LEDGER)
    code, text = run("eval", formula, "--book", book)
    self.assertEqual(text, answer)
    self.assertEqual(code, 3 if answer.startswith("#") else 0)


def _still_value_error(self, formula):
    book = written(LEDGER)
    self.assertEqual(run("eval", formula, "--book", book), (3, "#VALUE!"))


def _still_refused(self, formula):
    book = written(LEDGER)
    self.assertEqual(run("eval", formula, "--book", book)[0], 2)
    self.assertFalse(is_span(formula[5:-1]))


each(RectangleTest, "test_a_rectangle_still_comes_to_what_it_came_to",
     [
         ("=SUM(B1:B7)", "39"),
         ("=SUM(B2:C4)", "40.85"),
         ("=COUNTA(A1:A7)", "5"),
         ("=COUNTBLANK(A1:A7)", "2"),
         ("=ROWS(A1:A7)", "7"),
         ("=COLUMNS(A1:C7)", "3"),
         ("=INDEX(A1:A7,3)", "bolt"),
         ("=INDEX(B1:B7,8)", "#REF!"),
         ("=MATCH(\"washer\",A1:A7,0)", "4"),
         ("=VLOOKUP(\"bolt\",A1:C7,3,FALSE)", "1.25"),
         ("=SUMIF(A1:A7,\"nut\",B1:B7)", "10"),
         ("=SUM(Costs!B1:B4)", "23.85"),
         ("=SUM(B7:B1)", "39"),
         ("=SUM($B$1:$B$7)", "39"),
         ("=COUNTBLANK(Z1:Z9)", "9"),
         ("=AVERAGE(Z1:Z9)", "#DIV/0!"),
     ],
     _still_comes_to)
each(RectangleTest, "test_a_rectangle_where_one_value_belongs_is_still_a_value_error",
     ["=A1:A2+1", "=IF(A1:A2,1,2)", "=-B1:B2"], _still_value_error)
each(RectangleTest, "test_a_reference_that_is_not_one_is_still_refused",
     ["=SUM(A1:A)", "=SUM(A:A1)", "=SUM(Costs!A1:Items!B2)", "=1/"], _still_refused)


class UnchangedTest(_Guarded):
    """Rendering, moving, cost, the examples, the reports and the exit codes are unchanged."""

    def test_a_rectangle_still_renders_normalised(self):
        self.assertEqual(rendered_cell(parse("=SUM(B9:A1)")), "=SUM(A1:B9)")
        self.assertEqual(rendered_cell(parse("=sum(a1:b2)*2")), "=SUM(A1:B2)*2")
        self.assertEqual(str(read_span("B9:A1")), "A1:B9")

    def test_filling_a_rectangle_still_moves_it(self):
        sheet = Sheet("Main", {"A1": 1, "A2": 2, "B1": 3, "B2": 4, "C1": "=SUM(A1:A2)"})
        filled_across(sheet, "C1", "C1:D1")
        self.assertEqual(sheet.text_at("D1"), "=SUM(B1:B2)")
        filled_across(sheet, "C1", "C1:C2")
        self.assertEqual(sheet.text_at("C2"), "=SUM(A2:A3)")

    def test_filling_a_rectangle_off_the_sheet_is_still_a_reference_error(self):
        sheet = Sheet("Main", {"B2": "=SUM(A1:A3)"})
        filled_across(sheet, "B2", "A2:B2")
        self.assertEqual(sheet.text_at("A2"), "=SUM(#REF!)")

    def test_inserting_and_removing_still_move_a_rectangle(self):
        sheet = Sheet("Main", {"A1": 1, "A2": 2, "A3": 3, "C1": "=SUM(A1:A3)", "D1": "=SUM(A1:C9)"})
        self.assertEqual(inserted_rows(sheet.copy(), 1).text_at("C2"), "=SUM(A2:A4)")
        self.assertEqual(removed_rows(sheet.copy(), 2).text_at("C1"), "=SUM(A1:A2)")
        self.assertEqual(inserted_columns(sheet.copy(), 1).text_at("D1"), "=SUM(B1:B3)")
        self.assertEqual(removed_columns(sheet.copy(), 1).text_at("B1"), "=SUM(#REF!)")
        self.assertEqual(removed_columns(sheet.copy(), 2).text_at("C1"), "=SUM(A1:B9)")

    def test_a_sheet_still_costs_what_was_put_in_it(self):
        sheet = Sheet("Main", {"A1": 1, "B1": "=SUM(A1:A100000)"})
        self.assertEqual(recalculate(sheet).value_at("B1").written(), "1")

    def test_the_budget_still_comes_to_the_same(self):
        desk = Desk.demo("budget")
        self.assertEqual(desk.value_at("Left!B3").written(), "1090")
        self.assertEqual(desk.value_at("Left!B4").written(), "64.3")

    def test_the_links_of_the_budget_are_unchanged(self):
        code, text = run("links", "budget")
        self.assertEqual(code, 0)
        self.assertIn("6 formulas, 12 links", text)
        self.assertIn("Spending!B6      4  B2, B3, B4 and B5        1", text)

    def test_the_broken_book_still_reviews_the_same(self):
        code, text = run("calc", os.path.join(ROOT, "examples", "broken.book"))
        self.assertEqual(code, 3)
        self.assertIn("9 cells worked out", text)
        self.assertIn("review: 10 warnings, 6 notices", text)

    def test_the_exit_codes_are_unchanged(self):
        self.assertEqual(run("calc", "/no/such/book")[0], 2)
        self.assertEqual(run("value", "budget", "Left!B3"), (0, "1090"))
        self.assertEqual(run("review", "budget")[0], 0)
        self.assertEqual(run("diff", "budget", "budget")[0], 0)
        self.assertEqual(run("eval", "=1/0"), (3, "#DIV/0!"))
        self.assertEqual(run("eval", "=ROUND(2/3,4)"), (0, "0.6667"))

    def test_showing_over_a_rectangle_is_unchanged(self):
        code, text = run("show", "budget", "--sheet", "Left", "--over", "A1:B2")
        self.assertEqual(code, 0)
        self.assertEqual(text, "    A   B\n------------\n  1 in  3050\n  2 out 1960")

    def test_a_version_the_package_does_not_know_is_still_refused(self):
        book = written("trestle-book 2\nsheet S\n  A1 1\n")
        code, text = run("calc", book)
        self.assertEqual(code, 1)
        self.assertIn("version 2", text)

    def test_the_functions_are_still_seventy_nine(self):
        code, text = run("functions")
        self.assertEqual(code, 0)
        self.assertIn("79 functions", text)


if __name__ == "__main__":
    unittest.main()
