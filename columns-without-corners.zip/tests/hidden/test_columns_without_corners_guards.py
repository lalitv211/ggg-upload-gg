"""What already holds, and must go on holding once whole columns are in the language.

Rectangles, the two moving rules, the exit codes, the worked examples, the reports and the
refusals of the base all answer the same way after the change. Nothing here names a whole column.
"""

import io
import os
import signal
import tempfile

import pytest

from trestle import Desk
from trestle.cli.main import main
from trestle.formula import parse, rendered_cell
from trestle.recalc import recalculate
from trestle.refs import is_span, read_span
from trestle.sheet import (
    Sheet,
    filled_across,
    inserted_columns,
    inserted_rows,
    removed_columns,
    removed_rows,
)

LEDGER = """trestle-book 1
name Ledger
sheet Items
  A1 item
  B1 qty
  C1 price
  A2 nut
  B2 10
  C2 0.5
  A3 bolt
  B3 4
  C3 1.25
  A4 washer
  B4 25
  C4 0.1
  A6 note
  D7 7
sheet Costs
  A1 part
  B1 each
  A2 bracket
  B2 4.5
  A3 bearing
  B3 17.25
  A4 seal
  B4 2.1
"""


@pytest.fixture(autouse=True)
def _no_hanging():
    """A test that hangs fails rather than waits."""

    def _stop(signum, frame):
        raise AssertionError("took too long")

    signal.signal(signal.SIGALRM, _stop)
    signal.alarm(60)
    yield
    signal.alarm(0)


def run(*argv):
    """The command line, run in this process, with what it printed."""
    stream = io.StringIO()
    code = main(list(argv), stream)
    return code, stream.getvalue().rstrip("\n")


def written(text, name="ledger.book"):
    """A file holding some text, in a directory of its own."""
    path = os.path.join(tempfile.mkdtemp(), name)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return path


@pytest.mark.parametrize(
    "formula, answer",
    [
        ("=SUM(B1:B7)", "39"),
        ("=SUM(B2:C4)", "40.85"),
        ("=COUNTA(A1:A7)", "5"),
        ("=COUNTBLANK(A1:A7)", "2"),
        ("=ROWS(A1:A7)", "7"),
        ("=COLUMNS(A1:C7)", "3"),
        ("=INDEX(A1:A7,3)", "bolt"),
        ("=INDEX(B1:B7,8)", "#REF!"),
        ("=MATCH(\"washer\",A1:A7,0)", "4"),
        ("=VLOOKUP(\"bolt\",A1:C7,3,FALSE)", "1.25"),
        ("=SUMIF(A1:A7,\"nut\",B1:B7)", "10"),
        ("=SUM(Costs!B1:B4)", "23.85"),
        ("=SUM(B7:B1)", "39"),
        ("=SUM($B$1:$B$7)", "39"),
        ("=COUNTBLANK(Z1:Z9)", "9"),
        ("=AVERAGE(Z1:Z9)", "#DIV/0!"),
    ],
)
def test_a_rectangle_still_comes_to_what_it_came_to(formula, answer):
    book = written(LEDGER)
    code, text = run("eval", formula, "--book", book)
    assert text == answer
    assert code == (3 if answer.startswith("#") else 0)


@pytest.mark.parametrize("formula", ["=A1:A2+1", "=IF(A1:A2,1,2)", "=-B1:B2"])
def test_a_rectangle_where_one_value_belongs_is_still_a_value_error(formula):
    book = written(LEDGER)
    assert run("eval", formula, "--book", book) == (3, "#VALUE!")


@pytest.mark.parametrize("formula", ["=SUM(A1:A)", "=SUM(A:A1)", "=SUM(Costs!A1:Items!B2)", "=1/"])
def test_a_reference_that_is_not_one_is_still_refused(formula):
    book = written(LEDGER)
    assert run("eval", formula, "--book", book)[0] == 2
    assert not is_span(formula[5:-1])


def test_a_rectangle_still_renders_normalised():
    assert rendered_cell(parse("=SUM(B9:A1)")) == "=SUM(A1:B9)"
    assert rendered_cell(parse("=sum(a1:b2)*2")) == "=SUM(A1:B2)*2"
    assert str(read_span("B9:A1")) == "A1:B9"


def test_filling_a_rectangle_still_moves_it():
    sheet = Sheet("Main", {"A1": 1, "A2": 2, "B1": 3, "B2": 4, "C1": "=SUM(A1:A2)"})
    filled_across(sheet, "C1", "C1:D1")
    assert sheet.text_at("D1") == "=SUM(B1:B2)"
    filled_across(sheet, "C1", "C1:C2")
    assert sheet.text_at("C2") == "=SUM(A2:A3)"


def test_filling_a_rectangle_off_the_sheet_is_still_a_reference_error():
    sheet = Sheet("Main", {"B2": "=SUM(A1:A3)"})
    filled_across(sheet, "B2", "A2:B2")
    assert sheet.text_at("A2") == "=SUM(#REF!)"


def test_inserting_and_removing_still_move_a_rectangle():
    sheet = Sheet("Main", {"A1": 1, "A2": 2, "A3": 3, "C1": "=SUM(A1:A3)", "D1": "=SUM(A1:C9)"})
    assert inserted_rows(sheet.copy(), 1).text_at("C2") == "=SUM(A2:A4)"
    assert removed_rows(sheet.copy(), 2).text_at("C1") == "=SUM(A1:A2)"
    assert inserted_columns(sheet.copy(), 1).text_at("D1") == "=SUM(B1:B3)"
    assert removed_columns(sheet.copy(), 1).text_at("B1") == "=SUM(#REF!)"
    assert removed_columns(sheet.copy(), 2).text_at("C1") == "=SUM(A1:B9)"


def test_a_sheet_still_costs_what_was_put_in_it():
    sheet = Sheet("Main", {"A1": 1, "B1": "=SUM(A1:A100000)"})
    assert recalculate(sheet).value_at("B1").written() == "1"


def test_the_budget_still_comes_to_the_same():
    desk = Desk.demo("budget")
    assert desk.value_at("Left!B3").written() == "1090"
    assert desk.value_at("Left!B4").written() == "64.3"


def test_the_links_of_the_budget_are_unchanged():
    code, text = run("links", "budget")
    assert code == 0
    assert "6 formulas, 12 links" in text
    assert "Spending!B6      4  B2, B3, B4 and B5        1" in text


def test_the_broken_book_still_reviews_the_same():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    code, text = run("calc", os.path.join(root, "examples", "broken.book"))
    assert code == 3
    assert "9 cells worked out" in text
    assert "review: 10 warnings, 6 notices" in text


def test_the_exit_codes_are_unchanged():
    assert run("calc", "/no/such/book")[0] == 2
    assert run("value", "budget", "Left!B3") == (0, "1090")
    assert run("review", "budget")[0] == 0
    assert run("diff", "budget", "budget")[0] == 0
    assert run("eval", "=1/0") == (3, "#DIV/0!")
    assert run("eval", "=ROUND(2/3,4)") == (0, "0.6667")


def test_showing_over_a_rectangle_is_unchanged():
    code, text = run("show", "budget", "--sheet", "Left", "--over", "A1:B2")
    assert code == 0
    assert text == "    A   B\n------------\n  1 in  3050\n  2 out 1960"


def test_a_version_the_package_does_not_know_is_still_refused():
    book = written("trestle-book 2\nsheet S\n  A1 1\n")
    code, text = run("calc", book)
    assert code == 1
    assert "version 2" in text


def test_the_functions_are_still_seventy_nine():
    code, text = run("functions")
    assert code == 0
    assert "79 functions" in text
