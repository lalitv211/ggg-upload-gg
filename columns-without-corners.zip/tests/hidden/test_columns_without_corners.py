"""Whole-column references: `A:A`, `A:C`, `$A:$A`, `Costs!A:A`.

A whole column stands for the rectangle from row one down to the last row anything is typed in on
the sheet it is on, so everything a function gives over the rectangle it gives over the column.
These tests compare the two forms through the same command line and the same library calls, so
no representation is pinned: only what a book comes to, what a formula renders back to, and what
filling, inserting and removing do to it.

Standard library only: unittest, one method per case, so that every case has an id of its own.
"""

import io
import os
import re
import signal
import tempfile
import unittest

from trestle import Desk, write_book
from trestle.book import Book
from trestle.cli.main import main
from trestle.formula import parse, rendered_cell
from trestle.recalc import recalculate, recalculated_after
from trestle.refs import is_address, is_span, read_span
from trestle.sheet import (
    Sheet,
    filled_across,
    inserted_columns,
    inserted_rows,
    removed_columns,
    removed_rows,
)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

LEDGER = """trestle-book 1
name Ledger
sheet Items
  A1 item
  B1 qty
  C1 price
  A2 nut
  B2 10
  C2 0.5
  A3 bolt
  B3 4
  C3 1.25
  A4 washer
  B4 25
  C4 0.1
  A6 note
  D7 7
sheet Costs
  A1 part
  B1 each
  A2 bracket
  B2 4.5
  A3 bearing
  B3 17.25
  A4 seal
  B4 2.1
sheet Old Costs
  A1 x
  B1 9
  A3 y
  B3 11
"""

#: The last row anything is typed in, per sheet of the ledger.
LAST = {"Items": 7, "Costs": 4, "Old Costs": 3}


def _stop(signum, frame):
    raise AssertionError("took too long: a whole column must cost what is filled in it")


class _Guarded(unittest.TestCase):
    """A test that walks a million rows fails rather than waits."""

    def setUp(self):
        signal.signal(signal.SIGALRM, _stop)
        signal.alarm(60)

    def tearDown(self):
        signal.alarm(0)


def run(*argv):
    """The command line, run in this process, with what it printed."""
    stream = io.StringIO()
    code = main(list(argv), stream)
    return code, stream.getvalue().rstrip("\n")


def written(text, name="ledger.book"):
    """A file holding some text, in a directory of its own."""
    path = os.path.join(tempfile.mkdtemp(), name)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return path


def rectangle(formula):
    """The same formula with every whole column written as the rectangle it stands for."""

    def opened(found):
        sheet = found.group(1) or ""
        name = sheet.rstrip("!").strip("'") or "Items"
        first, second = found.group(2), found.group(3)
        return "%s%s1:%s%d" % (sheet, first, second, LAST[name])

    return re.sub(r"((?:'[^']*'|[A-Za-z]+)!)?(\$?[A-Za-z]{1,3}):(\$?[A-Za-z]{1,3})\b", opened, formula)


def evaluated(formula, book, sheet=None):
    """One formula worked out against a book file through the command line."""
    argv = ["eval", formula, "--book", book]
    if sheet:
        argv += ["--sheet", sheet]
    return run(*argv)


def slug(text):
    """A method name suffix made of a formula: letters, digits and underscores only."""
    held = re.sub(r"[^A-Za-z0-9]+", "_", text.replace("$", "held")).strip("_")
    return held or "formula"


def each(cls, prefix, cases, body):
    """Give a class one test method per case, named after the case."""
    seen = set()
    for case in cases:
        key = case if isinstance(case, str) else case[0]
        name = "%s_%s" % (prefix, slug(key))
        assert name not in seen, name
        seen.add(name)

        def method(self, case=case):
            body(self, case)

        method.__name__ = name
        setattr(cls, name, method)


OVER_THE_LEDGER = [
    "=SUM(B:B)",
    "=SUM(B:C)",
    "=SUM(C:B)",
    "=SUM($B:$B)",
    "=SUM($B:C)",
    "=sum(b:b)",
    "=AVERAGE(B:B)",
    "=COUNT(B:B)",
    "=COUNT(A:D)",
    "=COUNTA(A:A)",
    "=COUNTBLANK(A:A)",
    "=COUNTBLANK(A:C)",
    "=COUNTBLANK(D:D)",
    "=ROWS(A:A)",
    "=ROWS(C:D)",
    "=COLUMNS(A:C)",
    "=COLUMNS(C:A)",
    "=MIN(C:C)",
    "=MAX(B:C)",
    "=MAX(D:D)",
    "=INDEX(A:A,3)",
    "=INDEX(A:C,2,3)",
    "=INDEX(B:B,7)",
    "=INDEX(B:B,8)",
    "=MATCH(\"washer\",A:A,0)",
    "=MATCH(25,B:B,0)",
    "=MATCH(\"nothing\",A:A,0)",
    "=VLOOKUP(\"bolt\",A:C,3,FALSE)",
    "=VLOOKUP(\"washer\",A:B,2)",
    "=HLOOKUP(\"qty\",A:C,3)",
    "=COUNTIF(B:B,\">5\")",
    "=SUMIF(B:B,\">5\")",
    "=SUMIF(A:A,\"nut\",B:B)",
    "=AVERAGEIF(B:B,\">5\")",
    "=LARGE(B:B,2)",
    "=SMALL(C:C,1)",
    "=MEDIAN(B:B)",
    "=PRODUCT(C:C)",
    "=STDEV(B:B)",
    "=VAR(C:C)",
    "=CONCAT(A:A)",
    "=SUM(B:B)+SUM(C:C)",
    "=SUM(B:B)*2",
    "=ROUND(AVERAGE(C:C),2)",
    "=SUM(Costs!B:B)",
    "=ROWS(Costs!A:A)",
    "=COUNTBLANK(Costs!A:B)",
    "=INDEX(Costs!A:A,4)",
    "=SUM('Old Costs'!B:B)",
    "=ROWS('Old Costs'!A:B)",
    "=COUNTBLANK('Old Costs'!A:A)",
    "=VLOOKUP(\"seal\",Costs!A:B,2,FALSE)",
]


class FunctionsTest(_Guarded):
    """Every function gives over a whole column what it gives over the rectangle."""


def _against_the_rectangle(self, formula):
    book = written(LEDGER)
    wanted = evaluated(rectangle(formula), book)
    self.assertIn(wanted[0], (0, 3), wanted)
    self.assertEqual(evaluated(formula, book), wanted)


each(FunctionsTest, "test_a_whole_column_comes_to_what_its_rectangle_comes_to", OVER_THE_LEDGER,
     _against_the_rectangle)


class NamedSheetTest(_Guarded):
    """A bare whole column means the sheet named on the command line."""


def _on_the_sheet_named(self, case):
    formula, sheet = case
    book = written(LEDGER)
    named = "'%s'" % sheet if " " in sheet else sheet
    wanted = evaluated(rectangle(formula.replace("(", "(%s!" % named)), book)
    self.assertEqual(wanted[0], 0, wanted)
    self.assertEqual(evaluated(formula, book, sheet), wanted)


each(NamedSheetTest, "test_a_bare_whole_column_means_the_sheet_named_on_the_command_line",
     [("=SUM(B:B)", "Costs"), ("=ROWS(A:A)", "Costs"), ("=COUNTA(A:A)", "Old Costs")],
     _on_the_sheet_named)


class OneValueTest(_Guarded):
    """Where one value belongs, a whole column is #VALUE!, in a function as in an operator."""


def _value_error(self, formula):
    book = written(LEDGER)
    self.assertEqual(evaluated(formula, book), (3, "#VALUE!"))


each(OneValueTest, "test_a_whole_column_where_one_value_belongs_is_a_value_error",
     ["=A:A+1", "=IF(A:A,1,2)", "=-B:B", "=B:B&\"x\"", "=B:B=1"], _value_error)
each(OneValueTest, "test_a_whole_column_where_a_function_compares_one_value_is_a_value_error",
     [
         "=MATCH(A:A,B:B,0)",
         "=MATCH(1,B:B,A:A)",
         "=VLOOKUP(A:A,A:C,2,FALSE)",
         "=HLOOKUP(A:A,A:C,2)",
         "=COUNTIF(B:B,A:A)",
         "=SUMIF(B:B,A:A)",
         "=SUMIF(A:A,B:B,C:C)",
         "=AVERAGEIF(B:B,C:C)",
         "=SWITCH(A:A,1,2,3)",
         "=SWITCH(1,A:A,2,3)",
     ],
     _value_error)


class RenderTest(_Guarded):
    """A whole column renders back as one, normalised, and reads back to the same tree."""


def _renders(self, case):
    typed, shown = case
    self.assertEqual(rendered_cell(parse(typed)), shown)


def _round_trips(self, typed):
    self.assertEqual(parse(rendered_cell(parse(typed))), parse(typed))


each(RenderTest, "test_a_whole_column_renders_back_as_a_whole_column",
     [
         ("=SUM(C:A)", "=SUM(A:C)"),
         ("=sum(a:a)", "=SUM(A:A)"),
         ("=SUM($A:$A)", "=SUM($A:$A)"),
         ("=SUM($A:C)", "=SUM($A:C)"),
         ("=SUM(Costs!A:B)", "=SUM(Costs!A:B)"),
         ("=COUNTA(B:B)+ROWS(A:A)", "=COUNTA(B:B)+ROWS(A:A)"),
         ("=INDEX(A:C,2,3)", "=INDEX(A:C, 2, 3)"),
     ],
     _renders)
each(RenderTest, "test_a_rendered_whole_column_reads_back_into_the_same_tree",
     ["=SUM(A:A)", "=SUM($B:$D)", "=SUM(Costs!A:B)", "=SUM(C:A)"], _round_trips)


class LibraryTest(_Guarded):
    """Whole columns through the Desk, the Sheet, the Book and the graph."""

    def test_a_whole_column_with_no_book_at_all_adds_up_to_nought(self):
        self.assertEqual(run("eval", "=SUM(A:A)"), (0, "0"))

    def test_a_whole_column_on_a_sheet_that_is_not_there_is_a_reference_error(self):
        book = written(LEDGER)
        self.assertEqual(evaluated("=SUM(Missing!A:A)", book), (3, "#REF!"))

    def test_the_cell_asking_counts_as_typed_in(self):
        desk = Desk.of_text(LEDGER)
        desk.put("Items!F12", "=ROWS(A:A)")
        desk.put("Items!F13", "=COUNTBLANK(B:B)")
        self.assertEqual(desk.value_at("Items!F12").written(), "13")
        self.assertEqual(desk.value_at("Items!F13").written(), "9")

    def test_a_whole_column_across_sheets_stops_at_that_sheet_s_last_row(self):
        desk = Desk.of_text(LEDGER)
        desk.put("Items!F12", "=ROWS(Costs!A:A)")
        desk.put("Items!F13", "=COUNTBLANK(Costs!A:A)")
        self.assertEqual(desk.value_at("Items!F12").written(), "4")
        self.assertEqual(desk.value_at("Items!F13").written(), "0")

    def test_a_desk_works_a_whole_column_out_like_the_rectangle(self):
        desk = Desk.of_text(LEDGER)
        desk.put("Items!F1", "=SUM(B:B)")
        desk.put("Items!F2", "=SUM(B1:B7)")
        desk.put("Items!F3", "=INDEX(A:A,4)")
        self.assertEqual(desk.value_at("Items!F1").written(), desk.value_at("Items!F2").written())
        self.assertEqual(desk.value_at("Items!F3").written(), "washer")

    def test_a_sheet_on_its_own_works_a_whole_column_out(self):
        sheet = Sheet("Main", {"A1": 3, "A2": 4, "A4": 5, "C1": "=SUM(A:A)", "C2": "=ROWS(A:A)"})
        held = recalculate(sheet)
        self.assertEqual(held.value_at("C1").written(), "12")
        self.assertEqual(held.value_at("C2").written(), "4")

    def test_typing_into_the_column_makes_the_formula_over_it_stale(self):
        sheet = Sheet("Main", {"A1": 3, "A2": 4, "C1": "=SUM(A:A)", "D1": "=A1*2"})
        recalculate(sheet)
        sheet.put("A2", 40)
        held = recalculated_after(sheet, ["A2"])
        self.assertIn("C1", [one.at.written(False) for one in held.trace])
        self.assertEqual(held.value_at("C1").written(), "43")

    def test_typing_below_everything_makes_the_formula_over_it_stale(self):
        sheet = Sheet("Main", {"A1": 3, "A2": 4, "C1": "=SUM(A:A)"})
        recalculate(sheet)
        sheet.put("A9", 100)
        held = recalculated_after(sheet, ["A9"])
        self.assertEqual(held.value_at("C1").written(), "107")

    def test_reading_a_whole_column_reads_the_filled_cells_in_it(self):
        book = written(LEDGER.replace("  D7 7\n", "  D7 7\n  F1 =SUM(B:B)\n"))
        code, text = run("links", book)
        self.assertEqual(code, 0)
        row = [line for line in text.splitlines() if line.startswith("Items!F1")]
        self.assertEqual(len(row), 1)
        self.assertEqual(row[0].split()[1], "4")
        for cell in ("B1", "B2", "B3", "B4"):
            self.assertIn(cell, row[0])

    def test_a_cell_in_the_column_it_reads_needs_itself(self):
        desk = Desk.empty()
        desk.put("A1", 1)
        desk.put("A2", 2)
        desk.put("A5", "=SUM(A:A)")
        self.assertEqual(desk.value_at("A5").written(), "#CYCLE!")

    def test_the_cycle_is_counted_and_warned_about(self):
        book = written("trestle-book 1\nsheet S\n  A1 1\n  A2 2\n  A5 =SUM(A:A)\n  B1 =SUM(A1:A2)\n")
        code, text = run("calc", book)
        self.assertEqual(code, 3)
        self.assertIn("1 cell in a cycle", text)
        self.assertEqual(run("review", book, "--only", "cycles")[0], 1)

    def test_a_cell_beside_the_column_it_reads_is_not_a_cycle(self):
        book = written("trestle-book 1\nsheet S\n  A1 1\n  A2 2\n  B5 =SUM(A:A)\n")
        self.assertEqual(run("review", book, "--only", "cycles")[0], 0)
        self.assertEqual(run("value", book, "B5"), (0, "3"))

    def test_the_spans_a_formula_names_include_whole_columns(self):
        self.assertTrue(is_span("A:C"))
        self.assertTrue(is_span("$A:$A"))
        self.assertFalse(is_address("A:C"))
        self.assertEqual(str(read_span("C:A")), "A:C")
        self.assertEqual(str(read_span("Costs!B:B")), "Costs!B:B")

    def test_what_was_typed_shows_as_it_was_typed(self):
        book = written(LEDGER.replace("  D7 7\n", "  D7 7\n  F1 =SUM(B:B)\n"))
        self.assertEqual(run("value", book, "Items!F1", "--typed"), (0, "=SUM(B:B)"))
        code, text = run("show", book, "--sheet", "Items", "--formulas")
        self.assertEqual(code, 0)
        self.assertIn("=SUM(B:B)", text)
        code, text = run("csv", book, "--sheet", "Items", "--formulas")
        self.assertEqual(code, 0)
        self.assertIn("=SUM(B:B)", text)

    def test_the_formulas_table_says_the_column_is_read(self):
        book = written(LEDGER.replace("  D7 7\n", "  D7 7\n  F1 =SUM(B:B)\n"))
        code, text = run("formulas", book, "--sheet", "Items")
        self.assertEqual(code, 0)
        row = [line for line in text.splitlines() if line.startswith("F1")]
        self.assertEqual(len(row), 1)
        self.assertIn("B:B", row[0])
        self.assertIn("39", row[0])

    def test_a_book_written_out_keeps_the_whole_column_as_typed(self):
        book = written(LEDGER.replace("  D7 7\n", "  D7 7\n  F1 =SUM(B:B)\n"))
        out = os.path.join(os.path.dirname(book), "again.book")
        code, _ = run("set", book, "Items!F2", "=COUNTA(A:A)", "--out", out)
        self.assertEqual(code, 0)
        with open(out, encoding="utf-8") as handle:
            text = handle.read()
        self.assertIn("  F1 =SUM(B:B)\n", text)
        self.assertIn("  F2 =COUNTA(A:A)\n", text)
        self.assertEqual(run("value", out, "Items!F2"), (0, "5"))


class MovingTest(_Guarded):
    """Filling moves the columns and never the rows; inserting and removing follow the rectangle."""

    def test_filling_across_moves_the_column(self):
        sheet = Sheet("Main", {"A1": 1, "A2": 2, "B1": 10, "B2": 20, "C1": 100, "D1": "=SUM(A:A)"})
        filled_across(sheet, "D1", "D1:F1")
        self.assertEqual(sheet.text_at("E1"), "=SUM(B:B)")
        self.assertEqual(sheet.text_at("F1"), "=SUM(C:C)")
        held = recalculate(sheet)
        self.assertEqual([held.value_at(one).written() for one in ("D1", "E1", "F1")],
                         ["3", "30", "100"])

    def test_filling_down_leaves_the_column_where_it_is(self):
        sheet = Sheet("Main", {"A1": 1, "A2": 2, "A3": 3, "C1": "=SUM(A:A)"})
        filled_across(sheet, "C1", "C1:C4")
        self.assertEqual([sheet.text_at("C%d" % row) for row in (2, 3, 4)], ["=SUM(A:A)"] * 3)
        held = recalculate(sheet)
        self.assertEqual([held.value_at("C%d" % row).written() for row in (1, 2, 3, 4)], ["6"] * 4)

    def test_filling_a_column_held_still_leaves_it_where_it_is(self):
        sheet = Sheet("Main", {"A1": 1, "B1": 2, "C1": "=SUM($A:$A)", "D1": "=SUM($A:B)"})
        filled_across(sheet, "C1", "C1:C2")
        filled_across(sheet, "D1", "D1:E1")
        self.assertEqual(sheet.text_at("C2"), "=SUM($A:$A)")
        self.assertEqual(sheet.text_at("E1"), "=SUM($A:C)")

    def test_filling_a_column_off_the_sheet_is_a_reference_error(self):
        sheet = Sheet("Main", {"A1": 1, "B1": "=SUM(A:A)"})
        filled_across(sheet, "B1", "A1:B1")
        self.assertEqual(sheet.text_at("A1"), "=SUM(#REF!)")

    def test_inserting_a_row_leaves_a_whole_column_as_it_was(self):
        sheet = Sheet("Main", {"A1": 1, "A2": 2, "A3": 3, "C1": "=SUM(A:A)", "C2": "=ROWS(A:A)"})
        held = inserted_rows(sheet, 1, 2)
        self.assertEqual(held.text_at("C3"), "=SUM(A:A)")
        self.assertEqual(held.text_at("C4"), "=ROWS(A:A)")
        found = recalculate(held)
        self.assertEqual(found.value_at("C3").written(), "6")
        self.assertEqual(found.value_at("C4").written(), "5")

    def test_removing_a_row_leaves_a_whole_column_as_it_was(self):
        sheet = Sheet("Main", {"A1": 1, "A2": 2, "A3": 3, "C1": "=SUM(A:A)"})
        held = removed_rows(sheet, 2)
        self.assertEqual(held.text_at("C1"), "=SUM(A:A)")
        self.assertEqual(recalculate(held).value_at("C1").written(), "4")

    def test_inserting_a_column_moves_a_whole_column_like_a_rectangle(self):
        sheet = Sheet("Main", {"A1": 1, "B1": 2, "C1": 3, "E1": "=SUM(B:B)", "E2": "=SUM(A:C)"})
        held = inserted_columns(sheet, 2)
        self.assertEqual(held.text_at("F1"), "=SUM(C:C)")
        self.assertEqual(held.text_at("F2"), "=SUM(A:D)")
        found = recalculate(held)
        self.assertEqual(found.value_at("F1").written(), "2")
        self.assertEqual(found.value_at("F2").written(), "6")

    def test_removing_a_column_moves_a_whole_column_like_a_rectangle(self):
        sheet = Sheet("Main", {"A1": 1, "B1": 2, "C1": 3, "E1": "=SUM(B:B)", "E2": "=SUM(A:C)"})
        held = removed_columns(sheet, 2)
        self.assertEqual(held.text_at("D1"), "=SUM(#REF!)")
        self.assertEqual(held.text_at("D2"), "=SUM(A:B)")
        self.assertEqual(recalculate(held).value_at("D2").written(), "4")

    def test_removing_every_column_of_a_whole_column_is_a_reference_error(self):
        sheet = Sheet("Main", {"A1": 1, "B1": 2, "C1": 3, "E1": "=SUM(A:C)"})
        held = removed_columns(sheet, 1, 3)
        self.assertEqual(held.text_at("B1"), "=SUM(#REF!)")

    def test_renaming_a_sheet_rewrites_a_whole_column_that_named_it(self):
        book = Book("Two")
        book.add(Sheet("Costs", {"B1": 4, "B2": 6}))
        book.add(Sheet("Quote", {"A1": "=SUM(Costs!B:B)"}))
        book.rename("Costs", "Prices")
        self.assertEqual(book.sheet_named("Quote").text_at("A1"), "=SUM(Prices!B:B)")
        book.recalculate()
        self.assertEqual(book.value_at("Quote!A1").written(), "10")


class CostAndPagesTest(_Guarded):
    """Only what was put in a sheet costs anything; --over; the pages and the changelog."""

    def test_forty_whole_columns_over_five_cells_cost_next_to_nothing(self):
        signal.alarm(20)
        desk = Desk.empty()
        for row in range(1, 6):
            desk.put("A%d" % row, row)
        for row in range(1, 41):
            desk.put("C%d" % row, "=SUM(A:A)+COUNTBLANK(B:B)+ROWS(A:B)")
        self.assertEqual(desk.value_at("C40").written(), "95")
        self.assertEqual(run("calc", written(write_book(desk.book)))[0], 0)

    def test_showing_over_a_whole_column_draws_it_to_the_last_filled_row(self):
        signal.alarm(20)
        code, text = run("show", "budget", "--sheet", "Income", "--over", "B:B")
        self.assertEqual(code, 0)
        lines = [line for line in text.splitlines() if line.strip()]
        self.assertEqual(len(lines), 6)
        self.assertIn("3050", text)
        self.assertNotIn("source", text)

    def test_listing_cells_over_a_whole_column_lists_that_column(self):
        signal.alarm(20)
        code, text = run("cells", "budget", "--sheet", "Spending", "--over", "B:B")
        self.assertEqual(code, 0)
        self.assertIn("6 cells", text)
        self.assertNotIn("A1", text)

    def test_the_readme_no_longer_lists_the_gap(self):
        with open(os.path.join(ROOT, "README.md"), encoding="utf-8") as handle:
            text = handle.read()
        numbered = re.findall(r"^(\d+)\. \*\*(.*)$", text, re.M)
        self.assertEqual([one for one, _ in numbered], [str(one) for one in range(1, 15)])
        self.assertFalse(any("whole-column" in rest.lower() or "whole column" in rest.lower()
                             for _, rest in numbered))

    def test_the_formulas_page_shows_a_whole_column_in_a_formula(self):
        with open(os.path.join(ROOT, "docs", "formulas.md"), encoding="utf-8") as handle:
            text = handle.read()
        self.assertTrue(re.search(r"[A-Z]+\([^)\n]*\b\$?[A-Z]{1,3}:\$?[A-Z]{1,3}\b", text))

    def test_the_changelog_records_the_feature(self):
        with open(os.path.join(ROOT, "CHANGELOG.md"), encoding="utf-8") as handle:
            text = handle.read()
        self.assertGreater(len(re.findall(r"^- ", text, re.M)), 37)


if __name__ == "__main__":
    unittest.main()
