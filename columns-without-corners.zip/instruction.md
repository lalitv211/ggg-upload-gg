Readme says no whole-column references, A:A is not a range, both corners are cells. Please take this gap away.

Whole column is written as everywhere. A:A is one column, A:C is three, dollar holds a column still, sheet name goes in front as usual, Costs!A:A. Corners either way round, same as rectangle. A cell and a column mixed is refused like any formula that won't read.

What it stands for is the column from row one down to the last row anything is typed in on that sheet. So every function gives over A:A exactly what it gives over that rectangle, ROWS, COUNTBLANK and INDEX included. Where one value belongs it is #VALUE!, formulas page promises that. From there on it is a rectangle like any other, wherever the package reads one, moves one, draws one or writes one back, and the same rules hold. It has columns to move and no rows. Only what was put in a sheet costs anything, whole column keeps to that.

Model page says changing one cell marks it and what reads it and only those are worked out again. Desk doesn't keep that, every change works the whole book out again, trace shows all six cells of budget for one number. Please make desk keep the promise, on every sheet, cycles made or broken included, emptying a cell is a change as well. Where a column stops is part of what a formula over it reads. Trace should hold exactly the cells worked out, answers same as working everything out, fresh book still works everything out.

Formulas page should say what it is, with an example. Readme list is fourteen now, two tests there say otherwise. Please prove the traces in tests, changelog entry as usual, version can stay.
