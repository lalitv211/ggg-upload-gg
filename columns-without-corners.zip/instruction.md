Readme says we have no whole-column references, A:A is not a range, both corners of a rectangle are cells. People paste sheets from elsewhere and first thing that breaks is SUM(B:B). Please take this gap away.

Whole column is written like everywhere else. A:A is one column, A:C is three, dollar holds a column still, sheet name goes in front as usual, Costs!A:A. Corners either way round, same as rectangle. A cell and a column mixed is not a reference, refuse it like any formula that won't read.

What it stands for is the column from row one down to the last row anything is typed in on that sheet. So every function gives over A:A exactly what it gives over that rectangle, ROWS, COUNTBLANK and INDEX included. Where one value belongs it is #VALUE!, comparing included, formulas page promises that. From there on it is a rectangle like any other, wherever the package reads one, moves one, draws one or writes one back, and the same rules hold. It has columns to move and no rows. Only what was put in a sheet costs anything, performance page says so, whole column keeps to that.

Formulas page should say what it is, with an example. Readme list is fourteen now, two tests there say otherwise. Please add tests and changelog entry as usual, version can stay.
