import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

type Rows = Array<Record<string, unknown>>;
const table = { rows: [] as Rows, error: null as unknown };
const invoke = vi.fn();
const post = vi.fn();

const CHAIN = ['select', 'eq', 'neq', 'in', 'is', 'order', 'limit', 'range', 'filter', 'match', 'gte', 'lte', 'gt', 'lt', 'like', 'ilike', 'or', 'not', 'contains', 'overlaps'];
function builder() {
  const b: Record<string, unknown> = {};
  for (const m of CHAIN) b[m] = vi.fn(() => b);
  b.maybeSingle = vi.fn(async () => ({ data: table.rows[0] ?? null, error: table.error }));
  b.single = vi.fn(async () => ({ data: table.rows[0] ?? null, error: table.error ?? (table.rows[0] ? null : { message: 'no rows' }) }));
  b.then = (res: (v: unknown) => unknown, rej?: (e: unknown) => unknown) =>
    Promise.resolve({ data: table.rows, error: table.error, count: table.rows.length }).then(res, rej);
  return b;
}

vi.mock('@/lib/supabaseClient', () => ({
  supabase: {
    functions: { invoke: (...args: unknown[]) => invoke(...args) },
    from: () => builder(),
    auth: { getSession: async () => ({ data: { session: null } }) },
  },
}));
vi.mock('@/services/api/httpClient', () => ({
  httpClient: { post: (...args: unknown[]) => post(...args), get: vi.fn(), patch: vi.fn(), put: vi.fn(), delete: vi.fn() },
  HttpClient: class {},
  default: class {},
}));

async function service() {
  return import('@/services/supabase/appointmentNotificationService');
}

beforeEach(() => {
  vi.spyOn(console, 'log').mockImplementation(() => {});
  vi.spyOn(console, 'error').mockImplementation(() => {});
  invoke.mockReset();
  post.mockReset();
  post.mockResolvedValue({ success: true, message: 'Confirmation email sent', booking_reference: 'BR-1' });
  table.rows = [];
  table.error = null;
});

afterEach(() => {
  vi.restoreAllMocks();
});

describe('the public surface of the notification service', () => {
  it('exports the seven functions', async () => {
    const svc = await service();
    for (const name of ['sendAppointmentConfirmation', 'getAppointmentNotifications', 'hasConfirmationBeenSent', 'sendAppointmentSMS', 'hasSMSBeenSent', 'sendVetRequestNotification', 'sendAppointmentConfirmations']) {
      expect(typeof (svc as Record<string, unknown>)[name]).toBe('function');
    }
  });
});

describe('the confirmation email goes through the backend API', () => {
  it('posts the appointment id to send-confirmation-email', async () => {
    const { sendAppointmentConfirmation } = await service();
    const result = await sendAppointmentConfirmation('apt-1');
    expect(result.success).toBe(true);
    expect(result.booking_reference).toBe('BR-1');
    expect(post).toHaveBeenCalledTimes(1);
    const [path, body] = post.mock.calls[0] as [string, Record<string, unknown>];
    expect(path).toContain('/appointments/send-confirmation-email');
    expect(body).toMatchObject({ appointment_id: 'apt-1' });
  });

  it('returns the backend answer as it is', async () => {
    post.mockResolvedValue({ success: false, message: 'Not sent', error: 'Client has no email address' });
    const { sendAppointmentConfirmation } = await service();
    const result = await sendAppointmentConfirmation('apt-1');
    expect(result.success).toBe(false);
    expect(result.error).toBe('Client has no email address');
  });

  it('a thrown backend error becomes a failed result with its message', async () => {
    post.mockRejectedValue({ message: 'HTTP 503: Service Unavailable', code: 'HTTP_503' });
    const { sendAppointmentConfirmation } = await service();
    const result = await sendAppointmentConfirmation('apt-1');
    expect(result.success).toBe(false);
    expect(result.message).toBe('Failed to send confirmation email');
    expect(result.error).toContain('HTTP 503');
  });

  it('a thrown Error becomes a failed result with its message', async () => {
    post.mockRejectedValue(new Error('Unable to connect to server'));
    const { sendAppointmentConfirmation } = await service();
    const result = await sendAppointmentConfirmation('apt-1');
    expect(result.success).toBe(false);
    expect(result.error).toContain('Unable to connect to server');
  });
});

describe('what the status checks and the combined send already do', () => {
  it('hasSMSBeenSent is false when no row exists', async () => {
    const { hasSMSBeenSent } = await service();
    expect(await hasSMSBeenSent('apt-1')).toBe(false);
  });

  it('hasConfirmationBeenSent is false when no row exists', async () => {
    const { hasConfirmationBeenSent } = await service();
    expect(await hasConfirmationBeenSent('apt-1')).toBe(false);
  });

  it('sendAppointmentConfirmations returns an email result and an sms result', async () => {
    invoke.mockResolvedValue({ data: { success: true, message: 'SMS sent' }, error: null });
    const { sendAppointmentConfirmations } = await service();
    const result = await sendAppointmentConfirmations('apt-1');
    expect(typeof result.email.success).toBe('boolean');
    expect(typeof result.sms.success).toBe('boolean');
    expect(typeof result.email.message).toBe('string');
    expect(typeof result.sms.message).toBe('string');
  });

  it('a failed SMS send is a result, never a throw', async () => {
    invoke.mockRejectedValue(new Error('boom'));
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(false);
    expect(typeof result.message).toBe('string');
  });

  it('a failed vet notification is a result, never a throw', async () => {
    invoke.mockRejectedValue(new Error('boom'));
    const { sendVetRequestNotification } = await service();
    const result = await sendVetRequestNotification('apt-2');
    expect(result.success).toBe(false);
    expect(typeof result.message).toBe('string');
  });
});
