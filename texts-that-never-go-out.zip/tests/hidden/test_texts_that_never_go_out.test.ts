import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { FunctionsFetchError, FunctionsHttpError, FunctionsRelayError } from '@supabase/supabase-js';

type Rows = Array<Record<string, unknown>>;
const table = { rows: [] as Rows, error: null as unknown };
const invoke = vi.fn();
const from = vi.fn();
const sendEmail = vi.fn();
// captured before any fake timers: a real turn of the event loop, so node can report an unhandled rejection
const realSetImmediate = setImmediate;
const eventLoopTurn = () => new Promise<void>((resolve) => realSetImmediate(() => resolve()));

const CHAIN = ['select', 'eq', 'neq', 'in', 'is', 'order', 'limit', 'range', 'filter', 'match', 'gte', 'lte', 'gt', 'lt', 'like', 'ilike', 'or', 'not', 'contains', 'overlaps'];
function builder() {
  const b: Record<string, unknown> = {};
  for (const m of CHAIN) b[m] = vi.fn(() => b);
  b.maybeSingle = vi.fn(async () => ({ data: table.rows[0] ?? null, error: table.error }));
  b.single = vi.fn(async () => ({ data: table.rows[0] ?? null, error: table.error ?? (table.rows[0] ? null : { message: 'no rows' }) }));
  b.then = (res: (v: unknown) => unknown, rej?: (e: unknown) => unknown) =>
    Promise.resolve({ data: table.rows, error: table.error, count: table.rows.length }).then(res, rej);
  return b;
}

vi.mock('@/lib/supabaseClient', () => ({
  supabase: {
    functions: { invoke: (...args: unknown[]) => invoke(...args) },
    from: (...args: unknown[]) => { from(...args); return builder(); },
    auth: { getSession: async () => ({ data: { session: null } }) },
  },
}));
vi.mock('@/features/appointments/api/backendAppointmentNotificationService', () => ({
  sendBackendAppointmentConfirmation: (...args: unknown[]) => sendEmail(...args),
}));
vi.mock('@/services/api/httpClient', () => ({
  httpClient: { post: (...args: unknown[]) => sendEmail(...args), get: vi.fn(), patch: vi.fn(), put: vi.fn(), delete: vi.fn() },
  HttpClient: class {},
  default: class {},
}));

const jsonResponse = (body: unknown, status: number) =>
  new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const textResponse = (body: string, status: number) =>
  new Response(body, { status, headers: { 'content-type': 'text/plain' } });
const refusal = (response: Response) => ({ data: null, error: new FunctionsHttpError(response) });
const answer = (data: unknown) => ({ data, error: null });

async function service() {
  return import('@/services/supabase/appointmentNotificationService');
}

beforeEach(() => {
  vi.spyOn(console, 'log').mockImplementation(() => {});
  vi.spyOn(console, 'error').mockImplementation(() => {});
  vi.spyOn(console, 'warn').mockImplementation(() => {});
  invoke.mockReset();
  from.mockReset();
  sendEmail.mockReset();
  sendEmail.mockResolvedValue({ success: true, message: 'Confirmation email sent' });
  table.rows = [];
  table.error = null;
});

afterEach(() => {
  vi.useRealTimers();
  vi.restoreAllMocks();
});

describe('the SMS send reaches the edge function', () => {
  it('invokes send-appointment-sms with the appointment id', async () => {
    invoke.mockResolvedValue(answer({ success: true, message: 'SMS sent' }));
    const { sendAppointmentSMS } = await service();
    await sendAppointmentSMS('apt-1');
    expect(invoke).toHaveBeenCalledTimes(1);
    expect(invoke).toHaveBeenCalledWith('send-appointment-sms', expect.objectContaining({ body: expect.objectContaining({ appointment_id: 'apt-1' }) }));
  });

  it('returns the function answer as it is, phone number included', async () => {
    invoke.mockResolvedValue(answer({ success: true, message: 'SMS sent', sent_to: '+15550100', twilio_sid: 'SM1', booking_reference: 'BR-7' }));
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(true);
    expect(result.sent_to).toBe('+15550100');
    expect(result.twilio_sid).toBe('SM1');
    expect(result.booking_reference).toBe('BR-7');
  });

  it('an answer without a success field still counts as sent', async () => {
    invoke.mockResolvedValue(answer({ booking_reference: 'BR-8' }));
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(true);
    expect(result.booking_reference).toBe('BR-8');
  });

  it('the vet request notification invokes notify-vet-new-request', async () => {
    invoke.mockResolvedValue(answer({ success: true, message: 'Vet notified' }));
    const { sendVetRequestNotification } = await service();
    const result = await sendVetRequestNotification('apt-2');
    expect(result.success).toBe(true);
    expect(invoke).toHaveBeenCalledWith('notify-vet-new-request', expect.objectContaining({ body: expect.objectContaining({ appointment_id: 'apt-2' }) }));
  });

  it('a function answer that says it failed is returned as a failure', async () => {
    invoke.mockResolvedValue(answer({ success: false, message: 'Not sent', error: 'Twilio rejected the number' }));
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(false);
    expect(result.error).toContain('Twilio rejected the number');
  });
});

describe('a refusal carries the reason the function gave', () => {
  it('a json error body on a 400', async () => {
    invoke.mockResolvedValue(refusal(jsonResponse({ error: 'Pet owner phone number not found' }, 400)));
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(false);
    expect(result.error).toContain('Pet owner phone number not found');
  });

  it('a json message body on a 422', async () => {
    invoke.mockResolvedValue(refusal(jsonResponse({ message: 'Appointment must be in scheduled status' }, 422)));
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(false);
    expect(result.error).toContain('Appointment must be in scheduled status');
  });

  it('a plain text body on a 500', async () => {
    invoke.mockResolvedValue(refusal(textResponse('SMS service not configured', 500)));
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(false);
    expect(result.error).toContain('SMS service not configured');
  });

  it('an empty body still reports a failure with some error text', async () => {
    invoke.mockResolvedValue(refusal(new Response(null, { status: 502 })));
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(false);
    expect(typeof result.error).toBe('string');
    expect((result.error as string).trim().length).toBeGreaterThan(0);
    expect(result.error).not.toContain('not defined');
  });

  it('a validation body with a message list names the listed reason', async () => {
    invoke.mockResolvedValue(refusal(jsonResponse({ statusCode: 400, message: ['Pet owner phone number not found'] }, 400)));
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(false);
    expect(result.error).toContain('Pet owner phone number not found');
  });

  it('two listed reasons both reach the caller', async () => {
    invoke.mockResolvedValue(refusal(jsonResponse({ statusCode: 400, message: ['Pet owner phone number not found', 'Appointment must be in scheduled status'] }, 400)));
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(false);
    expect(result.error).toContain('Pet owner phone number not found');
    expect(result.error).toContain('Appointment must be in scheduled status');
  });

  it('the vet notification reads a message list the same way', async () => {
    invoke.mockResolvedValue(refusal(jsonResponse({ statusCode: 400, message: ['Assigned vet has no phone number'] }, 400)));
    const { sendVetRequestNotification } = await service();
    const result = await sendVetRequestNotification('apt-2');
    expect(result.success).toBe(false);
    expect(result.error).toContain('Assigned vet has no phone number');
  });

  it('the vet request notification carries the reason too', async () => {
    invoke.mockResolvedValue(refusal(jsonResponse({ error: 'Assigned vet has no phone number' }, 400)));
    const { sendVetRequestNotification } = await service();
    const result = await sendVetRequestNotification('apt-2');
    expect(result.success).toBe(false);
    expect(result.error).toContain('Assigned vet has no phone number');
  });

  it('a relay error is a failure with its message', async () => {
    invoke.mockResolvedValue({ data: null, error: new FunctionsRelayError(new Response(null, { status: 546 })) });
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(false);
    expect((result.error as string).length).toBeGreaterThan(0);
    expect(result.error).not.toContain('not defined');
  });

  it('a fetch failure is a failure with its message', async () => {
    invoke.mockResolvedValue({ data: null, error: new FunctionsFetchError(new TypeError('Failed to fetch')) });
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(false);
    expect((result.error as string).length).toBeGreaterThan(0);
    expect(result.error).not.toContain('not defined');
  });
});

describe('the ten second timeout', () => {
  it('a function that never answers times out as a failure', async () => {
    vi.useFakeTimers();
    invoke.mockReturnValue(new Promise(() => {}));
    const { sendAppointmentSMS } = await service();
    const pending = sendAppointmentSMS('apt-1');
    await vi.advanceTimersByTimeAsync(10_000);
    const result = await pending;
    expect(result.success).toBe(false);
    expect(result.error).toContain('SMS send timeout');
  });

  it('the vet notification that never answers times out as a failure', async () => {
    vi.useFakeTimers();
    invoke.mockReturnValue(new Promise(() => {}));
    const { sendVetRequestNotification } = await service();
    const pending = sendVetRequestNotification('apt-2');
    await vi.advanceTimersByTimeAsync(10_000);
    const result = await pending;
    expect(result.success).toBe(false);
    expect(result.error).toMatch(/timeout/i);
  });

  it('a quick answer leaves no timer armed', async () => {
    vi.useFakeTimers();
    invoke.mockResolvedValue(answer({ success: true, message: 'SMS sent' }));
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(true);
    expect(vi.getTimerCount()).toBe(0);
  });

  it('a quick refusal leaves no timer armed', async () => {
    vi.useFakeTimers();
    invoke.mockResolvedValue(refusal(jsonResponse({ error: 'Pet owner phone number not found' }, 400)));
    const { sendAppointmentSMS } = await service();
    const result = await sendAppointmentSMS('apt-1');
    expect(result.success).toBe(false);
    expect(vi.getTimerCount()).toBe(0);
  });

  it('the vet notification leaves no timer armed after a quick answer', async () => {
    vi.useFakeTimers();
    invoke.mockResolvedValue(answer({ success: true, message: 'Vet notified' }));
    const { sendVetRequestNotification } = await service();
    await sendVetRequestNotification('apt-2');
    expect(vi.getTimerCount()).toBe(0);
  });

  it('nothing rejects after a quick answer once ten seconds pass', async () => {
    vi.useFakeTimers();
    const unhandled = vi.fn();
    process.on('unhandledRejection', unhandled);
    try {
      invoke.mockResolvedValue(answer({ success: true, message: 'SMS sent' }));
      const { sendAppointmentSMS } = await service();
      await sendAppointmentSMS('apt-1');
      await vi.advanceTimersByTimeAsync(11_000);
      await eventLoopTurn();
      await eventLoopTurn();
      expect(unhandled).not.toHaveBeenCalled();
    } finally {
      process.off('unhandledRejection', unhandled);
    }
  });
});

describe('status checks and history read the notifications table', () => {
  it('hasSMSBeenSent is true when a sent SMS row exists', async () => {
    table.rows = [{ id: 'n1' }];
    const { hasSMSBeenSent } = await service();
    expect(await hasSMSBeenSent('apt-1')).toBe(true);
    expect(from).toHaveBeenCalledWith('appointment_notifications');
  });

  it('hasConfirmationBeenSent is true when a sent email row exists', async () => {
    table.rows = [{ id: 'n2' }];
    const { hasConfirmationBeenSent } = await service();
    expect(await hasConfirmationBeenSent('apt-1')).toBe(true);
    expect(from).toHaveBeenCalledWith('appointment_notifications');
  });

  it('getAppointmentNotifications returns the rows', async () => {
    table.rows = [{ id: 'n3', notification_type: 'confirmation_sms' }, { id: 'n1', notification_type: 'confirmation_email' }];
    const { getAppointmentNotifications } = await service();
    const rows = await getAppointmentNotifications('apt-1');
    expect(rows).toEqual(table.rows);
    expect(from).toHaveBeenCalledWith('appointment_notifications');
  });

  it('getAppointmentNotifications rejects with the query error', async () => {
    table.error = { message: 'permission denied for table appointment_notifications' };
    const { getAppointmentNotifications } = await service();
    await expect(getAppointmentNotifications('apt-1')).rejects.toMatchObject({ message: expect.stringContaining('permission denied') });
  });
});

describe('both confirmations at once', () => {
  it('a refused SMS does not hide a sent email', async () => {
    invoke.mockResolvedValue(refusal(jsonResponse({ error: 'Pet owner phone number not found' }, 400)));
    const { sendAppointmentConfirmations } = await service();
    const result = await sendAppointmentConfirmations('apt-1');
    expect(result.email.success).toBe(true);
    expect(result.sms.success).toBe(false);
    expect(result.sms.error).toContain('Pet owner phone number not found');
  });

  it('a sent SMS does not hide a failed email', async () => {
    invoke.mockResolvedValue(answer({ success: true, message: 'SMS sent', sent_to: '+15550100' }));
    sendEmail.mockRejectedValue({ message: 'HTTP 500: Internal Server Error', code: 'HTTP_500' });
    const { sendAppointmentConfirmations } = await service();
    const result = await sendAppointmentConfirmations('apt-1');
    expect(result.sms.success).toBe(true);
    expect(result.sms.sent_to).toBe('+15550100');
    expect(result.email.success).toBe(false);
  });

  it('both sent come back as two successes', async () => {
    invoke.mockResolvedValue(answer({ success: true, message: 'SMS sent' }));
    const { sendAppointmentConfirmations } = await service();
    const result = await sendAppointmentConfirmations('apt-1');
    expect(result.email.success).toBe(true);
    expect(result.sms.success).toBe(true);
  });
});

describe('the hooks live where the guide says', () => {
  it('the hook module exports the hooks the guide names', async () => {
    const hooks = await import('@/features/appointments/hooks/useAppointmentNotifications');
    expect(typeof hooks.useSendAppointmentSMS).toBe('function');
    expect(typeof hooks.useSendAppointmentConfirmations).toBe('function');
    expect(typeof hooks.useSMSStatus).toBe('function');
  });

  it('the hook module exports the email and vet hooks too', async () => {
    const hooks = await import('@/features/appointments/hooks/useAppointmentNotifications');
    expect(typeof hooks.useSendAppointmentConfirmation).toBe('function');
    expect(typeof hooks.useConfirmationStatus).toBe('function');
    expect(typeof hooks.useAppointmentNotifications).toBe('function');
    expect(typeof hooks.useSendVetRequestNotification).toBe('function');
  });

  it('the SMS button module loads', async () => {
    const mod = await import('@/components/appointments/AppointmentSMSButton');
    expect(typeof mod.AppointmentSMSButton).toBe('function');
  });

  it('the email confirmation button module loads again', async () => {
    const mod = await import('@/deprecated/components/appointments/AppointmentConfirmationButton');
    expect(typeof mod.AppointmentConfirmationButton).toBe('function');
  });

  it('the notification buttons module loads', async () => {
    const mod = await import('@/components/appointments/AppointmentNotificationButtons');
    expect(typeof mod.AppointmentNotificationButtons).toBe('function');
  });
});
