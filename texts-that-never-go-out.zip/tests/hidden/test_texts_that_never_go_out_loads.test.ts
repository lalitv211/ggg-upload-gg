import { describe, expect, it, vi } from 'vitest';

vi.mock('@/lib/supabaseClient', () => ({ supabase: { functions: { invoke: vi.fn() }, from: vi.fn(), auth: { getSession: async () => ({ data: { session: null } }) } } }));

describe('the modules the change touches still load', () => {
  it('the notification service loads with its functions', async () => {
    const svc = await import('@/services/supabase/appointmentNotificationService');
    expect(typeof svc.sendAppointmentSMS).toBe('function');
    expect(typeof svc.sendAppointmentConfirmations).toBe('function');
  });

  it('the backend confirmation service loads', async () => {
    const mod = await import('@/features/appointments/api/backendAppointmentNotificationService');
    expect(typeof mod.sendBackendAppointmentConfirmation).toBe('function');
  });

  it('the error helper loads', async () => {
    const mod = await import('@/utils/errorHandler');
    expect(typeof mod.extractErrorMessage).toBe('function');
  });

  it('the supabase client module is importable by name', async () => {
    const mod = await import('@/lib/supabaseClient');
    expect(mod.supabase).toBeTruthy();
  });
});
