import { describe, expect, it } from 'vitest';
import { formatBreedForDisplay } from '@/lib/formatBreed';
import { formatDate, formatDateTime, formatTime } from '@/lib/utils';
import { formatCurrency } from '@/services/stripe/paymentService';
import {
  formatAppointmentTime,
  formatTimeSlot,
  formatWeekRange,
  generateTimeSlots,
  isSameDay,
} from '@/utils/calendarUtils';
import { formatDoctorName } from '@/components/calendar/utils/doctorNameFormatter';
import {
  formatName,
  getFirstName,
  getFullName,
  getInitials,
  getLastName,
  parseFullName,
} from '@/deprecated/utils/nameHelpers';

describe('formatBreedForDisplay', () => {
  it('returns empty string for null, undefined, and empty values', () => {
    expect(formatBreedForDisplay(null)).toBe('');
    expect(formatBreedForDisplay(undefined)).toBe('');
    expect(formatBreedForDisplay('')).toBe('');
  });

  it('joins native string arrays with a slash separator', () => {
    expect(formatBreedForDisplay(['Labrador', 'Poodle'])).toBe('Labrador / Poodle');
  });

  it('parses a JSON array string stored in the database', () => {
    expect(formatBreedForDisplay('["Beagle","Mix"]')).toBe('Beagle / Mix');
  });

  it('returns a legacy single breed string unchanged', () => {
    expect(formatBreedForDisplay('Domestic Shorthair')).toBe('Domestic Shorthair');
  });
});

describe('calendar time helpers', () => {
  it('formats midnight and noon in 12-hour labels', () => {
    expect(formatTimeSlot(0, 0)).toEqual({ time: '00:00', label: '12:00 AM' });
    expect(formatTimeSlot(12, 0)).toEqual({ time: '12:00', label: '12:00 PM' });
  });

  it('formats afternoon hours with a PM label', () => {
    expect(formatTimeSlot(14, 15)).toEqual({ time: '14:15', label: '2:15 PM' });
  });

  it('pads single-digit hours in the 24-hour time string', () => {
    expect(formatTimeSlot(9, 5).time).toBe('09:05');
  });

  it('generates 15-minute slots and stops at the end hour', () => {
    const slots = generateTimeSlots(8, 9);
    expect(slots.map((s) => s.time)).toEqual(['08:00', '08:15', '08:30', '08:45', '09:00']);
  });

  it('treats two Date objects on the same calendar day as the same day', () => {
    const morning = new Date(2024, 5, 3, 8, 0);
    const evening = new Date(2024, 5, 3, 21, 45);
    expect(isSameDay(morning, evening)).toBe(true);
  });

  it('treats dates on different calendar days as not the same day', () => {
    expect(isSameDay(new Date(2024, 5, 3), new Date(2024, 5, 4))).toBe(false);
  });

  it('formats a seven-day week range using the first and seventh entries', () => {
    const days = Array.from({ length: 7 }, (_, i) => new Date(2024, 0, 7 + i));
    expect(formatWeekRange(days)).toBe('Jan 7 - Jan 13, 2024');
  });

  it('returns an empty week range when given no days', () => {
    expect(formatWeekRange([])).toBe('');
  });

  it('formats appointment time as 24-hour HH:mm from a local Date', () => {
    expect(formatAppointmentTime(new Date(2024, 0, 15, 14, 5))).toBe('14:05');
  });
});

describe('formatDoctorName', () => {
  it('returns Unknown Doctor for an empty name', () => {
    expect(formatDoctorName('')).toBe('Unknown Doctor');
  });

  it('title-cases a simple name and prefixes Dr.', () => {
    expect(formatDoctorName('jane smith')).toBe('Dr. Jane Smith');
  });

  it('preserves apostrophes in names like O\'Brien', () => {
    expect(formatDoctorName("o'brien")).toBe("Dr. O'Brien");
  });
});

describe('name helpers', () => {
  it('prefers first and last name over full_name', () => {
    expect(getFullName({ first_name: 'Ada', last_name: 'Lovelace', full_name: 'Ignored' })).toBe(
      'Ada Lovelace'
    );
  });

  it('falls back to full_name when first and last are missing', () => {
    expect(getFullName({ full_name: '  Grace Hopper  ' })).toBe('Grace Hopper');
  });

  it('returns the fallback when the user is missing', () => {
    expect(getFullName(null, 'Guest')).toBe('Guest');
  });

  it('extracts first and last names from a full_name', () => {
    const user = { full_name: 'Marie Curie Skłodowska' };
    expect(getFirstName(user)).toBe('Marie');
    expect(getLastName(user)).toBe('Curie Skłodowska');
  });

  it('returns initials from first and last name', () => {
    expect(getInitials({ first_name: 'john', last_name: 'doe' })).toBe('JD');
  });

  it('returns lastFirst format and optional title', () => {
    expect(formatName({ first_name: 'Ada', last_name: 'Lovelace' }, { format: 'lastFirst' })).toBe(
      'Lovelace, Ada'
    );
    expect(
      formatName({ first_name: 'Ada', last_name: 'Lovelace' }, { includeTitle: true, title: 'Dr.' })
    ).toBe('Dr. Ada Lovelace');
  });

  it('parses a full name into first and remaining last parts', () => {
    expect(parseFullName('Jean Luc Picard')).toEqual({
      first_name: 'Jean',
      last_name: 'Luc Picard',
    });
  });

  it('parses a single-token name as first name only', () => {
    expect(parseFullName('Madonna')).toEqual({ first_name: 'Madonna', last_name: '' });
  });

  it('parses a blank name as empty parts', () => {
    expect(parseFullName('   ')).toEqual({ first_name: '', last_name: '' });
  });
});

describe('date formatting with local Date objects', () => {
  const noon = new Date(2024, 0, 15, 12, 0, 0);

  it('formats a short en-US date', () => {
    expect(formatDate(noon)).toBe('Jan 15, 2024');
  });

  it('formats a numeric date style', () => {
    expect(formatDate(noon, { style: 'numeric' })).toBe('01/15/2024');
  });

  it('formats a long date style', () => {
    expect(formatDate(noon, { style: 'long' })).toBe('January 15, 2024');
  });

  it('returns the fallback for null and invalid dates', () => {
    expect(formatDate(null)).toBe('N/A');
    expect(formatDate('not-a-date', { fallback: 'missing' })).toBe('missing');
  });

  it('returns display and tooltip when withTooltip is set', () => {
    const result = formatDate(noon, { withTooltip: true });
    expect(result).toEqual({
      display: 'Jan 15, 2024',
      tooltip: 'Monday, January 15, 2024',
    });
  });

  it('formats time in 12-hour en-US from a local Date', () => {
    expect(formatTime(new Date(2024, 0, 15, 10, 30)).replace(/\s/g, ' ')).toBe('10:30 AM');
  });

  it('returns the time fallback for null input', () => {
    expect(formatTime(null, 'none')).toBe('none');
  });

  it('formats date and time together for a local Date', () => {
    const text = formatDateTime(new Date(2024, 0, 15, 10, 30, 0));
    expect(text).toContain('2024');
    expect(text.replace(/\s/g, ' ')).toContain('10:30');
  });
});

describe('formatCurrency', () => {
  it('formats USD with a dollar sign and two fraction digits', () => {
    expect(formatCurrency(12)).toBe('$12.00');
    expect(formatCurrency(1234.5)).toBe('$1,234.50');
  });

  it('formats zero dollars', () => {
    expect(formatCurrency(0)).toBe('$0.00');
  });
});
