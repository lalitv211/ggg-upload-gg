import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

type Rows = Array<Record<string, unknown>>;
const table = { rows: [] as Rows, error: null as unknown };
const invoke = vi.fn();
const toastCalls: Array<{ kind: string; text: unknown }> = [];

const CHAIN = ['select', 'eq', 'neq', 'in', 'is', 'order', 'limit', 'range', 'filter', 'match', 'gte', 'lte', 'gt', 'lt', 'like', 'ilike', 'or', 'not', 'contains', 'overlaps'];
function builder() {
  const b: Record<string, unknown> = {};
  for (const m of CHAIN) b[m] = vi.fn(() => b);
  b.maybeSingle = vi.fn(async () => ({ data: table.rows[0] ?? null, error: table.error }));
  b.single = vi.fn(async () => ({ data: table.rows[0] ?? null, error: table.error ?? (table.rows[0] ? null : { message: 'no rows' }) }));
  b.then = (res: (v: unknown) => unknown, rej?: (e: unknown) => unknown) =>
    Promise.resolve({ data: table.rows, error: table.error, count: table.rows.length }).then(res, rej);
  return b;
}

vi.mock('@/lib/supabaseClient', () => ({
  supabase: {
    functions: { invoke: (...args: unknown[]) => invoke(...args) },
    from: () => builder(),
    auth: { getSession: async () => ({ data: { session: null } }) },
  },
}));
vi.mock('@/features/appointments/api/backendAppointmentNotificationService', () => ({
  sendBackendAppointmentConfirmation: async () => ({ success: true, message: 'Confirmation email sent' }),
}));
vi.mock('@/services/api/httpClient', () => ({
  httpClient: { post: async () => ({ success: true, message: 'Confirmation email sent' }), get: vi.fn(), patch: vi.fn(), put: vi.fn(), delete: vi.fn() },
  HttpClient: class {},
  default: class {},
}));
// React Query hooks are handed their option objects back, so the hook functions can be driven without React
vi.mock('@tanstack/react-query', () => ({
  useMutation: (options: Record<string, unknown>) => ({ ...options, mutateAsync: options.mutationFn, mutate: options.mutationFn, isPending: false }),
  useQuery: (options: Record<string, unknown>) => ({ ...options, data: undefined, isLoading: false }),
  useQueryClient: () => ({ invalidateQueries: vi.fn() }),
  QueryClient: class {},
}));
const toastMock = () => {
  const t = ((text: unknown) => toastCalls.push({ kind: 'plain', text })) as unknown as Record<string, unknown>;
  for (const kind of ['success', 'error', 'warning', 'info', 'loading', 'message', 'custom', 'promise', 'dismiss']) {
    t[kind] = (text: unknown) => toastCalls.push({ kind, text });
  }
  return t;
};
vi.mock('sonner', () => ({ toast: toastMock(), Toaster: () => null, useSonner: () => ({ toasts: [] }) }));
vi.mock('react-hot-toast', () => ({ default: toastMock(), toast: toastMock(), Toaster: () => null }));

async function hooks() {
  return import('@/features/appointments/hooks/useAppointmentNotifications');
}

beforeEach(() => {
  vi.spyOn(console, 'log').mockImplementation(() => {});
  vi.spyOn(console, 'error').mockImplementation(() => {});
  invoke.mockReset();
  toastCalls.length = 0;
  table.rows = [];
  table.error = null;
});

afterEach(() => {
  vi.restoreAllMocks();
});

describe('the hooks drive the service', () => {
  it('useSendAppointmentSMS sends through the edge function', async () => {
    invoke.mockResolvedValue({ data: { success: true, message: 'SMS sent' }, error: null });
    const { useSendAppointmentSMS } = await hooks();
    const mutation = useSendAppointmentSMS() as unknown as { mutationFn: (id: string) => Promise<{ success: boolean }> };
    const result = await mutation.mutationFn('apt-1');
    expect(result.success).toBe(true);
    expect(invoke).toHaveBeenCalledWith('send-appointment-sms', expect.objectContaining({ body: expect.objectContaining({ appointment_id: 'apt-1' }) }));
  });

  it('useSendAppointmentConfirmations sends both', async () => {
    invoke.mockResolvedValue({ data: { success: true, message: 'SMS sent' }, error: null });
    const { useSendAppointmentConfirmations } = await hooks();
    const mutation = useSendAppointmentConfirmations() as unknown as { mutationFn: (id: string) => Promise<{ email: { success: boolean }; sms: { success: boolean } }> };
    const result = await mutation.mutationFn('apt-1');
    expect(result.email.success).toBe(true);
    expect(result.sms.success).toBe(true);
  });

  it('useSMSStatus reads the sent row', async () => {
    table.rows = [{ id: 'n1' }];
    const { useSMSStatus } = await hooks();
    const query = useSMSStatus('apt-1') as unknown as { queryFn: () => Promise<boolean>; enabled?: boolean };
    expect(await query.queryFn()).toBe(true);
    expect(query.enabled).not.toBe(false);
  });

  it('useSMSStatus does not run without an appointment id', async () => {
    const { useSMSStatus } = await hooks();
    const query = useSMSStatus('') as unknown as { enabled?: boolean };
    expect(query.enabled).toBe(false);
  });
});
